/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 *  java.lang.Throwable
 */
package io.opencensus.common;

public final class ServerStatsDeserializationException
extends Exception {
    private static final long serialVersionUID;

    public ServerStatsDeserializationException(String string2) {
        super(string2);
    }

    public ServerStatsDeserializationException(String string2, Throwable throwable) {
        super(string2, throwable);
    }
}

