/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.TreeMap
 *  javax.annotation.Nullable
 */
package io.opencensus.common;

import java.util.TreeMap;
import javax.annotation.Nullable;

public final class ServerStatsFieldEnums {
    private static final int TOTALSIZE = ServerStatsFieldEnums.computeTotalSize();

    private ServerStatsFieldEnums() {
    }

    private static int computeTotalSize() {
        Size[] arrsize = Size.values();
        int n = arrsize.length;
        int n2 = 0;
        for (int i = 0; i < n; ++i) {
            n2 = 1 + (n2 + arrsize[i].value());
        }
        return n2;
    }

    public static int getTotalSize() {
        return TOTALSIZE;
    }

    public static final class Id
    extends Enum<Id> {
        private static final /* synthetic */ Id[] $VALUES;
        public static final /* enum */ Id SERVER_STATS_LB_LATENCY_ID;
        public static final /* enum */ Id SERVER_STATS_SERVICE_LATENCY_ID;
        public static final /* enum */ Id SERVER_STATS_TRACE_OPTION_ID;
        private static final TreeMap<Integer, Id> map;
        private final int value;

        static {
            Id id2;
            SERVER_STATS_LB_LATENCY_ID = new Id(0);
            SERVER_STATS_SERVICE_LATENCY_ID = new Id(1);
            SERVER_STATS_TRACE_OPTION_ID = id2 = new Id(2);
            Id[] arrid = new Id[]{SERVER_STATS_LB_LATENCY_ID, SERVER_STATS_SERVICE_LATENCY_ID, id2};
            $VALUES = arrid;
            map = new TreeMap();
            for (Id id3 : Id.values()) {
                map.put((Object)id3.value, (Object)id3);
            }
        }

        private Id(int n2) {
            this.value = n2;
        }

        @Nullable
        public static Id valueOf(int n) {
            return (Id)((Object)map.get((Object)n));
        }

        public static Id valueOf(String string2) {
            return (Id)Enum.valueOf(Id.class, (String)string2);
        }

        public static Id[] values() {
            return (Id[])$VALUES.clone();
        }

        public int value() {
            return this.value;
        }
    }

    public static final class Size
    extends Enum<Size> {
        private static final /* synthetic */ Size[] $VALUES;
        public static final /* enum */ Size SERVER_STATS_LB_LATENCY_SIZE;
        public static final /* enum */ Size SERVER_STATS_SERVICE_LATENCY_SIZE;
        public static final /* enum */ Size SERVER_STATS_TRACE_OPTION_SIZE;
        private final int value;

        static {
            Size size;
            SERVER_STATS_LB_LATENCY_SIZE = new Size(8);
            SERVER_STATS_SERVICE_LATENCY_SIZE = new Size(8);
            SERVER_STATS_TRACE_OPTION_SIZE = size = new Size(1);
            Size[] arrsize = new Size[]{SERVER_STATS_LB_LATENCY_SIZE, SERVER_STATS_SERVICE_LATENCY_SIZE, size};
            $VALUES = arrsize;
        }

        private Size(int n2) {
            this.value = n2;
        }

        public static Size valueOf(String string2) {
            return (Size)Enum.valueOf(Size.class, (String)string2);
        }

        public static Size[] values() {
            return (Size[])$VALUES.clone();
        }

        public int value() {
            return this.value;
        }
    }

}

