/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.opencensus.common;

public interface ToDoubleFunction<T> {
    public double applyAsDouble(T var1);
}

