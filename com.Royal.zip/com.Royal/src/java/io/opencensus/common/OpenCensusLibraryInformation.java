/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.opencensus.common;

public final class OpenCensusLibraryInformation {
    public static final String VERSION = "0.24.0";

    private OpenCensusLibraryInformation() {
    }
}

