/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.opencensus.common;

import io.opencensus.common.NonThrowingCloseable;

public interface Scope
extends NonThrowingCloseable {
    @Override
    public void close();
}

