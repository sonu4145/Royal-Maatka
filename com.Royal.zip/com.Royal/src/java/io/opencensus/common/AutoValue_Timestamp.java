/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package io.opencensus.common;

import io.opencensus.common.Timestamp;

final class AutoValue_Timestamp
extends Timestamp {
    private final int nanos;
    private final long seconds;

    AutoValue_Timestamp(long l, int n) {
        this.seconds = l;
        this.nanos = n;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof Timestamp) {
            Timestamp timestamp = (Timestamp)object;
            return this.seconds == timestamp.getSeconds() && this.nanos == timestamp.getNanos();
        }
        return false;
    }

    @Override
    public int getNanos() {
        return this.nanos;
    }

    @Override
    public long getSeconds() {
        return this.seconds;
    }

    public int hashCode() {
        long l = 1000003;
        long l2 = this.seconds;
        return 1000003 * (int)(l ^ (l2 ^ l2 >>> 32)) ^ this.nanos;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Timestamp{seconds=");
        stringBuilder.append(this.seconds);
        stringBuilder.append(", nanos=");
        stringBuilder.append(this.nanos);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

