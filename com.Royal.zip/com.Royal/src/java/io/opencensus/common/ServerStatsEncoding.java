/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.Buffer
 *  java.nio.ByteBuffer
 *  java.nio.ByteOrder
 */
package io.opencensus.common;

import io.opencensus.common.ServerStats;
import io.opencensus.common.ServerStatsDeserializationException;
import io.opencensus.common.ServerStatsFieldEnums;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class ServerStatsEncoding {
    public static final byte CURRENT_VERSION;

    private ServerStatsEncoding() {
    }

    public static ServerStats parseBytes(byte[] arrby) throws ServerStatsDeserializationException {
        ServerStatsDeserializationException serverStatsDeserializationException;
        ByteBuffer byteBuffer = ByteBuffer.wrap((byte[])arrby);
        byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
        if (byteBuffer.hasRemaining()) {
            byte by = byteBuffer.get();
            if (by <= 0 && by >= 0) {
                long l;
                long l2 = l = 0L;
                byte by2 = 0;
                while (byteBuffer.hasRemaining()) {
                    ServerStatsFieldEnums.Id id2 = ServerStatsFieldEnums.Id.valueOf(255 & byteBuffer.get());
                    if (id2 == null) {
                        byteBuffer.position(byteBuffer.limit());
                        continue;
                    }
                    int n = 1.$SwitchMap$io$opencensus$common$ServerStatsFieldEnums$Id[id2.ordinal()];
                    if (n != 1) {
                        if (n != 2) {
                            if (n != 3) continue;
                            by2 = byteBuffer.get();
                            continue;
                        }
                        l2 = byteBuffer.getLong();
                        continue;
                    }
                    l = byteBuffer.getLong();
                }
                try {
                    ServerStats serverStats = ServerStats.create(l, l2, by2);
                    return serverStats;
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Serialized ServiceStats contains invalid values: ");
                    stringBuilder.append(illegalArgumentException.getMessage());
                    throw new ServerStatsDeserializationException(stringBuilder.toString());
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid ServerStats version: ");
            stringBuilder.append((int)by);
            throw new ServerStatsDeserializationException(stringBuilder.toString());
        }
        serverStatsDeserializationException = new ServerStatsDeserializationException("Serialized ServerStats buffer is empty");
        throw serverStatsDeserializationException;
    }

    public static byte[] toBytes(ServerStats serverStats) {
        ByteBuffer byteBuffer = ByteBuffer.allocate((int)(1 + ServerStatsFieldEnums.getTotalSize()));
        byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
        byteBuffer.put((byte)0);
        byteBuffer.put((byte)ServerStatsFieldEnums.Id.SERVER_STATS_LB_LATENCY_ID.value());
        byteBuffer.putLong(serverStats.getLbLatencyNs());
        byteBuffer.put((byte)ServerStatsFieldEnums.Id.SERVER_STATS_SERVICE_LATENCY_ID.value());
        byteBuffer.putLong(serverStats.getServiceLatencyNs());
        byteBuffer.put((byte)ServerStatsFieldEnums.Id.SERVER_STATS_TRACE_OPTION_ID.value());
        byteBuffer.put(serverStats.getTraceOption());
        return byteBuffer.array();
    }

}

