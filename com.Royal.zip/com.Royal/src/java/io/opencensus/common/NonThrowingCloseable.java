/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.lang.Deprecated
 *  java.lang.Object
 */
package io.opencensus.common;

import java.io.Closeable;

@Deprecated
public interface NonThrowingCloseable
extends Closeable {
    public void close();
}

