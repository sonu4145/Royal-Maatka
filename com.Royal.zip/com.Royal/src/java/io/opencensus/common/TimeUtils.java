/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.ArithmeticException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.math.BigInteger
 */
package io.opencensus.common;

import java.math.BigInteger;

final class TimeUtils {
    private static final BigInteger MAX_LONG_VALUE = BigInteger.valueOf((long)Long.MAX_VALUE);
    static final int MAX_NANOS = 999999999;
    static final long MAX_SECONDS = 315576000000L;
    static final long MILLIS_PER_SECOND = 1000L;
    private static final BigInteger MIN_LONG_VALUE = BigInteger.valueOf((long)Long.MIN_VALUE);
    static final long NANOS_PER_MILLI = 1000000L;
    static final long NANOS_PER_SECOND = 1000000000L;

    private TimeUtils() {
    }

    static long checkedAdd(long l, long l2) {
        BigInteger bigInteger = BigInteger.valueOf((long)l).add(BigInteger.valueOf((long)l2));
        if (bigInteger.compareTo(MAX_LONG_VALUE) <= 0 && bigInteger.compareTo(MIN_LONG_VALUE) >= 0) {
            return l + l2;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Long sum overflow: x=");
        stringBuilder.append(l);
        stringBuilder.append(", y=");
        stringBuilder.append(l2);
        throw new ArithmeticException(stringBuilder.toString());
    }

    static int compareLongs(long l, long l2) {
        if (l < l2) {
            return -1;
        }
        return l != l2;
    }
}

