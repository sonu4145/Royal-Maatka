/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Comparable
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.concurrent.TimeUnit
 */
package io.opencensus.common;

import io.opencensus.common.AutoValue_Duration;
import io.opencensus.common.TimeUtils;
import java.util.concurrent.TimeUnit;

public abstract class Duration
implements Comparable<Duration> {
    Duration() {
    }

    public static Duration create(long l, int n) {
        if (l >= -315576000000L) {
            if (l <= 315576000000L) {
                if (n >= -999999999) {
                    if (n <= 999999999) {
                        if (l < 0L && n > 0 || l > 0L && n < 0) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("'seconds' and 'nanos' have inconsistent sign: seconds=");
                            stringBuilder.append(l);
                            stringBuilder.append(", nanos=");
                            stringBuilder.append(n);
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                        return new AutoValue_Duration(l, n);
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("'nanos' is greater than maximum (999999999): ");
                    stringBuilder.append(n);
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("'nanos' is less than minimum (-999999999): ");
                stringBuilder.append(n);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("'seconds' is greater than maximum (315576000000): ");
            stringBuilder.append(l);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("'seconds' is less than minimum (-315576000000): ");
        stringBuilder.append(l);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static Duration fromMillis(long l) {
        return Duration.create(l / 1000L, (int)(1000000L * (l % 1000L)));
    }

    public int compareTo(Duration duration) {
        int n = TimeUtils.compareLongs(this.getSeconds(), duration.getSeconds());
        if (n != 0) {
            return n;
        }
        return TimeUtils.compareLongs(this.getNanos(), duration.getNanos());
    }

    public abstract int getNanos();

    public abstract long getSeconds();

    public long toMillis() {
        return TimeUnit.SECONDS.toMillis(this.getSeconds()) + TimeUnit.NANOSECONDS.toMillis((long)this.getNanos());
    }
}

