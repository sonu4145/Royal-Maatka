/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package io.opencensus.common;

import io.opencensus.common.ServerStats;

final class AutoValue_ServerStats
extends ServerStats {
    private final long lbLatencyNs;
    private final long serviceLatencyNs;
    private final byte traceOption;

    AutoValue_ServerStats(long l, long l2, byte by) {
        this.lbLatencyNs = l;
        this.serviceLatencyNs = l2;
        this.traceOption = by;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof ServerStats) {
            ServerStats serverStats = (ServerStats)object;
            return this.lbLatencyNs == serverStats.getLbLatencyNs() && this.serviceLatencyNs == serverStats.getServiceLatencyNs() && this.traceOption == serverStats.getTraceOption();
        }
        return false;
    }

    @Override
    public long getLbLatencyNs() {
        return this.lbLatencyNs;
    }

    @Override
    public long getServiceLatencyNs() {
        return this.serviceLatencyNs;
    }

    @Override
    public byte getTraceOption() {
        return this.traceOption;
    }

    public int hashCode() {
        long l = 1000003;
        long l2 = this.lbLatencyNs;
        long l3 = 1000003 * (int)(l ^ (l2 ^ l2 >>> 32));
        long l4 = this.serviceLatencyNs;
        return 1000003 * (int)(l3 ^ (l4 ^ l4 >>> 32)) ^ this.traceOption;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ServerStats{lbLatencyNs=");
        stringBuilder.append(this.lbLatencyNs);
        stringBuilder.append(", serviceLatencyNs=");
        stringBuilder.append(this.serviceLatencyNs);
        stringBuilder.append(", traceOption=");
        stringBuilder.append((int)this.traceOption);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

