/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.Arrays
 */
package io.grpc;

import java.util.Arrays;

final class PersistentHashArrayMappedTrie<K, V> {
    private final Node<K, V> root;

    PersistentHashArrayMappedTrie() {
        this(null);
    }

    private PersistentHashArrayMappedTrie(Node<K, V> node) {
        this.root = node;
    }

    public V get(K k) {
        Node<K, V> node = this.root;
        if (node == null) {
            return null;
        }
        return node.get(k, k.hashCode(), 0);
    }

    public PersistentHashArrayMappedTrie<K, V> put(K k, V v) {
        Node<K, V> node = this.root;
        if (node == null) {
            return new PersistentHashArrayMappedTrie<K, V>(new Leaf<K, V>(k, v));
        }
        return new PersistentHashArrayMappedTrie<K, V>(node.put(k, v, k.hashCode(), 0));
    }

    public int size() {
        Node<K, V> node = this.root;
        if (node == null) {
            return 0;
        }
        return node.size();
    }

    static final class CollisionLeaf<K, V>
    implements Node<K, V> {
        static final /* synthetic */ boolean $assertionsDisabled;
        private final K[] keys;
        private final V[] values;

        CollisionLeaf(K k, V v, K k2, V v2) {
            this(new Object[]{k, k2}, new Object[]{v, v2});
        }

        private CollisionLeaf(K[] arrK, V[] arrV) {
            this.keys = arrK;
            this.values = arrV;
        }

        private int indexOfKey(K k) {
            K[] arrK;
            for (int i = 0; i < (arrK = this.keys).length; ++i) {
                if (arrK[i] != k) continue;
                return i;
            }
            return -1;
        }

        @Override
        public V get(K k, int n, int n2) {
            K[] arrK;
            for (int i = 0; i < (arrK = this.keys).length; ++i) {
                if (arrK[i] != k) continue;
                return this.values[i];
            }
            return null;
        }

        @Override
        public Node<K, V> put(K k, V v, int n, int n2) {
            int n3 = this.keys[0].hashCode();
            if (n3 != n) {
                return CompressedIndex.combine(new Leaf<K, V>(k, v), n, this, n3, n2);
            }
            int n4 = this.indexOfKey(k);
            if (n4 != -1) {
                Object[] arrobject = this.keys;
                Object[] arrobject2 = Arrays.copyOf((Object[])arrobject, (int)arrobject.length);
                Object[] arrobject3 = Arrays.copyOf((Object[])this.values, (int)this.keys.length);
                arrobject2[n4] = k;
                arrobject3[n4] = v;
                return new CollisionLeaf<Object, Object>(arrobject2, arrobject3);
            }
            Object[] arrobject = this.keys;
            Object[] arrobject4 = Arrays.copyOf((Object[])arrobject, (int)(1 + arrobject.length));
            Object[] arrobject5 = Arrays.copyOf((Object[])this.values, (int)(1 + this.keys.length));
            K[] arrK = this.keys;
            arrobject4[arrK.length] = k;
            arrobject5[arrK.length] = v;
            return new CollisionLeaf<Object, Object>(arrobject4, arrobject5);
        }

        @Override
        public int size() {
            return this.values.length;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("CollisionLeaf(");
            for (int i = 0; i < this.values.length; ++i) {
                stringBuilder.append("(key=");
                stringBuilder.append(this.keys[i]);
                stringBuilder.append(" value=");
                stringBuilder.append(this.values[i]);
                stringBuilder.append(") ");
            }
            stringBuilder.append(")");
            return stringBuilder.toString();
        }
    }

    static final class CompressedIndex<K, V>
    implements Node<K, V> {
        static final /* synthetic */ boolean $assertionsDisabled = false;
        private static final int BITS = 5;
        private static final int BITS_MASK = 31;
        final int bitmap;
        private final int size;
        final Node<K, V>[] values;

        private CompressedIndex(int n, Node<K, V>[] arrnode, int n2) {
            this.bitmap = n;
            this.values = arrnode;
            this.size = n2;
        }

        static <K, V> Node<K, V> combine(Node<K, V> node, int n, Node<K, V> node2, int n2, int n3) {
            int n4;
            int n5 = CompressedIndex.indexBit(n, n3);
            if (n5 == (n4 = CompressedIndex.indexBit(n2, n3))) {
                Node<K, V> node3 = CompressedIndex.combine(node, n, node2, n2, n3 + 5);
                return new CompressedIndex<K, V>(n5, new Node[]{node3}, node3.size());
            }
            if (CompressedIndex.uncompressedIndex(n, n3) > CompressedIndex.uncompressedIndex(n2, n3)) {
                Node<K, V> node4 = node2;
                node2 = node;
                node = node4;
            }
            Node[] arrnode = new Node[]{node, node2};
            return new CompressedIndex<K, V>(n5 | n4, arrnode, node.size() + node2.size());
        }

        private int compressedIndex(int n) {
            return Integer.bitCount((int)(this.bitmap & n - 1));
        }

        private static int indexBit(int n, int n2) {
            return 1 << CompressedIndex.uncompressedIndex(n, n2);
        }

        private static int uncompressedIndex(int n, int n2) {
            return 31 & n >>> n2;
        }

        @Override
        public V get(K k, int n, int n2) {
            int n3 = CompressedIndex.indexBit(n, n2);
            if ((n3 & this.bitmap) == 0) {
                return null;
            }
            int n4 = this.compressedIndex(n3);
            return this.values[n4].get(k, n, n2 + 5);
        }

        @Override
        public Node<K, V> put(K k, V v, int n, int n2) {
            int n3 = CompressedIndex.indexBit(n, n2);
            int n4 = this.compressedIndex(n3);
            int n5 = this.bitmap;
            if ((n5 & n3) == 0) {
                int n6 = n5 | n3;
                Node<K, V>[] arrnode = this.values;
                Node[] arrnode2 = new Node[1 + arrnode.length];
                System.arraycopy(arrnode, (int)0, (Object)arrnode2, (int)0, (int)n4);
                arrnode2[n4] = new Leaf<K, V>(k, v);
                Node<K, V>[] arrnode3 = this.values;
                System.arraycopy(arrnode3, (int)n4, (Object)arrnode2, (int)(n4 + 1), (int)(arrnode3.length - n4));
                return new CompressedIndex<K, V>(n6, arrnode2, 1 + this.size());
            }
            Object[] arrobject = this.values;
            Node[] arrnode = (Node[])Arrays.copyOf((Object[])arrobject, (int)arrobject.length);
            arrnode[n4] = this.values[n4].put(k, v, n, n2 + 5);
            int n7 = this.size() + arrnode[n4].size() - this.values[n4].size();
            return new CompressedIndex<K, V>(this.bitmap, arrnode, n7);
        }

        @Override
        public int size() {
            return this.size;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("CompressedIndex(");
            Object[] arrobject = new Object[1];
            String string2 = Integer.toBinaryString((int)this.bitmap);
            arrobject[0] = string2;
            stringBuilder.append(String.format((String)"bitmap=%s ", (Object[])arrobject));
            Node<K, V>[] arrnode = this.values;
            int n = arrnode.length;
            for (int i = 0; i < n; ++i) {
                stringBuilder.append(arrnode[i]);
                stringBuilder.append(" ");
            }
            stringBuilder.append(")");
            return stringBuilder.toString();
        }
    }

    static final class Leaf<K, V>
    implements Node<K, V> {
        private final K key;
        private final V value;

        public Leaf(K k, V v) {
            this.key = k;
            this.value = v;
        }

        @Override
        public V get(K k, int n, int n2) {
            if (this.key == k) {
                return this.value;
            }
            return null;
        }

        @Override
        public Node<K, V> put(K k, V v, int n, int n2) {
            int n3 = this.key.hashCode();
            if (n3 != n) {
                return CompressedIndex.combine(new Leaf<K, V>(k, v), n, this, n3, n2);
            }
            if (this.key == k) {
                return new Leaf<K, V>(k, v);
            }
            return new CollisionLeaf<K, V>(this.key, this.value, k, v);
        }

        @Override
        public int size() {
            return 1;
        }

        public String toString() {
            Object[] arrobject = new Object[]{this.key, this.value};
            return String.format((String)"Leaf(key=%s value=%s)", (Object[])arrobject);
        }
    }

    static interface Node<K, V> {
        public V get(K var1, int var2, int var3);

        public Node<K, V> put(K var1, V var2, int var3, int var4);

        public int size();
    }

}

