/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.telephony.SmsMessage
 *  android.util.Log
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.stfalcon.smsverifycatcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import com.stfalcon.smsverifycatcher.OnSmsCatchListener;

class SmsReceiver
extends BroadcastReceiver {
    private OnSmsCatchListener<String> callback;
    private String filter;
    private String phoneNumberFilter;

    SmsReceiver() {
    }

    private SmsMessage getIncomingMessage(Object object, Bundle bundle) {
        if (Build.VERSION.SDK_INT >= 23) {
            String string2 = bundle.getString("format");
            return SmsMessage.createFromPdu((byte[])((byte[])object), (String)string2);
        }
        return SmsMessage.createFromPdu((byte[])((byte[])object));
    }

    public void onReceive(Context context, Intent intent) {
        block7 : {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                int n;
                Object[] arrobject;
                try {
                    arrobject = (Object[])bundle.get("pdus");
                    n = 0;
                }
                catch (Exception exception) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Exception smsReceiver");
                    stringBuilder.append((Object)exception);
                    Log.e((String)"SmsReceiver", (String)stringBuilder.toString());
                }
                do {
                    block8 : {
                        if (n >= arrobject.length) break block7;
                        SmsMessage smsMessage = this.getIncomingMessage(arrobject[n], bundle);
                        String string2 = smsMessage.getDisplayOriginatingAddress();
                        if (this.phoneNumberFilter != null && !string2.equals((Object)this.phoneNumberFilter)) {
                            return;
                        }
                        String string3 = smsMessage.getDisplayMessageBody();
                        if (this.filter != null && !string3.matches(this.filter)) {
                            return;
                        }
                        if (this.callback == null) break block8;
                        this.callback.onSmsCatch(string3);
                    }
                    ++n;
                } while (true);
            }
        }
    }

    public void setCallback(OnSmsCatchListener<String> onSmsCatchListener) {
        this.callback = onSmsCatchListener;
    }

    public void setFilter(String string2) {
        this.filter = string2;
    }

    public void setPhoneNumberFilter(String string2) {
        this.phoneNumberFilter = string2;
    }
}

