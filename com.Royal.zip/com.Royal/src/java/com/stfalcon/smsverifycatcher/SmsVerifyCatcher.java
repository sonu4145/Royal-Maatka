/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Fragment
 *  android.content.BroadcastReceiver
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.util.Log
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.stfalcon.smsverifycatcher;

import android.app.Activity;
import android.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;
import com.stfalcon.smsverifycatcher.OnSmsCatchListener;
import com.stfalcon.smsverifycatcher.SmsReceiver;

public class SmsVerifyCatcher {
    private static final int PERMISSION_REQUEST_CODE = 12;
    private Activity activity;
    private String filter;
    private Fragment fragment;
    private OnSmsCatchListener<String> onSmsCatchListener;
    private String phoneNumber;
    private SmsReceiver smsReceiver;

    public SmsVerifyCatcher(Activity activity, Fragment fragment, OnSmsCatchListener<String> onSmsCatchListener) {
        this(activity, onSmsCatchListener);
        this.fragment = fragment;
    }

    public SmsVerifyCatcher(Activity activity, OnSmsCatchListener<String> onSmsCatchListener) {
        SmsReceiver smsReceiver;
        this.activity = activity;
        this.onSmsCatchListener = onSmsCatchListener;
        this.smsReceiver = smsReceiver = new SmsReceiver();
        smsReceiver.setCallback(this.onSmsCatchListener);
    }

    public static boolean isStoragePermissionGranted(Activity activity, Fragment fragment) {
        return true;
    }

    private void registerReceiver() {
        SmsReceiver smsReceiver;
        this.smsReceiver = smsReceiver = new SmsReceiver();
        smsReceiver.setCallback(this.onSmsCatchListener);
        this.smsReceiver.setPhoneNumberFilter(this.phoneNumber);
        this.smsReceiver.setFilter(this.filter);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.provider.Telephony.SMS_RECEIVED");
        this.activity.registerReceiver((BroadcastReceiver)this.smsReceiver, intentFilter);
    }

    public void onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
        if (n == 12) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(arrn[0]);
            Log.e((String)"grantresult", (String)stringBuilder.toString());
            if (arrn[0] == 0 && arrn[1] == 0) {
                this.registerReceiver();
            }
        }
    }

    public void onStart() {
        if (SmsVerifyCatcher.isStoragePermissionGranted(this.activity, this.fragment)) {
            this.registerReceiver();
        }
    }

    public void onStop() {
        try {
            this.activity.unregisterReceiver((BroadcastReceiver)this.smsReceiver);
        }
        catch (IllegalArgumentException illegalArgumentException) {}
    }

    public void setFilter(String string2) {
        this.filter = string2;
    }

    public void setPhoneNumberFilter(String string2) {
        this.phoneNumber = string2;
    }
}

