/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.balysv.materialripple;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int mrl_rippleAlpha = 2130903787;
        public static final int mrl_rippleBackground = 2130903788;
        public static final int mrl_rippleColor = 2130903789;
        public static final int mrl_rippleDelayClick = 2130903790;
        public static final int mrl_rippleDimension = 2130903791;
        public static final int mrl_rippleDuration = 2130903792;
        public static final int mrl_rippleFadeDuration = 2130903793;
        public static final int mrl_rippleHover = 2130903794;
        public static final int mrl_rippleInAdapter = 2130903795;
        public static final int mrl_rippleOverlay = 2130903796;
        public static final int mrl_ripplePersistent = 2130903797;
        public static final int mrl_rippleRoundedCorners = 2130903798;

        private attr() {
        }
    }

    public static final class color {
        public static final int transparent = 2131034735;

        private color() {
        }
    }

    public static final class styleable {
        public static final int[] MaterialRippleLayout = new int[]{2130903787, 2130903788, 2130903789, 2130903790, 2130903791, 2130903792, 2130903793, 2130903794, 2130903795, 2130903796, 2130903797, 2130903798};
        public static final int MaterialRippleLayout_mrl_rippleAlpha = 0;
        public static final int MaterialRippleLayout_mrl_rippleBackground = 1;
        public static final int MaterialRippleLayout_mrl_rippleColor = 2;
        public static final int MaterialRippleLayout_mrl_rippleDelayClick = 3;
        public static final int MaterialRippleLayout_mrl_rippleDimension = 4;
        public static final int MaterialRippleLayout_mrl_rippleDuration = 5;
        public static final int MaterialRippleLayout_mrl_rippleFadeDuration = 6;
        public static final int MaterialRippleLayout_mrl_rippleHover = 7;
        public static final int MaterialRippleLayout_mrl_rippleInAdapter = 8;
        public static final int MaterialRippleLayout_mrl_rippleOverlay = 9;
        public static final int MaterialRippleLayout_mrl_ripplePersistent = 10;
        public static final int MaterialRippleLayout_mrl_rippleRoundedCorners = 11;

        private styleable() {
        }
    }

}

