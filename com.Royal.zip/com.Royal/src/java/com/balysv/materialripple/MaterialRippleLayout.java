/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.AnimatorListenerAdapter
 *  android.animation.AnimatorSet
 *  android.animation.AnimatorSet$Builder
 *  android.animation.ObjectAnimator
 *  android.animation.TimeInterpolator
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.Path$Direction
 *  android.graphics.Point
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.Property
 *  android.util.TypedValue
 *  android.view.GestureDetector
 *  android.view.GestureDetector$OnGestureListener
 *  android.view.GestureDetector$SimpleOnGestureListener
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.ViewConfiguration
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.view.animation.AccelerateInterpolator
 *  android.view.animation.DecelerateInterpolator
 *  android.view.animation.LinearInterpolator
 *  android.widget.Adapter
 *  android.widget.AdapterView
 *  android.widget.FrameLayout
 *  java.lang.Class
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package com.balysv.materialripple;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Property;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import com.balysv.materialripple.R;

public class MaterialRippleLayout
extends FrameLayout {
    private static final float DEFAULT_ALPHA = 0.2f;
    private static final int DEFAULT_BACKGROUND = 0;
    private static final int DEFAULT_COLOR = -16777216;
    private static final boolean DEFAULT_DELAY_CLICK = true;
    private static final float DEFAULT_DIAMETER_DP = 35.0f;
    private static final int DEFAULT_DURATION = 350;
    private static final int DEFAULT_FADE_DURATION = 75;
    private static final boolean DEFAULT_HOVER = true;
    private static final boolean DEFAULT_PERSISTENT = false;
    private static final boolean DEFAULT_RIPPLE_OVERLAY = false;
    private static final int DEFAULT_ROUNDED_CORNERS = 0;
    private static final boolean DEFAULT_SEARCH_ADAPTER = false;
    private static final int FADE_EXTRA_DELAY = 50;
    private static final long HOVER_DURATION = 2500L;
    private final Rect bounds = new Rect();
    private View childView;
    private Property<MaterialRippleLayout, Integer> circleAlphaProperty = new Property<MaterialRippleLayout, Integer>(Integer.class, "rippleAlpha"){

        public Integer get(MaterialRippleLayout materialRippleLayout) {
            return materialRippleLayout.getRippleAlpha();
        }

        public void set(MaterialRippleLayout materialRippleLayout, Integer n) {
            materialRippleLayout.setRippleAlpha(n);
        }
    };
    private Point currentCoords = new Point();
    private boolean eventCancelled;
    private GestureDetector gestureDetector;
    private boolean hasPerformedLongPress;
    private ObjectAnimator hoverAnimator;
    private int layerType;
    private GestureDetector.SimpleOnGestureListener longClickListener = new GestureDetector.SimpleOnGestureListener(){

        public boolean onDown(MotionEvent motionEvent) {
            MaterialRippleLayout.this.hasPerformedLongPress = false;
            return super.onDown(motionEvent);
        }

        public void onLongPress(MotionEvent motionEvent) {
            MaterialRippleLayout materialRippleLayout = MaterialRippleLayout.this;
            materialRippleLayout.hasPerformedLongPress = materialRippleLayout.childView.performLongClick();
            if (MaterialRippleLayout.this.hasPerformedLongPress) {
                if (MaterialRippleLayout.this.rippleHover) {
                    MaterialRippleLayout.this.startRipple(null);
                }
                MaterialRippleLayout.this.cancelPressedEvent();
            }
        }
    };
    private final Paint paint = new Paint(1);
    private AdapterView parentAdapter;
    private PerformClickEvent pendingClickEvent;
    private PressedEvent pendingPressEvent;
    private int positionInAdapter;
    private boolean prepressed;
    private Point previousCoords = new Point();
    private float radius;
    private Property<MaterialRippleLayout, Float> radiusProperty = new Property<MaterialRippleLayout, Float>(Float.class, "radius"){

        public Float get(MaterialRippleLayout materialRippleLayout) {
            return Float.valueOf((float)materialRippleLayout.getRadius());
        }

        public void set(MaterialRippleLayout materialRippleLayout, Float f) {
            materialRippleLayout.setRadius(f.floatValue());
        }
    };
    private int rippleAlpha;
    private AnimatorSet rippleAnimator;
    private Drawable rippleBackground;
    private int rippleColor;
    private boolean rippleDelayClick;
    private int rippleDiameter;
    private int rippleDuration;
    private int rippleFadeDuration;
    private boolean rippleHover;
    private boolean rippleInAdapter;
    private boolean rippleOverlay;
    private boolean ripplePersistent;
    private float rippleRoundedCorners;

    public MaterialRippleLayout(Context context) {
        this(context, null, 0);
    }

    public MaterialRippleLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public MaterialRippleLayout(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.setWillNotDraw(false);
        this.gestureDetector = new GestureDetector(context, (GestureDetector.OnGestureListener)this.longClickListener);
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, R.styleable.MaterialRippleLayout);
        this.rippleColor = typedArray.getColor(R.styleable.MaterialRippleLayout_mrl_rippleColor, -16777216);
        this.rippleDiameter = typedArray.getDimensionPixelSize(R.styleable.MaterialRippleLayout_mrl_rippleDimension, (int)MaterialRippleLayout.dpToPx(this.getResources(), 35.0f));
        this.rippleOverlay = typedArray.getBoolean(R.styleable.MaterialRippleLayout_mrl_rippleOverlay, false);
        this.rippleHover = typedArray.getBoolean(R.styleable.MaterialRippleLayout_mrl_rippleHover, true);
        this.rippleDuration = typedArray.getInt(R.styleable.MaterialRippleLayout_mrl_rippleDuration, 350);
        this.rippleAlpha = (int)(255.0f * typedArray.getFloat(R.styleable.MaterialRippleLayout_mrl_rippleAlpha, 0.2f));
        this.rippleDelayClick = typedArray.getBoolean(R.styleable.MaterialRippleLayout_mrl_rippleDelayClick, true);
        this.rippleFadeDuration = typedArray.getInteger(R.styleable.MaterialRippleLayout_mrl_rippleFadeDuration, 75);
        this.rippleBackground = new ColorDrawable(typedArray.getColor(R.styleable.MaterialRippleLayout_mrl_rippleBackground, 0));
        this.ripplePersistent = typedArray.getBoolean(R.styleable.MaterialRippleLayout_mrl_ripplePersistent, false);
        this.rippleInAdapter = typedArray.getBoolean(R.styleable.MaterialRippleLayout_mrl_rippleInAdapter, false);
        this.rippleRoundedCorners = typedArray.getDimensionPixelSize(R.styleable.MaterialRippleLayout_mrl_rippleRoundedCorners, 0);
        typedArray.recycle();
        this.paint.setColor(this.rippleColor);
        this.paint.setAlpha(this.rippleAlpha);
        this.enableClipPathSupportIfNecessary();
    }

    private boolean adapterPositionChanged() {
        if (this.rippleInAdapter) {
            int n = this.findParentAdapterView().getPositionForView((View)this);
            boolean bl = n != this.positionInAdapter;
            this.positionInAdapter = n;
            if (bl) {
                this.cancelPressedEvent();
                this.cancelAnimations();
                this.childView.setPressed(false);
                this.setRadius(0.0f);
            }
            return bl;
        }
        return false;
    }

    private void cancelAnimations() {
        ObjectAnimator objectAnimator;
        AnimatorSet animatorSet = this.rippleAnimator;
        if (animatorSet != null) {
            animatorSet.cancel();
            this.rippleAnimator.removeAllListeners();
        }
        if ((objectAnimator = this.hoverAnimator) != null) {
            objectAnimator.cancel();
        }
    }

    private void cancelPressedEvent() {
        PressedEvent pressedEvent = this.pendingPressEvent;
        if (pressedEvent != null) {
            this.removeCallbacks((Runnable)pressedEvent);
            this.prepressed = false;
        }
    }

    static float dpToPx(Resources resources, float f) {
        return TypedValue.applyDimension((int)1, (float)f, (DisplayMetrics)resources.getDisplayMetrics());
    }

    private void enableClipPathSupportIfNecessary() {
        if (Build.VERSION.SDK_INT <= 17) {
            if (this.rippleRoundedCorners != 0.0f) {
                this.layerType = this.getLayerType();
                this.setLayerType(1, null);
                return;
            }
            this.setLayerType(this.layerType, null);
        }
    }

    private boolean findClickableViewInChild(View view, int n, int n2) {
        block4 : {
            boolean bl;
            block5 : {
                block6 : {
                    block3 : {
                        boolean bl2 = view instanceof ViewGroup;
                        if (!bl2) break block3;
                        ViewGroup viewGroup = (ViewGroup)view;
                        for (int i = 0; i < viewGroup.getChildCount(); ++i) {
                            View view2 = viewGroup.getChildAt(i);
                            Rect rect = new Rect();
                            view2.getHitRect(rect);
                            if (!rect.contains(n, n2)) continue;
                            return this.findClickableViewInChild(view2, n - rect.left, n2 - rect.top);
                        }
                        break block4;
                    }
                    if (view == this.childView) break block4;
                    boolean bl3 = view.isEnabled();
                    bl = false;
                    if (!bl3) break block5;
                    if (view.isClickable() || view.isLongClickable()) break block6;
                    boolean bl4 = view.isFocusableInTouchMode();
                    bl = false;
                    if (!bl4) break block5;
                }
                bl = true;
            }
            return bl;
        }
        return view.isFocusableInTouchMode();
    }

    private AdapterView findParentAdapterView() {
        AdapterView adapterView = this.parentAdapter;
        if (adapterView != null) {
            return adapterView;
        }
        ViewParent viewParent = this.getParent();
        do {
            if (viewParent instanceof AdapterView) {
                AdapterView adapterView2;
                this.parentAdapter = adapterView2 = (AdapterView)viewParent;
                return adapterView2;
            }
            try {
                viewParent = viewParent.getParent();
            }
            catch (NullPointerException nullPointerException) {
                RuntimeException runtimeException = new RuntimeException("Could not find a parent AdapterView");
                throw runtimeException;
            }
        } while (true);
    }

    private float getEndRadius() {
        int n = this.getWidth();
        int n2 = this.getHeight();
        int n3 = n / 2;
        int n4 = n2 / 2;
        int n5 = n3 > this.currentCoords.x ? n - this.currentCoords.x : this.currentCoords.x;
        float f = n5;
        int n6 = n4 > this.currentCoords.y ? n2 - this.currentCoords.y : this.currentCoords.y;
        float f2 = n6;
        return 1.2f * (float)Math.sqrt((double)(Math.pow((double)f, (double)2.0) + Math.pow((double)f2, (double)2.0)));
    }

    private float getRadius() {
        return this.radius;
    }

    private boolean isInScrollingContainer() {
        for (ViewParent viewParent = this.getParent(); viewParent != null && viewParent instanceof ViewGroup; viewParent = viewParent.getParent()) {
            if (!((ViewGroup)viewParent).shouldDelayChildPressedState()) continue;
            return true;
        }
        return false;
    }

    public static RippleBuilder on(View view) {
        return new RippleBuilder(view);
    }

    private void setPositionInAdapter() {
        if (this.rippleInAdapter) {
            this.positionInAdapter = this.findParentAdapterView().getPositionForView((View)this);
        }
    }

    private void startHover() {
        ObjectAnimator objectAnimator;
        if (this.eventCancelled) {
            return;
        }
        ObjectAnimator objectAnimator2 = this.hoverAnimator;
        if (objectAnimator2 != null) {
            objectAnimator2.cancel();
        }
        float f = (float)(1.2000000476837158 * Math.sqrt((double)(Math.pow((double)this.getWidth(), (double)2.0) + Math.pow((double)this.getHeight(), (double)2.0))));
        Property<MaterialRippleLayout, Float> property = this.radiusProperty;
        float[] arrf = new float[]{this.rippleDiameter, f};
        this.hoverAnimator = objectAnimator = ObjectAnimator.ofFloat((Object)((Object)this), property, (float[])arrf).setDuration(2500L);
        objectAnimator.setInterpolator((TimeInterpolator)new LinearInterpolator());
        this.hoverAnimator.start();
    }

    private void startRipple(final Runnable runnable) {
        AnimatorSet animatorSet;
        if (this.eventCancelled) {
            return;
        }
        float f = this.getEndRadius();
        this.cancelAnimations();
        this.rippleAnimator = animatorSet = new AnimatorSet();
        animatorSet.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter(){

            public void onAnimationEnd(Animator animator2) {
                if (!MaterialRippleLayout.this.ripplePersistent) {
                    MaterialRippleLayout.this.setRadius(0.0f);
                    MaterialRippleLayout materialRippleLayout = MaterialRippleLayout.this;
                    materialRippleLayout.setRippleAlpha(materialRippleLayout.rippleAlpha);
                }
                if (runnable != null && MaterialRippleLayout.this.rippleDelayClick) {
                    runnable.run();
                }
                MaterialRippleLayout.this.childView.setPressed(false);
            }
        });
        Property<MaterialRippleLayout, Float> property = this.radiusProperty;
        float[] arrf = new float[]{this.radius, f};
        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat((Object)((Object)this), property, (float[])arrf);
        objectAnimator.setDuration((long)this.rippleDuration);
        objectAnimator.setInterpolator((TimeInterpolator)new DecelerateInterpolator());
        Property<MaterialRippleLayout, Integer> property2 = this.circleAlphaProperty;
        int[] arrn = new int[]{this.rippleAlpha, 0};
        ObjectAnimator objectAnimator2 = ObjectAnimator.ofInt((Object)((Object)this), property2, (int[])arrn);
        objectAnimator2.setDuration((long)this.rippleFadeDuration);
        objectAnimator2.setInterpolator((TimeInterpolator)new AccelerateInterpolator());
        objectAnimator2.setStartDelay((long)(-50 + (this.rippleDuration - this.rippleFadeDuration)));
        if (this.ripplePersistent) {
            this.rippleAnimator.play((Animator)objectAnimator);
        } else if (this.getRadius() > f) {
            objectAnimator2.setStartDelay(0L);
            this.rippleAnimator.play((Animator)objectAnimator2);
        } else {
            this.rippleAnimator.playTogether(new Animator[]{objectAnimator, objectAnimator2});
        }
        this.rippleAnimator.start();
    }

    public final void addView(View view, int n, ViewGroup.LayoutParams layoutParams) {
        if (this.getChildCount() <= 0) {
            this.childView = view;
            super.addView(view, n, layoutParams);
            return;
        }
        throw new IllegalStateException("MaterialRippleLayout can host only one child");
    }

    public void draw(Canvas canvas) {
        boolean bl = this.adapterPositionChanged();
        if (this.rippleOverlay) {
            if (!bl) {
                this.rippleBackground.draw(canvas);
            }
            super.draw(canvas);
            if (!bl) {
                if (this.rippleRoundedCorners != 0.0f) {
                    Path path = new Path();
                    RectF rectF = new RectF(0.0f, 0.0f, (float)canvas.getWidth(), (float)canvas.getHeight());
                    float f = this.rippleRoundedCorners;
                    path.addRoundRect(rectF, f, f, Path.Direction.CW);
                    canvas.clipPath(path);
                }
                canvas.drawCircle((float)this.currentCoords.x, (float)this.currentCoords.y, this.radius, this.paint);
                return;
            }
        } else {
            if (!bl) {
                this.rippleBackground.draw(canvas);
                canvas.drawCircle((float)this.currentCoords.x, (float)this.currentCoords.y, this.radius, this.paint);
            }
            super.draw(canvas);
        }
    }

    public <T extends View> T getChildView() {
        return (T)this.childView;
    }

    public int getRippleAlpha() {
        return this.paint.getAlpha();
    }

    public boolean isInEditMode() {
        return true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return true ^ this.findClickableViewInChild(this.childView, (int)motionEvent.getX(), (int)motionEvent.getY());
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        super.onSizeChanged(n, n2, n3, n4);
        this.bounds.set(0, 0, n, n2);
        this.rippleBackground.setBounds(this.bounds);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean bl = super.onTouchEvent(motionEvent);
        if (!this.isEnabled()) return bl;
        if (!this.childView.isEnabled()) {
            return bl;
        }
        boolean bl2 = this.bounds.contains((int)motionEvent.getX(), (int)motionEvent.getY());
        if (bl2) {
            this.previousCoords.set(this.currentCoords.x, this.currentCoords.y);
            this.currentCoords.set((int)motionEvent.getX(), (int)motionEvent.getY());
        }
        if (this.gestureDetector.onTouchEvent(motionEvent)) return true;
        if (this.hasPerformedLongPress) {
            return true;
        }
        int n = motionEvent.getActionMasked();
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    if (n != 3) {
                        return true;
                    }
                    if (this.rippleInAdapter) {
                        this.currentCoords.set(this.previousCoords.x, this.previousCoords.y);
                        this.previousCoords = new Point();
                    }
                    this.childView.onTouchEvent(motionEvent);
                    if (this.rippleHover) {
                        if (!this.prepressed) {
                            this.startRipple(null);
                        }
                    } else {
                        this.childView.setPressed(false);
                    }
                    this.cancelPressedEvent();
                    return true;
                }
                if (this.rippleHover) {
                    if (bl2 && !this.eventCancelled) {
                        this.invalidate();
                    } else if (!bl2) {
                        this.startRipple(null);
                    }
                }
                if (bl2) return true;
                this.cancelPressedEvent();
                ObjectAnimator objectAnimator = this.hoverAnimator;
                if (objectAnimator != null) {
                    objectAnimator.cancel();
                }
                this.childView.onTouchEvent(motionEvent);
                this.eventCancelled = true;
                return true;
            }
            this.pendingClickEvent = new PerformClickEvent();
            if (this.prepressed) {
                this.childView.setPressed(true);
                this.postDelayed(new Runnable(){

                    public void run() {
                        MaterialRippleLayout.this.childView.setPressed(false);
                    }
                }, (long)ViewConfiguration.getPressedStateDuration());
            }
            if (bl2) {
                this.startRipple(this.pendingClickEvent);
            } else if (!this.rippleHover) {
                this.setRadius(0.0f);
            }
            if (!this.rippleDelayClick && bl2) {
                this.pendingClickEvent.run();
            }
            this.cancelPressedEvent();
            return true;
        }
        this.setPositionInAdapter();
        this.eventCancelled = false;
        this.pendingPressEvent = new PressedEvent(motionEvent);
        if (this.isInScrollingContainer()) {
            this.cancelPressedEvent();
            this.prepressed = true;
            this.postDelayed((Runnable)this.pendingPressEvent, (long)ViewConfiguration.getTapTimeout());
            return true;
        }
        this.pendingPressEvent.run();
        return true;
    }

    public void performRipple() {
        this.currentCoords = new Point(this.getWidth() / 2, this.getHeight() / 2);
        this.startRipple(null);
    }

    public void performRipple(Point point) {
        this.currentCoords = new Point(point.x, point.y);
        this.startRipple(null);
    }

    public void setDefaultRippleAlpha(int n) {
        this.rippleAlpha = n;
        this.paint.setAlpha(n);
        this.invalidate();
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        View view = this.childView;
        if (view != null) {
            view.setOnClickListener(onClickListener);
            return;
        }
        throw new IllegalStateException("MaterialRippleLayout must have a child view to handle clicks");
    }

    public void setOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        View view = this.childView;
        if (view != null) {
            view.setOnLongClickListener(onLongClickListener);
            return;
        }
        throw new IllegalStateException("MaterialRippleLayout must have a child view to handle clicks");
    }

    public void setRadius(float f) {
        this.radius = f;
        this.invalidate();
    }

    public void setRippleAlpha(Integer n) {
        this.paint.setAlpha(n.intValue());
        this.invalidate();
    }

    public void setRippleBackground(int n) {
        ColorDrawable colorDrawable = new ColorDrawable(n);
        this.rippleBackground = colorDrawable;
        colorDrawable.setBounds(this.bounds);
        this.invalidate();
    }

    public void setRippleColor(int n) {
        this.rippleColor = n;
        this.paint.setColor(n);
        this.paint.setAlpha(this.rippleAlpha);
        this.invalidate();
    }

    public void setRippleDelayClick(boolean bl) {
        this.rippleDelayClick = bl;
    }

    public void setRippleDiameter(int n) {
        this.rippleDiameter = n;
    }

    public void setRippleDuration(int n) {
        this.rippleDuration = n;
    }

    public void setRippleFadeDuration(int n) {
        this.rippleFadeDuration = n;
    }

    public void setRippleHover(boolean bl) {
        this.rippleHover = bl;
    }

    public void setRippleInAdapter(boolean bl) {
        this.rippleInAdapter = bl;
    }

    public void setRippleOverlay(boolean bl) {
        this.rippleOverlay = bl;
    }

    public void setRipplePersistent(boolean bl) {
        this.ripplePersistent = bl;
    }

    public void setRippleRoundedCorners(int n) {
        this.rippleRoundedCorners = n;
        this.enableClipPathSupportIfNecessary();
    }

    private class PerformClickEvent
    implements Runnable {
        private PerformClickEvent() {
        }

        private void clickAdapterView(AdapterView adapterView) {
            int n = adapterView.getPositionForView((View)MaterialRippleLayout.this);
            long l = adapterView.getAdapter() != null ? adapterView.getAdapter().getItemId(n) : 0L;
            if (n != -1) {
                adapterView.performItemClick((View)MaterialRippleLayout.this, n, l);
            }
        }

        public void run() {
            if (MaterialRippleLayout.this.hasPerformedLongPress) {
                return;
            }
            if (MaterialRippleLayout.this.getParent() instanceof AdapterView) {
                this.clickAdapterView((AdapterView)MaterialRippleLayout.this.getParent());
                return;
            }
            if (MaterialRippleLayout.this.rippleInAdapter) {
                this.clickAdapterView(MaterialRippleLayout.this.findParentAdapterView());
                return;
            }
            MaterialRippleLayout.this.childView.performClick();
        }
    }

    private final class PressedEvent
    implements Runnable {
        private final MotionEvent event;

        public PressedEvent(MotionEvent motionEvent) {
            this.event = motionEvent;
        }

        public void run() {
            MaterialRippleLayout.this.prepressed = false;
            MaterialRippleLayout.this.childView.setLongClickable(false);
            MaterialRippleLayout.this.childView.onTouchEvent(this.event);
            MaterialRippleLayout.this.childView.setPressed(true);
            if (MaterialRippleLayout.this.rippleHover) {
                MaterialRippleLayout.this.startHover();
            }
        }
    }

    public static class RippleBuilder {
        private final View child;
        private final Context context;
        private float rippleAlpha = 0.2f;
        private int rippleBackground = 0;
        private int rippleColor = -16777216;
        private boolean rippleDelayClick = true;
        private float rippleDiameter = 35.0f;
        private int rippleDuration = 350;
        private int rippleFadeDuration = 75;
        private boolean rippleHover = true;
        private boolean rippleOverlay = false;
        private boolean ripplePersistent = false;
        private float rippleRoundedCorner = 0.0f;
        private boolean rippleSearchAdapter = false;

        public RippleBuilder(View view) {
            this.child = view;
            this.context = view.getContext();
        }

        public MaterialRippleLayout create() {
            int n;
            MaterialRippleLayout materialRippleLayout = new MaterialRippleLayout(this.context);
            materialRippleLayout.setRippleColor(this.rippleColor);
            materialRippleLayout.setDefaultRippleAlpha((int)this.rippleAlpha);
            materialRippleLayout.setRippleDelayClick(this.rippleDelayClick);
            materialRippleLayout.setRippleDiameter((int)MaterialRippleLayout.dpToPx(this.context.getResources(), this.rippleDiameter));
            materialRippleLayout.setRippleDuration(this.rippleDuration);
            materialRippleLayout.setRippleFadeDuration(this.rippleFadeDuration);
            materialRippleLayout.setRippleHover(this.rippleHover);
            materialRippleLayout.setRipplePersistent(this.ripplePersistent);
            materialRippleLayout.setRippleOverlay(this.rippleOverlay);
            materialRippleLayout.setRippleBackground(this.rippleBackground);
            materialRippleLayout.setRippleInAdapter(this.rippleSearchAdapter);
            materialRippleLayout.setRippleRoundedCorners((int)MaterialRippleLayout.dpToPx(this.context.getResources(), this.rippleRoundedCorner));
            ViewGroup.LayoutParams layoutParams = this.child.getLayoutParams();
            ViewGroup viewGroup = (ViewGroup)this.child.getParent();
            if (viewGroup != null && viewGroup instanceof MaterialRippleLayout) {
                throw new IllegalStateException("MaterialRippleLayout could not be created: parent of the view already is a MaterialRippleLayout");
            }
            if (viewGroup != null) {
                n = viewGroup.indexOfChild(this.child);
                viewGroup.removeView(this.child);
            } else {
                n = 0;
            }
            materialRippleLayout.addView(this.child, new ViewGroup.LayoutParams(-1, -1));
            if (viewGroup != null) {
                viewGroup.addView((View)materialRippleLayout, n, layoutParams);
            }
            return materialRippleLayout;
        }

        public RippleBuilder rippleAlpha(float f) {
            this.rippleAlpha = f * 255.0f;
            return this;
        }

        public RippleBuilder rippleBackground(int n) {
            this.rippleBackground = n;
            return this;
        }

        public RippleBuilder rippleColor(int n) {
            this.rippleColor = n;
            return this;
        }

        public RippleBuilder rippleDelayClick(boolean bl) {
            this.rippleDelayClick = bl;
            return this;
        }

        public RippleBuilder rippleDiameterDp(int n) {
            this.rippleDiameter = n;
            return this;
        }

        public RippleBuilder rippleDuration(int n) {
            this.rippleDuration = n;
            return this;
        }

        public RippleBuilder rippleFadeDuration(int n) {
            this.rippleFadeDuration = n;
            return this;
        }

        public RippleBuilder rippleHover(boolean bl) {
            this.rippleHover = bl;
            return this;
        }

        public RippleBuilder rippleInAdapter(boolean bl) {
            this.rippleSearchAdapter = bl;
            return this;
        }

        public RippleBuilder rippleOverlay(boolean bl) {
            this.rippleOverlay = bl;
            return this;
        }

        public RippleBuilder ripplePersistent(boolean bl) {
            this.ripplePersistent = bl;
            return this;
        }

        public RippleBuilder rippleRoundedCorners(int n) {
            this.rippleRoundedCorner = n;
            return this;
        }
    }

}

