/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.os.IBinder
 *  android.text.Editable
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.LinearLayout
 *  com.hololo.library.otpview.OTPEditText
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.hololo.library.otpview;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.IBinder;
import android.text.Editable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import com.hololo.library.otpview.OTPEditText;
import com.hololo.library.otpview.OTPListener;
import com.hololo.library.otpview.R;

public class OTPView
extends LinearLayout {
    private int count;
    private String hint;
    private int hintColor;
    private int inputType;
    private OTPListener listener;
    private int textColor;
    private int textSize;
    private int viewsPadding;

    public OTPView(Context context) {
        super(context);
        this.init(null);
    }

    public OTPView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(attributeSet);
    }

    public OTPView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(attributeSet);
    }

    public OTPView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.init(attributeSet);
    }

    private void clearLayout() {
        this.removeAllViewsInLayout();
    }

    private float dp2px(int n) {
        return 0.5f + this.getContext().getResources().getDisplayMetrics().density * (float)n;
    }

    private void init(AttributeSet attributeSet) {
        int n = (int)this.dp2px(8);
        this.setPadding(n, n, n, n);
        this.setFocusableInTouchMode(true);
        TypedArray typedArray = this.getContext().obtainStyledAttributes(attributeSet, R.styleable.OTPView);
        this.count = typedArray.getInt(R.styleable.OTPView_count, 5);
        this.inputType = typedArray.getInt(R.styleable.OTPView_inputType, 1);
        this.textColor = typedArray.getInt(R.styleable.OTPView_textColor, -1);
        this.hintColor = typedArray.getInt(R.styleable.OTPView_hintColor, -1);
        this.viewsPadding = typedArray.getInt(R.styleable.OTPView_viewsPadding, -1);
        this.hint = typedArray.getString(R.styleable.OTPView_otpHint);
        this.textSize = typedArray.getInt(R.styleable.OTPView_textSize, -1);
        String string2 = typedArray.getString(R.styleable.OTPView_otpText);
        this.fillLayout();
        this.setOtp(string2);
    }

    public void fillLayout() {
        this.clearLayout();
        for (int i = 0; i < this.count; ++i) {
            int n;
            int n2;
            String string2;
            int n3;
            OTPEditText oTPEditText = new OTPEditText(this.getContext(), i);
            oTPEditText.setMargin((int)this.dp2px(22));
            oTPEditText.setInputType(this.inputType);
            int n4 = this.textColor;
            if (n4 != -1) {
                oTPEditText.setTextColor(n4);
            }
            if ((n2 = this.hintColor) != -1) {
                oTPEditText.setHintTextColor(n2);
            }
            if ((n3 = this.viewsPadding) != -1) {
                oTPEditText.setMargin(n3);
            }
            if ((n = this.textSize) != -1) {
                oTPEditText.setTextSize(this.dp2px(n));
            }
            if ((string2 = this.hint) != null && string2.length() > 0) {
                oTPEditText.setHint((CharSequence)this.hint.substring(0, 1));
            }
            this.addView((View)oTPEditText);
        }
        this.getChildAt(0).requestFocus();
    }

    public void focusChange(View view) {
        if (((OTPEditText)view).getOrder() < -1 + this.getOtp().length()) {
            this.setFocus();
            InputMethodManager inputMethodManager = (InputMethodManager)this.getContext().getSystemService("input_method");
            if (inputMethodManager != null) {
                inputMethodManager.toggleSoftInputFromWindow(this.getApplicationWindowToken(), 2, 0);
            }
        }
    }

    public String getOtp() {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < this.getChildCount(); ++i) {
            stringBuilder.append(((OTPEditText)this.getChildAt(i)).getText().toString());
        }
        return stringBuilder.toString();
    }

    public void onBackPressed(OTPEditText oTPEditText) {
        OTPEditText oTPEditText2 = (OTPEditText)this.getChildAt(-1 + oTPEditText.getOrder());
        if (oTPEditText2 != null) {
            oTPEditText2.setText((CharSequence)"");
            oTPEditText2.requestFocus();
        }
    }

    public void onKeyPressed(OTPEditText oTPEditText) {
        OTPEditText oTPEditText2 = (OTPEditText)this.getChildAt(1 + oTPEditText.getOrder());
        if (oTPEditText2 != null) {
            oTPEditText2.requestFocus();
            return;
        }
        InputMethodManager inputMethodManager = (InputMethodManager)this.getContext().getSystemService("input_method");
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(this.getWindowToken(), 0);
        }
        this.requestFocus();
        OTPListener oTPListener = this.listener;
        if (oTPListener != null) {
            oTPListener.otpFinished(this.getOtp());
        }
    }

    public OTPView setCount(int n) {
        this.count = n;
        return this;
    }

    public OTPView setFocus() {
        View view = this.getChildAt(this.getOtp().length());
        if (view != null) {
            view.requestFocus();
            return this;
        }
        this.getChildAt(-1 + this.getChildCount()).requestFocus();
        return this;
    }

    public OTPView setHint(String string2) {
        this.hint = string2;
        return this;
    }

    public OTPView setHintColor(int n) {
        this.hintColor = n;
        return this;
    }

    public OTPView setInputType(int n) {
        this.inputType = n;
        return this;
    }

    public OTPView setListener(OTPListener oTPListener) {
        this.listener = oTPListener;
        return this;
    }

    public OTPView setOtp(String string2) {
        if (string2 != null) {
            for (int i = 0; i < string2.length(); ++i) {
                ((OTPEditText)this.getChildAt(i)).setText((CharSequence)String.valueOf((char)string2.toCharArray()[i]));
            }
        }
        return this;
    }

    public OTPView setTextColor(int n) {
        this.textColor = n;
        return this;
    }

    public OTPView setTextSize(int n) {
        this.textSize = n;
        return this;
    }

    public OTPView setViewsPadding(int n) {
        this.viewsPadding = n;
        return this;
    }
}

