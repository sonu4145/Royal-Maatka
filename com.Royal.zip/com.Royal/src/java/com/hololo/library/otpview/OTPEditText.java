/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.text.Editable
 *  android.text.InputFilter
 *  android.text.InputFilter$LengthFilter
 *  android.text.TextWatcher
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnFocusChangeListener
 *  android.view.View$OnKeyListener
 *  android.view.View$OnTouchListener
 *  android.view.ViewParent
 *  androidx.appcompat.widget.AppCompatEditText
 *  java.lang.CharSequence
 *  java.lang.String
 */
package com.hololo.library.otpview;

import android.content.Context;
import android.content.res.Resources;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import androidx.appcompat.widget.AppCompatEditText;
import com.hololo.library.otpview.OTPEditText;
import com.hololo.library.otpview.OTPView;

class OTPEditText
extends AppCompatEditText
implements TextWatcher,
View.OnFocusChangeListener,
View.OnClickListener,
View.OnTouchListener {
    private int order;

    public OTPEditText(Context context, int n) {
        super(context);
        this.order = n;
        this.init();
    }

    public OTPEditText(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet);
        this.order = n;
        this.init();
    }

    public OTPEditText(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n);
        this.order = n2;
        this.init();
    }

    private void changeBackground(boolean bl) {
        this.setBackgroundColor(0);
        if (!bl) {
            ((OTPView)this.getParent()).onKeyPressed(this);
        }
    }

    private float dp2px(int n) {
        return 0.5f + this.getContext().getResources().getDisplayMetrics().density * (float)n;
    }

    public void afterTextChanged(Editable editable) {
        this.changeBackground(editable.toString().isEmpty());
    }

    public void beforeTextChanged(CharSequence charSequence, int n, int n2, int n3) {
    }

    public int getOrder() {
        return this.order;
    }

    public void init() {
        this.setHint((CharSequence)"*");
        this.setCursorVisible(false);
        this.changeBackground(true);
        this.addTextChangedListener((TextWatcher)this);
        this.setOnTouchListener((View.OnTouchListener)this);
        this.setClickable(true);
        this.setMaxLines(1);
        InputFilter[] arrinputFilter = new InputFilter[]{new InputFilter.LengthFilter(1)};
        this.setFilters(arrinputFilter);
        this.setOnClickListener((View.OnClickListener)this);
        this.setOnFocusChangeListener((View.OnFocusChangeListener)this);
        this.setOnKeyListener(new View.OnKeyListener(this){
            final /* synthetic */ OTPEditText this$0;
            {
                this.this$0 = oTPEditText;
            }

            public boolean onKey(View view, int n, android.view.KeyEvent keyEvent) {
                if (n == 67 && this.this$0.getParent() instanceof OTPView) {
                    this.this$0.setText((CharSequence)"");
                    ((OTPView)this.this$0.getParent()).onBackPressed(this.this$0);
                }
                return false;
            }
        });
    }

    public void onClick(View view) {
        ((OTPView)this.getParent()).setFocus();
    }

    public void onFocusChange(View view, boolean bl) {
        if (bl) {
            ((OTPView)this.getParent()).focusChange(view);
        }
    }

    public void onTextChanged(CharSequence charSequence, int n, int n2, int n3) {
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        ((OTPView)this.getParent()).setFocus();
        return false;
    }

    public void setMargin(int n) {
        this.setPadding(n, n, n, n);
    }
}

