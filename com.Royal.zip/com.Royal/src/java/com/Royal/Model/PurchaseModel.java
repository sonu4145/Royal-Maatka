/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class PurchaseModel {
    String date;
    String point;
    String resultId;
    String type;
    String winpoint;

    public String getDate() {
        return this.date;
    }

    public String getPoint() {
        return this.point;
    }

    public String getResultId() {
        return this.resultId;
    }

    public String getType() {
        return this.type;
    }

    public String getWinpoint() {
        return this.winpoint;
    }

    public void setDate(String string2) {
        this.date = string2;
    }

    public void setPoint(String string2) {
        this.point = string2;
    }

    public void setResultId(String string2) {
        this.resultId = string2;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    public void setWinpoint(String string2) {
        this.winpoint = string2;
    }
}

