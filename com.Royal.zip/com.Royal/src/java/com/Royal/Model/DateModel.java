/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class DateModel {
    String enddate;
    String startdate;
    String stdate;
    String stid;
    String stpana;

    public DateModel() {
    }

    public DateModel(String string2, String string3) {
        this.startdate = string2;
        this.enddate = string3;
    }

    public String getEnddate() {
        return this.enddate;
    }

    public String getStartdate() {
        return this.startdate;
    }

    public String getStdate() {
        return this.stdate;
    }

    public String getStid() {
        return this.stid;
    }

    public String getStpana() {
        return this.stpana;
    }

    public void setEnddate(String string2) {
        this.enddate = string2;
    }

    public void setStartdate(String string2) {
        this.startdate = string2;
    }

    public void setStdate(String string2) {
        this.stdate = string2;
    }

    public void setStid(String string2) {
        this.stid = string2;
    }

    public void setStpana(String string2) {
        this.stpana = string2;
    }
}

