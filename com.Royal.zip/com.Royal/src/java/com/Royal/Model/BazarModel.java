/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class BazarModel {
    String ank;
    String bazaarSideId;
    String bazarid;
    String createdOn;
    String fridayCloseTime;
    String fridayOpenTime;
    String id;
    String isFriday;
    String isMonday;
    String isSaturday;
    String isStatus;
    String isSunday;
    String isThursday;
    String isTuesday;
    String isWednesday;
    String jodi;
    String mondayCloseTime;
    String mondayOpenTime;
    String name;
    String pana;
    String saturdayCloseTime;
    String saturdayOpenTime;
    String sundayCloseTime;
    String sundayOpenTime;
    String thursdayCloseTime;
    String thursdayOpenTime;
    String tuesdayCloseTime;
    String tuesdayOpenTime;
    String updatedOn;
    String wednesdayCloseTime;
    String wednesdayOpenTime;

    public String getAnk() {
        return this.ank;
    }

    public String getBazaarSideId() {
        return this.bazaarSideId;
    }

    public String getBazarid() {
        return this.bazarid;
    }

    public String getCreatedOn() {
        return this.createdOn;
    }

    public String getFridayCloseTime() {
        return this.fridayCloseTime;
    }

    public String getFridayOpenTime() {
        return this.fridayOpenTime;
    }

    public String getId() {
        return this.id;
    }

    public String getIsFriday() {
        return this.isFriday;
    }

    public String getIsMonday() {
        return this.isMonday;
    }

    public String getIsSaturday() {
        return this.isSaturday;
    }

    public String getIsStatus() {
        return this.isStatus;
    }

    public String getIsSunday() {
        return this.isSunday;
    }

    public String getIsThursday() {
        return this.isThursday;
    }

    public String getIsTuesday() {
        return this.isTuesday;
    }

    public String getIsWednesday() {
        return this.isWednesday;
    }

    public String getJodi() {
        return this.jodi;
    }

    public String getMondayCloseTime() {
        return this.mondayCloseTime;
    }

    public String getMondayOpenTime() {
        return this.mondayOpenTime;
    }

    public String getName() {
        return this.name;
    }

    public String getPana() {
        return this.pana;
    }

    public String getSaturdayCloseTime() {
        return this.saturdayCloseTime;
    }

    public String getSaturdayOpenTime() {
        return this.saturdayOpenTime;
    }

    public String getSundayCloseTime() {
        return this.sundayCloseTime;
    }

    public String getSundayOpenTime() {
        return this.sundayOpenTime;
    }

    public String getThursdayCloseTime() {
        return this.thursdayCloseTime;
    }

    public String getThursdayOpenTime() {
        return this.thursdayOpenTime;
    }

    public String getTuesdayCloseTime() {
        return this.tuesdayCloseTime;
    }

    public String getTuesdayOpenTime() {
        return this.tuesdayOpenTime;
    }

    public String getUpdatedOn() {
        return this.updatedOn;
    }

    public String getWednesdayCloseTime() {
        return this.wednesdayCloseTime;
    }

    public String getWednesdayOpenTime() {
        return this.wednesdayOpenTime;
    }

    public void setAnk(String string2) {
        this.ank = string2;
    }

    public void setBazaarSideId(String string2) {
        this.bazaarSideId = string2;
    }

    public void setBazarid(String string2) {
        this.bazarid = string2;
    }

    public void setCreatedOn(String string2) {
        this.createdOn = string2;
    }

    public void setFridayCloseTime(String string2) {
        this.fridayCloseTime = string2;
    }

    public void setFridayOpenTime(String string2) {
        this.fridayOpenTime = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setIsFriday(String string2) {
        this.isFriday = string2;
    }

    public void setIsMonday(String string2) {
        this.isMonday = string2;
    }

    public void setIsSaturday(String string2) {
        this.isSaturday = string2;
    }

    public void setIsStatus(String string2) {
        this.isStatus = string2;
    }

    public void setIsSunday(String string2) {
        this.isSunday = string2;
    }

    public void setIsThursday(String string2) {
        this.isThursday = string2;
    }

    public void setIsTuesday(String string2) {
        this.isTuesday = string2;
    }

    public void setIsWednesday(String string2) {
        this.isWednesday = string2;
    }

    public void setJodi(String string2) {
        this.jodi = string2;
    }

    public void setMondayCloseTime(String string2) {
        this.mondayCloseTime = string2;
    }

    public void setMondayOpenTime(String string2) {
        this.mondayOpenTime = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setPana(String string2) {
        this.pana = string2;
    }

    public void setSaturdayCloseTime(String string2) {
        this.saturdayCloseTime = string2;
    }

    public void setSaturdayOpenTime(String string2) {
        this.saturdayOpenTime = string2;
    }

    public void setSundayCloseTime(String string2) {
        this.sundayCloseTime = string2;
    }

    public void setSundayOpenTime(String string2) {
        this.sundayOpenTime = string2;
    }

    public void setThursdayCloseTime(String string2) {
        this.thursdayCloseTime = string2;
    }

    public void setThursdayOpenTime(String string2) {
        this.thursdayOpenTime = string2;
    }

    public void setTuesdayCloseTime(String string2) {
        this.tuesdayCloseTime = string2;
    }

    public void setTuesdayOpenTime(String string2) {
        this.tuesdayOpenTime = string2;
    }

    public void setUpdatedOn(String string2) {
        this.updatedOn = string2;
    }

    public void setWednesdayCloseTime(String string2) {
        this.wednesdayCloseTime = string2;
    }

    public void setWednesdayOpenTime(String string2) {
        this.wednesdayOpenTime = string2;
    }
}

