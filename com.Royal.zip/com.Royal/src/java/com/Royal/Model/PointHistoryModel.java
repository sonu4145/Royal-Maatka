/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class PointHistoryModel {
    String accountType;
    String actionid;
    String actiontype;
    String availablepoint;
    String createdOn;
    String id;
    String isStatus;
    String point;
    String requestType;
    String senderorreciever;
    String userid;

    public String getAccountType() {
        return this.accountType;
    }

    public String getActionid() {
        return this.actionid;
    }

    public String getActiontype() {
        return this.actiontype;
    }

    public String getAvailablepoint() {
        return this.availablepoint;
    }

    public String getCreatedOn() {
        return this.createdOn;
    }

    public String getId() {
        return this.id;
    }

    public String getIsStatus() {
        return this.isStatus;
    }

    public String getPoint() {
        return this.point;
    }

    public String getRequestType() {
        return this.requestType;
    }

    public String getSenderorreciever() {
        return this.senderorreciever;
    }

    public String getUserid() {
        return this.userid;
    }

    public void setAccountType(String string2) {
        this.accountType = string2;
    }

    public void setActionid(String string2) {
        this.actionid = string2;
    }

    public void setActiontype(String string2) {
        this.actiontype = string2;
    }

    public void setAvailablepoint(String string2) {
        this.availablepoint = string2;
    }

    public void setCreatedOn(String string2) {
        this.createdOn = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setIsStatus(String string2) {
        this.isStatus = string2;
    }

    public void setPoint(String string2) {
        this.point = string2;
    }

    public void setRequestType(String string2) {
        this.requestType = string2;
    }

    public void setSenderorreciever(String string2) {
        this.senderorreciever = string2;
    }

    public void setUserid(String string2) {
        this.userid = string2;
    }
}

