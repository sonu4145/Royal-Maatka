/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class SubsetModel {
    String digitset;

    public String getDigitset() {
        return this.digitset;
    }

    public void setDigitset(String string2) {
        this.digitset = string2;
    }
}

