/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class BidingModel {
    String Date;
    String digit;
    String ponts;
    String type;

    public String getDate() {
        return this.Date;
    }

    public String getDigit() {
        return this.digit;
    }

    public String getPonts() {
        return this.ponts;
    }

    public String getType() {
        return this.type;
    }

    public void setDate(String string2) {
        this.Date = string2;
    }

    public void setDigit(String string2) {
        this.digit = string2;
    }

    public void setPonts(String string2) {
        this.ponts = string2;
    }

    public void setType(String string2) {
        this.type = string2;
    }
}

