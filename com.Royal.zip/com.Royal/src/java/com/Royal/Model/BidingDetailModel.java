/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class BidingDetailModel {
    String bazaar;
    String createdOn;
    String date;
    String digit;
    String game;
    String isStatus;
    String isToday;
    String point;
    String resultId;
    String session;
    String todayRemaningCancelDayForBid;
    String todayRemaningCancelTimeForCloseBid;
    String todayRemaningCancelTimeForOpenBid;
    String type;
    String userBidTransactionDetailId;
    String winpoint;

    public String getBazaar() {
        return this.bazaar;
    }

    public String getCreatedOn() {
        return this.createdOn;
    }

    public String getDate() {
        return this.date;
    }

    public String getDigit() {
        return this.digit;
    }

    public String getGame() {
        return this.game;
    }

    public String getIsStatus() {
        return this.isStatus;
    }

    public String getIsToday() {
        return this.isToday;
    }

    public String getPoint() {
        return this.point;
    }

    public String getResultId() {
        return this.resultId;
    }

    public String getSession() {
        return this.session;
    }

    public String getTodayRemaningCancelDayForBid() {
        return this.todayRemaningCancelDayForBid;
    }

    public String getTodayRemaningCancelTimeForCloseBid() {
        return this.todayRemaningCancelTimeForCloseBid;
    }

    public String getTodayRemaningCancelTimeForOpenBid() {
        return this.todayRemaningCancelTimeForOpenBid;
    }

    public String getType() {
        return this.type;
    }

    public String getUserBidTransactionDetailId() {
        return this.userBidTransactionDetailId;
    }

    public String getWinpoint() {
        return this.winpoint;
    }

    public void setBazaar(String string2) {
        this.bazaar = string2;
    }

    public void setCreatedOn(String string2) {
        this.createdOn = string2;
    }

    public void setDate(String string2) {
        this.date = string2;
    }

    public void setDigit(String string2) {
        this.digit = string2;
    }

    public void setGame(String string2) {
        this.game = string2;
    }

    public void setIsStatus(String string2) {
        this.isStatus = string2;
    }

    public void setIsToday(String string2) {
        this.isToday = string2;
    }

    public void setPoint(String string2) {
        this.point = string2;
    }

    public void setResultId(String string2) {
        this.resultId = string2;
    }

    public void setSession(String string2) {
        this.session = string2;
    }

    public void setTodayRemaningCancelDayForBid(String string2) {
        this.todayRemaningCancelDayForBid = string2;
    }

    public void setTodayRemaningCancelTimeForCloseBid(String string2) {
        this.todayRemaningCancelTimeForCloseBid = string2;
    }

    public void setTodayRemaningCancelTimeForOpenBid(String string2) {
        this.todayRemaningCancelTimeForOpenBid = string2;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    public void setUserBidTransactionDetailId(String string2) {
        this.userBidTransactionDetailId = string2;
    }

    public void setWinpoint(String string2) {
        this.winpoint = string2;
    }
}

