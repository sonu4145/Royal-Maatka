/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class LockPointHistoryModal {
    String accholdername;
    String accnum;
    String accountname;
    String acctype;
    String createdon;
    String id;
    String isstatus;
    String point;
    String requestype;
    String transactiondate;
    String transactionid;
    String updatedby;
    String updatedon;
    String userid;
    String usertype;

    public String getAccholdername() {
        return this.accholdername;
    }

    public String getAccnum() {
        return this.accnum;
    }

    public String getAccountname() {
        return this.accountname;
    }

    public String getAcctype() {
        return this.acctype;
    }

    public String getCreatedon() {
        return this.createdon;
    }

    public String getId() {
        return this.id;
    }

    public String getIsstatus() {
        return this.isstatus;
    }

    public String getPoint() {
        return this.point;
    }

    public String getRequestype() {
        return this.requestype;
    }

    public String getTransactiondate() {
        return this.transactiondate;
    }

    public String getTransactionid() {
        return this.transactionid;
    }

    public String getUpdatedby() {
        return this.updatedby;
    }

    public String getUpdatedon() {
        return this.updatedon;
    }

    public String getUserid() {
        return this.userid;
    }

    public String getUsertype() {
        return this.usertype;
    }

    public void setAccholdername(String string2) {
        this.accholdername = string2;
    }

    public void setAccnum(String string2) {
        this.accnum = string2;
    }

    public void setAccountname(String string2) {
        this.accountname = string2;
    }

    public void setAcctype(String string2) {
        this.acctype = string2;
    }

    public void setCreatedon(String string2) {
        this.createdon = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setIsstatus(String string2) {
        this.isstatus = string2;
    }

    public void setPoint(String string2) {
        this.point = string2;
    }

    public void setRequestype(String string2) {
        this.requestype = string2;
    }

    public void setTransactiondate(String string2) {
        this.transactiondate = string2;
    }

    public void setTransactionid(String string2) {
        this.transactionid = string2;
    }

    public void setUpdatedby(String string2) {
        this.updatedby = string2;
    }

    public void setUpdatedon(String string2) {
        this.updatedon = string2;
    }

    public void setUserid(String string2) {
        this.userid = string2;
    }

    public void setUsertype(String string2) {
        this.usertype = string2;
    }
}

