/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class RecordModel {
    String Bazar;
    String BazarId;
    String ank;
    String date;
    String jodi;
    String pana;
    String session;

    public String getAnk() {
        return this.ank;
    }

    public String getBazar() {
        return this.Bazar;
    }

    public String getBazarId() {
        return this.BazarId;
    }

    public String getDate() {
        return this.date;
    }

    public String getJodi() {
        return this.jodi;
    }

    public String getPana() {
        return this.pana;
    }

    public String getSession() {
        return this.session;
    }

    public void setAnk(String string2) {
        this.ank = string2;
    }

    public void setBazar(String string2) {
        this.Bazar = string2;
    }

    public void setBazarId(String string2) {
        this.BazarId = string2;
    }

    public void setDate(String string2) {
        this.date = string2;
    }

    public void setJodi(String string2) {
        this.jodi = string2;
    }

    public void setPana(String string2) {
        this.pana = string2;
    }

    public void setSession(String string2) {
        this.session = string2;
    }
}

