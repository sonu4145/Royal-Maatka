/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class BankModel {
    String accountHolderName;
    String accountName;
    String accountNumber;
    String branchName;
    String id;
    String ifscCode;
    String isStatus;
    String type;
    String userId;

    public String getAccountHolderName() {
        return this.accountHolderName;
    }

    public String getAccountName() {
        return this.accountName;
    }

    public String getAccountNumber() {
        return this.accountNumber;
    }

    public String getBranchName() {
        return this.branchName;
    }

    public String getId() {
        return this.id;
    }

    public String getIfscCode() {
        return this.ifscCode;
    }

    public String getIsStatus() {
        return this.isStatus;
    }

    public String getType() {
        return this.type;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setAccountHolderName(String string2) {
        this.accountHolderName = string2;
    }

    public void setAccountName(String string2) {
        this.accountName = string2;
    }

    public void setAccountNumber(String string2) {
        this.accountNumber = string2;
    }

    public void setBranchName(String string2) {
        this.branchName = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setIfscCode(String string2) {
        this.ifscCode = string2;
    }

    public void setIsStatus(String string2) {
        this.isStatus = string2;
    }

    public void setType(String string2) {
        this.type = string2;
    }

    public void setUserId(String string2) {
        this.userId = string2;
    }
}

