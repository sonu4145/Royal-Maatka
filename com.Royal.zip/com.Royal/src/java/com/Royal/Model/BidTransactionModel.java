/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class BidTransactionModel {
    String bazaarSide;
    String bazaarSideId;
    String bidPoint;
    String createdOn;
    String id;
    String isStatus;
    String numberOfBid;
    String userId;

    public String getBazaarSide() {
        return this.bazaarSide;
    }

    public String getBazaarSideId() {
        return this.bazaarSideId;
    }

    public String getBidPoint() {
        return this.bidPoint;
    }

    public String getCreatedOn() {
        return this.createdOn;
    }

    public String getId() {
        return this.id;
    }

    public String getIsStatus() {
        return this.isStatus;
    }

    public String getNumberOfBid() {
        return this.numberOfBid;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setBazaarSide(String string2) {
        this.bazaarSide = string2;
    }

    public void setBazaarSideId(String string2) {
        this.bazaarSideId = string2;
    }

    public void setBidPoint(String string2) {
        this.bidPoint = string2;
    }

    public void setCreatedOn(String string2) {
        this.createdOn = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setIsStatus(String string2) {
        this.isStatus = string2;
    }

    public void setNumberOfBid(String string2) {
        this.numberOfBid = string2;
    }

    public void setUserId(String string2) {
        this.userId = string2;
    }
}

