/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class CloseModel {
    String ank;
    String bazarid;
    String jodi;
    String pana;

    public String getAnk() {
        return this.ank;
    }

    public String getBazarid() {
        return this.bazarid;
    }

    public String getJodi() {
        return this.jodi;
    }

    public String getPana() {
        return this.pana;
    }

    public void setAnk(String string2) {
        this.ank = string2;
    }

    public void setBazarid(String string2) {
        this.bazarid = string2;
    }

    public void setJodi(String string2) {
        this.jodi = string2;
    }

    public void setPana(String string2) {
        this.pana = string2;
    }
}

