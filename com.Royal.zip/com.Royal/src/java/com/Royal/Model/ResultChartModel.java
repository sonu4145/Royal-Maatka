/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class ResultChartModel {
    String friday;
    String monday;
    String saturday;
    String singledate;
    String sunday;
    String thursday;
    String tuesday;
    String wednesday;

    public String getFriday() {
        return this.friday;
    }

    public String getMonday() {
        return this.monday;
    }

    public String getSaturday() {
        return this.saturday;
    }

    public String getSingledate() {
        return this.singledate;
    }

    public String getSunday() {
        return this.sunday;
    }

    public String getThursday() {
        return this.thursday;
    }

    public String getTuesday() {
        return this.tuesday;
    }

    public String getWednesday() {
        return this.wednesday;
    }

    public void setFriday(String string2) {
        this.friday = string2;
    }

    public void setMonday(String string2) {
        this.monday = string2;
    }

    public void setSaturday(String string2) {
        this.saturday = string2;
    }

    public void setSingledate(String string2) {
        this.singledate = string2;
    }

    public void setSunday(String string2) {
        this.sunday = string2;
    }

    public void setThursday(String string2) {
        this.thursday = string2;
    }

    public void setTuesday(String string2) {
        this.tuesday = string2;
    }

    public void setWednesday(String string2) {
        this.wednesday = string2;
    }
}

