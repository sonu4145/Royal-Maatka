/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Model;

public class NewsModel {
    String createdBy;
    String createdOn;
    String id;
    String isStatus;
    String news;

    public String getCreatedBy() {
        return this.createdBy;
    }

    public String getCreatedOn() {
        return this.createdOn;
    }

    public String getId() {
        return this.id;
    }

    public String getIsStatus() {
        return this.isStatus;
    }

    public String getNews() {
        return this.news;
    }

    public void setCreatedBy(String string2) {
        this.createdBy = string2;
    }

    public void setCreatedOn(String string2) {
        this.createdOn = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setIsStatus(String string2) {
        this.isStatus = string2;
    }

    public void setNews(String string2) {
        this.news = string2;
    }
}

