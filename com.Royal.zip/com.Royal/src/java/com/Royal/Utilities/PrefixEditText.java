/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.text.TextPaint
 *  android.util.AttributeSet
 *  androidx.appcompat.widget.AppCompatEditText
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Utilities;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.TextPaint;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatEditText;

public class PrefixEditText
extends AppCompatEditText {
    float mOriginalLeftPadding = -1.0f;

    public PrefixEditText(Context context) {
        super(context);
    }

    public PrefixEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public PrefixEditText(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
    }

    private void calculatePrefix() {
        if (this.mOriginalLeftPadding == -1.0f) {
            float f;
            String string2 = (String)this.getTag();
            int n = string2.length();
            float[] arrf = new float[n];
            this.getPaint().getTextWidths(string2, arrf);
            float f2 = 0.0f;
            for (int i = 0; i < n; ++i) {
                f2 += arrf[i];
            }
            this.mOriginalLeftPadding = f = (float)this.getCompoundPaddingLeft();
            this.setPadding((int)(f2 + f), this.getPaddingRight(), this.getPaddingTop(), this.getPaddingBottom());
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawText((String)this.getTag(), this.mOriginalLeftPadding, (float)this.getLineBounds(0, null), (Paint)this.getPaint());
    }

    protected void onMeasure(int n, int n2) {
        super.onMeasure(n, n2);
        this.calculatePrefix();
    }
}

