/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.widget.Toast
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package com.Royal.Utilities;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.Royal.Utils.CryptoHelper;
import java.io.PrintStream;

public class BaseAppFragments
extends Fragment {
    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public String decryptjson(String string2) {
        void var2_7;
        String string3;
        block4 : {
            string3 = CryptoHelper.decrypt(string2);
            try {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("output:");
                stringBuilder.append(string3);
                printStream.println(stringBuilder.toString());
                return string3;
            }
            catch (Exception exception) {}
            break block4;
            catch (Exception exception) {
                string3 = null;
            }
        }
        var2_7.printStackTrace();
        return string3;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public String encryptjson(String string2) {
        void var2_7;
        String string3;
        block4 : {
            string3 = CryptoHelper.encrypt(string2);
            try {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("cipher:");
                stringBuilder.append(string3);
                printStream.println(stringBuilder.toString());
                return string3;
            }
            catch (Exception exception) {}
            break block4;
            catch (Exception exception) {
                string3 = null;
            }
        }
        var2_7.printStackTrace();
        return string3;
    }

    public boolean isInternetOn() {
        ConnectivityManager connectivityManager = (ConnectivityManager)this.getActivity().getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isAvailable() && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public void showToast(String string2) {
        Toast.makeText((Context)this.getActivity(), (CharSequence)string2, (int)0).show();
    }
}

