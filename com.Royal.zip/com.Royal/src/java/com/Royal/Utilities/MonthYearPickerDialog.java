/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.DatePickerDialog
 *  android.app.DatePickerDialog$OnDateSetListener
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.NumberPicker
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  androidx.fragment.app.DialogFragment
 *  androidx.fragment.app.FragmentActivity
 *  java.util.Calendar
 */
package com.Royal.Utilities;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.NumberPicker;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import com.Royal.Utilities.MonthYearPickerDialog;
import java.util.Calendar;

public class MonthYearPickerDialog
extends DialogFragment {
    private static final int MAX_YEAR = 2099;
    private DatePickerDialog.OnDateSetListener listener;

    static /* synthetic */ DatePickerDialog.OnDateSetListener access$000(MonthYearPickerDialog monthYearPickerDialog) {
        return monthYearPickerDialog.listener;
    }

    public Dialog onCreateDialog(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this.getActivity());
        LayoutInflater layoutInflater = this.getActivity().getLayoutInflater();
        Calendar calendar = Calendar.getInstance();
        View view = layoutInflater.inflate(2131492978, null);
        NumberPicker numberPicker = (NumberPicker)view.findViewById(2131296780);
        NumberPicker numberPicker2 = (NumberPicker)view.findViewById(2131296781);
        numberPicker.setMinValue(1);
        numberPicker.setMaxValue(12);
        numberPicker.setValue(1 + calendar.get(2));
        int n = calendar.get(1);
        numberPicker2.setMinValue(2000);
        numberPicker2.setMaxValue(n);
        numberPicker2.setValue(n);
        builder.setView(view).setPositiveButton(2131820716, new DialogInterface.OnClickListener(this, numberPicker2, numberPicker){
            final /* synthetic */ MonthYearPickerDialog this$0;
            final /* synthetic */ NumberPicker val$monthPicker;
            final /* synthetic */ NumberPicker val$yearPicker;
            {
                this.this$0 = monthYearPickerDialog;
                this.val$yearPicker = numberPicker;
                this.val$monthPicker = numberPicker2;
            }

            public void onClick(DialogInterface dialogInterface, int n) {
                MonthYearPickerDialog.access$000(this.this$0).onDateSet(null, this.val$yearPicker.getValue(), this.val$monthPicker.getValue(), 0);
            }
        }).setNegativeButton(2131820585, new DialogInterface.OnClickListener(this){
            final /* synthetic */ MonthYearPickerDialog this$0;
            {
                this.this$0 = monthYearPickerDialog;
            }

            public void onClick(DialogInterface dialogInterface, int n) {
                this.this$0.getDialog().cancel();
            }
        });
        return builder.create();
    }

    public void setListener(DatePickerDialog.OnDateSetListener onDateSetListener) {
        this.listener = onDateSetListener;
    }
}

