/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$BadTokenException
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.Utilities;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.Window;
import android.view.WindowManager;

public class CommonParams {
    public static final String BASE = "http://www.royalmatka.net/api/v1/";
    public static final String GCM_ID = "gcm_id";
    public static final String NO_IMAGE_FOUND = "No image found";
    public static final String NO_INTERNET_CONNECTION = "No internet connection";
    public static final String PLEASE_GPS_ENABLE = "Please enable gps";
    public static final String SEARCH_ALL_STATE_FILE = "search_all_state_file";
    public static final String SELECT_CITY = "Place Select City";
    public static final String SELECT_STATE = "Please Select State";
    public static final String SOMETHING_HAPPEN_WRONG = "Something went wrong";
    public static final String UNABLE_REACH_SERVER = "Unable to reach Server";
    public static final String URL_AddNewAccount = "http://www.royalmatka.net/api/v1/account/add-new";
    public static final String URL_Add_USer_Bid = "http://www.royalmatka.net/api/v1/bid-transaction/placed";
    public static final String URL_AllBazar = "http://www.royalmatka.net/api/v1/bazaar/all";
    public static final String URL_AppBiddingTime = "http://www.royalmatka.net/api/v1/app-setting/forBidding";
    public static final String URL_AppSetting = "http://www.royalmatka.net/api/v1/app-setting/hasLock";
    public static final String URL_CancelBid = "http://www.royalmatka.net/api/v1/bidding/cancel";
    public static final String URL_Deposit_point = "http://www.royalmatka.net/api/v1/userPoint/deposit";
    public static final String URL_EditBankAccount = "http://www.royalmatka.net/api/v1/account/edit";
    public static final String URL_EditProfile = "http://www.royalmatka.net/api/v1/user/edit";
    public static final String URL_FCM = "http://www.royalmatka.net/api/v1/user/setFcm";
    public static final String URL_GET_MOBILE = "http://www.royalmatka.net/api/v1/admin/contact";
    public static final String URL_GET_YOUTUBE = "http://www.royalmatka.net/api/v1/admin/youtube";
    public static final String URL_GetAllBank = "http://www.royalmatka.net/api/v1/userAccount/all";
    public static final String URL_GetAllNews = "http://www.royalmatka.net/api/v1/news/all";
    public static final String URL_GetBidTransaction = "http://www.royalmatka.net/api/v1/bidding/all";
    public static final String URL_GetBidTransactionDetail = "http://www.royalmatka.net/api/v1/bidding/detail";
    public static final String URL_GetUserTotalPoint = "http://www.royalmatka.net/api/v1/user/point";
    public static final String URL_GetVersion = "http://www.royalmatka.net/api/v1/appSetting/android";
    public static final String URL_Login = "http://www.royalmatka.net/api/v1/user/login";
    public static final String URL_Panel_Chart = "http://www.royalmatka.net/api/v1/record/panelChart";
    public static final String URL_PointHistory = "http://www.royalmatka.net/api/v1/userPoint/history";
    public static final String URL_PointHistoryDetail = "http://www.royalmatka.net/api/v1/userPoint/lockHistoryDetail";
    public static final String URL_PointLOCKHistory = "http://www.royalmatka.net/api/v1/userPoint/lockHistory";
    public static final String URL_Purchase_report = "http://www.royalmatka.net/api/v1/bidding/purchaseReport";
    public static final String URL_Record = "http://www.royalmatka.net/api/v1/record/result";
    public static final String URL_Register = "http://www.royalmatka.net/api/v1/user/registration";
    public static final String URL_RemoveBankAccount = "http://www.royalmatka.net/api/v1/account/remove";
    public static final String URL_ResetPassword = "http://www.royalmatka.net/api/v1/user/changePassword";
    public static final String URL_Result_Chart = "http://www.royalmatka.net/api/v1/record/resultChart";
    public static final String URL_SendOtp = "http://www.royalmatka.net/api/v1/user/registrationOtp";
    public static final String URL_TransferConfirm = "http://www.royalmatka.net/api/v1/userPoint/transferConfirm";
    public static final String URL_TransferPoint = "http://www.royalmatka.net/api/v1/userPoint/transfer";
    public static final String URL_WITHDRAWCANCEL = "http://www.royalmatka.net/api/v1/userPoint/withdrawCancel";
    public static final String URL_WidthrawPoint = "http://www.royalmatka.net/api/v1/userPoint/withdraw";
    public static final String URL_getAllAdminAcc = "http://www.royalmatka.net/api/v1/adminAccount/defaultList";
    public static String addBidTimeGap = "";
    public static final String[] bankname;
    public static final String[] blankspdptp;
    public static String cancelBidTimeGap = "";
    public static final String[] doublepanarule;
    public static final String[] dptp;
    public static final String[] familypanarule;
    public static final String[] jodi;
    public static final String key_value = "56fw#^&";
    public static String lockpoint = "";
    private static ProgressDialog pDialog;
    public static final String[] singlepanaarray;
    public static final String[] spdp;
    public static final String[] spdptp;
    public static final String[] sptp;
    public static String totalpoint = "";
    public static final String[] triplepana;
    public static String userId = "";
    public static final int value_bytes = 16;
    public static final String[] walletname;

    static {
        singlepanaarray = new String[]{"127", "136", "145", "190", "235", "280", "370", "389", "460", "479", "569", "578", "128", "137", "146", "236", "245", "290", "380", "470", "489", "560", "579", "678", "129", "138", "147", "156", "237", "246", "345", "390", "480", "570", "589", "679", "120", "139", "148", "157", "238", "247", "256", "346", "490", "580", "670", "689", "130", "149", "158", "167", "239", "248", "257", "347", "356", "590", "680", "789", "140", "159", "168", "230", "249", "258", "267", "348", "357", "456", "690", "780", "123", "150", "169", "178", "240", "259", "268", "349", "358", "367", "457", "790", "124", "160", "179", "250", "269", "278", "340", "359", "368", "458", "467", "890", "125", "134", "170", "189", "260", "279", "350", "369", "378", "459", "468", "567", "126", "135", "180", "234", "270", "289", "360", "379", "450", "469", "478", "568"};
        doublepanarule = new String[]{"118", "226", "244", "299", "334", "488", "550", "668", "677", "100", "119", "155", "227", "335", "344", "399", "588", "669", "110", "200", "228", "255", "336", "499", "660", "688", "778", "166", "229", "300", "337", "355", "445", "599", "779", "788", "112", "220", "266", "338", "400", "446", "455", "699", "770", "113", "122", "177", "339", "366", "447", "500", "799", "889", "114", "277", "330", "448", "466", "556", "600", "880", "899", "115", "133", "188", "223", "377", "449", "557", "566", "700", "116", "224", "233", "288", "440", "477", "558", "800", "990", "117", "144", "199", "225", "388", "559", "577", "667", "900"};
        triplepana = new String[]{"777", "444", "111", "888", "555", "222", "999", "666", "333", "000"};
        jodi = new String[]{"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99"};
        spdptp = new String[]{"100", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "122", "123", "124", "125", "126", "127", "128", "129", "130", "133", "134", "135", "136", "137", "138", "139", "140", "144", "145", "146", "147", "148", "149", "150", "155", "156", "157", "158", "159", "160", "166", "167", "168", "169", "170", "177", "178", "179", "180", "188", "189", "190", "199", "200", "220", "222", "223", "224", "225", "226", "227", "228", "229", "230", "233", "234", "235", "236", "237", "238", "239", "240", "244", "245", "246", "247", "248", "249", "250", "255", "256", "257", "258", "259", "260", "266", "267", "268", "269", "270", "277", "278", "279", "280", "288", "289", "290", "299", "300", "330", "333", "334", "335", "336", "337", "338", "339", "340", "344", "345", "346", "347", "348", "349", "350", "355", "356", "357", "358", "359", "360", "366", "367", "368", "369", "370", "377", "378", "379", "380", "388", "389", "390", "399", "400", "440", "444", "445", "446", "447", "448", "449", "450", "455", "456", "457", "458", "459", "460", "466", "467", "468", "469", "470", "477", "478", "479", "480", "488", "489", "490", "499", "500", "550", "555", "556", "557", "558", "559", "560", "566", "567", "568", "569", "570", "577", "578", "579", "580", "588", "589", "590", "599", "600", "660", "666", "667", "668", "669", "670", "677", "678", "679", "680", "688", "689", "690", "699", "700", "770", "777", "778", "779", "780", "788", "789", "790", "799", "800", "880", "888", "889", "890", "899", "900", "990", "999", "000"};
        spdp = new String[]{"127", "136", "145", "190", "235", "280", "370", "389", "460", "479", "569", "578", "128", "137", "146", "236", "245", "290", "380", "470", "489", "560", "579", "678", "129", "138", "147", "156", "237", "246", "345", "390", "480", "570", "589", "679", "120", "139", "148", "157", "238", "247", "256", "346", "490", "580", "670", "689", "130", "149", "158", "167", "239", "248", "257", "347", "356", "590", "680", "789", "140", "159", "168", "230", "249", "258", "267", "348", "357", "456", "690", "780", "123", "150", "169", "178", "240", "259", "268", "349", "358", "367", "457", "790", "124", "160", "179", "250", "269", "278", "340", "359", "368", "458", "467", "890", "125", "134", "170", "189", "260", "279", "350", "369", "378", "459", "468", "567", "126", "135", "180", "234", "270", "289", "360", "379", "450", "469", "478", "568", "118", "226", "244", "299", "334", "488", "550", "668", "677", "100", "119", "155", "227", "335", "344", "399", "588", "669", "110", "200", "228", "255", "336", "499", "660", "688", "778", "166", "229", "300", "337", "355", "445", "599", "779", "788", "112", "220", "266", "338", "400", "446", "455", "699", "770", "113", "122", "177", "339", "366", "447", "500", "799", "889", "114", "277", "330", "448", "466", "556", "600", "880", "899", "115", "133", "188", "223", "377", "449", "557", "566", "700", "116", "224", "233", "288", "440", "477", "558", "800", "990", "117", "144", "199", "225", "388", "559", "577", "667", "900"};
        sptp = new String[]{"127", "136", "145", "190", "235", "280", "370", "389", "460", "479", "569", "578", "128", "137", "146", "236", "245", "290", "380", "470", "489", "560", "579", "678", "129", "138", "147", "156", "237", "246", "345", "390", "480", "570", "589", "679", "120", "139", "148", "157", "238", "247", "256", "346", "490", "580", "670", "689", "130", "149", "158", "167", "239", "248", "257", "347", "356", "590", "680", "789", "140", "159", "168", "230", "249", "258", "267", "348", "357", "456", "690", "780", "123", "150", "169", "178", "240", "259", "268", "349", "358", "367", "457", "790", "124", "160", "179", "250", "269", "278", "340", "359", "368", "458", "467", "890", "125", "134", "170", "189", "260", "279", "350", "369", "378", "459", "468", "567", "126", "135", "180", "234", "270", "289", "360", "379", "450", "469", "478", "568", "777", "444", "111", "888", "555", "222", "999", "666", "333", "000"};
        dptp = new String[]{"118", "226", "244", "299", "334", "488", "550", "668", "677", "100", "119", "155", "227", "335", "344", "399", "588", "669", "110", "200", "228", "255", "336", "499", "660", "688", "778", "166", "229", "300", "337", "355", "445", "599", "779", "788", "112", "220", "266", "338", "400", "446", "455", "699", "770", "113", "122", "177", "339", "366", "447", "500", "799", "889", "114", "277", "330", "448", "466", "556", "600", "880", "899", "115", "133", "188", "223", "377", "449", "557", "566", "700", "116", "224", "233", "288", "440", "477", "558", "800", "990", "117", "144", "199", "225", "388", "559", "577", "667", "900", "777", "444", "111", "888", "555", "222", "999", "666", "333", "000"};
        blankspdptp = new String[]{""};
        familypanarule = new String[]{"128", "245", "129", "345", "120", "139", "130", "239", "140", "230", "227", "137", "290", "147", "390", "157", "148", "158", "248", "159", "258", "277", "236", "470", "246", "480", "256", "346", "356", "347", "456", "357", "222", "678", "579", "679", "589", "670", "689", "680", "789", "690", "780", "777", "123", "240", "124", "340", "125", "134", "135", "234", "145", "235", "449", "178", "259", "179", "359", "170", "189", "180", "289", "190", "280", "499", "268", "457", "269", "458", "260", "369", "360", "379", "460", "370", "444", "367", "790", "467", "890", "567", "468", "568", "478", "569", "578", "999", "146", "380", "138", "156", "238", "247", "167", "257", "168", "429", "166", "119", "335", "336", "110", "337", "229", "112", "220", "113", "447", "116", "669", "588", "688", "660", "788", "779", "266", "770", "366", "799", "111", "169", "358", "368", "160", "378", "279", "126", "270", "136", "479", "666", "114", "330", "133", "115", "233", "224", "117", "225", "118", "244", "338", "466", "880", "188", "566", "288", "477", "667", "577", "668", "299", "388", "489", "560", "237", "570", "490", "580", "149", "590", "267", "348", "888", "344", "100", "228", "200", "445", "300", "446", "400", "122", "339", "333", "399", "155", "778", "255", "599", "355", "699", "455", "177", "889", "500", "349", "150", "278", "250", "459", "350", "469", "450", "127", "389", "550", "448", "556", "223", "557", "440", "558", "144", "559", "226", "334", "555", "899", "600", "377", "700", "990", "800", "199", "900", "677", "488", "0"};
        bankname = new String[]{"Select Bank Name", "ABHYUDAYA CO-OP BANK LTD", "ABU DHABI COMMERCIAL BANK", "AKOLA DISTRICT CENTRAL CO-OPERATIVE BANK", "AKOLA JANATA COMMERCIAL COOPERATIVE BANK", "ALLAHABAD BANK", "ALMORA URBAN CO-OPERATIVE BANK LTD", "ANDHRA BANK", "ANDHRA PRAGATHI GRAMEENA BANK", "APNA SAHAKARI BANK LTD", "AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED", "AXIS BANK", "BANK INTERNASIONAL INDONESIA", "BANK OF AMERICA", "BANK OF BAHRAIN AND KUWAIT", "BANK OF BARODA", "BANK OF CEYLON", "BANK OF INDIA", "BANK OF MAHARASHTRA", "BANK OF TOKYO-MITSUBISHI UFJ LTD", "BARCLAYS BANK PLC", "BASSEIN CATHOLIC CO-OP BANK LTD", "BHARATIYA MAHILA BANK LIMITED", "BNP PARIBAS", "CALYON BANK", "CANARA BANK", "CAPITAL LOCAL AREA BANK LTD", "CATHOLIC SYRIAN BANK LTD", "CENTRAL BANK OF INDIA", "CHINATRUST COMMERCIAL BANK", "CITIBANK NA", "CITIZENCREDIT CO-OPERATIVE BANK LTD", "CITY UNION BANK LTD", "COMMONWEALTH BANK OF AUSTRALIA", "CORPORATION BANK", "CREDIT SUISSE AG", "DBS BANK LTD", "DENA BANK", "DEUTSCHE BANK", "DEUTSCHE SECURITIES INDIA PRIVATE LIMITED", "DEVELOPMENT CREDIT BANK LIMITED", "DHANLAXMI BANK LTD", "DICGC", "DOMBIVLI NAGARI SAHAKARI BANK LIMITED", "FIRSTRAND BANK LIMITED", "GOPINATH PATIL PARSIK JANATA SAHAKARI BANK LTD", "GURGAON GRAMIN BANK", "HDFC BANK LTD", "HSBC", "ICICI BANK LTD", "IDBI BANK LTD", "IDRBT", "INDIAN BANK", "INDIAN OVERSEAS BANK", "INDUSIND BANK LTD", "INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED", "ING VYSYA BANK LTD", "JALGAON JANATA SAHKARI BANK LTD", "JANAKALYAN SAHAKARI BANK LTD", "JANASEVA SAHAKARI BANK (BORIVLI) LTD", "JANASEVA SAHAKARI BANK LTD. PUNE", "JANATA SAHAKARI BANK LTD (PUNE)", "JPMORGAN CHASE BANK N.A", "KALLAPPANNA AWADE ICH JANATA S BANK", "KAPOL CO OP BANK", "KARNATAKA BANK LTD", "KARNATAKA VIKAS GRAMEENA BANK", "KARUR VYSYA BANK", "KOTAK MAHINDRA BANK", "KURMANCHAL NAGAR SAHKARI BANK LTD", "MAHANAGAR CO-OP BANK LTD", "MAHARASHTRA STATE CO OPERATIVE BANK", "MASHREQBANK PSC", "MIZUHO CORPORATE BANK LTD", "MUMBAI DISTRICT CENTRAL CO-OP. BANK LTD", "NAGPUR NAGRIK SAHAKARI BANK LTD", "NATIONAL AUSTRALIA BANK", "NEW INDIA CO-OPERATIVE BANK LTD", "NKGSB CO-OP BANK LTD", "NORTH MALABAR GRAMIN BANK", "NUTAN NAGARIK SAHAKARI BANK LTD", "OMAN INTERNATIONAL BANK SAOG", "ORIENTAL BANK OF COMMERCE", "PARSIK JANATA SAHAKARI BANK LTD", "PRATHAMA BANK", "PRIME CO OPERATIVE BANK LTD", "PUNJAB AND MAHARASHTRA CO-OP BANK LTD", "PUNJAB AND SIND BANK", "PUNJAB NATIONAL BANK", "RABOBANK INTERNATIONAL (CCRB)", "RAJGURUNAGAR SAHAKARI BANK LTD", "RAJKOT NAGARIK SAHAKARI BANK LTD ", "RESERVE BANK OF INDIA", "SBERBANK", "SHINHAN BANK", "SHRI CHHATRAPATI RAJARSHI SHAHU URBAN CO-OP BANK LTD", "SOCIETE GENERALE", "SOLAPUR JANATA SAHKARI BANK LTD.SOLAPUR", "SOUTH INDIAN BANK", "STANDARD CHARTERED BANK", "STATE BANK OF BIKANER AND JAIPUR", "STATE BANK OF HYDERABAD", "STATE BANK OF INDIA", "STATE BANK OF MAURITIUS LTD", "STATE BANK OF MYSORE", "STATE BANK OF PATIALA", "STATE BANK OF TRAVANCORE", "SUMITOMO MITSUI BANKING CORPORATION", "SYNDICATE BANK", "TAMILNAD MERCANTILE BANK LTD", "THANE BHARAT SAHAKARI BANK LTD", "THE A.P. MAHESH CO-OP URBAN BANK LTD", "THE AHMEDABAD MERCANTILE CO-OPERATIVE BANK LTD", "THE ANDHRA PRADESH STATE COOP BANK LTD", "THE BANK OF NOVA SCOTIA", "THE BANK OF RAJASTHAN LTD", "THE BHARAT CO-OPERATIVE BANK (MUMBAI) LTD", "THE COSMOS CO-OPERATIVE BANK LTD", "THE DELHI STATE COOPERATIVE BANK LTD", "THE FEDERAL BANK LTD", "THE GADCHIROLI DISTRICT CENTRAL COOPERATIVE BANK LTD", "THE GREATER BOMBAY CO-OP. BANK LTD", "THE GUJARAT STATE CO-OPERATIVE BANK LTD", "THE JALGAON PEOPLES CO-OP BANK", "THE JAMMU AND KASHMIR BANK LTD", "THE KALUPUR COMMERCIAL CO. OP. BANK LTD", "THE KALYAN JANATA SAHAKARI BANK LTD", "THE KANGRA CENTRAL CO-OPERATIVE BANK LTD", "THE KANGRA COOPERATIVE BANK LTD", "THE KARAD URBAN CO-OP BANK LTD", "THE KARNATAKA STATE APEX COOP. BANK LTD", "THE LAKSHMI VILAS BANK LTD", "THE MEHSANA URBAN COOPERATIVE BANK LTD", "THE MUNICIPAL CO OPERATIVE BANK LTD MUMBAI", "THE NAINITAL BANK LIMITED", "THE NASIK MERCHANTS CO-OP BANK LTD., NASHIK", "THE RAJASTHAN STATE COOPERATIVE BANK LTD", "THE RATNAKAR BANK LTD", "THE ROYAL BANK OF SCOTLAND N.V", "THE SAHEBRAO DESHMUKH CO-OP. BANK LTD", "THE SARASWAT CO-OPERATIVE BANK LTD", "THE SEVA VIKAS CO-OPERATIVE BANK LTD (SVB)", "THE SHAMRAO VITHAL CO-OPERATIVE BANK LTD", "THE SURAT DISTRICT CO OPERATIVE BANK LTD", "THE SURAT PEOPLES CO-OP BANK LTD", "THE SUTEX CO.OP. BANK LTD", "THE TAMILNADU STATE APEX COOPERATIVE BANK LIMITED", "THE THANE DISTRICT CENTRAL CO-OP BANK LTD", "THE THANE JANATA SAHAKARI BANK LTD", "THE VARACHHA CO-OP. BANK LTD", "THE VISHWESHWAR SAHAKARI BANK LTD.,PUNE", "THE WEST BENGAL STATE COOPERATIVE BANK LTD", "TJSB SAHAKARI BANK LTD", "TUMKUR GRAIN MERCHANTS COOPERATIVE BANK LTD", "UBS AG", "UCO BANK", "UNION BANK OF INDIA", "UNITED BANK OF INDIA", "UNITED OVERSEAS BANK", "VASAI VIKAS SAHAKARI BANK LTD", "VIJAYA BANK", "WEST BENGAL STATE COOPERATIVE BANK", "WESTPAC BANKING CORPORATION", "WOORI BANK", "YES BANK LTD", "ZILA SAHKARI BANK LTD GHAZIABAD"};
        walletname = new String[]{"Select Account Name", "Paytm", "MobiKwik", "FreeCharge", "Oxigen Wallet", "Jio Money", "Airtel Money", "Vodafone M-paise", "mRupee", "PayUMoney", "JusPay", "Citi Master Pass", "Citrus Pay", "HDFC PayZapp", "ICICI Pockets", "Axis Bank Lime", "State Bank Buddy"};
    }

    public static ProgressDialog createProgressDialog(Context context) {
        ProgressDialog progressDialog = new ProgressDialog(context);
        try {
            progressDialog.show();
        }
        catch (WindowManager.BadTokenException badTokenException) {
            badTokenException.printStackTrace();
        }
        progressDialog.setCancelable(false);
        progressDialog.getWindow().setBackgroundDrawable((Drawable)new ColorDrawable(0));
        progressDialog.setContentView(2131493025);
        return progressDialog;
    }

    public static void hideProgressDialog() {
        if (pDialog.isShowing()) {
            pDialog.hide();
        }
    }

    public static void showProgressDialog(Context context) {
        ProgressDialog progressDialog;
        pDialog = progressDialog = new ProgressDialog(context);
        progressDialog.setMessage((CharSequence)"Loading...");
        pDialog.setCancelable(false);
        pDialog.show();
    }
}

