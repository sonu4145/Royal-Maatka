/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Resources
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.os.Bundle
 *  android.os.CountDownTimer
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RadioButton
 *  android.widget.RadioGroup
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.recyclerview.widget.RecyclerView
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 */
package com.Royal.Utilities;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.BidingAdapter;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utils.CryptoHelper;
import com.Royal.Utils.GameUtils;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.BazaarData;
import com.Royal.data.BazaarTimeData;
import com.Royal.data.BiddingData;
import com.Royal.data.DayData;
import com.Royal.data.DaysName;
import com.Royal.data.GamesName;
import com.Royal.data.UserData;
import com.Royal.data.helper.CalenderHelper;
import com.Royal.data.remote.GameDataRepository;
import com.Royal.data.remote.GameDataSource;
import com.Royal.data.remote.UserDataRepository;
import com.Royal.data.remote.UserDataSource;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class BaseAppCompactActivity
extends AppCompatActivity {
    public static long myPoints;
    public BidingAdapter adapter;
    public Button add;
    public RadioButton close;
    public CountDownTimer countDownTimer;
    public BazaarData data;
    public TextView day;
    public List<Calendar> daylist = new ArrayList();
    public ArrayList<String> daysData = new ArrayList();
    public Spinner dayspiner;
    public GamesName gamesName = GamesName.ANK;
    public Button goodluck;
    public TextView hour;
    public ImageView imageBack;
    public LinearLayout layout_bid_container;
    public GameDataRepository mGameDataRepository;
    public Dialog mProgressDialog;
    public UserDataRepository mUserDataRepository;
    public TextView minute;
    public RadioButton open;
    public RadioGroup radioGroup;
    public RecyclerView recyclerView;
    public TextView second;
    public Calendar selectDate = null;
    public TextView textMainTitle;
    public TextView textTitle;
    public BazaarTimeData timeData;
    public TextView totalbid;
    public TextView totalpoint;
    public TextView tvpoints;
    public TextView txtpoints;
    public UserData userData;

    public void AddBidding() {
        if (!this.isInternetOn() && BiddingData.getBiddingData().size() < 1) {
            return;
        }
        if (!this.isShowingProgress()) {
            this.showProgress(true);
        }
        this.mGameDataRepository.placeBid(this.data, new GameDataSource.GetBidPlaceCallBack(){

            @Override
            public void onBidPlaced(String string2) {
                BaseAppCompactActivity.this.showProgress(false);
                BaseAppCompactActivity.this.showToast(string2);
                BaseAppCompactActivity.myPoints = Long.parseLong((String)BaseAppCompactActivity.this.tvpoints.getText().toString()) - (long)BiddingData.getTotalPoints();
                BaseAppCompactActivity.this.userData.setTotalPoint(Integer.parseInt((String)String.valueOf((long)BaseAppCompactActivity.myPoints)));
                SharedPreferences.Editor editor = BaseAppCompactActivity.this.getSharedPreferences("shared", 0).edit();
                editor.putInt("tp", BaseAppCompactActivity.this.userData.getTotalPoint());
                editor.apply();
                BaseAppCompactActivity.this.onBackPressed();
            }

            @Override
            public void onErrorInLoading(String string2) {
                BaseAppCompactActivity.this.showProgress(false);
                BaseAppCompactActivity.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                BaseAppCompactActivity.this.showProgress(false);
                BaseAppCompactActivity.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)BaseAppCompactActivity.this);
            }
        });
    }

    public String FuncCheckDoublePana(String string2, String string3, String string4) {
        if (Integer.parseInt((String)string2) > 0 && (Integer.parseInt((String)string2) > 0 && Integer.parseInt((String)string3) == Integer.parseInt((String)string4) && string4.equals((Object)"0") || Integer.parseInt((String)string2) < Integer.parseInt((String)string3) && Integer.parseInt((String)string3) == Integer.parseInt((String)string4) || Integer.parseInt((String)string2) == Integer.parseInt((String)string3) && (Integer.parseInt((String)string3) < Integer.parseInt((String)string4) || string4.equals((Object)"0")))) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append("");
            stringBuilder.append(string3);
            stringBuilder.append("");
            stringBuilder.append(string4);
            return stringBuilder.toString();
        }
        return "";
    }

    public String FuncCheckSinglePana(String string2, String string3, String string4) {
        if (Integer.parseInt((String)string2) > 0 && Integer.parseInt((String)string2) < Integer.parseInt((String)string3) && (Integer.parseInt((String)string3) < Integer.parseInt((String)string4) || string4.equals((Object)"0"))) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append("");
            stringBuilder.append(string3);
            stringBuilder.append("");
            stringBuilder.append(string4);
            return stringBuilder.toString();
        }
        return "";
    }

    public String FuncCheckTripplePana(String string2, String string3, String string4) {
        if (Integer.parseInt((String)string2) == Integer.parseInt((String)string3) && Integer.parseInt((String)string3) == Integer.parseInt((String)string4)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append("");
            stringBuilder.append(string3);
            stringBuilder.append("");
            stringBuilder.append(string4);
            return stringBuilder.toString();
        }
        return "";
    }

    public boolean checkAndSetupForDay(Calendar calendar, DaysName daysName, String string2) {
        block9 : {
            boolean bl;
            boolean bl2;
            block18 : {
                block19 : {
                    block15 : {
                        block16 : {
                            block17 : {
                                DayData dayData;
                                Calendar calendar2;
                                block13 : {
                                    block14 : {
                                        block10 : {
                                            block11 : {
                                                block12 : {
                                                    calendar2 = Calendar.getInstance();
                                                    calendar2.setTime(CalenderHelper.currentCalendar.getTime());
                                                    if (!CalenderHelper.weekDayFullNameFormat.format(calendar.getTime()).equalsIgnoreCase(string2) || !(dayData = this.timeData.getDayData(daysName)).getIsActive()) break block9;
                                                    if (!this.timeData.hasOpenSession(this.gamesName) || dayData.getCalOpenTime() == null) break block10;
                                                    Calendar calendar3 = Calendar.getInstance();
                                                    calendar3.setTime(calendar.getTime());
                                                    calendar3.set(11, dayData.getCalOpenTime().get(11));
                                                    calendar3.set(12, dayData.getCalOpenTime().get(12));
                                                    calendar3.set(13, dayData.getCalOpenTime().get(13));
                                                    if (this.timeData.hasOpenResult(calendar3)) break block11;
                                                    if (CalenderHelper.isTimeInPast(calendar2, calendar3, this.timeData.getCreateBidTimeGapInMinute())) break block12;
                                                    if (!this.open.isChecked() && !this.close.isChecked()) {
                                                        this.open.setEnabled(true);
                                                        this.open.setChecked(true);
                                                        this.startTimer(calendar2, calendar3);
                                                    } else if (this.open.isChecked()) {
                                                        this.open.setEnabled(true);
                                                        this.startTimer(calendar2, calendar3);
                                                    }
                                                    bl2 = true;
                                                    break block13;
                                                }
                                                this.open.setEnabled(false);
                                                break block14;
                                            }
                                            this.open.setEnabled(false);
                                            break block14;
                                        }
                                        this.open.setEnabled(false);
                                    }
                                    bl2 = false;
                                }
                                if (!this.timeData.hasCloseSession(this.gamesName) || dayData.getCalCloseTime() == null) break block15;
                                Calendar calendar4 = Calendar.getInstance();
                                calendar4.setTime(calendar.getTime());
                                calendar4.set(11, dayData.getCalCloseTime().get(11));
                                calendar4.set(12, dayData.getCalCloseTime().get(12));
                                calendar4.set(13, dayData.getCalCloseTime().get(13));
                                if (this.timeData.hasCloseResult(calendar4)) break block16;
                                if (CalenderHelper.isTimeInPast(calendar2, calendar4, this.timeData.getCreateBidTimeGapInMinute())) break block17;
                                this.close.setEnabled(true);
                                if (!this.open.isChecked() && !this.close.isChecked()) {
                                    this.close.setEnabled(true);
                                    this.close.setChecked(true);
                                    this.startTimer(calendar2, calendar4);
                                } else if (this.close.isChecked()) {
                                    this.close.setEnabled(true);
                                    this.startTimer(calendar2, calendar4);
                                } else if (!bl2) {
                                    this.close.setChecked(true);
                                    this.startTimer(calendar2, calendar);
                                }
                                bl = true;
                                break block18;
                            }
                            this.close.setEnabled(false);
                            break block19;
                        }
                        this.close.setEnabled(false);
                        break block19;
                    }
                    this.close.setEnabled(false);
                }
                bl = false;
            }
            if (bl2 || bl) {
                return true;
            }
        }
        return false;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public String decryptjson(String string2) {
        void var2_7;
        String string3;
        block4 : {
            string3 = CryptoHelper.decrypt(string2);
            try {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("output:");
                stringBuilder.append(string3);
                printStream.println(stringBuilder.toString());
                return string3;
            }
            catch (Exception exception) {}
            break block4;
            catch (Exception exception) {
                string3 = null;
            }
        }
        var2_7.printStackTrace();
        return string3;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public String encryptjson(String string2) {
        void var2_7;
        String string3;
        block4 : {
            string3 = CryptoHelper.encrypt(string2);
            try {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("cipher:");
                stringBuilder.append(string3);
                printStream.println(stringBuilder.toString());
                return string3;
            }
            catch (Exception exception) {}
            break block4;
            catch (Exception exception) {
                string3 = null;
            }
        }
        var2_7.printStackTrace();
        return string3;
    }

    public boolean isInternetOn() {
        ConnectivityManager connectivityManager = (ConnectivityManager)this.getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isAvailable() && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public boolean isShowingProgress() {
        return this.mProgressDialog.isShowing();
    }

    public void loadDate(final boolean bl, final Calendar calendar) {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mGameDataRepository.updateDateTime(new GameDataSource.GetDateTimeUpdateCallBack(){

            @Override
            public void onDateUpdated(Calendar calendar2) {
                if (bl) {
                    BaseAppCompactActivity.this.showProgress(false);
                    BaseAppCompactActivity.this.setupCounterData(calendar);
                    return;
                }
                BaseAppCompactActivity baseAppCompactActivity = BaseAppCompactActivity.this;
                baseAppCompactActivity.daylist = GameUtils.calculateDates(baseAppCompactActivity.timeData, BaseAppCompactActivity.this.gamesName);
                BaseAppCompactActivity.this.setDateSpinner();
            }

            @Override
            public void onErrorInLoading(String string2) {
                BaseAppCompactActivity.this.showProgress(false);
                BaseAppCompactActivity.this.showToast(string2);
                BaseAppCompactActivity.this.onBackPressed();
            }

            @Override
            public void onLocked(String string2) {
                BaseAppCompactActivity.this.showProgress(false);
                BaseAppCompactActivity.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)BaseAppCompactActivity.this);
            }
        });
    }

    public void loadPoints() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mUserDataRepository.getUserPoints(new UserDataSource.GetUserPointsCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                BaseAppCompactActivity.this.showProgress(false);
                BaseAppCompactActivity.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                BaseAppCompactActivity.this.showProgress(false);
                BaseAppCompactActivity.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)BaseAppCompactActivity.this);
            }

            @Override
            public void onUserPointLoaded(UserData userData) {
                BaseAppCompactActivity.this.userData = userData;
                BaseAppCompactActivity.myPoints = userData.getTotalPoint();
                BaseAppCompactActivity.this.tvpoints.setText((CharSequence)String.valueOf((long)BaseAppCompactActivity.myPoints));
                BaseAppCompactActivity.this.loadDate(false, null);
            }
        });
    }

    protected void onCreate(Bundle bundle) {
        Dialog dialog;
        super.onCreate(bundle);
        this.mUserDataRepository = UserDataRepository.getInstance((Context)this);
        this.mGameDataRepository = GameDataRepository.getInstance((Context)this);
        this.mProgressDialog = dialog = new Dialog((Context)this);
        dialog.requestWindowFeature(1);
        this.mProgressDialog.setContentView(2131493025);
        this.mProgressDialog.setCancelable(false);
        this.mProgressDialog.getWindow().setBackgroundDrawable((Drawable)new ColorDrawable(0));
    }

    protected void onDestroy() {
        BiddingData.clearBiddingData();
        super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            this.finish();
            this.overridePendingTransition(2130771982, 2130771981);
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void sendToNextActivity(Class class_) {
        this.startActivity(new Intent((Context)this, class_));
        this.overridePendingTransition(2130771983, 2130771980);
    }

    public void setBidTotal() {
        TextView textView = this.totalbid;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Bids ");
        stringBuilder.append(BiddingData.getBiddingData().size());
        textView.setText((CharSequence)stringBuilder.toString());
        long l = BiddingData.getTotalPoints();
        TextView textView2 = this.totalpoint;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Points ");
        stringBuilder2.append(l);
        textView2.setText((CharSequence)stringBuilder2.toString());
        this.txtpoints.setText((CharSequence)String.valueOf((long)(myPoints - l)));
    }

    public void setDateSpinner() {
        this.daysData.clear();
        for (int i = 0; i < this.daylist.size(); ++i) {
            this.daysData.add((Object)CalenderHelper.dayAndDateDisplayFormat.format(((Calendar)this.daylist.get(i)).getTime()));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, this.daysData);
        arrayAdapter.setDropDownViewResource(17367049);
        this.dayspiner.setAdapter((SpinnerAdapter)arrayAdapter);
        this.dayspiner.setSelection(0);
    }

    public void setToolbarName(String string2) {
        Toolbar toolbar = (Toolbar)this.findViewById(2131296976);
        this.setSupportActionBar(toolbar);
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayShowHomeEnabled(true);
            this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setTitleTextColor(this.getResources().getColor(2131034736));
        toolbar.setTitle((CharSequence)string2);
    }

    public void setUpToolbarByName(String string2) {
        Toolbar toolbar = (Toolbar)this.findViewById(2131296976);
        toolbar.setTitleTextColor(-1);
        this.setSupportActionBar(toolbar);
        Drawable drawable2 = this.getResources().getDrawable(2131165350);
        drawable2.setColorFilter(-1, PorterDuff.Mode.SRC_ATOP);
        this.getSupportActionBar().setHomeAsUpIndicator(drawable2);
        toolbar.setNavigationIcon(drawable2);
        toolbar.setNavigationOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ BaseAppCompactActivity this$0;
            {
                this.this$0 = baseAppCompactActivity;
            }

            public void onClick(View view) {
                this.this$0.finish();
            }
        });
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            this.getSupportActionBar().setDisplayShowHomeEnabled(true);
            this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setTitle((CharSequence)string2);
    }

    public void setupCounterData(Calendar calendar) {
        this.open.setEnabled(true);
        this.close.setEnabled(true);
        if (this.checkAndSetupForDay(calendar, DaysName.SUNDAY, "sunday")) {
            return;
        }
        if (this.checkAndSetupForDay(calendar, DaysName.MONDAY, "monday")) {
            return;
        }
        if (this.checkAndSetupForDay(calendar, DaysName.TUESDAY, "tuesday")) {
            return;
        }
        if (this.checkAndSetupForDay(calendar, DaysName.WEDNESDAY, "wednesday")) {
            return;
        }
        if (this.checkAndSetupForDay(calendar, DaysName.THURSDAY, "thursday")) {
            return;
        }
        if (this.checkAndSetupForDay(calendar, DaysName.FRIDAY, "friday")) {
            return;
        }
        this.checkAndSetupForDay(calendar, DaysName.SATURDAY, "saturday");
    }

    public void showProgress(boolean bl) {
        if (bl) {
            if (!this.mProgressDialog.isShowing()) {
                this.mProgressDialog.show();
                return;
            }
        } else if (this.mProgressDialog.isShowing()) {
            this.mProgressDialog.dismiss();
        }
    }

    public void showToast(String string2) {
        Toast.makeText((Context)this, (CharSequence)string2, (int)1).show();
    }

    public void startTimer(Calendar calendar, Calendar calendar2) {
        CountDownTimer countDownTimer;
        CountDownTimer countDownTimer2 = this.countDownTimer;
        if (countDownTimer2 != null) {
            countDownTimer2.cancel();
        }
        this.selectDate = calendar2;
        long l = CalenderHelper.getTimeDifferenceInSecond(calendar, calendar2) - (long)(60 * this.timeData.getCreateBidTimeGapInMinute());
        this.countDownTimer = countDownTimer = new CountDownTimer(this, l * 1000L, 1000L){
            final /* synthetic */ BaseAppCompactActivity this$0;
            {
                this.this$0 = baseAppCompactActivity;
                super(l, l2);
            }

            public void onFinish() {
                this.this$0.runOnUiThread(new java.lang.Runnable(this){
                    final /* synthetic */ 4 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void run() {
                        this.this$1.this$0.loadPoints();
                    }
                });
            }

            public void onTick(long l) {
                long l2 = l / 1000L;
                long l3 = l2 / 60L;
                long l4 = l3 / 60L;
                long l5 = l4 / 24L;
                long l6 = l2 % 60L;
                long l7 = l4 % 24L;
                long l8 = l3 % 60L;
                Object[] arrobject = new Object[]{l5};
                String string2 = String.format((String)"%d", (Object[])arrobject);
                Object[] arrobject2 = new Object[]{l7};
                String string3 = String.format((String)"%02d", (Object[])arrobject2);
                Object[] arrobject3 = new Object[]{l8};
                String string4 = String.format((String)"%02d", (Object[])arrobject3);
                Object[] arrobject4 = new Object[]{l6};
                String string5 = String.format((String)"%02d", (Object[])arrobject4);
                if (l5 > 0L) {
                    TextView textView = this.this$0.day;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string2);
                    stringBuilder.append("D ");
                    textView.setText((CharSequence)stringBuilder.toString());
                } else {
                    this.this$0.day.setText((CharSequence)"");
                }
                TextView textView = this.this$0.hour;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string3);
                stringBuilder.append(":");
                textView.setText((CharSequence)stringBuilder.toString());
                TextView textView2 = this.this$0.minute;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(string4);
                stringBuilder2.append(":");
                textView2.setText((CharSequence)stringBuilder2.toString());
                this.this$0.second.setText((CharSequence)string5);
            }
        };
        countDownTimer.start();
    }

}

