/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Calendar
 */
package com.Royal.data;

import com.Royal.data.DaysName;
import java.io.Serializable;
import java.util.Calendar;

public class DayData
implements Serializable {
    Calendar calCloseTime;
    Calendar calOpenTime;
    String closeTime;
    DaysName dayName;
    boolean isActive;
    String openTime;

    public Calendar getCalCloseTime() {
        return this.calCloseTime;
    }

    public Calendar getCalOpenTime() {
        return this.calOpenTime;
    }

    public String getCloseTime() {
        return this.closeTime;
    }

    public DaysName getDayName() {
        return this.dayName;
    }

    public boolean getIsActive() {
        return this.isActive;
    }

    public String getOpenTime() {
        return this.openTime;
    }

    public void setCalCloseTime(Calendar calendar) {
        this.calCloseTime = calendar;
    }

    public void setCalOpenTime(Calendar calendar) {
        this.calOpenTime = calendar;
    }

    public void setCloseTime(String string2) {
        this.closeTime = string2;
    }

    public void setDayName(DaysName daysName) {
        this.dayName = daysName;
    }

    public void setIsActive(boolean bl) {
        this.isActive = bl;
    }

    public void setOpenTime(String string2) {
        this.openTime = string2;
    }
}

