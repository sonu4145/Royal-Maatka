/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.Royal.data.GamesName$1
 *  com.Royal.data.GamesName$10
 *  com.Royal.data.GamesName$11
 *  com.Royal.data.GamesName$12
 *  com.Royal.data.GamesName$13
 *  com.Royal.data.GamesName$14
 *  com.Royal.data.GamesName$15
 *  com.Royal.data.GamesName$16
 *  com.Royal.data.GamesName$17
 *  com.Royal.data.GamesName$18
 *  com.Royal.data.GamesName$2
 *  com.Royal.data.GamesName$3
 *  com.Royal.data.GamesName$4
 *  com.Royal.data.GamesName$5
 *  com.Royal.data.GamesName$6
 *  com.Royal.data.GamesName$7
 *  com.Royal.data.GamesName$8
 *  com.Royal.data.GamesName$9
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.data;

import com.Royal.data.GamesName;

public abstract class GamesName
extends Enum<GamesName> {
    private static final /* synthetic */ GamesName[] $VALUES;
    public static final /* enum */ GamesName ANK = new 1("ANK", 0);
    public static final /* enum */ GamesName BULK_JODI;
    public static final /* enum */ GamesName COMBINE_PANA;
    public static final /* enum */ GamesName CP_MOTOR;
    public static final /* enum */ GamesName DOUBLE_PANA;
    public static final /* enum */ GamesName DP_MOTOR;
    public static final /* enum */ GamesName FAMILY_JODI;
    public static final /* enum */ GamesName FAMILY_PANA;
    public static final /* enum */ GamesName FULL_SANGAM;
    public static final /* enum */ GamesName HALF_SANGAM;
    public static final /* enum */ GamesName JODI;
    public static final /* enum */ GamesName MULTIPLE_PANA;
    public static final /* enum */ GamesName RED_JODI;
    public static final /* enum */ GamesName SINGLE_PANA;
    public static final /* enum */ GamesName SPDPTP_PANA;
    public static final /* enum */ GamesName SPDP_MOTOR;
    public static final /* enum */ GamesName SP_MOTOR;
    public static final /* enum */ GamesName TRIPLE_PANA;

    static {
        SINGLE_PANA = new 2("SINGLE_PANA", 1);
        DOUBLE_PANA = new 3("DOUBLE_PANA", 2);
        TRIPLE_PANA = new 4("TRIPLE_PANA", 3);
        SPDPTP_PANA = new 5("SPDPTP_PANA", 4);
        COMBINE_PANA = new 6("COMBINE_PANA", 5);
        FAMILY_PANA = new 7("FAMILY_PANA", 6);
        MULTIPLE_PANA = new 8("MULTIPLE_PANA", 7);
        SP_MOTOR = new 9("SP_MOTOR", 8);
        DP_MOTOR = new 10("DP_MOTOR", 9);
        SPDP_MOTOR = new 11("SPDP_MOTOR", 10);
        CP_MOTOR = new 12("CP_MOTOR", 11);
        JODI = new 13("JODI", 12);
        BULK_JODI = new 14("BULK_JODI", 13);
        FAMILY_JODI = new 15("FAMILY_JODI", 14);
        RED_JODI = new 16("RED_JODI", 15);
        HALF_SANGAM = new 17("HALF_SANGAM", 16);
        18 var0 = new 18("FULL_SANGAM", 17);
        FULL_SANGAM = var0;
        GamesName[] arrgamesName = new GamesName[]{ANK, SINGLE_PANA, DOUBLE_PANA, TRIPLE_PANA, SPDPTP_PANA, COMBINE_PANA, FAMILY_PANA, MULTIPLE_PANA, SP_MOTOR, DP_MOTOR, SPDP_MOTOR, CP_MOTOR, JODI, BULK_JODI, FAMILY_JODI, RED_JODI, HALF_SANGAM, var0};
        $VALUES = arrgamesName;
    }

    private GamesName() {
    }

    public static GamesName valueOf(String string2) {
        return (GamesName)Enum.valueOf(GamesName.class, (String)string2);
    }

    public static GamesName[] values() {
        return (GamesName[])$VALUES.clone();
    }

    public abstract String getGame();

    public abstract String getName();
}

