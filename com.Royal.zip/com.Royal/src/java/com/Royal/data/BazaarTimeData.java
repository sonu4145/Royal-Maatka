/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Calendar
 */
package com.Royal.data;

import com.Royal.data.DayData;
import com.Royal.data.DaysName;
import com.Royal.data.GamesName;
import com.Royal.data.ResultData;
import com.Royal.data.helper.CalenderHelper;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;

public class BazaarTimeData
implements Serializable {
    ArrayList<ResultData> closeResult;
    ArrayList<String> closeSession;
    int createBidTimeGapInMinute;
    ArrayList<DayData> dayData;
    ArrayList<ResultData> openResult;
    ArrayList<String> openSession;

    public ArrayList<ResultData> getCloseResult() {
        return this.closeResult;
    }

    public ArrayList<String> getCloseSession() {
        return this.closeSession;
    }

    public int getCreateBidTimeGapInMinute() {
        return this.createBidTimeGapInMinute;
    }

    public DayData getDayData(DaysName daysName) {
        for (int i = 0; i < this.dayData.size(); ++i) {
            if (!((DayData)this.dayData.get(i)).getDayName().getName().equals((Object)daysName.getName())) continue;
            return (DayData)this.dayData.get(i);
        }
        return null;
    }

    public ArrayList<DayData> getDayData() {
        return this.dayData;
    }

    public ArrayList<ResultData> getOpenResult() {
        return this.openResult;
    }

    public ArrayList<String> getOpenSession() {
        return this.openSession;
    }

    public boolean hasCloseResult(Calendar calendar) {
        for (int i = 0; i < this.closeResult.size(); ++i) {
            if (!CalenderHelper.isDateIsSame(calendar, ((ResultData)this.closeResult.get(i)).getCalDate())) continue;
            return true;
        }
        return false;
    }

    public boolean hasCloseSession(GamesName gamesName) {
        return this.closeSession.contains((Object)gamesName.getName());
    }

    public boolean hasOpenResult(Calendar calendar) {
        for (int i = 0; i < this.openResult.size(); ++i) {
            if (!CalenderHelper.isDateIsSame(calendar, ((ResultData)this.openResult.get(i)).getCalDate())) continue;
            return true;
        }
        return false;
    }

    public boolean hasOpenSession(GamesName gamesName) {
        return this.openSession.contains((Object)gamesName.getName());
    }

    public void setCloseResult(ArrayList<ResultData> arrayList) {
        this.closeResult = arrayList;
    }

    public void setCloseSession(ArrayList<String> arrayList) {
        this.closeSession = arrayList;
    }

    public void setCreateBidTimeGapInMinute(int n) {
        this.createBidTimeGapInMinute = n;
    }

    public void setDayData(ArrayList<DayData> arrayList) {
        this.dayData = arrayList;
    }

    public void setOpenResult(ArrayList<ResultData> arrayList) {
        this.openResult = arrayList;
    }

    public void setOpenSession(ArrayList<String> arrayList) {
        this.openSession = arrayList;
    }
}

