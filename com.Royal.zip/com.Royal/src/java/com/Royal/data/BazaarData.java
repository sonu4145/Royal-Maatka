/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Calendar
 */
package com.Royal.data;

import com.Royal.data.ResultData;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;

public class BazaarData
implements Serializable {
    Calendar calCloseTime;
    Calendar calOpenTime;
    ArrayList<ResultData> closeResultData;
    String closeTime;
    int id;
    String isactive;
    String name;
    ArrayList<ResultData> openResultData;
    String openTime;
    int sideId;
    String sideName;

    public Calendar getCalCloseTime() {
        return this.calCloseTime;
    }

    public Calendar getCalOpenTime() {
        return this.calOpenTime;
    }

    public ArrayList<ResultData> getCloseResultData() {
        return this.closeResultData;
    }

    public String getCloseTime() {
        return this.closeTime;
    }

    public int getId() {
        return this.id;
    }

    public String getIsactive() {
        return this.isactive;
    }

    public String getName() {
        return this.name;
    }

    public ArrayList<ResultData> getOpenResultData() {
        return this.openResultData;
    }

    public String getOpenTime() {
        return this.openTime;
    }

    public int getSideId() {
        return this.sideId;
    }

    public String getSideName() {
        return this.sideName;
    }

    public void setCalCloseTime(Calendar calendar) {
        this.calCloseTime = calendar;
    }

    public void setCalOpenTime(Calendar calendar) {
        this.calOpenTime = calendar;
    }

    public void setCloseResultData(ArrayList<ResultData> arrayList) {
        this.closeResultData = arrayList;
    }

    public void setCloseTime(String string2) {
        this.closeTime = string2;
    }

    public void setId(int n) {
        this.id = n;
    }

    public void setIsactive(String string2) {
        this.isactive = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setOpenResultData(ArrayList<ResultData> arrayList) {
        this.openResultData = arrayList;
    }

    public void setOpenTime(String string2) {
        this.openTime = string2;
    }

    public void setSideId(int n) {
        this.sideId = n;
    }

    public void setSideName(String string2) {
        this.sideName = string2;
    }
}

