/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Calendar
 */
package com.Royal.data;

import java.io.Serializable;
import java.util.Calendar;

public class ResultData
implements Serializable {
    String ank;
    int bazaarId;
    Calendar calDate;
    String date;
    String jodi;
    String pana;
    String session;

    public String getAnk() {
        return this.ank;
    }

    public int getBazaarId() {
        return this.bazaarId;
    }

    public Calendar getCalDate() {
        return this.calDate;
    }

    public String getDate() {
        return this.date;
    }

    public String getJodi() {
        return this.jodi;
    }

    public String getPana() {
        return this.pana;
    }

    public String getSession() {
        return this.session;
    }

    public void setAnk(String string2) {
        this.ank = string2;
    }

    public void setBazaarId(int n) {
        this.bazaarId = n;
    }

    public void setCalDate(Calendar calendar) {
        this.calDate = calendar;
    }

    public void setDate(String string2) {
        this.date = string2;
    }

    public void setJodi(String string2) {
        this.jodi = string2;
    }

    public void setPana(String string2) {
        this.pana = string2;
    }

    public void setSession(String string2) {
        this.session = string2;
    }
}

