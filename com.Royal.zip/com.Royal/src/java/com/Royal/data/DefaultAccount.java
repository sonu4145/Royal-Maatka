/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.data;

import java.io.Serializable;

public class DefaultAccount
implements Serializable {
    String name;
    String value;

    public String getName() {
        return this.name;
    }

    public String getValue() {
        return this.value;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setValue(String string2) {
        this.value = string2;
    }
}

