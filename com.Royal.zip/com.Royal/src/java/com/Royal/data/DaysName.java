/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.Royal.data.DaysName$1
 *  com.Royal.data.DaysName$2
 *  com.Royal.data.DaysName$3
 *  com.Royal.data.DaysName$4
 *  com.Royal.data.DaysName$5
 *  com.Royal.data.DaysName$6
 *  com.Royal.data.DaysName$7
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.data;

import com.Royal.data.DaysName;

public abstract class DaysName
extends Enum<DaysName> {
    private static final /* synthetic */ DaysName[] $VALUES;
    public static final /* enum */ DaysName FRIDAY;
    public static final /* enum */ DaysName MONDAY;
    public static final /* enum */ DaysName SATURDAY;
    public static final /* enum */ DaysName SUNDAY;
    public static final /* enum */ DaysName THURSDAY;
    public static final /* enum */ DaysName TUESDAY;
    public static final /* enum */ DaysName WEDNESDAY;

    static {
        SUNDAY = new 1("SUNDAY", 0);
        MONDAY = new 2("MONDAY", 1);
        TUESDAY = new 3("TUESDAY", 2);
        WEDNESDAY = new 4("WEDNESDAY", 3);
        THURSDAY = new 5("THURSDAY", 4);
        FRIDAY = new 6("FRIDAY", 5);
        7 var0 = new 7("SATURDAY", 6);
        SATURDAY = var0;
        DaysName[] arrdaysName = new DaysName[]{SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, var0};
        $VALUES = arrdaysName;
    }

    private DaysName() {
    }

    public static DaysName valueOf(String string2) {
        return (DaysName)Enum.valueOf(DaysName.class, (String)string2);
    }

    public static DaysName[] values() {
        return (DaysName[])$VALUES.clone();
    }

    public abstract String getName();
}

