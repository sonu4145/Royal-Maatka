/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.data;

public interface BaseDataSource {

    public static interface BaseCallBack {
        public void onErrorInLoading(String var1);

        public void onLocked(String var1);
    }

}

