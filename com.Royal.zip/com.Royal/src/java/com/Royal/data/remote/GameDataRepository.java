/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Log
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$GetRequestBuilder
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.StringRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.Royal.data.remote;

import android.content.Context;
import android.util.Log;
import com.Royal.data.BazaarData;
import com.Royal.data.BazaarTimeData;
import com.Royal.data.BiddingData;
import com.Royal.data.DayData;
import com.Royal.data.DaysName;
import com.Royal.data.ResultData;
import com.Royal.data.UserData;
import com.Royal.data.helper.CalenderHelper;
import com.Royal.data.helper.CryptoHelper;
import com.Royal.data.helper.GamesHelper;
import com.Royal.data.helper.JSONHelper;
import com.Royal.data.helper.LockHelper;
import com.Royal.data.helper.LogHelper;
import com.Royal.data.remote.GameDataSource;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONObject;

public class GameDataRepository
implements GameDataSource {
    private static GameDataRepository INSTANCE;
    private final String TAG = this.getClass().getSimpleName();
    private Context context;

    private GameDataRepository(Context context) {
        this.context = context;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static GameDataRepository getInstance(Context context) {
        if (INSTANCE != null) return INSTANCE;
        Class<GameDataRepository> class_ = GameDataRepository.class;
        synchronized (GameDataRepository.class) {
            if (INSTANCE != null) return INSTANCE;
            INSTANCE = new GameDataRepository(context);
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return INSTANCE;
        }
    }

    @Override
    public void getBazaarList(final GameDataSource.GetBazaarCallBack getBazaarCallBack) {
        AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/bazaar/all").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                getBazaarCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                LogHelper.showErrors(aNError.getErrorBody());
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            public void onResponse(String var1_1) {
                LogHelper.showApiResponse(var1_1);
                try {
                    var2_2 = new JSONObject(var1_1);
                    if (var2_2.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(var2_2)) {
                            getBazaarCallBack.onLocked("true");
                            return;
                        }
                    } else {
                        var4_21 = var2_2.isNull("errorCode");
                        if (var4_21) {
                            var7_22 = var2_2.getString("error");
                            getBazaarCallBack.onErrorInLoading(var7_22);
                        } else if (var2_2.getString("errorCode").contains((CharSequence)"UVE")) {
                            var6_23 = var2_2.getJSONObject("error");
                            if (var6_23.has("mobile")) {
                                getBazaarCallBack.onErrorInLoading(var6_23.getString("userId"));
                            }
                        } else {
                            getBazaarCallBack.onErrorInLoading("Something Went Wroing");
                        }
                        Log.d((String)GameDataRepository.access$000(GameDataRepository.this), (String)var2_2.getString("error"));
                        return;
                    }
                    CalenderHelper.setCurrentTime(JSONHelper.getString(var2_2, "currentDate"), JSONHelper.getString(var2_2, "currentTime"));
                    var8_3 = JSONHelper.getJSONArray(var2_2, "bazaars");
                    var9_4 = JSONHelper.getJSONArray(var2_2, "results");
                    var10_5 = new ArrayList();
                    var11_6 = new ArrayList();
                    var12_7 = 0;
                    do {
                        var13_9 = var9_4.length();
                        var14_10 = 0;
                        if (var12_7 >= var13_9) break;
                        var15_11 = JSONHelper.getJSONObject(var9_4, var12_7);
                        var16_8 = new ResultData();
                        var16_8.setBazaarId(JSONHelper.getInt(var15_11, "bazaarId"));
                        var16_8.setAnk(JSONHelper.getString(var15_11, "ank"));
                        var16_8.setPana(JSONHelper.getString(var15_11, "pana"));
                        var16_8.setJodi(JSONHelper.getString(var15_11, "jodi"));
                        var16_8.setSession(JSONHelper.getString(var15_11, "session"));
                        var10_5.add((Object)var16_8);
                        ++var12_7;
                    } while (true);
lbl42: // 2 sources:
                    do {
                        if (var14_10 >= var8_3.length()) {
                            getBazaarCallBack.onBazaarLoaded((ArrayList<BazaarData>)var11_6);
                            return;
                        }
                        var18_13 = JSONHelper.getJSONObject(var8_3, var14_10);
                        var19_14 = new BazaarData();
                        var19_14.setId(JSONHelper.getInt(var18_13, "id"));
                        var19_14.setSideId(JSONHelper.getInt(var2_2, "bazaarSideId"));
                        var19_14.setSideName(JSONHelper.getString(var2_2, "bazaarSide"));
                        var19_14.setName(JSONHelper.getString(var18_13, "name"));
                        var19_14.setIsactive(JSONHelper.getString(var18_13, "isToday"));
                        var19_14.setOpenTime(JSONHelper.getString(var18_13, "todayOpenTime"));
                        var19_14.setCloseTime(JSONHelper.getString(var18_13, "todayCloseTime"));
                        if (JSONHelper.getString(var18_13, "isToday").equals((Object)"active")) {
                            var20_15 = Calendar.getInstance();
                            var21_16 = CalenderHelper.dateTimeFormat;
                            var22_17 = new StringBuilder();
                            var22_17.append(CalenderHelper.currentDate);
                            var22_17.append(" ");
                            var22_17.append(var19_14.getOpenTime().trim());
                            var20_15.setTime(var21_16.parse(var22_17.toString()));
                            var19_14.setCalOpenTime(var20_15);
                            var26_18 = Calendar.getInstance();
                            var27_19 = CalenderHelper.dateTimeFormat;
                            var28_20 = new StringBuilder();
                            var28_20.append(CalenderHelper.currentDate);
                            var28_20.append(" ");
                            var28_20.append(var19_14.getCloseTime().trim());
                            var26_18.setTime(var27_19.parse(var28_20.toString()));
                            var19_14.setCalCloseTime(var26_18);
                            var32_12 = GamesHelper.getResultByBazaar(var19_14, (ArrayList<ResultData>)var10_5);
                            var19_14.setOpenResultData(GamesHelper.filterOpenResult(var32_12));
                            var19_14.setCloseResultData(GamesHelper.filterCloseResult(var32_12));
                            var11_6.add((Object)var19_14);
                        }
                        break;
                    } while (true);
                }
                catch (Exception var3_24) {
                    var3_24.printStackTrace();
                    getBazaarCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                    return;
                }
                ++var14_10;
                ** while (true)
            }
        });
    }

    @Override
    public void getBazaarTime(BazaarData bazaarData, final GameDataSource.GetBazaarTimeCallBack getBazaarTimeCallBack) {
        String string2;
        UserData userData = UserData.getInstance(this.context);
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("bazaarId", bazaarData.getId());
            jSONObject.put("userId", (Object)userData.getUserId());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("post: ");
            stringBuilder.append(jSONObject.toString());
            LogHelper.showApiResponse(stringBuilder.toString());
            string2 = CryptoHelper.encrypt(jSONObject.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            string2 = "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post: ");
        stringBuilder.append(string2);
        LogHelper.showApiResponse(stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/bazaar/timing").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string2).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                getBazaarTimeCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                LogHelper.showErrors(aNError.getErrorBody());
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                ArrayList arrayList;
                ArrayList arrayList2;
                JSONObject jSONObject;
                ArrayList arrayList3;
                LogHelper.showApiResponse(string2);
                try {
                    JSONArray jSONArray;
                    JSONArray jSONArray2;
                    int n;
                    int n2;
                    jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getBazaarTimeCallBack.onLocked("true");
                            return;
                        }
                        CalenderHelper.setCurrentTime(JSONHelper.getString(jSONObject, "currentDate"), JSONHelper.getString(jSONObject, "currentTime"));
                        JSONObject jSONObject2 = JSONHelper.getJSONObject(jSONObject, "games");
                        jSONArray2 = JSONHelper.getJSONArray(jSONObject2, "openSession");
                        jSONArray = JSONHelper.getJSONArray(jSONObject2, "closeSession");
                        arrayList3 = new ArrayList();
                        arrayList = new ArrayList();
                        n = 0;
                    } else {
                        boolean bl = jSONObject.isNull("errorCode");
                        if (bl) {
                            String string3 = jSONObject.getString("error");
                            getBazaarTimeCallBack.onErrorInLoading(string3);
                        } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                            JSONObject jSONObject3 = jSONObject.getJSONObject("error");
                            if (jSONObject3.has("bazaarId")) {
                                getBazaarTimeCallBack.onErrorInLoading(jSONObject3.getString("bazaarId"));
                            }
                        } else {
                            getBazaarTimeCallBack.onErrorInLoading("Something Went Wroing");
                        }
                        Log.d((String)GameDataRepository.this.TAG, (String)jSONObject.getString("error"));
                        return;
                    }
                    for (int i = 0; i < jSONArray2.length(); ++i) {
                        arrayList3.add((Object)JSONHelper.getString(jSONArray2, i));
                    }
                    for (int i = 0; i < jSONArray.length(); ++i) {
                        arrayList.add((Object)JSONHelper.getString(jSONArray, i));
                    }
                    JSONArray jSONArray3 = JSONHelper.getJSONArray(jSONObject, "results");
                    arrayList2 = new ArrayList();
                    while (n < (n2 = jSONArray3.length())) {
                        JSONObject jSONObject4 = JSONHelper.getJSONObject(jSONArray3, n);
                        ResultData resultData = new ResultData();
                        resultData.setSession(JSONHelper.getString(jSONObject4, "session"));
                        resultData.setDate(JSONHelper.getString(jSONObject4, "date"));
                        Calendar calendar = Calendar.getInstance();
                        SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(resultData.getDate().trim());
                        stringBuilder.append(" ");
                        stringBuilder.append(CalenderHelper.time24HourFormatWithSecond.format(calendar.getTime()));
                        calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                        resultData.setCalDate(calendar);
                        arrayList2.add((Object)resultData);
                        ++n;
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getBazaarTimeCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                    return;
                }
                {
                    BazaarTimeData bazaarTimeData = new BazaarTimeData();
                    bazaarTimeData.setOpenSession((ArrayList<String>)arrayList3);
                    bazaarTimeData.setCloseSession((ArrayList<String>)arrayList);
                    bazaarTimeData.setOpenResult(GamesHelper.filterOpenResult((ArrayList<ResultData>)arrayList2));
                    bazaarTimeData.setCloseResult(GamesHelper.filterCloseResult((ArrayList<ResultData>)arrayList2));
                    bazaarTimeData.setCreateBidTimeGapInMinute(JSONHelper.getInt(jSONObject, "createBidTimeGapInMinute"));
                    JSONObject jSONObject5 = JSONHelper.getJSONObject(jSONObject, "bazaar");
                    ArrayList arrayList4 = new ArrayList();
                    DayData dayData = new DayData();
                    dayData.setDayName(DaysName.SUNDAY);
                    dayData.setIsActive(GamesHelper.getIsActiveStatus(JSONHelper.getString(jSONObject5, "isSunday")));
                    dayData.setOpenTime(JSONHelper.getString(jSONObject5, "sundayOpenTime"));
                    dayData.setCloseTime(JSONHelper.getString(jSONObject5, "sundayCloseTime"));
                    if (dayData.getIsActive()) {
                        if (dayData.getOpenTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData.getOpenTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData.setCalOpenTime(calendar);
                        }
                        if (dayData.getCloseTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData.getCloseTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData.setCalCloseTime(calendar);
                        }
                    }
                    arrayList4.add((Object)dayData);
                    DayData dayData2 = new DayData();
                    dayData2.setDayName(DaysName.MONDAY);
                    dayData2.setIsActive(GamesHelper.getIsActiveStatus(JSONHelper.getString(jSONObject5, "isMonday")));
                    dayData2.setOpenTime(JSONHelper.getString(jSONObject5, "mondayOpenTime"));
                    dayData2.setCloseTime(JSONHelper.getString(jSONObject5, "mondayCloseTime"));
                    if (dayData2.getIsActive()) {
                        if (dayData2.getOpenTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData2.getOpenTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData2.setCalOpenTime(calendar);
                        }
                        if (dayData2.getCloseTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData2.getCloseTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData2.setCalCloseTime(calendar);
                        }
                    }
                    arrayList4.add((Object)dayData2);
                    DayData dayData3 = new DayData();
                    dayData3.setDayName(DaysName.TUESDAY);
                    dayData3.setIsActive(GamesHelper.getIsActiveStatus(JSONHelper.getString(jSONObject5, "isTuesday")));
                    dayData3.setOpenTime(JSONHelper.getString(jSONObject5, "tuesdayOpenTime"));
                    dayData3.setCloseTime(JSONHelper.getString(jSONObject5, "tuesdayCloseTime"));
                    if (dayData3.getIsActive()) {
                        if (dayData3.getOpenTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData3.getOpenTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData3.setCalOpenTime(calendar);
                        }
                        if (dayData3.getCloseTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData3.getCloseTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData3.setCalCloseTime(calendar);
                        }
                    }
                    arrayList4.add((Object)dayData3);
                    DayData dayData4 = new DayData();
                    dayData4.setDayName(DaysName.WEDNESDAY);
                    dayData4.setIsActive(GamesHelper.getIsActiveStatus(JSONHelper.getString(jSONObject5, "isWednesday")));
                    dayData4.setOpenTime(JSONHelper.getString(jSONObject5, "wednesdayOpenTime"));
                    dayData4.setCloseTime(JSONHelper.getString(jSONObject5, "wednesdayCloseTime"));
                    if (dayData4.getIsActive()) {
                        if (dayData4.getOpenTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData4.getOpenTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData4.setCalOpenTime(calendar);
                        }
                        if (dayData4.getCloseTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData4.getCloseTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData4.setCalCloseTime(calendar);
                        }
                    }
                    arrayList4.add((Object)dayData4);
                    DayData dayData5 = new DayData();
                    dayData5.setDayName(DaysName.THURSDAY);
                    dayData5.setIsActive(GamesHelper.getIsActiveStatus(JSONHelper.getString(jSONObject5, "isThursday")));
                    dayData5.setOpenTime(JSONHelper.getString(jSONObject5, "thursdayOpenTime"));
                    dayData5.setCloseTime(JSONHelper.getString(jSONObject5, "thursdayCloseTime"));
                    if (dayData5.getIsActive()) {
                        if (dayData5.getOpenTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData5.getOpenTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData5.setCalOpenTime(calendar);
                        }
                        if (dayData5.getCloseTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData5.getCloseTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData5.setCalCloseTime(calendar);
                        }
                    }
                    arrayList4.add((Object)dayData5);
                    DayData dayData6 = new DayData();
                    dayData6.setDayName(DaysName.FRIDAY);
                    dayData6.setIsActive(GamesHelper.getIsActiveStatus(JSONHelper.getString(jSONObject5, "isFriday")));
                    dayData6.setOpenTime(JSONHelper.getString(jSONObject5, "fridayOpenTime"));
                    dayData6.setCloseTime(JSONHelper.getString(jSONObject5, "fridayCloseTime"));
                    if (dayData6.getIsActive()) {
                        if (dayData6.getOpenTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData6.getOpenTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData6.setCalOpenTime(calendar);
                        }
                        if (dayData6.getCloseTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData6.getCloseTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData6.setCalCloseTime(calendar);
                        }
                    }
                    arrayList4.add((Object)dayData6);
                    DayData dayData7 = new DayData();
                    dayData7.setDayName(DaysName.SATURDAY);
                    dayData7.setIsActive(GamesHelper.getIsActiveStatus(JSONHelper.getString(jSONObject5, "isSaturday")));
                    dayData7.setOpenTime(JSONHelper.getString(jSONObject5, "saturdayOpenTime"));
                    dayData7.setCloseTime(JSONHelper.getString(jSONObject5, "saturdayCloseTime"));
                    if (dayData7.getIsActive()) {
                        if (dayData7.getOpenTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData7.getOpenTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData7.setCalOpenTime(calendar);
                        }
                        if (dayData7.getCloseTime().trim().length() > 7) {
                            Calendar calendar = Calendar.getInstance();
                            SimpleDateFormat simpleDateFormat = CalenderHelper.dateTimeFormat;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(CalenderHelper.currentDate);
                            stringBuilder.append(" ");
                            stringBuilder.append(dayData7.getCloseTime().trim());
                            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
                            dayData7.setCalCloseTime(calendar);
                        }
                    }
                    arrayList4.add((Object)dayData7);
                    bazaarTimeData.setDayData((ArrayList<DayData>)arrayList4);
                    getBazaarTimeCallBack.onBazaarTimeLoaded(bazaarTimeData);
                    return;
                }
            }
        });
    }

    @Override
    public void placeBid(BazaarData bazaarData, final GameDataSource.GetBidPlaceCallBack getBidPlaceCallBack) {
        UserData userData = UserData.getInstance(this.context);
        String string2 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)userData.getUserId());
            jSONObject.put("bazaarId", bazaarData.getId());
            jSONObject.put("bazaar", (Object)bazaarData.getName());
            jSONObject.put("bazaarSideId", bazaarData.getSideId());
            jSONObject.put("bazaarSide", (Object)bazaarData.getSideName());
            jSONObject.put("bidPoint", BiddingData.getTotalPoints());
            jSONObject.put("biddings", (Object)BiddingData.getBiddingList());
            jSONObject.put("gameKeys", (Object)BiddingData.getGameKeyList());
            string2 = CryptoHelper.encrypt(jSONObject.toString());
            String string3 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA : ");
            stringBuilder.append(CryptoHelper.decrypt(string2.toString()));
            Log.d((String)string3, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string4 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post : ");
        stringBuilder.append(string2);
        Log.e((String)string4, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/bidding/create").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string2).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                String string2 = GameDataRepository.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error");
                stringBuilder.append(aNError.getErrorBody());
                Log.d((String)string2, (String)stringBuilder.toString());
                getBidPlaceCallBack.onErrorInLoading("Something Went Wroing");
            }

            /*
             * Loose catch block
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            public void onResponse(String string2) {
                JSONObject jSONObject;
                block20 : {
                    block21 : {
                        String string3;
                        void var4_15;
                        block22 : {
                            Log.e((String)"Api_response", (String)string2);
                            jSONObject = new JSONObject(string2);
                            if (jSONObject.getString("status").equals((Object)"true")) {
                                getBidPlaceCallBack.onBidPlaced(JSONHelper.getString(jSONObject, "message"));
                                return;
                            }
                            boolean bl = jSONObject.isNull("errorCode");
                            if (bl) {
                                String string4 = jSONObject.getString("error");
                                getBidPlaceCallBack.onErrorInLoading(string4);
                                String string5 = "Something Went Wroing";
                                break block20;
                            }
                            String string6 = jSONObject.getString("errorCode");
                            if (string6.contains((CharSequence)"AIE")) {
                                String string7 = jSONObject.getString("error");
                                getBidPlaceCallBack.onErrorInLoading(string7);
                                break block21;
                            }
                            if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                                JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                                if (jSONObject2.has("userId")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                                }
                                if (jSONObject2.has("game")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("game"));
                                }
                                if (jSONObject2.has("bazaarId")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("bazaarId"));
                                }
                                if (jSONObject2.has("bazaar")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("bazaar"));
                                }
                                if (jSONObject2.has("bazaarSideId")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("bazaarSideId"));
                                }
                                if (jSONObject2.has("bazaarSide")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("bazaarSide"));
                                }
                                if (jSONObject2.has("totalPointsOfBidding")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("totalPointsOfBidding"));
                                }
                                if (jSONObject2.has("totalNumberOfBiddings")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("totalNumberOfBiddings"));
                                }
                                if (jSONObject2.has("biddingDateList")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("biddingDateList"));
                                }
                                if (jSONObject2.has("biddingList")) {
                                    getBidPlaceCallBack.onErrorInLoading(jSONObject2.getString("biddingList"));
                                }
                                break block21;
                            }
                            GameDataSource.GetBidPlaceCallBack getBidPlaceCallBack2 = getBidPlaceCallBack;
                            string3 = "Something Went Wroing";
                            try {
                                getBidPlaceCallBack2.onErrorInLoading(string3);
                                break block20;
                            }
                            catch (Exception exception) {
                                break block22;
                            }
                            catch (Exception exception) {
                                string3 = "Something Went Wroing";
                            }
                            break block22;
                            catch (Exception exception) {
                                string3 = "Something Went Wroing";
                            }
                        }
                        var4_15.printStackTrace();
                        getBidPlaceCallBack.onErrorInLoading(string3);
                        return;
                    }
                    String string8 = "Something Went Wroing";
                }
                Log.d((String)GameDataRepository.this.TAG, (String)jSONObject.getString("error"));
            }
        });
    }

    @Override
    public void updateDateTime(final GameDataSource.GetDateTimeUpdateCallBack getDateTimeUpdateCallBack) {
        AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/defaultSetting/getCurrentDateTime").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                getDateTimeUpdateCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                LogHelper.showErrors(aNError.getErrorBody());
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                LogHelper.showApiResponse(string2);
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getDateTimeUpdateCallBack.onLocked("true");
                            return;
                        }
                        CalenderHelper.setCurrentTime(JSONHelper.getString(jSONObject, "date"), JSONHelper.getString(jSONObject, "time"));
                        getDateTimeUpdateCallBack.onDateUpdated(CalenderHelper.currentCalendar);
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string3 = jSONObject.getString("error");
                        getDateTimeUpdateCallBack.onErrorInLoading(string3);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("mobile")) {
                            getDateTimeUpdateCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                        }
                    } else {
                        getDateTimeUpdateCallBack.onErrorInLoading("Something Went Wroing");
                    }
                    Log.d((String)GameDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getDateTimeUpdateCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                    return;
                }
            }
        });
    }

}

