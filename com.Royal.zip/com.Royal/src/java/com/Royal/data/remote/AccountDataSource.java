/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.Royal.data.remote.AccountDataSource$GetAccountCallBack
 *  com.Royal.data.remote.AccountDataSource$GetAddAccountCallBack
 *  com.Royal.data.remote.AccountDataSource$GetDefaultAccountCallBack
 *  com.Royal.data.remote.AccountDataSource$GetRemoveAccountCallBack
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.data.remote;

import com.Royal.data.AccountData;
import com.Royal.data.remote.AccountDataSource;

public interface AccountDataSource {
    public void addAccount(String var1, String var2, String var3, String var4, String var5, String var6, GetAddAccountCallBack var7);

    public void getBankAccount(GetAccountCallBack var1);

    public void getDefaultAccount(GetDefaultAccountCallBack var1);

    public void getWalletAccount(GetAccountCallBack var1);

    public void removeAccount(AccountData var1, GetRemoveAccountCallBack var2);

    public void updateAccount(String var1, String var2, String var3, String var4, String var5, String var6, String var7, GetAddAccountCallBack var8);
}

