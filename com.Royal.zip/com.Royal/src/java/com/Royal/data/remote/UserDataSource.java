/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.Royal.data.remote.UserDataSource$ChangePasswordCallBack
 *  com.Royal.data.remote.UserDataSource$GetUserDataCallBack
 *  com.Royal.data.remote.UserDataSource$GetUserLoginCallBack
 *  com.Royal.data.remote.UserDataSource$GetUserOtpCallBack
 *  com.Royal.data.remote.UserDataSource$GetUserPointsCallBack
 *  com.Royal.data.remote.UserDataSource$GetUserRegistrationCallBack
 *  com.Royal.data.remote.UserDataSource$SetNewPasswordCallBack
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.data.remote;

import com.Royal.data.UserData;
import com.Royal.data.remote.UserDataSource;

public interface UserDataSource {
    public void changePassword(String var1, String var2, ChangePasswordCallBack var3);

    public void getDetailAndLoginUser(String var1, String var2, GetUserLoginCallBack var3);

    public void getProfileData(GetUserDataCallBack var1);

    public UserData getUserData();

    public void getUserData(GetUserDataCallBack var1);

    public void getUserPoints(GetUserPointsCallBack var1);

    public void registerNewUser(String var1, String var2, String var3, String var4, GetUserRegistrationCallBack var5);

    public void sendOtpMsg(String var1, String var2, String var3, GetUserOtpCallBack var4);

    public void sendVerificationCode(String var1, String var2, String var3, GetUserOtpCallBack var4);

    public void setNewPassword(String var1, String var2, String var3, String var4, SetNewPasswordCallBack var5);
}

