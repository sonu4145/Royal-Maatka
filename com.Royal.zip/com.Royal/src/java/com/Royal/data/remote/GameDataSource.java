/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.Royal.data.remote.GameDataSource$GetBazaarCallBack
 *  com.Royal.data.remote.GameDataSource$GetBazaarTimeCallBack
 *  com.Royal.data.remote.GameDataSource$GetBidPlaceCallBack
 *  com.Royal.data.remote.GameDataSource$GetDateTimeUpdateCallBack
 *  java.lang.Object
 */
package com.Royal.data.remote;

import com.Royal.data.BazaarData;
import com.Royal.data.remote.GameDataSource;

public interface GameDataSource {
    public void getBazaarList(GetBazaarCallBack var1);

    public void getBazaarTime(BazaarData var1, GetBazaarTimeCallBack var2);

    public void placeBid(BazaarData var1, GetBidPlaceCallBack var2);

    public void updateDateTime(GetDateTimeUpdateCallBack var1);
}

