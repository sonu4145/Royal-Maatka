/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Log
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$GetRequestBuilder
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.StringRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.Royal.data.remote;

import android.content.Context;
import android.util.Log;
import com.Royal.data.AccountData;
import com.Royal.data.DefaultAccount;
import com.Royal.data.UserData;
import com.Royal.data.helper.CryptoHelper;
import com.Royal.data.helper.JSONHelper;
import com.Royal.data.helper.LockHelper;
import com.Royal.data.helper.LogHelper;
import com.Royal.data.remote.AccountDataSource;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class AccountDataRepository
implements AccountDataSource {
    private static AccountDataRepository INSTANCE;
    private final String TAG = this.getClass().getSimpleName();
    private Context context;

    private AccountDataRepository(Context context) {
        this.context = context;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static AccountDataRepository getInstance(Context context) {
        if (INSTANCE != null) return INSTANCE;
        Class<AccountDataRepository> class_ = AccountDataRepository.class;
        synchronized (AccountDataRepository.class) {
            if (INSTANCE != null) return INSTANCE;
            INSTANCE = new AccountDataRepository(context);
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return INSTANCE;
        }
    }

    @Override
    public void addAccount(String string2, String string3, String string4, String string5, String string6, String string7, final AccountDataSource.GetAddAccountCallBack getAddAccountCallBack) {
        UserData userData = UserData.getInstance(this.context);
        String string8 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)userData.getUserId());
            jSONObject.put("type", (Object)string2);
            jSONObject.put("accountName", (Object)string3);
            jSONObject.put("accountNumber", (Object)string4);
            jSONObject.put("accountHolderName", (Object)userData.getDisplayName());
            jSONObject.put("branchName", (Object)string6);
            jSONObject.put("ifscCode", (Object)string7);
            string8 = CryptoHelper.encrypt(jSONObject.toString());
            String string9 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA : ");
            stringBuilder.append(CryptoHelper.decrypt(string8.toString()));
            Log.d((String)string9, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string10 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post : ");
        stringBuilder.append(string8);
        Log.e((String)string10, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userAccount/create").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string8).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                String string2 = AccountDataRepository.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error");
                stringBuilder.append(aNError.getErrorBody());
                Log.d((String)string2, (String)stringBuilder.toString());
                getAddAccountCallBack.onErrorInLoading("Something Went Wroing");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getAddAccountCallBack.onLocked("true");
                            return;
                        }
                        getAddAccountCallBack.onAccountAdded(JSONHelper.getString(jSONObject, "message"));
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string3 = jSONObject.getString("error");
                        getAddAccountCallBack.onErrorInLoading(string3);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"AIE")) {
                        String string4 = jSONObject.getString("error");
                        getAddAccountCallBack.onErrorInLoading(string4);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("userId")) {
                            getAddAccountCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                        }
                        if (jSONObject2.has("type")) {
                            getAddAccountCallBack.onErrorInLoading(jSONObject2.getString("type"));
                        }
                        if (jSONObject2.has("accountName")) {
                            getAddAccountCallBack.onErrorInAccountName(jSONObject2.getString("accountName"));
                        }
                        if (jSONObject2.has("accountNumber")) {
                            getAddAccountCallBack.onErrorInAccountNumber(jSONObject2.getString("accountNumber"));
                        }
                        if (jSONObject2.has("accountHolderName")) {
                            getAddAccountCallBack.onErrorInHolderName(jSONObject2.getString("accountHolderName"));
                        }
                        if (jSONObject2.has("branchName")) {
                            getAddAccountCallBack.onErrorInBranchName(jSONObject2.getString("branchName"));
                        }
                        if (jSONObject2.has("ifscCode")) {
                            getAddAccountCallBack.onErrorInIfsc(jSONObject2.getString("ifscCode"));
                        }
                    } else {
                        getAddAccountCallBack.onErrorInLoading("Something Went Wroing");
                    }
                    Log.d((String)AccountDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getAddAccountCallBack.onErrorInLoading("Something Went Wroing");
                    return;
                }
            }
        });
    }

    @Override
    public void getBankAccount(final AccountDataSource.GetAccountCallBack getAccountCallBack) {
        UserData userData = UserData.getInstance(this.context);
        String string2 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)userData.getUserId());
            string2 = CryptoHelper.encrypt(jSONObject.toString());
            String string3 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA : ");
            stringBuilder.append(CryptoHelper.decrypt(string2.toString()));
            Log.d((String)string3, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string4 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post : ");
        stringBuilder.append(string2);
        Log.e((String)string4, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userAccount/all").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string2).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                String string2 = AccountDataRepository.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error");
                stringBuilder.append(aNError.getErrorBody());
                Log.d((String)string2, (String)stringBuilder.toString());
                getAccountCallBack.onErrorInLoading("Something Went Wroing");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONArray jSONArray;
                    ArrayList arrayList;
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getAccountCallBack.onLocked("true");
                            return;
                        }
                        jSONArray = JSONHelper.getJSONArray(jSONObject, "banks");
                        arrayList = new ArrayList();
                    } else {
                        boolean bl = jSONObject.isNull("errorCode");
                        if (bl) {
                            String string3 = jSONObject.getString("error");
                            getAccountCallBack.onErrorInLoading(string3);
                        } else if (jSONObject.getString("errorCode").contains((CharSequence)"AIE")) {
                            String string4 = jSONObject.getString("error");
                            getAccountCallBack.onErrorInLoading(string4);
                        } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                            JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                            if (jSONObject2.has("userId")) {
                                getAccountCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                            }
                        } else {
                            getAccountCallBack.onErrorInLoading("Something Went Wroing");
                        }
                        Log.d((String)AccountDataRepository.this.TAG, (String)jSONObject.getString("error"));
                        return;
                    }
                    for (int i = 0; i < jSONArray.length(); ++i) {
                        JSONObject jSONObject3 = JSONHelper.getJSONObject(jSONArray, i);
                        AccountData accountData = new AccountData();
                        accountData.setId(JSONHelper.getString(jSONObject3, "id"));
                        accountData.setAccountHolderName(JSONHelper.getString(jSONObject3, "accountHolderName"));
                        accountData.setAccountNumber(JSONHelper.getString(jSONObject3, "accountNumber"));
                        accountData.setAccountName(JSONHelper.getString(jSONObject3, "accountName"));
                        accountData.setIfscCode(JSONHelper.getString(jSONObject3, "ifscCode"));
                        accountData.setBranchName(JSONHelper.getString(jSONObject3, "branchName"));
                        accountData.setType(JSONHelper.getString(jSONObject3, "type"));
                        accountData.setIsStatus(JSONHelper.getString(jSONObject3, "isStatus"));
                        arrayList.add((Object)accountData);
                    }
                    getAccountCallBack.onLoaded((ArrayList<AccountData>)arrayList);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getAccountCallBack.onErrorInLoading("Something Went Wroing");
                    return;
                }
            }
        });
    }

    @Override
    public void getDefaultAccount(final AccountDataSource.GetDefaultAccountCallBack getDefaultAccountCallBack) {
        AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/userAccount/defaultList").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                getDefaultAccountCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                LogHelper.showErrors(aNError.getErrorBody());
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                ArrayList arrayList;
                ArrayList arrayList2;
                LogHelper.showApiResponse(string2);
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getDefaultAccountCallBack.onLocked("true");
                            return;
                        }
                    } else {
                        boolean bl = jSONObject.isNull("errorCode");
                        if (bl) {
                            String string3 = jSONObject.getString("error");
                            getDefaultAccountCallBack.onErrorInLoading(string3);
                        } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                            JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                            if (jSONObject2.has("mobile")) {
                                getDefaultAccountCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                            }
                        } else {
                            getDefaultAccountCallBack.onErrorInLoading("Something Went Wroing");
                        }
                        Log.d((String)AccountDataRepository.this.TAG, (String)jSONObject.getString("error"));
                        return;
                    }
                    JSONArray jSONArray = JSONHelper.getJSONArray(jSONObject, "banks");
                    JSONArray jSONArray2 = JSONHelper.getJSONArray(jSONObject, "wallets");
                    arrayList = new ArrayList();
                    arrayList2 = new ArrayList();
                    int n = 0;
                    do {
                        int n2 = jSONArray.length();
                        if (n >= n2) break;
                        JSONObject jSONObject3 = JSONHelper.getJSONObject(jSONArray, n);
                        DefaultAccount defaultAccount = new DefaultAccount();
                        defaultAccount.setName(JSONHelper.getString(jSONObject3, "text"));
                        defaultAccount.setValue(JSONHelper.getString(jSONObject3, "value"));
                        arrayList.add((Object)defaultAccount);
                        ++n;
                    } while (true);
                    for (int i = 0; i < jSONArray2.length(); ++i) {
                        JSONObject jSONObject4 = JSONHelper.getJSONObject(jSONArray2, i);
                        DefaultAccount defaultAccount = new DefaultAccount();
                        defaultAccount.setName(JSONHelper.getString(jSONObject4, "text"));
                        defaultAccount.setValue(JSONHelper.getString(jSONObject4, "value"));
                        arrayList2.add((Object)defaultAccount);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getDefaultAccountCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                    return;
                }
                {
                    getDefaultAccountCallBack.onLoaded((ArrayList<DefaultAccount>)arrayList, (ArrayList<DefaultAccount>)arrayList2);
                    return;
                }
            }
        });
    }

    @Override
    public void getWalletAccount(final AccountDataSource.GetAccountCallBack getAccountCallBack) {
        UserData userData = UserData.getInstance(this.context);
        String string2 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)userData.getUserId());
            string2 = CryptoHelper.encrypt(jSONObject.toString());
            String string3 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA : ");
            stringBuilder.append(CryptoHelper.decrypt(string2.toString()));
            Log.d((String)string3, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string4 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post : ");
        stringBuilder.append(string2);
        Log.e((String)string4, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userAccount/all").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string2).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                String string2 = AccountDataRepository.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error");
                stringBuilder.append(aNError.getErrorBody());
                Log.d((String)string2, (String)stringBuilder.toString());
                getAccountCallBack.onErrorInLoading("Something Went Wroing");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONArray jSONArray;
                    ArrayList arrayList;
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getAccountCallBack.onLocked("true");
                            return;
                        }
                        jSONArray = JSONHelper.getJSONArray(jSONObject, "wallets");
                        arrayList = new ArrayList();
                    } else {
                        boolean bl = jSONObject.isNull("errorCode");
                        if (bl) {
                            String string3 = jSONObject.getString("error");
                            getAccountCallBack.onErrorInLoading(string3);
                        } else if (jSONObject.getString("errorCode").contains((CharSequence)"AIE")) {
                            String string4 = jSONObject.getString("error");
                            getAccountCallBack.onErrorInLoading(string4);
                        } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                            JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                            if (jSONObject2.has("userId")) {
                                getAccountCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                            }
                        } else {
                            getAccountCallBack.onErrorInLoading("Something Went Wroing");
                        }
                        Log.d((String)AccountDataRepository.this.TAG, (String)jSONObject.getString("error"));
                        return;
                    }
                    for (int i = 0; i < jSONArray.length(); ++i) {
                        JSONObject jSONObject3 = JSONHelper.getJSONObject(jSONArray, i);
                        AccountData accountData = new AccountData();
                        accountData.setId(JSONHelper.getString(jSONObject3, "id"));
                        accountData.setAccountHolderName(JSONHelper.getString(jSONObject3, "accountHolderName"));
                        accountData.setAccountNumber(JSONHelper.getString(jSONObject3, "accountNumber"));
                        accountData.setAccountName(JSONHelper.getString(jSONObject3, "accountName"));
                        accountData.setIfscCode(JSONHelper.getString(jSONObject3, "ifscCode"));
                        accountData.setBranchName(JSONHelper.getString(jSONObject3, "branchName"));
                        accountData.setType(JSONHelper.getString(jSONObject3, "type"));
                        accountData.setIsStatus(JSONHelper.getString(jSONObject3, "isStatus"));
                        arrayList.add((Object)accountData);
                    }
                    getAccountCallBack.onLoaded((ArrayList<AccountData>)arrayList);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getAccountCallBack.onErrorInLoading("Something Went Wroing");
                    return;
                }
            }
        });
    }

    @Override
    public void removeAccount(AccountData accountData, final AccountDataSource.GetRemoveAccountCallBack getRemoveAccountCallBack) {
        UserData userData = UserData.getInstance(this.context);
        String string2 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)userData.getUserId());
            jSONObject.put("userAccountId", (Object)accountData.getId());
            string2 = CryptoHelper.encrypt(jSONObject.toString());
            String string3 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA : ");
            stringBuilder.append(CryptoHelper.decrypt(string2.toString()));
            Log.d((String)string3, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string4 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post : ");
        stringBuilder.append(string2);
        Log.e((String)string4, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userAccount/remove").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string2).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                String string2 = AccountDataRepository.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error");
                stringBuilder.append(aNError.getErrorBody());
                Log.d((String)string2, (String)stringBuilder.toString());
                getRemoveAccountCallBack.onErrorInLoading("Something Went Wroing");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getRemoveAccountCallBack.onLocked("true");
                            return;
                        }
                        getRemoveAccountCallBack.onRemoved(JSONHelper.getString(jSONObject, "message"));
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string3 = jSONObject.getString("error");
                        getRemoveAccountCallBack.onErrorInLoading(string3);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"AIE")) {
                        String string4 = jSONObject.getString("error");
                        getRemoveAccountCallBack.onErrorInLoading(string4);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("userId")) {
                            getRemoveAccountCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                        }
                        if (jSONObject2.has("userAccountId")) {
                            getRemoveAccountCallBack.onErrorInLoading(jSONObject2.getString("userAccountId"));
                        }
                    } else {
                        getRemoveAccountCallBack.onErrorInLoading("Something Went Wroing");
                    }
                    Log.d((String)AccountDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getRemoveAccountCallBack.onErrorInLoading("Something Went Wroing");
                    return;
                }
            }
        });
    }

    @Override
    public void updateAccount(String string2, String string3, String string4, String string5, String string6, String string7, String string8, final AccountDataSource.GetAddAccountCallBack getAddAccountCallBack) {
        UserData userData = UserData.getInstance(this.context);
        String string9 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)userData.getUserId());
            jSONObject.put("type", (Object)string3);
            jSONObject.put("userAccountId", (Object)string2);
            jSONObject.put("accountName", (Object)string4);
            jSONObject.put("accountNumber", (Object)string5);
            jSONObject.put("accountHolderName", (Object)string6);
            jSONObject.put("branchName", (Object)string7);
            jSONObject.put("ifscCode", (Object)string8);
            string9 = CryptoHelper.encrypt(jSONObject.toString());
            String string10 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA : ");
            stringBuilder.append(CryptoHelper.decrypt(string9.toString()));
            Log.d((String)string10, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string11 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post : ");
        stringBuilder.append(string9);
        Log.e((String)string11, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userAccount/edit").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string9).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                String string2 = AccountDataRepository.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error");
                stringBuilder.append(aNError.getErrorBody());
                Log.d((String)string2, (String)stringBuilder.toString());
                getAddAccountCallBack.onErrorInLoading("Something Went Wroing");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getAddAccountCallBack.onLocked("true");
                            return;
                        }
                        getAddAccountCallBack.onAccountAdded(JSONHelper.getString(jSONObject, "message"));
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string3 = jSONObject.getString("error");
                        getAddAccountCallBack.onErrorInLoading(string3);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"AIE")) {
                        String string4 = jSONObject.getString("error");
                        getAddAccountCallBack.onErrorInLoading(string4);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("userId")) {
                            getAddAccountCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                        }
                        if (jSONObject2.has("type")) {
                            getAddAccountCallBack.onErrorInLoading(jSONObject2.getString("type"));
                        }
                        if (jSONObject2.has("accountName")) {
                            getAddAccountCallBack.onErrorInAccountName(jSONObject2.getString("accountName"));
                        }
                        if (jSONObject2.has("accountNumber")) {
                            getAddAccountCallBack.onErrorInAccountNumber(jSONObject2.getString("accountNumber"));
                        }
                        if (jSONObject2.has("accountHolderName")) {
                            getAddAccountCallBack.onErrorInHolderName(jSONObject2.getString("accountHolderName"));
                        }
                        if (jSONObject2.has("branchName")) {
                            getAddAccountCallBack.onErrorInBranchName(jSONObject2.getString("branchName"));
                        }
                        if (jSONObject2.has("ifscCode")) {
                            getAddAccountCallBack.onErrorInIfsc(jSONObject2.getString("ifscCode"));
                        }
                    } else {
                        getAddAccountCallBack.onErrorInLoading("Something Went Wroing");
                    }
                    Log.d((String)AccountDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getAddAccountCallBack.onErrorInLoading("Something Went Wroing");
                    return;
                }
            }
        });
    }

}

