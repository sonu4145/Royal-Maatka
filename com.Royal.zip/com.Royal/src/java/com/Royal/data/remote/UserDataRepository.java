/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.Log
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.StringRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONObject
 */
package com.Royal.data.remote;

import android.content.Context;
import android.util.Log;
import com.Royal.data.UserData;
import com.Royal.data.helper.CryptoHelper;
import com.Royal.data.helper.JSONHelper;
import com.Royal.data.helper.LockHelper;
import com.Royal.data.remote.UserDataSource;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import org.json.JSONObject;

public class UserDataRepository
implements UserDataSource {
    private static UserDataRepository INSTANCE;
    private final String TAG = this.getClass().getSimpleName();
    private Context context;

    private UserDataRepository(Context context) {
        this.context = context;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static UserDataRepository getInstance(Context context) {
        if (INSTANCE != null) return INSTANCE;
        Class<UserDataRepository> class_ = UserDataRepository.class;
        synchronized (UserDataRepository.class) {
            if (INSTANCE != null) return INSTANCE;
            INSTANCE = new UserDataRepository(context);
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return INSTANCE;
        }
    }

    @Override
    public void changePassword(String string2, String string3, final UserDataSource.ChangePasswordCallBack changePasswordCallBack) {
        UserData userData = UserData.getInstance(this.context);
        String string4 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)userData.getUserId());
            jSONObject.put("currentPassword", (Object)string2);
            jSONObject.put("newPassword", (Object)string3);
            string4 = CryptoHelper.encrypt(jSONObject.toString());
            String string5 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA: ");
            stringBuilder.append(CryptoHelper.decrypt(string4.toString()));
            Log.d((String)string5, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            changePasswordCallBack.onErrorInLoading("Sorry, Something Went Wrong");
        }
        String string6 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post: ");
        stringBuilder.append(string4);
        Log.e((String)string6, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/modifyPassword").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string4).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                changePasswordCallBack.onErrorInLoading("Sorry, Something Went Wrong");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        changePasswordCallBack.onPasswordChanged(JSONHelper.getString(jSONObject, "message"));
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string3 = jSONObject.getString("error");
                        changePasswordCallBack.onErrorInLoading(string3);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("userId")) {
                            changePasswordCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                        }
                        if (jSONObject2.has("currentPassword")) {
                            changePasswordCallBack.onErrorInCurrentPassword(jSONObject2.getString("currentPassword"));
                        }
                        if (jSONObject2.has("newPassword")) {
                            changePasswordCallBack.onErrorInNewPassword(jSONObject2.getString("newPassword"));
                        }
                        if (jSONObject2.has("userAgent")) {
                            changePasswordCallBack.onErrorInLoading(jSONObject2.getString("userAgent"));
                        }
                    } else {
                        changePasswordCallBack.onErrorInLoading("Something Went Wrong");
                    }
                    Log.d((String)UserDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    changePasswordCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                    return;
                }
            }
        });
    }

    @Override
    public void getDetailAndLoginUser(String string2, String string3, final UserDataSource.GetUserLoginCallBack getUserLoginCallBack) {
        String string4 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("mobile", (Object)string2);
            jSONObject.put("password", (Object)string3);
            string4 = CryptoHelper.encrypt(jSONObject.toString());
            String string5 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA: ");
            stringBuilder.append(CryptoHelper.decrypt(string4.toString()));
            Log.d((String)string5, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            getUserLoginCallBack.onErrorInLoading("Sorry, Something Went Wrong");
        }
        String string6 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post: ");
        stringBuilder.append(string4);
        Log.e((String)string6, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/login").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string4).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                getUserLoginCallBack.onErrorInLoading("Sorry, Something Went Wrong");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    boolean bl = jSONObject.getString("status").equals((Object)"true");
                    if (bl) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getUserLoginCallBack.onLocked("true");
                            return;
                        }
                        String string3 = JSONHelper.getString(jSONObject, "id");
                        String string4 = JSONHelper.getString(jSONObject, "dealerId");
                        String string5 = JSONHelper.getString(jSONObject, "name");
                        String string6 = JSONHelper.getString(jSONObject, "email");
                        String string7 = JSONHelper.getString(jSONObject, "dailCode");
                        String string8 = JSONHelper.getString(jSONObject, "mobile");
                        String string9 = JSONHelper.getString(jSONObject, "password");
                        String string10 = JSONHelper.getString(jSONObject, "profileImage");
                        String string11 = JSONHelper.getString(jSONObject, "createdOn");
                        String string12 = JSONHelper.getString(jSONObject, "updatedOn");
                        String string13 = JSONHelper.getString(jSONObject, "updatedBy");
                        String string14 = JSONHelper.getString(jSONObject, "isStatus");
                        String string15 = JSONHelper.getString(jSONObject, "gender");
                        int n = JSONHelper.getInt(jSONObject, "lockPoint");
                        int n2 = JSONHelper.getInt(jSONObject, "totalPoint");
                        int n3 = JSONHelper.getInt(jSONObject, "bidPoint");
                        int n4 = JSONHelper.getInt(jSONObject, "winPoint");
                        int n5 = JSONHelper.getInt(jSONObject, "withdrawLockPoint");
                        UserData userData = UserData.getInstance(UserDataRepository.this.context);
                        userData.setUserId(string3);
                        userData.setDealerId(string4);
                        userData.setDisplayName(string5);
                        userData.setEmailAddress(string6);
                        userData.setCountryCode(string7);
                        userData.setMobileNumber(string8);
                        userData.setPassword(string9);
                        userData.setProfileImage(string10);
                        userData.setCreatedOn(string11);
                        userData.setUpdatedOn(string12);
                        userData.setUpdatedBy(string13);
                        userData.setIsStatus(string14);
                        userData.setGender(string15);
                        userData.setLockPoint(n);
                        userData.setTotalPoint(n2);
                        userData.setBidPoint(n3);
                        userData.setWinPoint(n4);
                        userData.setWithdrawLockPoint(n5);
                        userData.setIsLogin(true);
                        getUserLoginCallBack.onUserDataLoaded(userData);
                        return;
                    }
                    boolean bl2 = jSONObject.isNull("errorCode");
                    if (bl2) {
                        String string16 = jSONObject.getString("error");
                        getUserLoginCallBack.onErrorInLoading(string16);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("emailOrMobile")) {
                            getUserLoginCallBack.onErrorInUserName(jSONObject2.getString("emailOrMobile"));
                        }
                        if (jSONObject2.has("password")) {
                            getUserLoginCallBack.onErrorInPassword(jSONObject2.getString("password"));
                        }
                    } else {
                        getUserLoginCallBack.onErrorInLoading("Something Went Wroing");
                    }
                    Log.d((String)UserDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getUserLoginCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                    return;
                }
            }
        });
    }

    @Override
    public void getProfileData(final UserDataSource.GetUserDataCallBack getUserDataCallBack) {
        UserData userData = UserData.getInstance(this.context);
        String string2 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)userData.getUserId());
            string2 = CryptoHelper.encrypt(jSONObject.toString());
            String string3 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA : ");
            stringBuilder.append(CryptoHelper.decrypt(string2.toString()));
            Log.d((String)string3, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string4 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post : ");
        stringBuilder.append(string2);
        Log.e((String)string4, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/get").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string2).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                String string2 = UserDataRepository.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error");
                stringBuilder.append(aNError.getErrorBody());
                Log.d((String)string2, (String)stringBuilder.toString());
                getUserDataCallBack.onErrorInLoading("Something Went Wroing");
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            public void onResponse(String var1_1) {
                block12 : {
                    block11 : {
                        block13 : {
                            Log.e((String)"Api_response", (String)var1_1.toString());
                            var3_2 = new JSONObject(var1_1);
                            if (!var3_2.getString("status").equals((Object)"true")) ** GOTO lbl47
                            var13_3 = JSONHelper.getString(var3_2, "id");
                            var14_4 = JSONHelper.getString(var3_2, "dealerId");
                            var15_5 = JSONHelper.getString(var3_2, "name");
                            var16_6 = JSONHelper.getString(var3_2, "email");
                            var17_7 = JSONHelper.getString(var3_2, "dailCode");
                            var18_8 = JSONHelper.getString(var3_2, "mobile");
                            var19_9 = JSONHelper.getString(var3_2, "password");
                            var20_10 = JSONHelper.getString(var3_2, "profileImage");
                            var21_11 = JSONHelper.getString(var3_2, "createdOn");
                            var22_12 = JSONHelper.getString(var3_2, "updatedOn");
                            var23_13 = JSONHelper.getString(var3_2, "updatedBy");
                            var24_14 = JSONHelper.getString(var3_2, "isStatus");
                            var25_15 = JSONHelper.getString(var3_2, "gender");
                            var6_16 = "Something Went Wroing";
                            var26_18 = JSONHelper.getInt(var3_2, "lockPoint");
                            var27_19 = JSONHelper.getInt(var3_2, "totalPoint");
                            var28_20 = JSONHelper.getInt(var3_2, "bidPoint");
                            var29_21 = JSONHelper.getInt(var3_2, "winPoint");
                            var30_22 = JSONHelper.getInt(var3_2, "withdrawLockPoint");
                            var31_23 = UserData.getInstance(UserDataRepository.access$100(UserDataRepository.this));
                            var31_23.setUserId(var13_3);
                            var31_23.setDealerId(var14_4);
                            var31_23.setDisplayName(var15_5);
                            var31_23.setEmailAddress(var16_6);
                            var31_23.setCountryCode(var17_7);
                            var31_23.setMobileNumber(var18_8);
                            var31_23.setPassword(var19_9);
                            var31_23.setProfileImage(var20_10);
                            var31_23.setCreatedOn(var21_11);
                            var31_23.setUpdatedOn(var22_12);
                            var31_23.setUpdatedBy(var23_13);
                            var31_23.setIsStatus(var24_14);
                            var31_23.setGender(var25_15);
                            var31_23.setLockPoint(var26_18);
                            var31_23.setTotalPoint(var27_19);
                            var31_23.setBidPoint(var28_20);
                            var31_23.setWinPoint(var29_21);
                            var31_23.setWithdrawLockPoint(var30_22);
                            var31_23.setIsLogin(true);
                            getUserDataCallBack.onUserDataLoaded(var31_23);
                            return;
lbl47: // 1 sources:
                            var6_17 = "Something Went Wroing";
                            var7_24 = var3_2.isNull("errorCode");
                            if (var7_24) {
                                var12_25 = var3_2.getString("error");
                                getUserDataCallBack.onErrorInLoading(var12_25);
                                break block11;
                            }
                            if (var3_2.getString("errorCode").contains((CharSequence)"AIE")) {
                                var11_26 = var3_2.getString("error");
                                getUserDataCallBack.onErrorInLoading(var11_26);
                                break block11;
                            }
                            if (var3_2.getString("errorCode").contains((CharSequence)"UVE")) {
                                var10_27 = var3_2.getJSONObject("error");
                                if (var10_27.has("userId")) {
                                    getUserDataCallBack.onErrorInLoading(var10_27.getString("userId"));
                                }
                                if (var10_27.has("sessionId")) {
                                    getUserDataCallBack.onLocked(var10_27.getString("sessionId"));
                                }
                                break block11;
                            }
                            var8_28 = getUserDataCallBack;
                            var5_29 = var6_17;
                            try {
                                var8_28.onErrorInLoading(var5_29);
                                break block12;
                            }
                            catch (Exception var4_31) {
                                break block13;
                            }
                            catch (Exception var4_32) {
                                var5_29 = var6_16;
                            }
                            break block13;
                            catch (Exception var4_33) {
                                var5_29 = "Something Went Wroing";
                            }
                        }
                        var4_34.printStackTrace();
                        getUserDataCallBack.onErrorInLoading(var5_29);
                        return;
                    }
                    var5_30 = var6_17;
                }
                Log.d((String)UserDataRepository.access$000(UserDataRepository.this), (String)var3_2.getString("error"));
            }
        });
    }

    @Override
    public UserData getUserData() {
        return UserData.getInstance(this.context);
    }

    @Override
    public void getUserData(UserDataSource.GetUserDataCallBack getUserDataCallBack) {
        getUserDataCallBack.onUserDataLoaded(UserData.getInstance(this.context));
    }

    @Override
    public void getUserPoints(final UserDataSource.GetUserPointsCallBack getUserPointsCallBack) {
        UserData userData = UserData.getInstance(this.context);
        String string2 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)userData.getUserId());
            string2 = CryptoHelper.encrypt(jSONObject.toString());
            String string3 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA : ");
            stringBuilder.append(CryptoHelper.decrypt(string2.toString()));
            Log.d((String)string3, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string4 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post : ");
        stringBuilder.append(string2);
        Log.e((String)string4, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/point").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string2).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                String string2 = UserDataRepository.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error");
                stringBuilder.append(aNError.getErrorBody());
                Log.d((String)string2, (String)stringBuilder.toString());
                getUserPointsCallBack.onErrorInLoading("Something Went Wroing");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        int n = JSONHelper.getInt(jSONObject, "lockPoint");
                        int n2 = JSONHelper.getInt(jSONObject, "totalPoint");
                        int n3 = JSONHelper.getInt(jSONObject, "bidPoint");
                        int n4 = JSONHelper.getInt(jSONObject, "winPoint");
                        int n5 = JSONHelper.getInt(jSONObject, "withdrawLockPoint");
                        UserData userData = UserData.getInstance(UserDataRepository.this.context);
                        userData.setLockPoint(n);
                        userData.setTotalPoint(n2);
                        userData.setBidPoint(n3);
                        userData.setWinPoint(n4);
                        userData.setWithdrawLockPoint(n5);
                        userData.setIsLogin(true);
                        getUserPointsCallBack.onUserPointLoaded(userData);
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string3 = jSONObject.getString("error");
                        getUserPointsCallBack.onErrorInLoading(string3);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"AIE")) {
                        String string4 = jSONObject.getString("error");
                        getUserPointsCallBack.onErrorInLoading(string4);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("userId")) {
                            getUserPointsCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                        }
                        if (jSONObject2.has("sessionId")) {
                            getUserPointsCallBack.onLocked(jSONObject2.getString("sessionId"));
                        }
                    } else {
                        getUserPointsCallBack.onErrorInLoading("Something Went Wroing");
                    }
                    Log.d((String)UserDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getUserPointsCallBack.onErrorInLoading("Something Went Wroing");
                    return;
                }
            }
        });
    }

    @Override
    public void registerNewUser(String string2, String string3, String string4, String string5, final UserDataSource.GetUserRegistrationCallBack getUserRegistrationCallBack) {
        String string6 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("name", (Object)string2);
            jSONObject.put("dailCode", (Object)string3);
            jSONObject.put("mobile", (Object)string4);
            jSONObject.put("password", (Object)string5);
            string6 = CryptoHelper.encrypt(jSONObject.toString());
            String string7 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA: ");
            stringBuilder.append(CryptoHelper.decrypt(string6.toString()));
            Log.d((String)string7, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        String string8 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post: ");
        stringBuilder.append(string6);
        Log.e((String)string8, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/registration").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string6).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                String string2 = UserDataRepository.this.TAG;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("error");
                stringBuilder.append(aNError.getErrorBody());
                Log.d((String)string2, (String)stringBuilder.toString());
                getUserRegistrationCallBack.onErrorInLoading("Something Went Wroing");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getUserRegistrationCallBack.onLocked("true");
                            return;
                        }
                        UserData.getInstance(UserDataRepository.this.context);
                        getUserRegistrationCallBack.onUserRegisteredSuccessFully("Registration Successfully");
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string3 = jSONObject.getString("error");
                        getUserRegistrationCallBack.onErrorInLoading(string3);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"AIE")) {
                        String string4 = jSONObject.getString("error");
                        getUserRegistrationCallBack.onErrorInLoading(string4);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("name")) {
                            getUserRegistrationCallBack.onErrorInName(jSONObject2.getString("name"));
                        }
                        if (jSONObject2.has("dialCode")) {
                            getUserRegistrationCallBack.onErrorInCountryCode(jSONObject2.getString("dialCode"));
                        }
                        if (jSONObject2.has("mobile")) {
                            getUserRegistrationCallBack.onErrorInMobileNumber(jSONObject2.getString("mobile"));
                        }
                        if (jSONObject2.has("password")) {
                            getUserRegistrationCallBack.onErrorInPassword(jSONObject2.getString("mobile"));
                        }
                    } else {
                        getUserRegistrationCallBack.onErrorInLoading("Something Went Wroing");
                    }
                    Log.d((String)UserDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getUserRegistrationCallBack.onErrorInLoading("Something Went Wroing");
                    return;
                }
            }
        });
    }

    @Override
    public void sendOtpMsg(String string2, String string3, String string4, final UserDataSource.GetUserOtpCallBack getUserOtpCallBack) {
        String string5;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("mobile", (Object)string2);
            jSONObject.put("otp", (Object)string3);
            Log.e((String)this.TAG, (String)jSONObject.toString());
            string5 = CryptoHelper.encrypt(jSONObject.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            string5 = "";
        }
        String string6 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post: ");
        stringBuilder.append(string5);
        Log.e((String)string6, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/verificationCode").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string5).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                Log.e((String)"Api_response", (String)aNError.getErrorBody());
                getUserOtpCallBack.onErrorInLoading("Sorry, Something Went Wrong");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getUserOtpCallBack.onLocked("true");
                            return;
                        }
                        String string3 = jSONObject.getString("message");
                        getUserOtpCallBack.onUserOtpSent(string3, "");
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string4 = jSONObject.getString("error");
                        getUserOtpCallBack.onErrorInLoading(string4);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("mobile")) {
                            getUserOtpCallBack.onErrorInMobile(jSONObject2.getString("mobile"));
                        }
                        if (jSONObject2.has("otp")) {
                            getUserOtpCallBack.onErrorInLoading(jSONObject2.getString("otp"));
                        }
                    } else {
                        getUserOtpCallBack.onErrorInLoading("Something Went Wroing");
                    }
                    Log.d((String)UserDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getUserOtpCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                    return;
                }
            }
        });
    }

    @Override
    public void sendVerificationCode(String string2, String string3, String string4, final UserDataSource.GetUserOtpCallBack getUserOtpCallBack) {
        String string5;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("mobile", (Object)string2);
            jSONObject.put("otp", (Object)string3);
            Log.e((String)this.TAG, (String)jSONObject.toString());
            string5 = CryptoHelper.encrypt(jSONObject.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            string5 = "";
        }
        String string6 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post: ");
        stringBuilder.append(string5);
        Log.e((String)string6, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/identifyAndSendVerificationCode").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string5).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                getUserOtpCallBack.onErrorInLoading("Sorry, Something Went Wrong");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        if (LockHelper.isLocked(jSONObject)) {
                            getUserOtpCallBack.onLocked("true");
                            return;
                        }
                        String string3 = JSONHelper.getString(jSONObject, "id");
                        String string4 = jSONObject.getString("message");
                        getUserOtpCallBack.onUserOtpSent(string4, string3);
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string5 = jSONObject.getString("error");
                        getUserOtpCallBack.onErrorInLoading(string5);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("mobile")) {
                            getUserOtpCallBack.onErrorInMobile(jSONObject2.getString("mobile"));
                        }
                        if (jSONObject2.has("otp")) {
                            getUserOtpCallBack.onErrorInLoading(jSONObject2.getString("otp"));
                        }
                    } else {
                        getUserOtpCallBack.onErrorInLoading("Something Went Wroing");
                    }
                    Log.d((String)UserDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    getUserOtpCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                    return;
                }
            }
        });
    }

    @Override
    public void setNewPassword(String string2, String string3, String string4, String string5, final UserDataSource.SetNewPasswordCallBack setNewPasswordCallBack) {
        UserData.getInstance(this.context);
        String string6 = "";
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("userId", (Object)string2);
            jSONObject.put("mobile", (Object)string3);
            jSONObject.put("password", (Object)string4);
            string6 = CryptoHelper.encrypt(jSONObject.toString());
            String string7 = this.TAG;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DATA: ");
            stringBuilder.append(CryptoHelper.decrypt(string6.toString()));
            Log.d((String)string7, (String)stringBuilder.toString());
        }
        catch (Exception exception) {
            exception.printStackTrace();
            setNewPasswordCallBack.onErrorInLoading("Sorry, Something Went Wrong");
        }
        String string8 = this.TAG;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("post: ");
        stringBuilder.append(string6);
        Log.e((String)string8, (String)stringBuilder.toString());
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/setNewPasswordOnForgot").setTag((Object)this.TAG).setPriority(Priority.HIGH).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", string6).build().getAsString(new StringRequestListener(){

            public void onError(ANError aNError) {
                setNewPasswordCallBack.onErrorInLoading("Sorry, Something Went Wrong");
            }

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onResponse(String string2) {
                Log.e((String)"Api_response", (String)string2.toString());
                try {
                    JSONObject jSONObject = new JSONObject(string2);
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        setNewPasswordCallBack.onSetNewPassword(JSONHelper.getString(jSONObject, "message"));
                        return;
                    }
                    boolean bl = jSONObject.isNull("errorCode");
                    if (bl) {
                        String string3 = jSONObject.getString("error");
                        setNewPasswordCallBack.onErrorInLoading(string3);
                    } else if (jSONObject.getString("errorCode").contains((CharSequence)"UVE")) {
                        JSONObject jSONObject2 = jSONObject.getJSONObject("error");
                        if (jSONObject2.has("userId")) {
                            setNewPasswordCallBack.onErrorInLoading(jSONObject2.getString("userId"));
                        }
                        if (jSONObject2.has("username")) {
                            setNewPasswordCallBack.onErrorInLoading(jSONObject2.getString("username"));
                        }
                        if (jSONObject2.has("password")) {
                            setNewPasswordCallBack.onErrorInPassword(jSONObject2.getString("password"));
                        }
                        if (jSONObject2.has("verificationBy")) {
                            setNewPasswordCallBack.onErrorInLoading(jSONObject2.getString("verificationBy"));
                        }
                        if (jSONObject2.has("userAgent")) {
                            setNewPasswordCallBack.onErrorInLoading(jSONObject2.getString("userAgent"));
                        }
                    } else {
                        setNewPasswordCallBack.onErrorInLoading("Something Went Wrong");
                    }
                    Log.d((String)UserDataRepository.this.TAG, (String)jSONObject.getString("error"));
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    setNewPasswordCallBack.onErrorInLoading("Sorry, Something Went Wrong");
                    return;
                }
            }
        });
    }

}

