/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.Royal.data.helper;

import org.json.JSONArray;
import org.json.JSONObject;

public class JSONHelper {
    public static boolean getBoolean(JSONArray jSONArray, int n) {
        try {
            if (!jSONArray.isNull(n)) {
                boolean bl = jSONArray.getBoolean(n);
                return bl;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return false;
    }

    public static boolean getBoolean(JSONArray jSONArray, int n, boolean bl) {
        try {
            if (!jSONArray.isNull(n)) {
                boolean bl2 = jSONArray.getBoolean(n);
                return bl2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return bl;
    }

    public static boolean getBoolean(JSONObject jSONObject, String string2) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                boolean bl = jSONObject.getBoolean(string2);
                return bl;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return false;
    }

    public static boolean getBoolean(JSONObject jSONObject, String string2, boolean bl) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                boolean bl2 = jSONObject.getBoolean(string2);
                return bl2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return bl;
    }

    public static double getDouble(JSONArray jSONArray, int n) {
        try {
            if (!jSONArray.isNull(n)) {
                double d = jSONArray.getDouble(n);
                return d;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0.0;
    }

    public static double getDouble(JSONArray jSONArray, int n, double d) {
        try {
            if (!jSONArray.isNull(n)) {
                double d2 = jSONArray.getDouble(n);
                return d2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return d;
    }

    public static double getDouble(JSONObject jSONObject, String string2) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                double d = jSONObject.getDouble(string2);
                return d;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0.0;
    }

    public static double getDouble(JSONObject jSONObject, String string2, double d) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                double d2 = jSONObject.getDouble(string2);
                return d2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return d;
    }

    public static int getInt(JSONArray jSONArray, int n) {
        try {
            if (!jSONArray.isNull(n)) {
                int n2 = jSONArray.getInt(n);
                return n2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0;
    }

    public static int getInt(JSONArray jSONArray, int n, int n2) {
        try {
            if (!jSONArray.isNull(n)) {
                int n3 = jSONArray.getInt(n);
                return n3;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return n2;
    }

    public static int getInt(JSONObject jSONObject, String string2) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                int n = jSONObject.getInt(string2);
                return n;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0;
    }

    public static int getInt(JSONObject jSONObject, String string2, int n) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                int n2 = jSONObject.getInt(string2);
                return n2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return n;
    }

    public static JSONArray getJSONArray(JSONObject jSONObject, String string2) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                JSONArray jSONArray = jSONObject.getJSONArray(string2);
                return jSONArray;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return new JSONArray();
    }

    public static JSONObject getJSONObject(JSONArray jSONArray, int n) {
        try {
            if (!jSONArray.isNull(n)) {
                JSONObject jSONObject = jSONArray.getJSONObject(n);
                return jSONObject;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return new JSONObject();
    }

    public static JSONObject getJSONObject(JSONObject jSONObject, String string2) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                JSONObject jSONObject2 = jSONObject.getJSONObject(string2);
                return jSONObject2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return new JSONObject();
    }

    public static long getLong(JSONArray jSONArray, int n) {
        try {
            if (!jSONArray.isNull(n)) {
                long l = jSONArray.getLong(n);
                return l;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0L;
    }

    public static long getLong(JSONArray jSONArray, int n, long l) {
        try {
            if (!jSONArray.isNull(n)) {
                long l2 = jSONArray.getLong(n);
                return l2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return l;
    }

    public static long getLong(JSONObject jSONObject, String string2) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                long l = jSONObject.getLong(string2);
                return l;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return 0L;
    }

    public static long getLong(JSONObject jSONObject, String string2, long l) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                long l2 = jSONObject.getLong(string2);
                return l2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return l;
    }

    public static String getString(JSONArray jSONArray, int n) {
        try {
            if (!jSONArray.isNull(n)) {
                String string2 = jSONArray.getString(n);
                return string2;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return "";
    }

    public static String getString(JSONObject jSONObject, String string2) {
        try {
            if (jSONObject.has(string2) && !jSONObject.isNull(string2)) {
                String string3 = jSONObject.getString(string2);
                return string3;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return "";
    }
}

