/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.concurrent.TimeUnit
 */
package com.Royal.data.helper;

import com.Royal.data.helper.LogHelper;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class CalenderHelper {
    public static Calendar currentCalendar;
    public static String currentDate;
    public static String currentTime;
    public static final SimpleDateFormat dateFormat;
    public static final SimpleDateFormat dateTimeFormat;
    public static final SimpleDateFormat dateTimeFormatForTimeSlot;
    public static final SimpleDateFormat dayAndDateDisplayFormat;
    public static final SimpleDateFormat monthDate;
    public static final SimpleDateFormat monthDateAndTime;
    public static final SimpleDateFormat monthFullNameFormat;
    public static final SimpleDateFormat monthShortNameFormat;
    public static final SimpleDateFormat time12HourFormat;
    public static final SimpleDateFormat time24HourFormat;
    public static final SimpleDateFormat time24HourFormatWithSecond;
    public static final SimpleDateFormat weekDayFullNameFormat;
    public static final SimpleDateFormat weekDayShortNameFormat;

    static {
        Calendar calendar;
        time12HourFormat = new SimpleDateFormat("hh:mm a");
        time24HourFormat = new SimpleDateFormat("HH:mm");
        time24HourFormatWithSecond = new SimpleDateFormat("HH:mm:ss");
        dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateTimeFormatForTimeSlot = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        monthFullNameFormat = new SimpleDateFormat("MMMM");
        monthShortNameFormat = new SimpleDateFormat("MMM");
        weekDayFullNameFormat = new SimpleDateFormat("EEEE");
        weekDayShortNameFormat = new SimpleDateFormat("EEE");
        dayAndDateDisplayFormat = new SimpleDateFormat("EEEE, MMM d, yyyy");
        monthDateAndTime = new SimpleDateFormat("MMM d, yyyy hh:mm a");
        monthDate = new SimpleDateFormat("MMM d, yyyy");
        currentCalendar = calendar = Calendar.getInstance();
        currentDate = dateFormat.format(calendar.getTime());
        currentTime = time24HourFormat.format(currentCalendar.getTime());
    }

    public static long getTimeDifferenceInSecond(Calendar calendar, Calendar calendar2) {
        return Math.abs((long)TimeUnit.MILLISECONDS.toSeconds(calendar2.getTimeInMillis() - calendar.getTimeInMillis()));
    }

    public static boolean isDateIsSame(Calendar calendar, Calendar calendar2) {
        boolean bl = false;
        if (calendar != null) {
            if (calendar2 == null) {
                return false;
            }
            int n = calendar.get(1);
            int n2 = calendar2.get(1);
            bl = false;
            if (n == n2) {
                int n3 = calendar.get(2);
                int n4 = calendar2.get(2);
                bl = false;
                if (n3 == n4) {
                    int n5 = calendar.get(5);
                    int n6 = calendar2.get(5);
                    bl = false;
                    if (n5 == n6) {
                        bl = true;
                    }
                }
            }
        }
        return bl;
    }

    public static boolean isTimeInPast(Calendar calendar, Calendar calendar2, int n) {
        return TimeUnit.MILLISECONDS.toMinutes(calendar2.getTimeInMillis() - calendar.getTimeInMillis()) < (long)n;
    }

    public static void setCurrentTime(String string2, String string3) {
        try {
            currentDate = string2.trim();
            currentTime = string3.trim();
            Calendar calendar = currentCalendar;
            SimpleDateFormat simpleDateFormat = dateTimeFormat;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(currentDate);
            stringBuilder.append(" ");
            stringBuilder.append(currentTime);
            calendar.setTime(simpleDateFormat.parse(stringBuilder.toString()));
            return;
        }
        catch (Exception exception) {
            LogHelper.showErrors(exception.toString());
            return;
        }
    }
}

