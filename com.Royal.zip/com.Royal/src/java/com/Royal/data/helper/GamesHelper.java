/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.Royal.data.helper;

import com.Royal.data.BazaarData;
import com.Royal.data.ResultData;
import java.util.ArrayList;

public class GamesHelper {
    public static ArrayList<ResultData> filterCloseResult(ArrayList<ResultData> arrayList) {
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < arrayList.size(); ++i) {
            if (!((ResultData)arrayList.get(i)).getSession().contentEquals((CharSequence)"close")) continue;
            arrayList2.add((Object)((ResultData)arrayList.get(i)));
        }
        return arrayList2;
    }

    public static ArrayList<ResultData> filterOpenResult(ArrayList<ResultData> arrayList) {
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < arrayList.size(); ++i) {
            if (!((ResultData)arrayList.get(i)).getSession().contentEquals((CharSequence)"open")) continue;
            arrayList2.add((Object)((ResultData)arrayList.get(i)));
        }
        return arrayList2;
    }

    public static boolean getIsActiveStatus(String string2) {
        return string2.contentEquals((CharSequence)"active");
    }

    public static ArrayList<ResultData> getResultByBazaar(BazaarData bazaarData, ArrayList<ResultData> arrayList) {
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < arrayList.size(); ++i) {
            if (((ResultData)arrayList.get(i)).getBazaarId() != bazaarData.getId()) continue;
            arrayList2.add((Object)((ResultData)arrayList.get(i)));
        }
        return arrayList2;
    }
}

