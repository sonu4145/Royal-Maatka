/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.Royal.data.helper;

import com.Royal.data.helper.JSONHelper;
import org.json.JSONObject;

public class LockHelper {
    public static boolean isLocked(JSONObject jSONObject) {
        return jSONObject.has("lock") && JSONHelper.getString(jSONObject, "lock").equals((Object)"true");
    }
}

