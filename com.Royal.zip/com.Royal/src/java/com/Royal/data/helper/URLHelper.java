/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.data.helper;

public class URLHelper {
    public static final String AUTH_TOKEN = "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==";
    public static final String URL_ADD_USER_ACCOUNTS = "http://www.royalmatka.net/api/v1/userAccount/create";
    public static final String URL_BASE = "http://www.royalmatka.net/api/v1/";
    public static final String URL_DELETE_USER_ACCOUNTS = "http://www.royalmatka.net/api/v1/userAccount/remove";
    public static final String URL_GAME_BAZAAR_GET = "http://www.royalmatka.net/api/v1/bazaar/all";
    public static final String URL_GAME_BAZAAR_TIME = "http://www.royalmatka.net/api/v1/bazaar/timing";
    public static final String URL_GET_CURRENT_DATE_TIME = "http://www.royalmatka.net/api/v1/defaultSetting/getCurrentDateTime";
    public static final String URL_GET_DEFAULT_ACCOUNTS = "http://www.royalmatka.net/api/v1/userAccount/defaultList";
    public static final String URL_GET_USER_ACCOUNTS = "http://www.royalmatka.net/api/v1/userAccount/all";
    public static final String URL_PLACE_BID = "http://www.royalmatka.net/api/v1/bidding/create";
    public static final String URL_UPDATE_USER_ACCOUNTS = "http://www.royalmatka.net/api/v1/userAccount/edit";
    public static final String URL_USER_CHANGE_PASSWORD = "http://www.royalmatka.net/api/v1/user/modifyPassword";
    public static final String URL_USER_DETAIL = "http://www.royalmatka.net/api/v1/user/get";
    public static final String URL_USER_LOGIN = "http://www.royalmatka.net/api/v1/user/login";
    public static final String URL_USER_OTP = "http://www.royalmatka.net/api/v1/user/verificationCode";
    public static final String URL_USER_POINTS = "http://www.royalmatka.net/api/v1/user/point";
    public static final String URL_USER_REGISTRATION = "http://www.royalmatka.net/api/v1/user/registration";
    public static final String URL_USER_SEND_VERIFICATION_CODE = "http://www.royalmatka.net/api/v1/user/identifyAndSendVerificationCode";
    public static final String URL_USER_SET_NEW_PASSWORD = "http://www.royalmatka.net/api/v1/user/setNewPasswordOnForgot";
    public static final String URL_USER_VALIDATE_PASSWORD = "http://www.royalmatka.net/api/v1/user/validateCurrentPassword";
}

