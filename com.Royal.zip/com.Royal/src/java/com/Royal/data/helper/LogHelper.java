/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.Royal.data.helper;

import android.util.Log;

public class LogHelper {
    public static void showApiResponse(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("resp: ");
        stringBuilder.append(string2);
        Log.d((String)"API_Response", (String)stringBuilder.toString());
    }

    public static void showErrors(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("error: ");
        stringBuilder.append(string2);
        Log.e((String)"Error", (String)stringBuilder.toString());
    }
}

