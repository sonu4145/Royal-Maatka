/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.org.apache.commons.codec.binary.Base64
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.Key
 *  java.security.NoSuchAlgorithmException
 *  java.security.spec.AlgorithmParameterSpec
 *  javax.crypto.Cipher
 *  javax.crypto.NoSuchPaddingException
 *  javax.crypto.spec.IvParameterSpec
 *  javax.crypto.spec.SecretKeySpec
 */
package com.Royal.data.helper;

import android.org.apache.commons.codec.binary.Base64;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoHelper {
    private static final String SecretKey = "qaz127mlp[;.8yt&";
    private Cipher cipher;
    private IvParameterSpec ivspec = new IvParameterSpec("qaz127mlp[;.8yt&".getBytes());
    private SecretKeySpec keyspec = new SecretKeySpec("qaz127mlp[;.8yt&".getBytes(), "AES");

    public CryptoHelper() {
        try {
            this.cipher = Cipher.getInstance((String)"AES/CBC/PKCS5Padding");
            return;
        }
        catch (NoSuchPaddingException noSuchPaddingException) {
            noSuchPaddingException.printStackTrace();
            return;
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            noSuchAlgorithmException.printStackTrace();
            return;
        }
    }

    public static String decrypt(String string2) throws Exception {
        return new String(new CryptoHelper().decryptInternal(string2));
    }

    private byte[] decryptInternal(String string2) throws Exception {
        if (string2 != null && string2.length() != 0) {
            try {
                this.cipher.init(2, (Key)this.keyspec, (AlgorithmParameterSpec)this.ivspec);
                byte[] arrby = this.cipher.doFinal(Base64.decodeBase64((String)string2));
                return arrby;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("[decrypt] ");
                stringBuilder.append(exception.getMessage());
                throw new Exception(stringBuilder.toString());
            }
        }
        throw new Exception("Empty string");
    }

    public static String encrypt(String string2) throws Exception {
        return Base64.encodeBase64String((byte[])new CryptoHelper().encryptInternal(string2));
    }

    private byte[] encryptInternal(String string2) throws Exception {
        if (string2 != null && string2.length() != 0) {
            try {
                this.cipher.init(1, (Key)this.keyspec, (AlgorithmParameterSpec)this.ivspec);
                byte[] arrby = this.cipher.doFinal(string2.getBytes());
                return arrby;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("[encrypt] ");
                stringBuilder.append(exception.getMessage());
                throw new Exception(stringBuilder.toString());
            }
        }
        throw new Exception("Empty string");
    }
}

