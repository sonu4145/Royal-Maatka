/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.preference.PreferenceManager
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.Royal.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import java.io.Serializable;

public class UserData
implements Serializable {
    private static UserData INSTANCE;
    private final String TAG = this.getClass().getSimpleName();
    public int bidPoint;
    Context context;
    public String countryCode = "countryCode";
    public String createdOn = "createdOn";
    public String dealerId = "dealerId";
    public String displayName = "displayName";
    public String emailAddress = "emailAddress";
    public String gender = "gender";
    public boolean isLogin;
    public String isStatus = "isStatus";
    public int lockPoint;
    public String mobileNumber = "mobileNumber";
    public String password = "password";
    SharedPreferences prefs;
    public String profileImage = "profileImage";
    public int totalPoint;
    public String updatedBy = "updatedBy";
    public String updatedOn = "updatedOn";
    public String userId = "userId";
    public int winPoint;
    public int withdrawLockPoint;

    public UserData(Context context) {
        this.context = context;
        this.prefs = PreferenceManager.getDefaultSharedPreferences((Context)context);
    }

    public static UserData getINSTANCE() {
        return INSTANCE;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static UserData getInstance(Context context) {
        if (INSTANCE != null) return INSTANCE;
        Class<UserData> class_ = UserData.class;
        synchronized (UserData.class) {
            if (INSTANCE != null) return INSTANCE;
            INSTANCE = new UserData(context);
            // ** MonitorExit[var2_1] (shouldn't be in output)
            return INSTANCE;
        }
    }

    public static void setINSTANCE(UserData userData) {
        INSTANCE = userData;
    }

    public int getBidPoint() {
        return this.bidPoint;
    }

    public Context getContext() {
        return this.context;
    }

    public String getCountryCode() {
        return this.countryCode;
    }

    public String getCreatedOn() {
        return this.createdOn;
    }

    public String getDealerId() {
        return this.dealerId;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public String getGender() {
        return this.gender;
    }

    public boolean getIsLogin() {
        return this.isLogin;
    }

    public String getIsStatus() {
        return this.isStatus;
    }

    public int getLockPoint() {
        return this.lockPoint;
    }

    public String getMobileNumber() {
        return this.mobileNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public SharedPreferences getPrefs() {
        return this.prefs;
    }

    public String getProfileImage() {
        return this.profileImage;
    }

    public String getTAG() {
        return this.TAG;
    }

    public int getTotalPoint() {
        return this.totalPoint;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public String getUpdatedOn() {
        return this.updatedOn;
    }

    public String getUserId() {
        return this.userId;
    }

    public int getWinPoint() {
        return this.winPoint;
    }

    public int isWithdrawLockPoint() {
        return this.withdrawLockPoint;
    }

    public void setBidPoint(int n) {
        this.bidPoint = n;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public void setCountryCode(String string2) {
        this.countryCode = string2;
    }

    public void setCreatedOn(String string2) {
        this.createdOn = string2;
    }

    public void setDealerId(String string2) {
        this.dealerId = string2;
    }

    public void setDisplayName(String string2) {
        this.displayName = string2;
    }

    public void setEmailAddress(String string2) {
        this.emailAddress = string2;
    }

    public void setGender(String string2) {
        this.gender = string2;
    }

    public void setIsLogin(boolean bl) {
        this.isLogin = bl;
    }

    public void setIsStatus(String string2) {
        this.isStatus = string2;
    }

    public void setLockPoint(int n) {
        this.lockPoint = n;
    }

    public void setMobileNumber(String string2) {
        this.mobileNumber = string2;
    }

    public void setPassword(String string2) {
        this.password = string2;
    }

    public void setPrefs(SharedPreferences sharedPreferences) {
        this.prefs = sharedPreferences;
    }

    public void setProfileImage(String string2) {
        this.profileImage = string2;
    }

    public void setTotalPoint(int n) {
        this.totalPoint = n;
    }

    public void setUpdatedBy(String string2) {
        this.updatedBy = string2;
    }

    public void setUpdatedOn(String string2) {
        this.updatedOn = string2;
    }

    public void setUserId(String string2) {
        this.userId = string2;
    }

    public void setWinPoint(int n) {
        this.winPoint = n;
    }

    public void setWithdrawLockPoint(int n) {
        this.withdrawLockPoint = n;
    }
}

