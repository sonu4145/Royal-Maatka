/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.Iterator
 *  org.json.JSONArray
 *  org.json.JSONObject
 */
package com.Royal.data;

import com.Royal.Utils.GameUtils;
import com.Royal.data.GamesName;
import com.Royal.data.helper.CalenderHelper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

public class BiddingData {
    static ArrayList<BiddingData> biddingData = new ArrayList();
    public static GamesName game;
    Calendar calDateTime;
    String digit;
    int points;
    String session;

    public static void addBiddingData(BiddingData biddingData, GetBiddingDataCallBack getBiddingDataCallBack) {
        int n = BiddingData.findBidding(biddingData);
        if (n >= 0 && n < BiddingData.biddingData.size()) {
            int n2 = ((BiddingData)BiddingData.biddingData.get(n)).getPoints() + biddingData.getPoints();
            if (BiddingData.getTotalPoints() + biddingData.getPoints() <= 90000000) {
                ((BiddingData)BiddingData.biddingData.get(n)).setPoints(n2);
                getBiddingDataCallBack.onAdded("Bid Added Successfully");
                return;
            }
            getBiddingDataCallBack.onError("Sorry, Your Bid Amount Exceed The Limit Of 10000000");
            return;
        }
        if (BiddingData.getTotalPoints() + biddingData.getPoints() <= 90000000) {
            BiddingData.biddingData.add((Object)biddingData);
            getBiddingDataCallBack.onAdded("Bid Added Successfully");
            return;
        }
        getBiddingDataCallBack.onError("Sorry, Your Bid Amount Exceed The Limit Of 10000000");
    }

    public static void addBiddingData(ArrayList<BiddingData> arrayList, GetBiddingDataCallBack getBiddingDataCallBack) {
        boolean bl;
        block6 : {
            for (int i = 0; i < arrayList.size(); ++i) {
                BiddingData biddingData = (BiddingData)arrayList.get(i);
                int n = BiddingData.findBidding(biddingData);
                if (n >= 0 && n < BiddingData.biddingData.size()) {
                    int n2 = ((BiddingData)BiddingData.biddingData.get(n)).getPoints() + biddingData.getPoints();
                    int n3 = BiddingData.getTotalPoints() + biddingData.getPoints();
                    bl = false;
                    if (n3 <= 90000000) {
                        ((BiddingData)BiddingData.biddingData.get(n)).setPoints(n2);
                        continue;
                    }
                } else {
                    int n4 = BiddingData.getTotalPoints() + biddingData.getPoints();
                    bl = false;
                    if (n4 <= 90000000) {
                        BiddingData.biddingData.add((Object)biddingData);
                        continue;
                    }
                }
                break block6;
            }
            bl = true;
        }
        if (bl) {
            getBiddingDataCallBack.onAdded("Bid Added Successfully");
            return;
        }
        getBiddingDataCallBack.onError("Sorry, Your Bid Amount Exceed The Limit Of 10000000");
    }

    public static void clearBiddingData() {
        biddingData.clear();
    }

    public static int findBidding(BiddingData biddingData) {
        for (int i = 0; i < BiddingData.biddingData.size(); ++i) {
            BiddingData biddingData2 = (BiddingData)BiddingData.biddingData.get(i);
            if (!CalenderHelper.isDateIsSame(biddingData2.getCalDateTime(), biddingData.getCalDateTime()) || !biddingData2.getDigit().equalsIgnoreCase(biddingData.getDigit()) || !biddingData2.getSession().equalsIgnoreCase(biddingData.getSession())) continue;
            return i;
        }
        return -1;
    }

    public static ArrayList<BiddingData> getBiddingData() {
        return biddingData;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String getBiddingDateList() {
        JSONObject jSONObject = new JSONObject();
        try {
            ArrayList arrayList = new ArrayList();
            for (BiddingData biddingData : BiddingData.biddingData) {
                ArrayList<BiddingData> arrayList2;
                if (BiddingData.isAlreadyHaveSameDate((ArrayList<ArrayList<BiddingData>>)arrayList, biddingData) || (arrayList2 = BiddingData.getOpenAndCloseData(biddingData)).size() <= 0) continue;
                arrayList.add(arrayList2);
            }
            for (ArrayList arrayList3 : arrayList) {
                String string2 = "";
                JSONObject jSONObject2 = new JSONObject();
                for (BiddingData biddingData : arrayList3) {
                    String string3 = CalenderHelper.dateFormat.format(biddingData.getCalDateTime().getTime());
                    jSONObject2.put(biddingData.getSession(), (Object)CalenderHelper.time24HourFormatWithSecond.format(biddingData.getCalDateTime().getTime()));
                    string2 = string3;
                }
                jSONObject.put(string2, (Object)jSONObject2);
            }
            return jSONObject.toString().replace((CharSequence)"{", (CharSequence)"[").replace((CharSequence)"}", (CharSequence)"]");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return jSONObject.toString().replace((CharSequence)"{", (CharSequence)"[").replace((CharSequence)"}", (CharSequence)"]");
    }

    public static JSONArray getBiddingList() {
        JSONArray jSONArray = new JSONArray();
        try {
            for (BiddingData biddingData : BiddingData.biddingData) {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("date", (Object)CalenderHelper.dateFormat.format(biddingData.getCalDateTime().getTime()));
                jSONObject.put("game", (Object)BiddingData.getGame().getName());
                jSONObject.put("gameKey", (Object)BiddingData.getGame().getGame());
                jSONObject.put("session", (Object)biddingData.getSession());
                jSONObject.put("digit", (Object)biddingData.getDigit());
                jSONObject.put("point", biddingData.getPoints());
                jSONArray.put((Object)jSONObject);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return jSONArray;
    }

    public static JSONArray getDateList() {
        JSONArray jSONArray = new JSONArray();
        for (BiddingData biddingData : BiddingData.biddingData) {
            jSONArray.put((Object)CalenderHelper.dateFormat.format(biddingData.getCalDateTime().getTime()));
        }
        return jSONArray;
    }

    public static GamesName getGame() {
        return game;
    }

    public static JSONArray getGameKeyList() {
        JSONArray jSONArray = new JSONArray();
        if (BiddingData.getGame() == GamesName.ANK) {
            if (!jSONArray.toString().contains((CharSequence)"ANK")) {
                jSONArray.put((Object)"ANK");
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.SINGLE_PANA) {
            if (!jSONArray.toString().contains((CharSequence)"SPPANA")) {
                jSONArray.put((Object)"SPPANA");
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.DOUBLE_PANA) {
            if (!jSONArray.toString().contains((CharSequence)"DPPANA")) {
                jSONArray.put((Object)"DPPANA");
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.TRIPLE_PANA) {
            if (!jSONArray.toString().contains((CharSequence)"TPPANA")) {
                jSONArray.put((Object)"TPPANA");
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.SPDPTP_PANA) {
            for (BiddingData biddingData : BiddingData.biddingData) {
                if (GameUtils.isSinglePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"SPMOTOR")) {
                    jSONArray.put((Object)"SPMOTOR");
                }
                if (GameUtils.isDoublePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"DPMOTOR")) {
                    jSONArray.put((Object)"DPMOTOR");
                }
                if (GameUtils.isTriplePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"TPPANA")) {
                    jSONArray.put((Object)"TPPANA");
                }
                if (!jSONArray.toString().contains((CharSequence)"SPMOTOR") || !jSONArray.toString().contains((CharSequence)"DPMOTOR") || !jSONArray.toString().contains((CharSequence)"TPPANA")) continue;
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.COMBINE_PANA) {
            for (BiddingData biddingData : BiddingData.biddingData) {
                if (GameUtils.isSinglePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"SPPANA")) {
                    jSONArray.put((Object)"SPPANA");
                }
                if (GameUtils.isDoublePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"DPPANA")) {
                    jSONArray.put((Object)"DPPANA");
                }
                if (GameUtils.isTriplePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"TPPANA")) {
                    jSONArray.put((Object)"TPPANA");
                }
                if (!jSONArray.toString().contains((CharSequence)"SPPANA") || !jSONArray.toString().contains((CharSequence)"DPPANA") || !jSONArray.toString().contains((CharSequence)"TPPANA")) continue;
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.MULTIPLE_PANA) {
            for (BiddingData biddingData : BiddingData.biddingData) {
                if (GameUtils.isAnk(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"ANK")) {
                    jSONArray.put((Object)"ANK");
                }
                if (GameUtils.isSinglePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"SPPANA")) {
                    jSONArray.put((Object)"SPPANA");
                }
                if (GameUtils.isDoublePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"DPPANA")) {
                    jSONArray.put((Object)"DPPANA");
                }
                if (GameUtils.isTriplePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"TPPANA")) {
                    jSONArray.put((Object)"TPPANA");
                }
                if (GameUtils.isJodi(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"JODI")) {
                    jSONArray.put((Object)"JODI");
                }
                if (!jSONArray.toString().contains((CharSequence)"ANK") || !jSONArray.toString().contains((CharSequence)"SPPANA") || !jSONArray.toString().contains((CharSequence)"DPPANA") || !jSONArray.toString().contains((CharSequence)"TPPANA") || !jSONArray.toString().contains((CharSequence)"JODI")) continue;
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.FAMILY_PANA) {
            for (BiddingData biddingData : BiddingData.biddingData) {
                if (GameUtils.isSinglePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"SPPANA")) {
                    jSONArray.put((Object)"SPPANA");
                }
                if (GameUtils.isDoublePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"DPPANA")) {
                    jSONArray.put((Object)"DPPANA");
                }
                if (GameUtils.isTriplePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"TPPANA")) {
                    jSONArray.put((Object)"TPPANA");
                }
                if (!jSONArray.toString().contains((CharSequence)"SPPANA") || !jSONArray.toString().contains((CharSequence)"DPPANA") || !jSONArray.toString().contains((CharSequence)"TPPANA")) continue;
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.SP_MOTOR) {
            if (!jSONArray.toString().contains((CharSequence)"SPMOTOR")) {
                jSONArray.put((Object)"SPMOTOR");
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.DP_MOTOR) {
            if (!jSONArray.toString().contains((CharSequence)"DPMOTOR")) {
                jSONArray.put((Object)"DPMOTOR");
                return jSONArray;
            }
        } else if (BiddingData.getGame() == GamesName.CP_MOTOR) {
            for (BiddingData biddingData : BiddingData.biddingData) {
                if (GameUtils.isSinglePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"SPMOTOR")) {
                    jSONArray.put((Object)"SPMOTOR");
                }
                if (GameUtils.isDoublePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"DPMOTOR")) {
                    jSONArray.put((Object)"DPMOTOR");
                }
                if (GameUtils.isTriplePana(biddingData.getDigit()) && !jSONArray.toString().contains((CharSequence)"TPPANA")) {
                    jSONArray.put((Object)"TPPANA");
                }
                if (!jSONArray.toString().contains((CharSequence)"SPMOTOR") || !jSONArray.toString().contains((CharSequence)"DPMOTOR") || !jSONArray.toString().contains((CharSequence)"TPPANA")) continue;
                return jSONArray;
            }
        } else if (BiddingData.getGame() != GamesName.JODI && BiddingData.getGame() != GamesName.BULK_JODI && BiddingData.getGame() != GamesName.FAMILY_JODI && BiddingData.getGame() != GamesName.RED_JODI) {
            if (BiddingData.getGame() == GamesName.HALF_SANGAM) {
                if (!jSONArray.toString().contains((CharSequence)"HALFSANGAM")) {
                    jSONArray.put((Object)"HALFSANGAM");
                    return jSONArray;
                }
            } else if (BiddingData.getGame() == GamesName.FULL_SANGAM && !jSONArray.toString().contains((CharSequence)"FULLSANGAM")) {
                jSONArray.put((Object)"FULLSANGAM");
                return jSONArray;
            }
        } else if (!jSONArray.toString().contains((CharSequence)"JODI")) {
            jSONArray.put((Object)"JODI");
        }
        return jSONArray;
    }

    public static ArrayList<BiddingData> getOpenAndCloseData(BiddingData biddingData) {
        ArrayList arrayList = new ArrayList();
        for (BiddingData biddingData2 : BiddingData.biddingData) {
            if (!CalenderHelper.isDateIsSame(biddingData.getCalDateTime(), biddingData2.getCalDateTime()) || BiddingData.isAlreadyHaveSameDateAndSession((ArrayList<BiddingData>)arrayList, biddingData2)) continue;
            arrayList.add((Object)biddingData2);
        }
        return arrayList;
    }

    public static int getTotalPoints() {
        int n = 0;
        for (int i = 0; i < biddingData.size(); ++i) {
            n += ((BiddingData)biddingData.get(i)).getPoints();
        }
        return n;
    }

    public static boolean isAlreadyHaveSameDate(ArrayList<ArrayList<BiddingData>> arrayList, BiddingData biddingData) {
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            for (BiddingData biddingData2 : (ArrayList)iterator.next()) {
                if (!CalenderHelper.isDateIsSame(biddingData.getCalDateTime(), biddingData2.getCalDateTime())) continue;
                return true;
            }
        }
        return false;
    }

    public static boolean isAlreadyHaveSameDateAndSession(ArrayList<BiddingData> arrayList, BiddingData biddingData) {
        for (BiddingData biddingData2 : arrayList) {
            if (!CalenderHelper.isDateIsSame(biddingData.getCalDateTime(), biddingData2.getCalDateTime()) || !biddingData2.getSession().equalsIgnoreCase(biddingData.getSession())) continue;
            return true;
        }
        return false;
    }

    public Calendar getCalDateTime() {
        return this.calDateTime;
    }

    public String getDigit() {
        return this.digit;
    }

    public int getPoints() {
        return this.points;
    }

    public String getSession() {
        return this.session;
    }

    public void setCalDateTime(Calendar calendar) {
        this.calDateTime = calendar;
    }

    public void setDigit(String string2) {
        this.digit = string2;
    }

    public void setGame(GamesName gamesName) {
        game = gamesName;
    }

    public void setPoints(int n) {
        this.points = n;
    }

    public void setSession(String string2) {
        this.session = string2;
    }

    public static interface GetBiddingDataCallBack {
        public void onAdded(String var1);

        public void onError(String var1);
    }

}

