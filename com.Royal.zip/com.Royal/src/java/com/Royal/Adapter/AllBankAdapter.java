/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 */
package com.Royal.Adapter;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.AllBankAdapter;
import com.Royal.AllActivity.AppLockActivity;
import com.Royal.AllActivity.YourAccount;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.InternetUtils;
import com.Royal.data.AccountData;
import com.Royal.data.remote.AccountDataRepository;
import com.Royal.data.remote.AccountDataSource;
import java.util.List;

public class AllBankAdapter
extends RecyclerView.Adapter<BankViewHolder> {
    private List<AccountData> aptList;
    Context context;
    AccountDataRepository mAccountDataRepository;
    ProgressDialog pDialog;

    public AllBankAdapter(Context context, List<AccountData> list) {
        this.context = context;
        this.aptList = list;
        this.mAccountDataRepository = AccountDataRepository.getInstance(context);
    }

    private void RemoveAcount(AccountData accountData) {
        if (!InternetUtils.isInternetConnected(this.context)) {
            return;
        }
        final ProgressDialog progressDialog = CommonParams.createProgressDialog(this.context);
        this.mAccountDataRepository.removeAccount(accountData, new AccountDataSource.GetRemoveAccountCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                progressDialog.dismiss();
                Toast.makeText((Context)AllBankAdapter.this.context, (CharSequence)string2, (int)1).show();
            }

            @Override
            public void onLocked(String string2) {
                progressDialog.dismiss();
                Toast.makeText((Context)AllBankAdapter.this.context, (CharSequence)string2, (int)1).show();
                Intent intent = new Intent(AllBankAdapter.this.context, AppLockActivity.class);
                AllBankAdapter.this.context.startActivity(intent);
                ((Activity)AllBankAdapter.this.context).finish();
            }

            @Override
            public void onRemoved(String string2) {
                progressDialog.dismiss();
                Toast.makeText((Context)AllBankAdapter.this.context, (CharSequence)string2, (int)1).show();
                Intent intent = new Intent(AllBankAdapter.this.context, YourAccount.class);
                AllBankAdapter.this.context.startActivity(intent);
                ((Activity)AllBankAdapter.this.context).finish();
            }
        });
    }

    static /* synthetic */ void access$000(AllBankAdapter allBankAdapter, AccountData accountData) {
        allBankAdapter.RemoveAcount(accountData);
    }

    public int getItemCount() {
        return this.aptList.size();
    }

    public void onBindViewHolder(BankViewHolder bankViewHolder, int n) {
        AccountData accountData = (AccountData)this.aptList.get(n);
        bankViewHolder.name.setText((CharSequence)accountData.getAccountHolderName());
        TextView textView = bankViewHolder.accname;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(accountData.getAccountName());
        stringBuilder.append(" ( ");
        stringBuilder.append(accountData.getBranchName());
        stringBuilder.append(" )");
        textView.setText((CharSequence)stringBuilder.toString());
        TextView textView2 = bankViewHolder.accno;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("A/C : ");
        stringBuilder2.append(accountData.getAccountNumber());
        textView2.setText((CharSequence)stringBuilder2.toString());
        TextView textView3 = bankViewHolder.ifsc;
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("IFSC : ");
        stringBuilder3.append(accountData.getIfscCode());
        textView3.setText((CharSequence)stringBuilder3.toString());
        bankViewHolder.edit.setOnClickListener(new View.OnClickListener(this, accountData){
            final /* synthetic */ AllBankAdapter this$0;
            final /* synthetic */ AccountData val$model;
            {
                this.this$0 = allBankAdapter;
                this.val$model = accountData;
            }

            public void onClick(View view) {
                Intent intent = new Intent(this.this$0.context, com.Royal.AllActivity.EditBankAccount.class);
                intent.putExtra("data", (java.io.Serializable)this.val$model);
                this.this$0.context.startActivity(intent);
            }
        });
        bankViewHolder.delete.setOnClickListener(new View.OnClickListener(this, accountData){
            final /* synthetic */ AllBankAdapter this$0;
            final /* synthetic */ AccountData val$model;
            {
                this.this$0 = allBankAdapter;
                this.val$model = accountData;
            }

            public void onClick(View view) {
                new androidx.appcompat.app.AlertDialog$Builder(this.this$0.context).setTitle((CharSequence)"Delete account").setMessage((CharSequence)"Are you sure you want to delete this Account?").setPositiveButton(17039379, new android.content.DialogInterface$OnClickListener(this){
                    final /* synthetic */ 2 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void onClick(android.content.DialogInterface dialogInterface, int n) {
                        AllBankAdapter.access$000(this.this$1.this$0, this.this$1.val$model);
                    }
                }).setNegativeButton(17039369, null).setIcon(17301543).show();
            }
        });
    }

    public BankViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new BankViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131492907, viewGroup, false));
    }

    public class BankViewHolder
    extends RecyclerView.ViewHolder {
        TextView accname;
        TextView accno;
        ImageView delete;
        ImageView edit;
        TextView ifsc;
        TextView name;

        public BankViewHolder(View view) {
            super(view);
            this.name = (TextView)view.findViewById(2131296723);
            this.accname = (TextView)view.findViewById(2131296361);
            this.accno = (TextView)view.findViewById(2131296306);
            this.ifsc = (TextView)view.findViewById(2131296618);
            this.edit = (ImageView)view.findViewById(2131296533);
            this.delete = (ImageView)view.findViewById(2131296479);
        }
    }

}

