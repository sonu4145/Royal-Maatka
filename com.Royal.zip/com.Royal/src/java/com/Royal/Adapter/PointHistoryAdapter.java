/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.graphics.Color
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  androidx.cardview.widget.CardView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.json.JSONObject
 */
package com.Royal.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.PointHistoryAdapter;
import com.Royal.Model.PointHistoryModel;
import java.util.List;
import org.json.JSONObject;

public class PointHistoryAdapter
extends RecyclerView.Adapter<PointViewHolder> {
    String IV;
    private List<PointHistoryModel> aptList;
    JSONObject canceljson;
    Context context;
    String decryptdata;
    JSONObject encjson;
    String encryptedData;
    String id;
    ProgressDialog pDialog;

    public PointHistoryAdapter(Context context, List<PointHistoryModel> list) {
        this.context = context;
        this.aptList = list;
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public int getItemCount() {
        return this.aptList.size();
    }

    public void onBindViewHolder(PointViewHolder pointViewHolder, int n) {
        PointHistoryModel pointHistoryModel = (PointHistoryModel)this.aptList.get(n);
        String string2 = PointHistoryAdapter.getFormatedDateTime(pointHistoryModel.getCreatedOn(), "yyy-MM-dd HH:mm:ss", "EEEE dd-MMM-yyy hh:mm a");
        pointViewHolder.datetime.setText((CharSequence)string2);
        pointViewHolder.point.setText((CharSequence)pointHistoryModel.getPoint());
        pointViewHolder.credit.setText((CharSequence)pointHistoryModel.getRequestType());
        pointViewHolder.type.setText((CharSequence)pointHistoryModel.getAvailablepoint());
        if (pointHistoryModel.getRequestType().equals((Object)"withdraw decline")) {
            pointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#ffc107"));
        }
        if (pointHistoryModel.getRequestType().equals((Object)"withdraw")) {
            pointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#DC3545"));
        }
        if (pointHistoryModel.getRequestType().equals((Object)"deposit")) {
            pointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#28A745"));
        }
        if (pointHistoryModel.getRequestType().equals((Object)"bidding")) {
            pointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#6C757D"));
        }
        if (pointHistoryModel.getRequestType().equals((Object)"bidding cancel")) {
            pointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#17A2B8"));
        }
        if (pointHistoryModel.getRequestType().equals((Object)"withdraw cancel")) {
            pointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#17A2B8"));
        }
        if (pointHistoryModel.getRequestType().equals((Object)"transfer")) {
            pointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#007BFF"));
        }
        if (pointHistoryModel.getRequestType().equals((Object)"receive")) {
            pointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#007BFF"));
        }
        if (pointHistoryModel.getRequestType().equals((Object)"result win")) {
            pointViewHolder.credit.setText((CharSequence)"winning");
            pointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#28A745"));
        }
        pointViewHolder.cardView.setOnClickListener(new View.OnClickListener(this, pointHistoryModel){
            final /* synthetic */ PointHistoryAdapter this$0;
            final /* synthetic */ PointHistoryModel val$model;
            {
                this.this$0 = pointHistoryAdapter;
                this.val$model = pointHistoryModel;
            }

            public void onClick(View view) {
                if (!this.val$model.getRequestType().equals((Object)"result win") && !this.val$model.getRequestType().equals((Object)"bidding cancel")) {
                    if (!(this.val$model.getActiontype().equals((Object)"ticketNumber") || this.val$model.getActiontype().equals((Object)"userBidTransactionDetailId") || this.val$model.getActiontype().equals((Object)"resultWin") || this.val$model.getActiontype().equals((Object)"resultCancel"))) {
                        android.content.Intent intent = new android.content.Intent(this.this$0.context, com.Royal.AllActivity.PointHistoryDetail.class);
                        intent.putExtra("id", this.val$model.getId());
                        intent.putExtra("actiontype", this.val$model.getActiontype());
                        intent.putExtra("actionId", this.val$model.getActionid());
                        this.this$0.context.startActivity(intent);
                        return;
                    }
                    android.content.Intent intent = new android.content.Intent(this.this$0.context, com.Royal.AllActivity.BidingDetail.class);
                    intent.putExtra("id", this.val$model.getActionid());
                    this.this$0.context.startActivity(intent);
                    return;
                }
                android.content.Intent intent = new android.content.Intent(this.this$0.context, com.Royal.AllActivity.BidingTransaction.class);
                this.this$0.context.startActivity(intent);
            }
        });
    }

    public PointViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new PointViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131493023, viewGroup, false));
    }

    public class PointViewHolder
    extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView credit;
        TextView datetime;
        TextView point;
        TextView status;
        TextView type;

        public PointViewHolder(View view) {
            super(view);
            this.datetime = (TextView)view.findViewById(2131296471);
            this.point = (TextView)view.findViewById(2131296783);
            this.type = (TextView)view.findViewById(2131297024);
            this.credit = (TextView)view.findViewById(2131296461);
            this.status = (TextView)view.findViewById(2131296889);
            this.cardView = (CardView)view.findViewById(2131296415);
        }
    }

}

