/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.graphics.Color
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  androidx.cardview.widget.CardView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.json.JSONObject
 */
package com.Royal.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.LockPointHistoryAdapter;
import com.Royal.Model.LockPointHistoryModal;
import java.util.List;
import org.json.JSONObject;

public class LockPointHistoryAdapter
extends RecyclerView.Adapter<LockPointViewHolder> {
    String IV;
    private List<LockPointHistoryModal> aptList;
    JSONObject canceljson;
    Context context;
    String decryptdata;
    JSONObject encjson;
    String encryptedData;
    String id;
    ProgressDialog pDialog;

    public LockPointHistoryAdapter(Context context, List<LockPointHistoryModal> list) {
        this.context = context;
        this.aptList = list;
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public int getItemCount() {
        return this.aptList.size();
    }

    public void onBindViewHolder(LockPointViewHolder lockPointViewHolder, int n) {
        LockPointHistoryModal lockPointHistoryModal = (LockPointHistoryModal)this.aptList.get(n);
        String string2 = LockPointHistoryAdapter.getFormatedDateTime(lockPointHistoryModal.getCreatedon(), "yyy-MM-dd HH:mm:ss", "EEEE dd-MMM-yyy hh:mm a");
        lockPointViewHolder.datetime.setText((CharSequence)string2);
        lockPointViewHolder.point.setText((CharSequence)lockPointHistoryModal.getPoint());
        lockPointViewHolder.type.setText((CharSequence)lockPointHistoryModal.getAcctype());
        lockPointViewHolder.credit.setText((CharSequence)lockPointHistoryModal.getRequestype());
        lockPointViewHolder.status.setText((CharSequence)lockPointHistoryModal.getIsstatus());
        if (lockPointHistoryModal.getIsstatus().equals((Object)"decline")) {
            lockPointViewHolder.status.setBackgroundColor(Color.parseColor((String)"#DC3545"));
        }
        if (lockPointHistoryModal.getIsstatus().equals((Object)"success")) {
            lockPointViewHolder.status.setBackgroundColor(Color.parseColor((String)"#0e8123"));
        }
        if (lockPointHistoryModal.getIsstatus().equals((Object)"pending")) {
            lockPointViewHolder.status.setBackgroundColor(Color.parseColor((String)"#17a2b8"));
        }
        if (lockPointHistoryModal.getIsstatus().equals((Object)"cancel")) {
            lockPointViewHolder.status.setBackgroundColor(Color.parseColor((String)"#FFC107"));
        }
        if (lockPointHistoryModal.getRequestype().equals((Object)"deposit")) {
            lockPointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#0e8123"));
        }
        if (lockPointHistoryModal.getRequestype().equals((Object)"withdraw")) {
            lockPointViewHolder.credit.setBackgroundColor(Color.parseColor((String)"#DC3545"));
        }
        lockPointViewHolder.cardView.setOnClickListener(new View.OnClickListener(this, lockPointHistoryModal){
            final /* synthetic */ LockPointHistoryAdapter this$0;
            final /* synthetic */ LockPointHistoryModal val$model;
            {
                this.this$0 = lockPointHistoryAdapter;
                this.val$model = lockPointHistoryModal;
            }

            public void onClick(View view) {
                if (this.val$model.getIsstatus().equals((Object)"pending")) {
                    android.content.Intent intent = new android.content.Intent(this.this$0.context, com.Royal.AllActivity.LockPointHistoryDetail.class);
                    intent.putExtra("id", this.val$model.getId());
                    intent.putExtra("cancel", "yes");
                    this.this$0.context.startActivity(intent);
                    return;
                }
                android.content.Intent intent = new android.content.Intent(this.this$0.context, com.Royal.AllActivity.LockPointHistoryDetail.class);
                intent.putExtra("id", this.val$model.getId());
                intent.putExtra("cancel", "no");
                this.this$0.context.startActivity(intent);
            }
        });
    }

    public LockPointViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new LockPointViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131492956, viewGroup, false));
    }

    public class LockPointViewHolder
    extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView credit;
        TextView datetime;
        TextView point;
        TextView status;
        TextView type;

        public LockPointViewHolder(View view) {
            super(view);
            this.datetime = (TextView)view.findViewById(2131296471);
            this.point = (TextView)view.findViewById(2131296783);
            this.type = (TextView)view.findViewById(2131297024);
            this.credit = (TextView)view.findViewById(2131296461);
            this.status = (TextView)view.findViewById(2131296889);
            this.cardView = (CardView)view.findViewById(2131296415);
        }
    }

}

