/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.graphics.Color
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.Drawable
 *  android.util.Log
 *  android.util.SparseBooleanArray
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RatingBar
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 *  java.util.Random
 *  org.json.JSONObject
 */
package com.Royal.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.AllBazar_Adapter;
import com.Royal.data.BazaarData;
import com.Royal.data.ResultData;
import com.Royal.data.helper.CalenderHelper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import org.json.JSONObject;

public class AllBazar_Adapter
extends RecyclerView.Adapter<MyViewHolder> {
    String IV;
    private List<BazaarData> aptList;
    private final SparseBooleanArray array = new SparseBooleanArray();
    JSONObject canceljson;
    Context context;
    String decryptdata;
    JSONObject encjson;
    String encryptedData;
    String id;
    ProgressDialog pDialog;

    public AllBazar_Adapter(Context context, List<BazaarData> list) {
        this.context = context;
        this.aptList = list;
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    private void setupData(MyViewHolder myViewHolder, BazaarData bazaarData) {
        ArrayList<ResultData> arrayList = bazaarData.getOpenResultData();
        ArrayList<ResultData> arrayList2 = bazaarData.getCloseResultData();
        myViewHolder.name.setText((CharSequence)bazaarData.getName());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE");
        Date date = new Date();
        Random random = new Random();
        int n = Color.argb((int)255, (int)random.nextInt(256), (int)random.nextInt(256), (int)random.nextInt(256));
        myViewHolder.viewtop.setBackgroundColor(n);
        myViewHolder.viewbottom.setBackgroundColor(n);
        simpleDateFormat.format(date);
        myViewHolder.secondrating.getProgressDrawable().setColorFilter(Color.parseColor((String)"#102AA0"), PorterDuff.Mode.SRC_ATOP);
        myViewHolder.firstrating.getProgressDrawable().setColorFilter(Color.parseColor((String)"#102AA0"), PorterDuff.Mode.SRC_ATOP);
        myViewHolder.thirdrating.getProgressDrawable().setColorFilter(Color.parseColor((String)"#102AA0"), PorterDuff.Mode.SRC_ATOP);
        if (arrayList.size() > 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(((ResultData)arrayList.get(0)).getBazaarId());
            stringBuilder.append("m");
            stringBuilder.append(this.id);
            Log.e((String)"mainloop", (String)stringBuilder.toString());
            ResultData resultData = (ResultData)arrayList.get(0);
            myViewHolder.firstrating.setVisibility(8);
            myViewHolder.openresult.setVisibility(0);
            TextView textView = myViewHolder.openresult;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(resultData.getPana());
            stringBuilder2.append("-");
            textView.setText((CharSequence)stringBuilder2.toString());
            if (arrayList2.size() > 0) {
                ResultData resultData2 = (ResultData)arrayList2.get(0);
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("n");
                stringBuilder3.append(resultData2.getBazaarId());
                stringBuilder3.append("m");
                stringBuilder3.append(this.id);
                Log.e((String)"ival", (String)stringBuilder3.toString());
                myViewHolder.thirdrating.setVisibility(8);
                myViewHolder.closeresult.setVisibility(0);
                TextView textView2 = myViewHolder.closeresult;
                StringBuilder stringBuilder4 = new StringBuilder();
                stringBuilder4.append("-");
                stringBuilder4.append(resultData2.getPana());
                textView2.setText((CharSequence)stringBuilder4.toString());
                myViewHolder.secondrating.setVisibility(8);
                myViewHolder.jodi.setVisibility(0);
                myViewHolder.jodi.setText((CharSequence)resultData2.getJodi());
            } else {
                myViewHolder.secondrating.setVisibility(0);
                myViewHolder.secondrating.setNumStars(1);
                myViewHolder.secondrating.setRating(1.0f);
                myViewHolder.thirdrating.setVisibility(0);
                myViewHolder.closeresult.setVisibility(8);
                myViewHolder.jodi.setVisibility(0);
                myViewHolder.jodi.setText((CharSequence)resultData.getAnk());
            }
        } else if (arrayList2.size() > 0) {
            ResultData resultData = (ResultData)arrayList2.get(0);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(resultData.getBazaarId());
            stringBuilder.append("m");
            stringBuilder.append(this.id);
            Log.e((String)"ival", (String)stringBuilder.toString());
            myViewHolder.thirdrating.setVisibility(8);
            myViewHolder.closeresult.setVisibility(0);
            myViewHolder.closeresult.setText((CharSequence)resultData.getPana());
            myViewHolder.openresult.setVisibility(8);
            myViewHolder.secondrating.setVisibility(8);
            myViewHolder.jodi.setVisibility(0);
            TextView textView = myViewHolder.jodi;
            StringBuilder stringBuilder5 = new StringBuilder();
            stringBuilder5.append(resultData.getJodi());
            stringBuilder5.append("-");
            textView.setText((CharSequence)stringBuilder5.toString());
        } else {
            myViewHolder.firstrating.setVisibility(0);
            myViewHolder.firstrating.setRating(3.0f);
            myViewHolder.secondrating.setVisibility(0);
            myViewHolder.secondrating.setNumStars(2);
            myViewHolder.secondrating.setRating(2.0f);
            myViewHolder.thirdrating.setVisibility(0);
            myViewHolder.thirdrating.setRating(3.0f);
            myViewHolder.openresult.setVisibility(8);
            myViewHolder.closeresult.setVisibility(8);
            myViewHolder.jodi.setVisibility(8);
        }
        String string2 = CalenderHelper.time12HourFormat.format(bazaarData.getCalOpenTime().getTime());
        String string3 = CalenderHelper.time12HourFormat.format(bazaarData.getCalCloseTime().getTime());
        TextView textView = myViewHolder.time;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OPEN BIDS ");
        stringBuilder.append(string2);
        stringBuilder.append(" | CLOSE BIDS ");
        stringBuilder.append(string3);
        textView.setText((CharSequence)stringBuilder.toString());
        if (bazaarData.getCalCloseTime().before((Object)Calendar.getInstance())) {
            myViewHolder.txtbettingstatus.setText((CharSequence)"Betting is closed for today");
            myViewHolder.txtbettingstatus.setTextColor(-65536);
            this.array.put(myViewHolder.getAdapterPosition(), true);
        } else {
            myViewHolder.txtbettingstatus.setText((CharSequence)"Betting is running for today");
            myViewHolder.txtbettingstatus.setTextColor(Color.parseColor((String)"#004B19"));
            this.array.put(myViewHolder.getAdapterPosition(), false);
        }
        myViewHolder.playgame_ll.setOnClickListener(new View.OnClickListener(this, bazaarData){
            final /* synthetic */ AllBazar_Adapter this$0;
            final /* synthetic */ BazaarData val$model;
            {
                this.this$0 = allBazar_Adapter;
                this.val$model = bazaarData;
            }

            public void onClick(View view) {
                android.content.Intent intent = new android.content.Intent(this.this$0.context, com.Royal.AllActivity.AllGames.class);
                intent.putExtra("data", (java.io.Serializable)this.val$model);
                this.this$0.context.startActivity(intent);
            }
        });
    }

    private void setvalue(String string2, RatingBar ratingBar, TextView textView) {
    }

    public int getItemCount() {
        return this.aptList.size();
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int n) {
        myViewHolder.bazaarData = (BazaarData)this.aptList.get(n);
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new MyViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131492949, viewGroup, false));
    }

    public void onViewAttachedToWindow(MyViewHolder myViewHolder) {
        if (myViewHolder instanceof MyViewHolder) {
            this.setupData(myViewHolder, myViewHolder.bazaarData);
        }
    }

    public class MyViewHolder
    extends RecyclerView.ViewHolder {
        BazaarData bazaarData;
        TextView closeresult;
        RatingBar firstrating;
        ImageView img;
        TextView jodi;
        TextView name;
        TextView openresult;
        LinearLayout playgame_ll;
        RatingBar secondrating;
        RatingBar thirdrating;
        TextView time;
        TextView txtbettingstatus;
        View viewbottom;
        View viewtop;

        MyViewHolder(View view) {
            super(view);
            this.bazaarData = new BazaarData();
            this.setIsRecyclable(false);
            this.playgame_ll = (LinearLayout)view.findViewById(2131296981);
            this.name = (TextView)view.findViewById(2131296970);
            this.time = (TextView)view.findViewById(2131296969);
            this.txtbettingstatus = (TextView)view.findViewById(2131297013);
            this.firstrating = (RatingBar)view.findViewById(2131296568);
            this.viewbottom = view.findViewById(2131297042);
            this.viewtop = view.findViewById(2131297044);
            this.secondrating = (RatingBar)view.findViewById(2131296843);
            this.thirdrating = (RatingBar)view.findViewById(2131296966);
            this.openresult = (TextView)view.findViewById(2131296760);
            this.closeresult = (TextView)view.findViewById(2131296443);
            this.jodi = (TextView)view.findViewById(2131296636);
            this.firstrating.setRating(3.0f);
            this.secondrating.setRating(2.0f);
            this.thirdrating.setRating(3.0f);
        }
    }

}

