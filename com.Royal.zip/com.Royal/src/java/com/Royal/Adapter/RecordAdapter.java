/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.RatingBar
 *  android.widget.TextView
 *  androidx.cardview.widget.CardView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 *  org.json.JSONObject
 */
package com.Royal.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Model.BazarModel;
import com.Royal.Model.DateModel;
import com.Royal.Model.RecordModel;
import java.util.List;
import org.json.JSONObject;

public class RecordAdapter
extends RecyclerView.Adapter<RecordViewHolder> {
    String IV;
    private List<RecordModel> aptList;
    private List<BazarModel> bazarlist;
    JSONObject canceljson;
    Context context;
    String decryptdata;
    private List<DateModel> dtList;
    JSONObject encjson;
    String encryptedData;
    String id;
    ProgressDialog pDialog;

    public RecordAdapter(Context context, List<DateModel> list, List<RecordModel> list2) {
        this.context = context;
        this.aptList = list2;
        this.dtList = list;
        this.bazarlist = this.bazarlist;
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public int getItemCount() {
        return this.dtList.size();
    }

    public void onBindViewHolder(RecordViewHolder recordViewHolder, int n) {
        recordViewHolder.firstrating.setVisibility(0);
        recordViewHolder.firstrating.setRating(3.0f);
        recordViewHolder.secondrating.setVisibility(0);
        recordViewHolder.secondrating.setNumStars(2);
        recordViewHolder.secondrating.setRating(2.0f);
        recordViewHolder.thirdrating.setVisibility(0);
        recordViewHolder.thirdrating.setRating(3.0f);
        recordViewHolder.openresult.setVisibility(8);
        recordViewHolder.closeresult.setVisibility(8);
        recordViewHolder.jodi.setVisibility(8);
        if (this.aptList.size() > 0) {
            for (int i = 0; i < this.dtList.size(); ++i) {
                DateModel dateModel = (DateModel)this.dtList.get(i);
                for (int j = 0; j < this.aptList.size(); ++j) {
                    RecordModel recordModel = (RecordModel)this.aptList.get(j);
                    String string2 = RecordAdapter.getFormatedDateTime(recordModel.getDate(), "yyy-MM-dd", "dd-MMM,yyyy");
                    if (!dateModel.getStdate().equals((Object)string2)) continue;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("n");
                    stringBuilder.append(dateModel.getStdate());
                    Log.e((String)"matcheddate", (String)stringBuilder.toString());
                    if (recordModel.getSession().equals((Object)"open") && n == 10) {
                        recordViewHolder.firstrating.setVisibility(8);
                        recordViewHolder.openresult.setVisibility(0);
                        recordViewHolder.openresult.setText((CharSequence)recordModel.getPana());
                        recordViewHolder.secondrating.setNumStars(1);
                        recordViewHolder.secondrating.setRating(1.0f);
                        recordViewHolder.jodi.setVisibility(0);
                        recordViewHolder.jodi.setText((CharSequence)recordModel.getAnk());
                        Log.e((String)"open", (String)"nopen");
                    }
                    if (!recordModel.getSession().equals((Object)"close") || n != 10) continue;
                    recordViewHolder.thirdrating.setVisibility(8);
                    recordViewHolder.closeresult.setVisibility(0);
                    recordViewHolder.closeresult.setText((CharSequence)recordModel.getPana());
                    recordViewHolder.secondrating.setVisibility(8);
                    recordViewHolder.secondrating.setNumStars(0);
                    recordViewHolder.jodi.setVisibility(0);
                    recordViewHolder.jodi.setText((CharSequence)recordModel.getJodi());
                    Log.e((String)"close", (String)"nclose");
                }
            }
        }
    }

    public RecordViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new RecordViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131493027, viewGroup, false));
    }

    public class RecordViewHolder
    extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView closeresult;
        RatingBar firstrating;
        TextView jodi;
        TextView name;
        TextView openresult;
        RatingBar secondrating;
        RatingBar thirdrating;

        public RecordViewHolder(View view) {
            super(view);
            this.cardView = (CardView)view.findViewById(2131296415);
            this.firstrating = (RatingBar)view.findViewById(2131296568);
            this.secondrating = (RatingBar)view.findViewById(2131296843);
            this.thirdrating = (RatingBar)view.findViewById(2131296966);
            this.openresult = (TextView)view.findViewById(2131296760);
            this.closeresult = (TextView)view.findViewById(2131296443);
            this.jodi = (TextView)view.findViewById(2131296636);
            this.firstrating.setRating(3.0f);
            this.secondrating.setRating(2.0f);
            this.thirdrating.setRating(3.0f);
        }
    }

}

