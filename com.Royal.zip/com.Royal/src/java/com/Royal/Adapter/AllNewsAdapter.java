/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.json.JSONObject
 */
package com.Royal.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Model.NewsModel;
import java.util.List;
import org.json.JSONObject;

public class AllNewsAdapter
extends RecyclerView.Adapter<AllnewsViewHolder> {
    String IV;
    private List<NewsModel> aptList;
    JSONObject canceljson;
    Context context;
    String decryptdata;
    JSONObject encjson;
    String encryptedData;
    String id;
    ProgressDialog pDialog;

    public AllNewsAdapter(Context context, List<NewsModel> list) {
        this.context = context;
        this.aptList = list;
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public int getItemCount() {
        return this.aptList.size();
    }

    public void onBindViewHolder(AllnewsViewHolder allnewsViewHolder, int n) {
        NewsModel newsModel = (NewsModel)this.aptList.get(n);
        String string2 = AllNewsAdapter.getFormatedDateTime(newsModel.getCreatedOn(), "yyy-MM-dd HH:mm:ss", "EEEE dd-MMM-yyy");
        allnewsViewHolder.datetime.setText((CharSequence)string2);
        allnewsViewHolder.news.setText((CharSequence)newsModel.getNews());
    }

    public AllnewsViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new AllnewsViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131493012, viewGroup, false));
    }

    public class AllnewsViewHolder
    extends RecyclerView.ViewHolder {
        TextView datetime;
        TextView news;

        public AllnewsViewHolder(View view) {
            super(view);
            this.datetime = (TextView)view.findViewById(2131296468);
            this.news = (TextView)view.findViewById(2131296736);
        }
    }

}

