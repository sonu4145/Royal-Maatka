/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  androidx.cardview.widget.CardView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.List
 *  org.json.JSONObject
 */
package com.Royal.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Model.PurchaseModel;
import java.util.HashMap;
import java.util.List;
import org.json.JSONObject;

public class PurchaseReportAdapter
extends RecyclerView.Adapter<PurchaseViewHolder> {
    String IV;
    HashMap<String, List<PurchaseModel>> aptList;
    JSONObject canceljson;
    Context context;
    List<String> datelists;
    String decryptdata;
    JSONObject encjson;
    String encryptedData;
    String id;
    List<PurchaseModel> localist;
    ProgressDialog pDialog;
    int twinpoit = 0;

    public PurchaseReportAdapter(Context context, List<PurchaseModel> list) {
        this.context = context;
        this.localist = list;
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public int getItemCount() {
        return this.localist.size();
    }

    public void onBindViewHolder(PurchaseViewHolder purchaseViewHolder, int n) {
        PurchaseModel purchaseModel = (PurchaseModel)this.localist.get(n);
        String string2 = PurchaseReportAdapter.getFormatedDateTime(purchaseModel.getDate(), "yyy-MM-dd HH:mm:ss", "EEEE dd-MMM-yyy hh:mm a");
        if (this.localist.size() > 1) {
            if (n > 0) {
                int n2;
                List<PurchaseModel> list;
                int n3;
                String string3 = ((PurchaseModel)this.localist.get(n)).getDate();
                if (string3.equals((Object)((PurchaseModel)(list = this.localist).get(n3 = n - 1)).getDate())) {
                    purchaseViewHolder.cardView.setVisibility(0);
                    purchaseViewHolder.date.setText((CharSequence)string2);
                    int n4 = Integer.parseInt((String)purchaseModel.getPoint()) + Integer.parseInt((String)((PurchaseModel)this.localist.get(n3)).getPoint());
                    purchaseViewHolder.point.setText((CharSequence)String.valueOf((int)n4));
                    if (purchaseModel.getType().equals((Object)"win")) {
                        this.twinpoit = Integer.parseInt((String)purchaseModel.getWinpoint()) + this.twinpoit;
                    }
                    purchaseViewHolder.winpoint.setText((CharSequence)String.valueOf((int)this.twinpoit));
                    this.twinpoit = 0;
                    return;
                }
                int n5 = this.localist.size();
                if (n5 > (n2 = n + 1)) {
                    if (!((PurchaseModel)this.localist.get(n)).getDate().equals((Object)((PurchaseModel)this.localist.get(n2)).getDate())) {
                        purchaseViewHolder.cardView.setVisibility(0);
                        purchaseViewHolder.date.setText((CharSequence)string2);
                        purchaseViewHolder.point.setText((CharSequence)purchaseModel.getPoint());
                        if (purchaseModel.getType().equals((Object)"win")) {
                            purchaseViewHolder.winpoint.setText((CharSequence)purchaseModel.getWinpoint());
                            return;
                        }
                        purchaseViewHolder.winpoint.setText((CharSequence)"0");
                        return;
                    }
                } else if (purchaseModel.getType().equals((Object)"win")) {
                    this.twinpoit = Integer.parseInt((String)purchaseModel.getWinpoint());
                    return;
                }
            } else if (!((PurchaseModel)this.localist.get(n)).getDate().equals((Object)((PurchaseModel)this.localist.get(n + 1)).getDate())) {
                purchaseViewHolder.cardView.setVisibility(0);
                purchaseViewHolder.date.setText((CharSequence)string2);
                purchaseViewHolder.point.setText((CharSequence)purchaseModel.getPoint());
                if (purchaseModel.getType().equals((Object)"win")) {
                    purchaseViewHolder.winpoint.setText((CharSequence)purchaseModel.getWinpoint());
                    return;
                }
                purchaseViewHolder.winpoint.setText((CharSequence)"0");
                return;
            }
        } else {
            purchaseViewHolder.cardView.setVisibility(0);
            purchaseViewHolder.date.setText((CharSequence)string2);
            purchaseViewHolder.point.setText((CharSequence)purchaseModel.getPoint());
            purchaseViewHolder.winpoint.setText((CharSequence)purchaseModel.getWinpoint());
            if (purchaseModel.getType().equals((Object)"win")) {
                purchaseViewHolder.winpoint.setText((CharSequence)purchaseModel.getWinpoint());
                return;
            }
            purchaseViewHolder.winpoint.setText((CharSequence)"0");
        }
    }

    public PurchaseViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new PurchaseViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131493026, viewGroup, false));
    }

    public class PurchaseViewHolder
    extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView date;
        TextView point;
        TextView winpoint;

        public PurchaseViewHolder(View view) {
            super(view);
            this.date = (TextView)view.findViewById(2131296468);
            this.point = (TextView)view.findViewById(2131296783);
            this.winpoint = (TextView)view.findViewById(2131297057);
            this.cardView = (CardView)view.findViewById(2131296415);
        }
    }

}

