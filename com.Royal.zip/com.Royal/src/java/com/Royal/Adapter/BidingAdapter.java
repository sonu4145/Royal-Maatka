/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 */
package com.Royal.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.BidingAdapter;
import com.Royal.data.BiddingData;
import com.Royal.data.helper.CalenderHelper;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class BidingAdapter
extends RecyclerView.Adapter<BidingViewHolder> {
    private List<BiddingData> aptList;
    Context context;
    BiddingDataListener listener = null;

    public BidingAdapter(Context context, List<BiddingData> list) {
        this.context = context;
        this.aptList = list;
    }

    static /* synthetic */ List access$000(BidingAdapter bidingAdapter) {
        return bidingAdapter.aptList;
    }

    public List<BiddingData> getAptList() {
        return this.aptList;
    }

    public int getItemCount() {
        return this.aptList.size();
    }

    public void onBindViewHolder(BidingViewHolder bidingViewHolder, int n) {
        BiddingData biddingData = (BiddingData)this.aptList.get(n);
        bidingViewHolder.tvdate.setText((CharSequence)CalenderHelper.monthDate.format(biddingData.getCalDateTime().getTime()));
        bidingViewHolder.type.setText((CharSequence)biddingData.getSession());
        bidingViewHolder.digit.setText((CharSequence)biddingData.getDigit());
        TextView textView = bidingViewHolder.point;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(biddingData.getPoints());
        textView.setText((CharSequence)stringBuilder.toString());
        bidingViewHolder.deleteimg.setOnClickListener(new View.OnClickListener(this, bidingViewHolder, n){
            final /* synthetic */ BidingAdapter this$0;
            final /* synthetic */ BidingViewHolder val$holder;
            final /* synthetic */ int val$position;
            {
                this.this$0 = bidingAdapter;
                this.val$holder = bidingViewHolder;
                this.val$position = n;
            }

            public void onClick(View view) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("n");
                stringBuilder.append(this.val$holder.getAdapterPosition());
                android.util.Log.e((String)"position", (String)stringBuilder.toString());
                BidingAdapter.access$000(this.this$0).remove(this.val$holder.getAdapterPosition());
                this.this$0.notifyItemRemoved(this.val$position);
                if (this.this$0.listener != null) {
                    this.this$0.listener.onDataChanged();
                }
            }
        });
    }

    public BidingViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new BidingViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131492911, viewGroup, false));
    }

    public void setBiddingDataListener(BiddingDataListener biddingDataListener) {
        this.listener = biddingDataListener;
    }

    public class BidingViewHolder
    extends RecyclerView.ViewHolder {
        ImageView deleteimg;
        TextView digit;
        TextView point;
        TextView totalbid;
        TextView totalpoint;
        TextView tvdate;
        TextView type;

        public BidingViewHolder(View view) {
            super(view);
            this.tvdate = (TextView)view.findViewById(2131296468);
            this.type = (TextView)view.findViewById(2131297024);
            this.digit = (TextView)view.findViewById(2131296490);
            this.point = (TextView)view.findViewById(2131296783);
            this.totalbid = (TextView)view.findViewById(2131296985);
            this.totalpoint = (TextView)view.findViewById(2131296986);
            this.deleteimg = (ImageView)view.findViewById(2131296478);
        }
    }

}

