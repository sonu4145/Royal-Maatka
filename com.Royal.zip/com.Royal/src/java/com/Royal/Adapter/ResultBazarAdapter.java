/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  androidx.cardview.widget.CardView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.json.JSONObject
 */
package com.Royal.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Model.BazarModel;
import java.util.List;
import org.json.JSONObject;

public class ResultBazarAdapter
extends RecyclerView.Adapter<BazarViewHolder> {
    String IV;
    private List<BazarModel> aptList;
    JSONObject canceljson;
    Context context;
    String decryptdata;
    JSONObject encjson;
    String encryptedData;
    String id;
    ProgressDialog pDialog;

    public ResultBazarAdapter(Context context, List<BazarModel> list) {
        this.context = context;
        this.aptList = list;
    }

    public int getItemCount() {
        return this.aptList.size();
    }

    public void onBindViewHolder(BazarViewHolder bazarViewHolder, int n) {
        BazarModel bazarModel = (BazarModel)this.aptList.get(n);
        bazarViewHolder.bazaarname.setText((CharSequence)bazarModel.getName());
    }

    public BazarViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new BazarViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131493034, viewGroup, false));
    }

    public class BazarViewHolder
    extends RecyclerView.ViewHolder {
        TextView bazaarname;
        CardView cardView;
        TextView fri;
        TextView name;
        TextView sat;
        TextView sun;
        TextView thu;
        TextView tues;
        TextView wed;

        public BazarViewHolder(View view) {
            super(view);
            this.bazaarname = (TextView)view.findViewById(2131296365);
        }
    }

}

