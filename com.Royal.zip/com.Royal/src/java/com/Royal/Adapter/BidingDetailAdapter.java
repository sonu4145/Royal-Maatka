/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Color
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 *  java.util.Locale
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.Adapter;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.BidingDetailAdapter;
import com.Royal.AllActivity.BidingDetail;
import com.Royal.AllActivity.BidingTransaction;
import com.Royal.Model.BidingDetailModel;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.CryptoHelper;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public class BidingDetailAdapter
extends RecyclerView.Adapter<BiddetailViewHolder> {
    private List<BidingDetailModel> aptList;
    Context context;
    String decryptstring;
    String encryptstring;
    JSONObject inputjson;
    ProgressDialog pDialog;

    public BidingDetailAdapter(Context context, List<BidingDetailModel> list) {
        this.context = context;
        this.aptList = list;
    }

    private void RemoveAcount() {
        final ProgressDialog progressDialog = CommonParams.createProgressDialog(this.context);
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/bidding/cancel").addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", this.encryptstring).setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

            public void onError(ANError aNError) {
                progressDialog.dismiss();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(aNError.getErrorDetail());
                Log.d((String)"error", (String)stringBuilder.toString());
                Toast.makeText((Context)BidingDetailAdapter.this.context, (CharSequence)"Something went wrong", (int)1).show();
            }

            public void onResponse(JSONObject jSONObject) {
                progressDialog.dismiss();
                Log.e((String)"Api_response", (String)jSONObject.toString());
                try {
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        Intent intent = new Intent(BidingDetailAdapter.this.context, BidingTransaction.class);
                        BidingDetailAdapter.this.context.startActivity(intent);
                        ((Activity)BidingDetailAdapter.this.context).finish();
                        return;
                    }
                    String string2 = jSONObject.getString("error");
                    Toast.makeText((Context)BidingDetailAdapter.this.context, (CharSequence)string2, (int)1).show();
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    static /* synthetic */ void access$000(BidingDetailAdapter bidingDetailAdapter, String string2) {
        bidingDetailAdapter.makesimplejson(string2);
    }

    private long calculatetimediif(String string2) {
        String string3 = new SimpleDateFormat("yyy-MM-dd", Locale.getDefault()).format(new Date());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String string4 = simpleDateFormat.format(date);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(string4);
        Log.e((String)"currenttime", (String)stringBuilder.toString());
        try {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string3);
            stringBuilder2.append(" ");
            stringBuilder2.append(string2);
            Date date2 = simpleDateFormat.parse(stringBuilder2.toString());
            Log.e((String)"date2", (String)String.valueOf((Object)date2));
            long l = date2.getTime() - date.getTime();
            Log.e((String)"timediff", (String)String.valueOf((long)l));
            return l;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return 0L;
        }
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    private void makesimplejson(String string2) {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("ticketNumber", (Object)BidingDetail.userbidid);
            this.inputjson.put("bidTransactionDetailId", (Object)string2);
            this.inputjson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public String decryptjson(String string2) {
        void var2_7;
        String string3;
        block4 : {
            string3 = CryptoHelper.decrypt(string2);
            try {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("output:");
                stringBuilder.append(string3);
                printStream.println(stringBuilder.toString());
                return string3;
            }
            catch (Exception exception) {}
            break block4;
            catch (Exception exception) {
                string3 = null;
            }
        }
        var2_7.printStackTrace();
        return string3;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public String encryptjson(String string2) {
        void var2_7;
        String string3;
        block4 : {
            string3 = CryptoHelper.encrypt(string2);
            try {
                PrintStream printStream = System.out;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("cipher:");
                stringBuilder.append(string3);
                printStream.println(stringBuilder.toString());
                return string3;
            }
            catch (Exception exception) {}
            break block4;
            catch (Exception exception) {
                string3 = null;
            }
        }
        var2_7.printStackTrace();
        return string3;
    }

    public int getItemCount() {
        return this.aptList.size();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void onBindViewHolder(BiddetailViewHolder biddetailViewHolder, int n) {
        BidingDetailModel bidingDetailModel;
        Date date;
        Date date2;
        String string2;
        block13 : {
            Date date3;
            void var8_12;
            block14 : {
                bidingDetailModel = (BidingDetailModel)this.aptList.get(n);
                String string3 = BidingDetailAdapter.getFormatedDateTime(bidingDetailModel.getDate(), "yyy-MM-dd", "EEEE dd-MMM-yyy");
                biddetailViewHolder.datetime.setText((CharSequence)string3);
                biddetailViewHolder.bazarside.setText((CharSequence)bidingDetailModel.getBazaar());
                biddetailViewHolder.session.setText((CharSequence)bidingDetailModel.getSession());
                biddetailViewHolder.game.setText((CharSequence)bidingDetailModel.getGame());
                biddetailViewHolder.digit.setText((CharSequence)bidingDetailModel.getDigit());
                biddetailViewHolder.point.setText((CharSequence)bidingDetailModel.getPoint());
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyy-MM-dd");
                string2 = simpleDateFormat.format(new Date());
                date = null;
                date2 = simpleDateFormat.parse(bidingDetailModel.getDate());
                try {
                    date = simpleDateFormat.parse(string2);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("n");
                    stringBuilder.append((Object)date);
                    stringBuilder.append("b");
                    stringBuilder.append((Object)date2);
                    Log.e((String)"currenttime", (String)stringBuilder.toString());
                    break block13;
                }
                catch (ParseException parseException) {
                    Date date4 = date2;
                    date3 = date;
                    date = date4;
                    break block14;
                }
                catch (ParseException parseException) {
                    date3 = null;
                }
            }
            var8_12.printStackTrace();
            Date date5 = date3;
            date2 = date;
            date = date5;
        }
        if (date2.after(date)) {
            System.out.println("The date is future day");
        }
        if (date2.before(date)) {
            System.out.println("The date is older than current day");
        }
        if (string2.equals((Object)bidingDetailModel.getDate())) {
            bidingDetailModel.getResultId().equals((Object)"null");
            if (bidingDetailModel.getSession().equals((Object)"open")) {
                String string4 = this.subtracttime(bidingDetailModel.getDate(), bidingDetailModel.getTodayRemaningCancelTimeForOpenBid());
                long l = this.calculatetimediif(string4);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("open");
                stringBuilder.append(string4);
                Log.e((String)"open", (String)stringBuilder.toString());
                String.valueOf((long)l).contains((CharSequence)"-");
            }
            if (bidingDetailModel.getSession().equals((Object)"close")) {
                long l = this.calculatetimediif(this.subtracttime(bidingDetailModel.getDate(), bidingDetailModel.getTodayRemaningCancelTimeForCloseBid()));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("close");
                stringBuilder.append(l);
                Log.e((String)"close", (String)stringBuilder.toString());
                String.valueOf((long)l).contains((CharSequence)"-");
            }
        }
        if (bidingDetailModel.getIsStatus().equals((Object)"win") && !bidingDetailModel.getResultId().equals((Object)"null")) {
            TextView textView = biddetailViewHolder.result;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Win - ");
            stringBuilder.append(bidingDetailModel.getWinpoint());
            textView.setText((CharSequence)stringBuilder.toString());
            biddetailViewHolder.result.setBackgroundColor(Color.parseColor((String)"#0e8123"));
        }
        if (bidingDetailModel.getIsStatus().equals((Object)"bidding") && bidingDetailModel.getResultId().equals((Object)"null")) {
            biddetailViewHolder.result.setText((CharSequence)"Pending");
            biddetailViewHolder.result.setBackgroundColor(Color.parseColor((String)"#ffc107"));
        }
        if (bidingDetailModel.getIsStatus().equals((Object)"loss") && !bidingDetailModel.getResultId().equals((Object)"null")) {
            TextView textView = biddetailViewHolder.result;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Loss - ");
            stringBuilder.append(bidingDetailModel.getPoint());
            textView.setText((CharSequence)stringBuilder.toString());
            biddetailViewHolder.result.setBackgroundColor(Color.parseColor((String)"#ffc107"));
        }
        if (bidingDetailModel.getIsStatus().equals((Object)"cancel")) {
            TextView textView = biddetailViewHolder.result;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cancel - ");
            stringBuilder.append(bidingDetailModel.getTodayRemaningCancelDayForBid());
            textView.setText((CharSequence)stringBuilder.toString());
            biddetailViewHolder.result.setBackgroundColor(Color.parseColor((String)"#ffc107"));
        }
        biddetailViewHolder.cancel.setOnClickListener(new View.OnClickListener(this, bidingDetailModel){
            final /* synthetic */ BidingDetailAdapter this$0;
            final /* synthetic */ BidingDetailModel val$model;
            {
                this.this$0 = bidingDetailAdapter;
                this.val$model = bidingDetailModel;
            }

            public void onClick(View view) {
                BidingDetailAdapter.access$000(this.this$0, this.val$model.getUserBidTransactionDetailId());
                BidingDetailAdapter bidingDetailAdapter = this.this$0;
                bidingDetailAdapter.encryptstring = bidingDetailAdapter.encryptjson(bidingDetailAdapter.inputjson.toString());
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(this.this$0.inputjson.toString());
                Log.e((String)"data", (String)stringBuilder.toString());
            }
        });
    }

    public BiddetailViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new BiddetailViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131492910, viewGroup, false));
    }

    public String subtracttime(String string2, String string3) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("HH:mm:ss");
        try {
            Date date = simpleDateFormat.parse(string3);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(12, 0);
            String string4 = simpleDateFormat2.format(calendar.getTime());
            return string4;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return null;
        }
    }

    public class BiddetailViewHolder
    extends RecyclerView.ViewHolder {
        TextView bazarside;
        ImageView cancel;
        TextView datetime;
        TextView digit;
        TextView game;
        TextView point;
        TextView result;
        TextView session;

        public BiddetailViewHolder(View view) {
            super(view);
            this.datetime = (TextView)view.findViewById(2131296471);
            this.bazarside = (TextView)view.findViewById(2131296368);
            this.game = (TextView)view.findViewById(2131296584);
            this.point = (TextView)view.findViewById(2131296783);
            this.session = (TextView)view.findViewById(2131296848);
            this.digit = (TextView)view.findViewById(2131296491);
            this.result = (TextView)view.findViewById(2131296806);
            this.cancel = (ImageView)view.findViewById(2131296394);
        }
    }

}

