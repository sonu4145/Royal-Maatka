/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentPagerAdapter
 *  androidx.viewpager.widget.PagerAdapter
 *  androidx.viewpager.widget.ViewPager
 *  com.google.android.material.tabs.TabLayout
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.Royal.AllActivity;

import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.Royal.AllActivity.BankAccount;
import com.Royal.AllActivity.WalletAccount;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;

public class YourAccount
extends BaseAppCompactActivity {
    private TabLayout tabLayout;
    private ViewPager viewPager;

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(this.getSupportFragmentManager());
        viewPagerAdapter.addFragment(new BankAccount(), "Bank");
        viewPagerAdapter.addFragment(new WalletAccount(), "Wallet");
        viewPager.setAdapter((PagerAdapter)viewPagerAdapter);
    }

    @Override
    protected void onCreate(Bundle bundle) {
        TabLayout tabLayout;
        ViewPager viewPager;
        super.onCreate(bundle);
        this.setContentView(2131493069);
        this.setUpToolbarByName("Your Account");
        this.viewPager = viewPager = (ViewPager)this.findViewById(2131297043);
        this.setupViewPager(viewPager);
        this.tabLayout = tabLayout = (TabLayout)this.findViewById(2131296902);
        tabLayout.setupWithViewPager(this.viewPager);
    }

    class ViewPagerAdapter
    extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList;
        private final List<String> mFragmentTitleList;

        public ViewPagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
            this.mFragmentList = new ArrayList();
            this.mFragmentTitleList = new ArrayList();
        }

        public void addFragment(Fragment fragment, String string2) {
            this.mFragmentList.add((Object)fragment);
            this.mFragmentTitleList.add((Object)string2);
        }

        public int getCount() {
            return this.mFragmentList.size();
        }

        public Fragment getItem(int n) {
            return (Fragment)this.mFragmentList.get(n);
        }

        public CharSequence getPageTitle(int n) {
            return (CharSequence)this.mFragmentTitleList.get(n);
        }
    }

}

