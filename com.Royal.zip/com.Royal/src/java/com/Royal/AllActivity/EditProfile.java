/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.RadioButton
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.StringRequestListener
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.DatabaseHandler;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.StringRequestListener;
import org.json.JSONObject;

public class EditProfile
extends BaseAppCompactActivity
implements View.OnClickListener {
    DatabaseHandler db;
    String decryptstring;
    EditText edemail;
    EditText edname;
    String encryptstring;
    RadioButton female;
    JSONObject inputjson;
    RadioButton male;
    Button save;
    String stemail;
    String stgender;
    String stmobile;
    String stname;
    String stpassword;
    String stuserId;

    private void EditApi() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/edit").addBodyParameter("postData", this.encryptstring).setPriority(Priority.MEDIUM).build().getAsString(new StringRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    EditProfile.this.showToast("Something went wrong");
                }

                public void onResponse(String string2) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)string2.toString());
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void init() {
        Button button;
        this.edname = (EditText)this.findViewById(2131296544);
        this.edemail = (EditText)this.findViewById(2131296530);
        this.male = (RadioButton)this.findViewById(2131296661);
        this.female = (RadioButton)this.findViewById(2131296563);
        this.save = button = (Button)this.findViewById(2131296817);
        button.setOnClickListener((View.OnClickListener)this);
        Intent intent = this.getIntent();
        this.stuserId = intent.getStringExtra("userid");
        this.stname = intent.getStringExtra("name");
        this.stmobile = intent.getStringExtra("mobile");
        this.stemail = intent.getStringExtra("email");
        this.stgender = intent.getStringExtra("gender");
        this.stpassword = intent.getStringExtra("password");
        this.edname.setText((CharSequence)this.stname);
        this.edemail.setText((CharSequence)this.stemail);
        if (this.stgender.equals((Object)"male")) {
            this.male.setChecked(true);
        }
        if (this.stgender.equals((Object)"female")) {
            this.female.setChecked(true);
        }
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("userId", (Object)this.stuserId);
            this.inputjson.put("name", (Object)this.stname);
            this.inputjson.put("gender", (Object)this.stgender);
            this.inputjson.put("email", (Object)this.stemail);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void onClick(View view) {
        if (view == this.save) {
            if (this.edname.getText().toString().trim().length() == 0) {
                this.edname.setError((CharSequence)"Please enter name");
                this.edname.requestFocus();
            } else if (!this.male.isChecked() && !this.female.isChecked()) {
                this.showToast("Please choose gender");
            } else if (this.edemail.getText().toString().trim().length() == 0) {
                this.edemail.setError((CharSequence)"Please enter valid emailId");
                this.edemail.requestFocus();
            } else {
                this.stname = this.edname.getText().toString();
                this.stemail = this.edemail.getText().toString();
                if (this.male.isChecked()) {
                    this.stgender = "male";
                }
                if (this.female.isChecked()) {
                    this.stgender = "female";
                }
            }
            this.makesimplejson();
            this.encryptstring = this.encryptjson(this.inputjson.toString());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(this.inputjson.toString());
            Log.e((String)"encrypt", (String)stringBuilder.toString());
            this.EditApi();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492940);
        this.setUpToolbarByName("Edit Profile");
        this.db = new DatabaseHandler((Context)this);
        this.init();
    }

}

