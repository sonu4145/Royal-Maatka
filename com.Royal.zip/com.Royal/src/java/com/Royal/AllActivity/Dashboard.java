/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.ActionBarDrawerToggle
 *  androidx.appcompat.widget.Toolbar
 *  androidx.core.content.res.ResourcesCompat
 *  androidx.drawerlayout.widget.DrawerLayout
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout
 *  androidx.swiperefreshlayout.widget.SwipeRefreshLayout$OnRefreshListener
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$GetRequestBuilder
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  com.google.android.material.navigation.NavigationView
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.res.ResourcesCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.Royal.Adapter.AllBazar_Adapter;
import com.Royal.AllActivity.AllNews;
import com.Royal.AllActivity.BidingTransaction;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.Funds;
import com.Royal.AllActivity.GameRates;
import com.Royal.AllActivity.HowToPlay;
import com.Royal.AllActivity.LockPointHistory;
import com.Royal.AllActivity.PanelChart;
import com.Royal.AllActivity.PasswordSecurity;
import com.Royal.AllActivity.PointHistory;
import com.Royal.AllActivity.Profile;
import com.Royal.AllActivity.ProfileActivity;
import com.Royal.AllActivity.PurchaseReport;
import com.Royal.AllActivity.ResultActivity;
import com.Royal.AllActivity.ResultChart;
import com.Royal.AllActivity.TotalPoint;
import com.Royal.AllActivity.TransferPoint;
import com.Royal.AllActivity.WebViewActivity;
import com.Royal.AllActivity.WidthrawPoint;
import com.Royal.AllActivity.YourAccount;
import com.Royal.Model.CloseModel;
import com.Royal.Model.OpenModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.BazaarData;
import com.Royal.data.UserData;
import com.Royal.data.remote.GameDataRepository;
import com.Royal.data.remote.GameDataSource;
import com.Royal.data.remote.UserDataRepository;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.material.navigation.NavigationView;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class Dashboard
extends BaseAppCompactActivity
implements View.OnClickListener {
    public static String phone = "8181883355";
    AllBazar_Adapter adapter;
    LinearLayout allpoint;
    LinearLayout bidingtransaction;
    List<CloseModel> closelist;
    TextView contacttxt;
    LinearLayout depositpoint;
    private DrawerLayout drawerLayout;
    String encryptstring;
    String encryptstring2;
    LinearLayout gamewinratio;
    LinearLayout howtoplay;
    JSONObject inpujson;
    JSONObject inputjsonpoint;
    LinearLayout letusplay;
    List<BazaarData> list;
    LinearLayout logout;
    GameDataRepository mGameDataRepository;
    UserDataRepository mUserDataRepository;
    LinearLayout more;
    private NavigationView navigationView;
    TextView nobazar;
    TextView number;
    List<OpenModel> openlist;
    LinearLayout panel_chart;
    LinearLayout passwordsecurity;
    TextView point;
    LinearLayout point_lock_history;
    LinearLayout point_transaction_history;
    LinearLayout privacyandpolicy;
    LinearLayout profile;
    LinearLayout profileActivity;
    LinearLayout purchasereport;
    RecyclerView recyclerView;
    LinearLayout result;
    LinearLayout result_chart;
    SwipeRefreshLayout swipeRefreshLayout;
    LinearLayout termsandconditon;
    private Toolbar toolbar;
    LinearLayout transfer_point;
    TextView tv_userName;
    TextView tv_useremail;
    UserData userData;
    LinearLayout widthrawpoint;
    LinearLayout youraccount;
    LinearLayout yourpoint;

    private void BazarList() {
        if (!this.isInternetOn()) {
            return;
        }
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        this.mGameDataRepository.getBazaarList(new GameDataSource.GetBazaarCallBack(){

            @Override
            public void onBazaarLoaded(ArrayList<BazaarData> arrayList) {
                if (Dashboard.this.swipeRefreshLayout.isRefreshing()) {
                    Dashboard.this.swipeRefreshLayout.setRefreshing(false);
                }
                progressDialog.dismiss();
                Dashboard.this.list.addAll(arrayList);
                Dashboard.this.adapter.notifyDataSetChanged();
            }

            @Override
            public void onErrorInLoading(String string2) {
                progressDialog.dismiss();
                Dashboard.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                progressDialog.dismiss();
                ScreenUtils.showLockScreen((Activity)Dashboard.this);
            }
        });
    }

    private void GetPoint() {
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/point").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

            public void onError(ANError aNError) {
                progressDialog.dismiss();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(aNError.getErrorDetail());
                Log.d((String)"error", (String)stringBuilder.toString());
                Dashboard.this.showToast("Something went wrong");
            }

            public void onResponse(JSONObject jSONObject) {
                progressDialog.dismiss();
                Log.e((String)"Api_response", (String)jSONObject.toString());
                try {
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        String string2 = jSONObject.getString("totalPoint");
                        jSONObject.getString("lockPoint");
                        jSONObject.getString("bidPoint");
                        jSONObject.getString("winPoint");
                        BaseAppCompactActivity.myPoints = Long.parseLong((String)string2);
                        Dashboard.this.point.setText((CharSequence)String.valueOf((long)BaseAppCompactActivity.myPoints));
                        return;
                    }
                    jSONObject.getString("error");
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    static /* synthetic */ DrawerLayout access$100(Dashboard dashboard) {
        return dashboard.drawerLayout;
    }

    private void getWebServiceData() {
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/admin/contact").addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

            public void onError(ANError aNError) {
                progressDialog.dismiss();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(aNError.getErrorDetail());
                Log.d((String)"error", (String)stringBuilder.toString());
            }

            public void onResponse(JSONObject jSONObject) {
                progressDialog.dismiss();
                Log.e((String)"Api_response", (String)jSONObject.toString());
                try {
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        Dashboard.phone = jSONObject.getString("mobile");
                        Dashboard.this.contacttxt.setText((CharSequence)Dashboard.phone);
                        Dashboard.this.number.setText((CharSequence)Dashboard.phone);
                        return;
                    }
                    jSONObject.getString("error");
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    private void init() {
        AllBazar_Adapter allBazar_Adapter;
        this.recyclerView = (RecyclerView)this.findViewById(2131296367);
        this.nobazar = (TextView)this.findViewById(2131296741);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getApplicationContext());
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.list = new ArrayList();
        this.openlist = new ArrayList();
        this.closelist = new ArrayList();
        this.adapter = allBazar_Adapter = new AllBazar_Adapter((Context)this, this.list);
        this.recyclerView.setAdapter((RecyclerView.Adapter)allBazar_Adapter);
        this.BazarList();
    }

    private void initDrawerLayout() {
        DrawerLayout drawerLayout;
        this.drawerLayout = drawerLayout = (DrawerLayout)this.findViewById(2131296510);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle((Activity)this, drawerLayout, this.toolbar, 2131820718, 2131820597);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(false);
        actionBarDrawerToggle.setHomeAsUpIndicator(ResourcesCompat.getDrawable((Resources)this.getResources(), (int)2131165387, (Resources.Theme)this.getApplicationContext().getTheme()));
        actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener(this){
            final /* synthetic */ Dashboard this$0;
            {
                this.this$0 = dashboard;
            }

            public void onClick(View view) {
                if (Dashboard.access$100(this.this$0).isDrawerVisible(8388611)) {
                    Dashboard.access$100(this.this$0).closeDrawer(8388611);
                    return;
                }
                Dashboard.access$100(this.this$0).openDrawer(8388611);
            }
        });
    }

    private void initNavigationDrawer() {
        NavigationView navigationView;
        TextView textView;
        this.navigationView = navigationView = (NavigationView)this.findViewById(2131296732);
        this.tv_userName = (TextView)navigationView.findViewById(2131297031);
        this.tv_useremail = textView = (TextView)this.navigationView.findViewById(2131297030);
        textView.setText((CharSequence)this.userData.getMobileNumber());
        this.tv_userName.setText((CharSequence)this.userData.getDisplayName());
        this.logout = (LinearLayout)this.navigationView.findViewById(2131296660);
        this.gamewinratio = (LinearLayout)this.navigationView.findViewById(2131296585);
        this.howtoplay = (LinearLayout)this.navigationView.findViewById(2131296611);
        this.privacyandpolicy = (LinearLayout)this.navigationView.findViewById(2131296791);
        this.termsandconditon = (LinearLayout)this.navigationView.findViewById(2131296916);
        this.letusplay = (LinearLayout)this.navigationView.findViewById(2131296651);
        this.profileActivity = (LinearLayout)this.navigationView.findViewById(2131297067);
        this.bidingtransaction = (LinearLayout)this.navigationView.findViewById(2131296374);
        this.youraccount = (LinearLayout)this.navigationView.findViewById(2131297065);
        this.yourpoint = (LinearLayout)this.navigationView.findViewById(2131297066);
        this.depositpoint = (LinearLayout)this.navigationView.findViewById(2131296482);
        this.widthrawpoint = (LinearLayout)this.navigationView.findViewById(2131297056);
        this.profile = (LinearLayout)this.navigationView.findViewById(2131296792);
        this.passwordsecurity = (LinearLayout)this.navigationView.findViewById(2131296773);
        this.allpoint = (LinearLayout)this.navigationView.findViewById(2131297066);
        this.more = (LinearLayout)this.navigationView.findViewById(2131296696);
        this.transfer_point = (LinearLayout)this.navigationView.findViewById(2131296994);
        this.point_transaction_history = (LinearLayout)this.navigationView.findViewById(2131297037);
        this.point_lock_history = (LinearLayout)this.navigationView.findViewById(2131297035);
        this.result = (LinearLayout)this.navigationView.findViewById(2131296806);
        this.result_chart = (LinearLayout)this.navigationView.findViewById(2131296807);
        this.panel_chart = (LinearLayout)this.navigationView.findViewById(2131296767);
        this.purchasereport = (LinearLayout)this.navigationView.findViewById(2131296472);
        if (this.userData.getMobileNumber().equals((Object)"9876543210")) {
            this.profileActivity.setVisibility(8);
            this.bidingtransaction.setVisibility(8);
            this.point_transaction_history.setVisibility(8);
            this.depositpoint.setVisibility(8);
            this.yourpoint.setVisibility(8);
            this.gamewinratio.setVisibility(8);
            this.purchasereport.setVisibility(8);
        }
        this.logout.setOnClickListener((View.OnClickListener)this);
        this.letusplay.setOnClickListener((View.OnClickListener)this);
        this.profileActivity.setOnClickListener((View.OnClickListener)this);
        this.bidingtransaction.setOnClickListener((View.OnClickListener)this);
        this.youraccount.setOnClickListener((View.OnClickListener)this);
        this.yourpoint.setOnClickListener((View.OnClickListener)this);
        this.depositpoint.setOnClickListener((View.OnClickListener)this);
        this.widthrawpoint.setOnClickListener((View.OnClickListener)this);
        this.profile.setOnClickListener((View.OnClickListener)this);
        this.passwordsecurity.setOnClickListener((View.OnClickListener)this);
        this.allpoint.setOnClickListener((View.OnClickListener)this);
        this.more.setOnClickListener((View.OnClickListener)this);
        this.transfer_point.setOnClickListener((View.OnClickListener)this);
        this.point_transaction_history.setOnClickListener((View.OnClickListener)this);
        this.point_lock_history.setOnClickListener((View.OnClickListener)this);
        this.result.setOnClickListener((View.OnClickListener)this);
        this.gamewinratio.setOnClickListener((View.OnClickListener)this);
        this.privacyandpolicy.setOnClickListener((View.OnClickListener)this);
        this.howtoplay.setOnClickListener((View.OnClickListener)this);
        this.termsandconditon.setOnClickListener((View.OnClickListener)this);
        this.result_chart.setOnClickListener((View.OnClickListener)this);
        this.panel_chart.setOnClickListener((View.OnClickListener)this);
        this.purchasereport.setOnClickListener((View.OnClickListener)this);
    }

    private void initToolbar() {
        Toolbar toolbar;
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131296976);
        TextView textView = (TextView)toolbar.findViewById(2131296978);
        this.point = (TextView)this.toolbar.findViewById(2131296977);
        textView.setText((CharSequence)"BOMBAY SIDE GAMES");
        this.setSupportActionBar(this.toolbar);
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            this.getSupportActionBar().setDisplayShowHomeEnabled(false);
            this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void logoutConfirmAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this);
        builder.setMessage((CharSequence)"Are you sure you want to logout.").setCancelable(false).setPositiveButton((CharSequence)"Ok", new DialogInterface.OnClickListener(this){
            final /* synthetic */ Dashboard this$0;
            {
                this.this$0 = dashboard;
            }

            public void onClick(DialogInterface dialogInterface, int n) {
                this.this$0.userData.setIsLogin(false);
                android.content.SharedPreferences$Editor editor = this.this$0.getSharedPreferences("shared", 0).edit();
                editor.clear();
                editor.commit();
                this.this$0.sendToNextActivity(com.Royal.AllActivity.Login.class);
                this.this$0.finish();
            }
        });
        builder.setNegativeButton((CharSequence)"Cancel", new DialogInterface.OnClickListener(this){
            final /* synthetic */ Dashboard this$0;
            {
                this.this$0 = dashboard;
            }

            public void onClick(DialogInterface dialogInterface, int n) {
                dialogInterface.dismiss();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.setTitle((CharSequence)"Confirmation");
        alertDialog.show();
    }

    private void makepointjsonforpointdata() {
        JSONObject jSONObject;
        this.inputjsonpoint = jSONObject = new JSONObject();
        try {
            jSONObject.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void makesimplejson(String string2) {
        JSONObject jSONObject;
        this.inpujson = jSONObject = new JSONObject();
        try {
            jSONObject.put("fcmId", (Object)string2);
            this.inpujson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void onBackPressed() {
        if (this.drawerLayout.isDrawerOpen(8388611)) {
            this.drawerLayout.closeDrawers();
            return;
        }
        super.onBackPressed();
    }

    public void onClick(View view) {
        this.drawerLayout.closeDrawers();
        if (view == this.logout) {
            this.logoutConfirmAlert();
        }
        if (view == this.bidingtransaction) {
            this.sendToNextActivity(BidingTransaction.class);
        }
        if (view == this.youraccount) {
            this.sendToNextActivity(YourAccount.class);
        }
        if (view == this.letusplay) {
            this.drawerLayout.closeDrawer(3);
        }
        if (view == this.profileActivity) {
            this.sendToNextActivity(ProfileActivity.class);
        }
        if (view == this.depositpoint) {
            this.sendToNextActivity(Funds.class);
        }
        if (view == this.widthrawpoint) {
            this.sendToNextActivity(WidthrawPoint.class);
        }
        if (view == this.profile) {
            this.sendToNextActivity(Profile.class);
        }
        if (view == this.passwordsecurity) {
            this.sendToNextActivity(PasswordSecurity.class);
        }
        if (view == this.allpoint) {
            this.sendToNextActivity(TotalPoint.class);
        }
        if (view == this.more) {
            this.sendToNextActivity(AllNews.class);
        }
        if (view == this.transfer_point) {
            this.sendToNextActivity(TransferPoint.class);
        }
        if (view == this.point_transaction_history) {
            this.sendToNextActivity(PointHistory.class);
        }
        if (view == this.point_lock_history) {
            this.sendToNextActivity(LockPointHistory.class);
        }
        if (view == this.result) {
            this.sendToNextActivity(ResultActivity.class);
        }
        if (view == this.result_chart) {
            this.sendToNextActivity(ResultChart.class);
        }
        if (view == this.panel_chart) {
            this.sendToNextActivity(PanelChart.class);
        }
        if (view == this.purchasereport) {
            this.sendToNextActivity(PurchaseReport.class);
        }
        if (view == this.gamewinratio) {
            this.startActivity(new Intent((Context)this, GameRates.class));
            this.overridePendingTransition(2130771983, 2130771980);
        }
        if (view == this.privacyandpolicy) {
            Intent intent = new Intent((Context)this, WebViewActivity.class);
            intent.putExtra("url", "https://www.balajimatka.com/privacy-and-policy");
            this.startActivity(intent);
            this.overridePendingTransition(2130771983, 2130771980);
        }
        if (view == this.termsandconditon) {
            Intent intent = new Intent((Context)this, WebViewActivity.class);
            intent.putExtra("url", "https://www.balajimatka.com/term-and-condition");
            this.startActivity(intent);
            this.overridePendingTransition(2130771983, 2130771980);
        }
        if (view == this.howtoplay) {
            this.startActivity(new Intent((Context)this, HowToPlay.class));
            this.overridePendingTransition(2130771983, 2130771980);
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        SwipeRefreshLayout swipeRefreshLayout;
        super.onCreate(bundle);
        this.setContentView(2131492919);
        this.contacttxt = (TextView)this.findViewById(2131296393);
        this.number = (TextView)this.findViewById(2131296750);
        this.swipeRefreshLayout = swipeRefreshLayout = (SwipeRefreshLayout)this.findViewById(2131296452);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener(){

            public void onRefresh() {
                Dashboard.this.list = new ArrayList();
                Dashboard.this.openlist = new ArrayList();
                Dashboard.this.closelist = new ArrayList();
                Dashboard.this.BazarList();
            }
        });
        this.contacttxt.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ Dashboard this$0;
            {
                this.this$0 = dashboard;
            }

            public void onClick(View view) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("tel:");
                stringBuilder.append(Dashboard.phone);
                Intent intent = new Intent("android.intent.action.CALL", android.net.Uri.parse((String)stringBuilder.toString()));
                if (androidx.core.content.ContextCompat.checkSelfPermission((Context)this.this$0, (String)"android.permission.CALL_PHONE") != 0) {
                    androidx.core.app.ActivityCompat.requestPermissions((Activity)this.this$0, (String[])new String[]{"android.permission.CALL_PHONE"}, (int)1);
                    return;
                }
                this.this$0.startActivity(intent);
            }
        });
        this.getWebServiceData();
    }

    protected void onResume() {
        super.onResume();
        this.mUserDataRepository = UserDataRepository.getInstance((Context)this);
        this.mGameDataRepository = GameDataRepository.getInstance((Context)this);
        this.userData = this.mUserDataRepository.getUserData();
        this.init();
        this.initToolbar();
        this.initNavigationDrawer();
        this.initDrawerLayout();
        this.makepointjsonforpointdata();
        this.encryptstring = this.encryptjson(this.inputjsonpoint.toString());
        this.GetPoint();
    }

}

