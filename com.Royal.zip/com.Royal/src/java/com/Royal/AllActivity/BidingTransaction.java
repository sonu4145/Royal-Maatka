/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.DatePickerDialog
 *  android.app.DatePickerDialog$OnDateSetListener
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 *  java.util.Locale
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.BidTransactionAdapter;
import com.Royal.AllActivity.BidingTransaction;
import com.Royal.Model.BidTransactionModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BidingTransaction
extends BaseAppCompactActivity
implements View.OnClickListener {
    BidTransactionAdapter adapter;
    String decryptdtring;
    String encryptstring;
    DatePickerDialog.OnDateSetListener fdate;
    EditText fromdate;
    JSONObject inpujson;
    List<BidTransactionModel> list;
    Calendar myCalendar;
    RecyclerView recyclerView;
    Button search;
    String startindex = "";
    DatePickerDialog.OnDateSetListener tdate;
    EditText todate;

    private void TransactionList() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.encryptstring);
        Log.e((String)"bazar", (String)stringBuilder.toString());
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/bidding/all").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    BidingTransaction.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            String string2 = jSONObject.getString("data");
                            BidingTransaction.this.parseoperatorjson(string2);
                            return;
                        }
                        String string3 = jSONObject.getString("error");
                        BidingTransaction.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    static /* synthetic */ void access$000(BidingTransaction bidingTransaction) {
        bidingTransaction.updatefromLabel();
    }

    static /* synthetic */ void access$100(BidingTransaction bidingTransaction) {
        bidingTransaction.updatetoLabel();
    }

    private void init() {
        ArrayList arrayList;
        BidTransactionAdapter bidTransactionAdapter;
        this.fromdate = (EditText)this.findViewById(2131296581);
        this.todate = (EditText)this.findViewById(2131296974);
        this.search = (Button)this.findViewById(2131296829);
        this.recyclerView = (RecyclerView)this.findViewById(2131296989);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getApplicationContext());
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.search.setOnClickListener((View.OnClickListener)this);
        this.fromdate.setOnClickListener((View.OnClickListener)this);
        this.todate.setOnClickListener((View.OnClickListener)this);
        this.myCalendar = Calendar.getInstance();
        this.fdate = new DatePickerDialog.OnDateSetListener(this){
            final /* synthetic */ BidingTransaction this$0;
            {
                this.this$0 = bidingTransaction;
            }

            public void onDateSet(android.widget.DatePicker datePicker, int n, int n2, int n3) {
                this.this$0.myCalendar = Calendar.getInstance();
                this.this$0.myCalendar.set(1, n);
                this.this$0.myCalendar.set(2, n2);
                this.this$0.myCalendar.set(5, n3);
                BidingTransaction.access$000(this.this$0);
            }
        };
        this.tdate = new DatePickerDialog.OnDateSetListener(this){
            final /* synthetic */ BidingTransaction this$0;
            {
                this.this$0 = bidingTransaction;
            }

            public void onDateSet(android.widget.DatePicker datePicker, int n, int n2, int n3) {
                this.this$0.myCalendar = Calendar.getInstance();
                this.this$0.myCalendar.set(1, n);
                this.this$0.myCalendar.set(2, n2);
                this.this$0.myCalendar.set(5, n3);
                BidingTransaction.access$100(this.this$0);
            }
        };
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyy");
        this.fromdate.setText((CharSequence)simpleDateFormat.format(new Date()));
        this.todate.setText((CharSequence)simpleDateFormat.format(new Date()));
        this.list = arrayList = new ArrayList();
        this.adapter = bidTransactionAdapter = new BidTransactionAdapter((Context)this, (List<BidTransactionModel>)arrayList);
        this.recyclerView.setAdapter((RecyclerView.Adapter)bidTransactionAdapter);
        this.makesimplejson();
        Log.e((String)"json", (String)this.inpujson.toString());
        this.encryptstring = this.encryptjson(this.inpujson.toString());
        this.TransactionList();
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inpujson = jSONObject = new JSONObject();
        try {
            jSONObject.put("offset", (Object)"0");
            this.inpujson.put("perPage", (Object)"1500");
            this.inpujson.put("toDate", (Object)this.todate.getText().toString());
            this.inpujson.put("fromDate", (Object)this.fromdate.getText().toString());
            this.inpujson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void parseoperatorjson(String string2) {
        JSONArray jSONArray = new JSONArray(string2);
        if (jSONArray.length() == 0) {
            this.showToast("No data found");
        }
        this.list.clear();
        int n = 0;
        do {
            if (n >= jSONArray.length()) break;
            JSONObject jSONObject = jSONArray.getJSONObject(n);
            BidTransactionModel bidTransactionModel = new BidTransactionModel();
            bidTransactionModel.setId(jSONObject.getString("ticketNumber"));
            bidTransactionModel.setBazaarSideId(jSONObject.getString("bazaar"));
            bidTransactionModel.setUserId(jSONObject.getString("userId"));
            bidTransactionModel.setBazaarSide(jSONObject.getString("bazaarSide"));
            bidTransactionModel.setNumberOfBid(jSONObject.getString("numberOfBid"));
            bidTransactionModel.setBidPoint(jSONObject.getString("bidPoint"));
            bidTransactionModel.setIsStatus(jSONObject.getString("isStatus"));
            bidTransactionModel.setCreatedOn(jSONObject.getString("createdOn"));
            this.list.add((Object)bidTransactionModel);
            ++n;
        } while (true);
        try {
            this.adapter.notifyDataSetChanged();
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    private void updatefromLabel() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyy", Locale.US);
        this.fromdate.setText((CharSequence)simpleDateFormat.format(this.myCalendar.getTime()));
    }

    private void updatetoLabel() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyy", Locale.US);
        this.todate.setText((CharSequence)simpleDateFormat.format(this.myCalendar.getTime()));
    }

    public void onClick(View view) {
        if (view == this.fromdate) {
            DatePickerDialog datePickerDialog = new DatePickerDialog((Context)this, this.fdate, this.myCalendar.get(1), this.myCalendar.get(2), this.myCalendar.get(5));
            datePickerDialog.show();
        }
        if (view == this.todate) {
            DatePickerDialog datePickerDialog = new DatePickerDialog((Context)this, this.tdate, this.myCalendar.get(1), this.myCalendar.get(2), this.myCalendar.get(5));
            datePickerDialog.show();
        }
        if (view == this.search) {
            BidTransactionAdapter bidTransactionAdapter;
            ArrayList arrayList;
            if (this.fromdate.getText().toString().trim().length() == 0) {
                this.fromdate.setError((CharSequence)"Please choose From Date");
                this.fromdate.requestFocus();
                return;
            }
            if (this.todate.getText().toString().trim().length() == 0) {
                this.todate.setError((CharSequence)"Please choose To date");
                this.todate.requestFocus();
                return;
            }
            this.list = arrayList = new ArrayList();
            this.adapter = bidTransactionAdapter = new BidTransactionAdapter((Context)this, (List<BidTransactionModel>)arrayList);
            this.recyclerView.setAdapter((RecyclerView.Adapter)bidTransactionAdapter);
            this.makesimplejson();
            Log.e((String)"json", (String)this.inpujson.toString());
            this.encryptstring = this.encryptjson(this.inpujson.toString());
            this.TransactionList();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492912);
        this.setUpToolbarByName("Bid History");
        this.init();
    }

}

