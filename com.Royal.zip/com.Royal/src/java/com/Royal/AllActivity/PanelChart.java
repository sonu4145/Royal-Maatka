/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.app.ProgressDialog
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.os.Environment
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.text.Editable
 *  android.text.Html
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.HorizontalScrollView
 *  android.widget.NumberPicker
 *  android.widget.NumberPicker$OnValueChangeListener
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TableLayout
 *  android.widget.TableRow
 *  android.widget.TextView
 *  androidx.print.PrintHelper
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$GetRequestBuilder
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.OutputStream
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 *  java.util.Locale
 *  org.joda.time.LocalDate
 *  org.joda.time.ReadablePartial
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.print.PrintHelper;
import com.Royal.AllActivity.PanelChart;
import com.Royal.Model.BazarModel;
import com.Royal.Model.DateModel;
import com.Royal.Model.RecordModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.joda.time.LocalDate;
import org.joda.time.ReadablePartial;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PanelChart
extends BaseAppCompactActivity
implements View.OnClickListener,
NumberPicker.OnValueChangeListener {
    String bazarid;
    JSONObject bazarjson;
    List<BazarModel> bazarlist;
    Spinner choosebazar;
    String datecompare = "";
    String decryptdtring;
    List<DateModel> dtlistend;
    List<DateModel> dtliststart;
    EditText edyear;
    String encryptstring;
    JSONObject inputjson;
    Button print;
    List<RecordModel> recordlist = new ArrayList();
    ArrayList<String> redjodilist = new ArrayList();
    Button search;
    List<String> simplebazarlist;
    TableLayout stk;
    int year;

    private void BazarList() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.encryptstring);
        Log.e((String)"bazar", (String)stringBuilder.toString());
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/bazaar/all").addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    PanelChart.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            String string2 = jSONObject.getString("bazaars");
                            PanelChart.this.parseoperatorjson(string2);
                            return;
                        }
                        String string3 = jSONObject.getString("error");
                        PanelChart.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void ResultApiList() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.encryptstring);
        Log.e((String)"bazar", (String)stringBuilder.toString());
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/record/panelChart").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    PanelChart.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"resultApi_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            String string2 = jSONObject.getString("results");
                            String string3 = jSONObject.getString("redJodiList");
                            PanelChart.this.parseresultjson(string2);
                            PanelChart.this.parseredjodijson(string3);
                            return;
                        }
                        String string4 = jSONObject.getString("error");
                        PanelChart.this.showToast(Html.fromHtml((String)string4).toString());
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void getalldate() {
        this.dtlistend.clear();
        this.dtliststart.clear();
        LocalDate localDate = new LocalDate(this.year, 1, 1);
        LocalDate localDate2 = new LocalDate(this.year, 1, 1);
        LocalDate localDate3 = new LocalDate(this.year, 12, 31);
        LocalDate localDate4 = localDate.withDayOfWeek(1);
        LocalDate localDate5 = localDate2.withDayOfWeek(7);
        if (localDate.isAfter((ReadablePartial)localDate4)) {
            localDate4 = localDate4.plusWeeks(1);
        }
        if (localDate2.isAfter((ReadablePartial)localDate5)) {
            localDate5 = localDate5.plusWeeks(1);
        }
        do {
            if (!localDate4.isBefore((ReadablePartial)localDate3) && !localDate4.equals((Object)localDate3)) {
                do {
                    if (!localDate5.isBefore((ReadablePartial)localDate3) && !localDate5.equals((Object)localDate3)) {
                        String string2 = ((DateModel)this.dtliststart.get(0)).getStdate();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(this.year);
                        stringBuilder.append("-01-01");
                        if (!string2.equals((Object)stringBuilder.toString())) {
                            String string3 = ((DateModel)this.dtlistend.get(0)).getStdate();
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(this.year);
                            stringBuilder2.append("-01-01");
                            if (!string3.equals((Object)stringBuilder2.toString())) {
                                DateModel dateModel = new DateModel();
                                StringBuilder stringBuilder3 = new StringBuilder();
                                stringBuilder3.append(this.year);
                                stringBuilder3.append("-01-01");
                                dateModel.setStdate(stringBuilder3.toString());
                                this.dtliststart.add(0, (Object)dateModel);
                            }
                        }
                        List<DateModel> list = this.dtliststart;
                        String string4 = ((DateModel)list.get(list.size() - 1)).getStdate();
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(this.year);
                        stringBuilder4.append("-12-31");
                        if (!string4.equals((Object)stringBuilder4.toString())) {
                            List<DateModel> list2 = this.dtlistend;
                            String string5 = ((DateModel)list2.get(list2.size() - 1)).getStdate();
                            StringBuilder stringBuilder5 = new StringBuilder();
                            stringBuilder5.append(this.year);
                            stringBuilder5.append("-12-31");
                            if (!string5.equals((Object)stringBuilder5.toString())) {
                                DateModel dateModel = new DateModel();
                                StringBuilder stringBuilder6 = new StringBuilder();
                                stringBuilder6.append(this.year);
                                stringBuilder6.append("-12-31");
                                dateModel.setStdate(stringBuilder6.toString());
                                List<DateModel> list3 = this.dtlistend;
                                list3.add(list3.size(), (Object)dateModel);
                            }
                        }
                        return;
                    }
                    System.out.println((Object)localDate4);
                    DateModel dateModel = new DateModel();
                    dateModel.setStdate(String.valueOf((Object)localDate5));
                    this.dtlistend.add((Object)dateModel);
                    localDate5 = localDate5.plusWeeks(1);
                } while (true);
            }
            System.out.println((Object)localDate4);
            DateModel dateModel = new DateModel();
            dateModel.setStdate(String.valueOf((Object)localDate4));
            this.dtliststart.add((Object)dateModel);
            localDate4 = localDate4.plusWeeks(1);
        } while (true);
    }

    private void init() {
        this.choosebazar = (Spinner)this.findViewById(2131296432);
        this.edyear = (EditText)this.findViewById(2131296547);
        this.search = (Button)this.findViewById(2131296829);
        this.print = (Button)this.findViewById(2131296790);
        this.stk = (TableLayout)this.findViewById(2131296901);
        this.search.setOnClickListener((View.OnClickListener)this);
        this.print.setOnClickListener((View.OnClickListener)this);
        this.bazarlist = new ArrayList();
        this.dtliststart = new ArrayList();
        this.dtlistend = new ArrayList();
        this.simplebazarlist = new ArrayList();
        this.BazarList();
        this.year = Calendar.getInstance().get(1);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("nn");
        stringBuilder.append(this.year);
        Log.e((String)"year", (String)stringBuilder.toString());
        this.edyear.setText((CharSequence)String.valueOf((int)this.year));
        this.edyear.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ PanelChart this$0;
            {
                this.this$0 = panelChart;
            }

            public void onClick(View view) {
                this.this$0.show();
            }
        });
        this.choosebazar.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(this){
            final /* synthetic */ PanelChart this$0;
            {
                this.this$0 = panelChart;
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("n");
                stringBuilder.append(this.this$0.bazarlist.size());
                Log.e((String)"bazarsize", (String)stringBuilder.toString());
                if (this.this$0.bazarlist.size() > 0) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("n");
                    stringBuilder2.append(this.this$0.bazarlist.get(n));
                    Log.e((String)"bazarsize", (String)stringBuilder2.toString());
                    PanelChart panelChart = this.this$0;
                    panelChart.bazarid = ((BazarModel)panelChart.bazarlist.get(n)).getId();
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("bazaarId", (Object)this.bazarid);
            this.inputjson.put("year", (Object)this.edyear.getText().toString());
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void parseoperatorjson(String string2) {
        JSONArray jSONArray = new JSONArray(string2);
        int n = 0;
        do {
            if (n >= jSONArray.length()) break;
            JSONObject jSONObject = jSONArray.getJSONObject(n);
            BazarModel bazarModel = new BazarModel();
            bazarModel.setId(jSONObject.getString("id"));
            bazarModel.setBazaarSideId(jSONObject.getString("todayOpenTime"));
            bazarModel.setBazaarSideId(jSONObject.getString("todayCloseTime"));
            bazarModel.setName(jSONObject.getString("name"));
            this.simplebazarlist.add((Object)jSONObject.getString("name"));
            this.bazarlist.add((Object)bazarModel);
            ++n;
        } while (true);
        try {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, this.simplebazarlist);
            arrayAdapter.setDropDownViewResource(17367049);
            this.choosebazar.setAdapter((SpinnerAdapter)arrayAdapter);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void parseredjodijson(String string2) {
        try {
            JSONArray jSONArray = new JSONArray(string2);
            if (jSONArray.length() == 0) {
                this.showToast("No data found");
            }
            for (int i = 0; i < jSONArray.length(); ++i) {
                this.redjodilist.add((Object)((String)jSONArray.get(i)));
            }
            this.setdataontable();
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void parseresultjson(String string2) {
        try {
            JSONArray jSONArray = new JSONArray(string2);
            if (jSONArray.length() == 0) {
                this.showToast("No data found");
            }
            for (int i = 0; i < jSONArray.length(); ++i) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                RecordModel recordModel = new RecordModel();
                recordModel.setPana(jSONObject.getString("pana"));
                recordModel.setJodi(jSONObject.getString("jodi"));
                recordModel.setAnk(jSONObject.getString("ank"));
                recordModel.setDate(jSONObject.getString("date"));
                recordModel.setSession(jSONObject.getString("session"));
                this.recordlist.add((Object)recordModel);
            }
            if (this.recordlist.size() <= 0) return;
            this.datecompare = ((RecordModel)this.recordlist.get(0)).getDate();
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void setdataontable() {
        var1_1 = "yyyy-MM-dd";
        var2_2 = new TableRow((Context)this);
        var3_3 = new TextView((Context)this);
        var3_3.setText((CharSequence)"DATE RANGE/DAYS");
        var4_4 = -1;
        var3_3.setTextColor(var4_4);
        var2_2.addView((View)var3_3);
        var5_5 = new TextView((Context)this);
        var6_6 = "   ";
        var5_5.setText((CharSequence)var6_6);
        var5_5.setTextColor(var4_4);
        var2_2.addView((View)var5_5);
        var7_7 = new ArrayList();
        var7_7.add((Object)"Monday");
        var7_7.add((Object)"Tuesday");
        var7_7.add((Object)"Wednesday");
        var7_7.add((Object)"Thursday");
        var7_7.add((Object)"Friday");
        var7_7.add((Object)"Saturday");
        var7_7.add((Object)"Sunday");
        var15_8 = 0;
        do {
            var16_9 = var7_7.size();
            var17_10 = 17;
            if (var15_8 >= var16_9) break;
            var18_11 = new TextView((Context)this);
            var18_11.setText((CharSequence)var7_7.get(var15_8));
            var18_11.setTextColor(var4_4);
            var18_11.setGravity(var17_10);
            var2_2.addView((View)var18_11);
            var19_12 = new TextView((Context)this);
            var19_12.setText((CharSequence)"  ");
            var19_12.setTextColor(var4_4);
            var19_12.setGravity(var17_10);
            var2_2.addView((View)var19_12);
            ++var15_8;
        } while (true);
        this.stk.addView((View)var2_2);
        if (this.dtliststart.size() > this.dtlistend.size()) {
            var166_13 = this.dtlistend;
            var167_14 = var166_13.size();
            var168_15 = this.dtliststart;
            var166_13.add(var167_14, (Object)((DateModel)var168_15.get(var168_15.size() - 1)));
        }
        if (this.dtlistend.size() > this.dtliststart.size()) {
            this.dtliststart.add(0, (Object)((DateModel)this.dtlistend.get(0)));
        }
        if (this.dtliststart.size() != this.dtlistend.size()) return;
        var20_16 = 0;
        var21_17 = 0;
        block11 : do {
            if (var21_17 >= this.dtliststart.size()) return;
            var22_18 = new TableRow((Context)this);
            var23_19 = new TextView((Context)this);
            var24_20 = new StringBuilder();
            var24_20.append(this.parseDateToddMMyyyy(((DateModel)this.dtliststart.get(var21_17)).getStdate()));
            var24_20.append("\n    to \n");
            var24_20.append(this.parseDateToddMMyyyy(((DateModel)this.dtlistend.get(var21_17)).getStdate()));
            var24_20.append("\n");
            var23_19.setText((CharSequence)var24_20.toString());
            var23_19.setTextColor(var4_4);
            var23_19.setGravity(var17_10);
            var22_18.addView((View)var23_19);
            var29_21 = new TextView((Context)this);
            var29_21.setText((CharSequence)var6_6);
            var29_21.setTextColor(var4_4);
            var29_21.setGravity(var17_10);
            var22_18.addView((View)var29_21);
            var30_22 = var20_16;
            var32_24 = var31_23 = " ";
            var33_25 = 0;
            var34_26 = false;
            do {
                block37 : {
                    block43 : {
                        block47 : {
                            block46 : {
                                block44 : {
                                    block45 : {
                                        if (var33_25 >= var7_7.size()) break block44;
                                        var35_27 = new TextView((Context)this);
                                        var36_28 = this.recordlist.size();
                                        var37_29 = "*        *\n*  **  *\n*        *\n";
                                        if (var30_22 != var36_28) break block45;
                                        var38_30 = new TextView((Context)this);
                                        var38_30.setText((CharSequence)var37_29);
                                        var38_30.setTextColor(var4_4);
                                        var38_30.setGravity(17);
                                        var22_18.addView((View)var38_30);
                                        var39_31 = new TextView((Context)this);
                                        var39_31.setText((CharSequence)var6_6);
                                        var39_31.setTextColor(var4_4);
                                        var39_31.setGravity(17);
                                        var22_18.addView((View)var39_31);
                                        var40_32 = var1_1;
                                        var41_33 = var7_7;
                                        var42_34 = var6_6;
                                        var43_35 = var21_17;
                                        break block46;
                                    }
                                    var45_37 = var33_25;
                                    var46_38 = var30_22;
                                    var47_39 = var31_23;
                                    var48_40 = var32_24;
                                    var49_41 = false;
                                    var50_42 = false;
                                    var51_43 = 0;
                                    var52_44 = var35_27;
                                    var53_45 = var46_38;
                                    var54_46 = " ";
                                    break block47;
                                }
                                var161_102 = var1_1;
                                var162_103 = var7_7;
                                var164_104 = var21_17;
                                var165_105 = var30_22;
                                this.stk.addView((View)var22_18);
                                var21_17 = var164_104 + 1;
                                var20_16 = var165_105;
                                var1_1 = var161_102;
                                var7_7 = var162_103;
                                var4_4 = -1;
                                continue block11;
                            }
lbl117: // 4 sources:
                            do {
                                var44_36 = 1;
                                var17_10 = 17;
                                break block37;
                                break;
                            } while (true);
                        }
                        while (var53_45 < this.recordlist.size()) {
                            block63 : {
                                block62 : {
                                    block48 : {
                                        block57 : {
                                            block61 : {
                                                block58 : {
                                                    block59 : {
                                                        block55 : {
                                                            block60 : {
                                                                block49 : {
                                                                    block54 : {
                                                                        block56 : {
                                                                            block51 : {
                                                                                block52 : {
                                                                                    block53 : {
                                                                                        block50 : {
                                                                                            block40 : {
                                                                                                block41 : {
                                                                                                    block42 : {
                                                                                                        block38 : {
                                                                                                            block39 : {
                                                                                                                var57_48 = Calendar.getInstance();
                                                                                                                var58_49 = var34_26;
                                                                                                                var59_50 = Calendar.getInstance();
                                                                                                                var60_51 = var37_29;
                                                                                                                var61_52 = new SimpleDateFormat(var1_1);
                                                                                                                var62_53 = var6_6;
                                                                                                                try {
                                                                                                                    var57_48.setTime(var61_52.parse(((RecordModel)this.recordlist.get(var53_45)).getDate()));
                                                                                                                    var59_50.setTime(new SimpleDateFormat(var1_1).parse(((DateModel)this.dtliststart.get(var21_17)).getStdate()));
                                                                                                                    break block38;
                                                                                                                }
                                                                                                                catch (ParseException var63_55) {
                                                                                                                    break block39;
                                                                                                                }
                                                                                                                catch (ParseException var63_56) {
                                                                                                                    var62_53 = var6_6;
                                                                                                                }
                                                                                                            }
                                                                                                            var63_54.printStackTrace();
                                                                                                        }
                                                                                                        var65_61 = new SimpleDateFormat(var1_1).parse(((DateModel)this.dtliststart.get(var21_17)).getStdate());
                                                                                                        try {
                                                                                                            var66_62 = new SimpleDateFormat(var1_1).parse(((DateModel)this.dtlistend.get(var21_17)).getStdate());
                                                                                                        }
                                                                                                        catch (ParseException var64_59) {
                                                                                                            break block42;
                                                                                                        }
                                                                                                        try {
                                                                                                            var67_63 = new SimpleDateFormat(var1_1).parse(((RecordModel)this.recordlist.get(var53_45)).getDate());
                                                                                                            break block40;
                                                                                                        }
                                                                                                        catch (ParseException var64_58) {
                                                                                                            break block41;
                                                                                                        }
                                                                                                        catch (ParseException var64_60) {
                                                                                                            var65_61 = null;
                                                                                                        }
                                                                                                    }
                                                                                                    var66_62 = null;
                                                                                                }
                                                                                                var64_57.printStackTrace();
                                                                                                var67_63 = null;
                                                                                            }
                                                                                            var40_32 = var1_1;
                                                                                            var68_64 = Locale.US;
                                                                                            var43_35 = var21_17;
                                                                                            var69_65 = new SimpleDateFormat("EEEE", var68_64).format(var67_63);
                                                                                            if (var65_61.compareTo(var67_63) * var67_63.compareTo(var66_62) < 0 || !var69_65.equals(var7_7.get(var45_37))) break block48;
                                                                                            var75_71 = new TextView((Context)this);
                                                                                            if (!((RecordModel)this.recordlist.get(var53_45)).getSession().equals((Object)"open") || !((RecordModel)this.recordlist.get(var53_45)).getDate().equals((Object)this.datecompare)) break block49;
                                                                                            if (!var50_42 || !var54_46.equals((Object)" ")) break block50;
                                                                                            var144_99 = new StringBuilder();
                                                                                            var144_99.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(0));
                                                                                            var144_99.append("         ");
                                                                                            var144_99.append(var48_40.charAt(0));
                                                                                            var144_99.append("\n");
                                                                                            var144_99.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(1));
                                                                                            var144_99.append("  ");
                                                                                            var144_99.append(((RecordModel)this.recordlist.get(var53_45)).getAnk());
                                                                                            var144_99.append("*  ");
                                                                                            var144_99.append(var48_40.charAt(1));
                                                                                            var144_99.append("\n");
                                                                                            var144_99.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(2));
                                                                                            var144_99.append("         ");
                                                                                            var144_99.append(var48_40.charAt(2));
                                                                                            var144_99.append("\n");
                                                                                            var75_71.setText((CharSequence)var144_99.toString());
                                                                                            var75_71.setTextColor(-1);
                                                                                            var75_71.setGravity(17);
                                                                                            var22_18.addView((View)var75_71);
                                                                                            var159_100 = new TextView((Context)this);
                                                                                            var160_101 = var62_53;
                                                                                            var159_100.setText((CharSequence)var160_101);
                                                                                            var159_100.setTextColor(-1);
                                                                                            var159_100.setGravity(17);
                                                                                            var22_18.addView((View)var159_100);
                                                                                            var41_33 = var7_7;
                                                                                            var42_34 = var160_101;
                                                                                            ** GOTO lbl227
                                                                                        }
                                                                                        var42_34 = var62_53;
                                                                                        if (var50_42 && !var54_46.equals((Object)" ")) {
                                                                                            if (this.redjodilist.contains((Object)var54_46)) {
                                                                                                var75_71.setTextColor(-65536);
                                                                                            } else {
                                                                                                var75_71.setTextColor(-1);
                                                                                            }
                                                                                            var128_97 = new StringBuilder();
                                                                                            var128_97.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(0));
                                                                                            var128_97.append("         ");
                                                                                            var128_97.append(var48_40.charAt(0));
                                                                                            var128_97.append("\n");
                                                                                            var128_97.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(1));
                                                                                            var128_97.append("  ");
                                                                                            var128_97.append(var54_46);
                                                                                            var128_97.append(var42_34);
                                                                                            var128_97.append(var48_40.charAt(1));
                                                                                            var128_97.append("\n");
                                                                                            var128_97.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(2));
                                                                                            var128_97.append("         ");
                                                                                            var128_97.append(var48_40.charAt(2));
                                                                                            var128_97.append("\n");
                                                                                            var75_71.setText((CharSequence)var128_97.toString());
                                                                                            var75_71.setGravity(17);
                                                                                            var22_18.addView((View)var75_71);
                                                                                            var143_98 = new TextView((Context)this);
                                                                                            var143_98.setText((CharSequence)var42_34);
                                                                                            var143_98.setTextColor(-1);
                                                                                            var143_98.setGravity(17);
                                                                                            var22_18.addView((View)var143_98);
                                                                                            var41_33 = var7_7;
lbl227: // 2 sources:
                                                                                            var34_26 = var58_49;
                                                                                            var120_89 = false;
                                                                                            var50_42 = false;
                                                                                        } else {
                                                                                            var109_86 = ((RecordModel)this.recordlist.get(var53_45)).getPana();
                                                                                            var110_87 = new StringBuilder();
                                                                                            var110_87.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(0));
                                                                                            var110_87.append("         *\n");
                                                                                            var113_88 = ((RecordModel)this.recordlist.get(var53_45)).getPana();
                                                                                            var41_33 = var7_7;
                                                                                            var110_87.append(var113_88.charAt(1));
                                                                                            var110_87.append("  ");
                                                                                            var110_87.append(((RecordModel)this.recordlist.get(var53_45)).getAnk());
                                                                                            var110_87.append("*  *\n");
                                                                                            var110_87.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(2));
                                                                                            var110_87.append("         *\n");
                                                                                            var75_71.setText((CharSequence)var110_87.toString());
                                                                                            var75_71.setTextColor(-1);
                                                                                            var75_71.setGravity(17);
                                                                                            var52_44 = var75_71;
                                                                                            var47_39 = var109_86;
                                                                                            var120_89 = true;
                                                                                            var34_26 = true;
                                                                                        }
                                                                                        var121_90 = var51_43 + 1;
                                                                                        var122_91 = 6;
                                                                                        if (var45_37 > var122_91) break block51;
                                                                                        if (var121_90 <= 1) break block52;
                                                                                        var124_93 = var45_37 + 1;
                                                                                        if (++var53_45 != this.recordlist.size()) break block53;
                                                                                        var125_94 = this.recordlist.size();
                                                                                        var126_95 = new TextView((Context)this);
                                                                                        var126_95.setText((CharSequence)"**");
                                                                                        var126_95.setTextColor(-1);
                                                                                        var126_95.setGravity(17);
                                                                                        var22_18.addView((View)var126_95);
                                                                                        var127_96 = new TextView((Context)this);
                                                                                        var127_96.setText((CharSequence)var42_34);
                                                                                        var127_96.setTextColor(-1);
                                                                                        var127_96.setGravity(17);
                                                                                        var22_18.addView((View)var127_96);
                                                                                        var30_22 = var125_94;
                                                                                        var33_25 = var124_93;
                                                                                        var32_24 = var48_40;
                                                                                        break block54;
                                                                                    }
                                                                                    var49_41 = var120_89;
                                                                                    var45_37 = var124_93;
                                                                                    var77_73 = var52_44;
                                                                                    var71_67 = var60_51;
                                                                                    break block55;
                                                                                }
                                                                                var122_91 = 6;
                                                                            }
                                                                            if (var45_37 > var122_91) break block56;
                                                                            ++var53_45;
                                                                            var49_41 = var120_89;
                                                                            var51_43 = var121_90;
                                                                            var77_73 = var52_44;
                                                                            var71_67 = var60_51;
                                                                            break block57;
                                                                        }
                                                                        var123_92 = var53_45 + 1;
                                                                        var32_24 = var48_40;
                                                                        var33_25 = var45_37;
                                                                        var30_22 = var123_92;
                                                                    }
                                                                    var31_23 = var47_39;
                                                                    ** GOTO lbl117
                                                                }
                                                                var41_33 = var7_7;
                                                                var42_34 = var62_53;
                                                                if (!((RecordModel)this.recordlist.get(var53_45)).getSession().equals((Object)"close") || !((RecordModel)this.recordlist.get(var53_45)).getDate().equals((Object)this.datecompare)) ** GOTO lbl400
                                                                if (var49_41) {
                                                                    if (this.redjodilist.contains((Object)((RecordModel)this.recordlist.get(var53_45)).getJodi())) {
                                                                        var75_71.setTextColor(-65536);
                                                                    } else {
                                                                        var75_71.setTextColor(-1);
                                                                    }
                                                                    var93_84 = new StringBuilder();
                                                                    var79_75 = var47_39;
                                                                    var93_84.append(var79_75.charAt(0));
                                                                    var93_84.append("         ");
                                                                    var93_84.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(0));
                                                                    var93_84.append("\n");
                                                                    var93_84.append(var79_75.charAt(1));
                                                                    var93_84.append("  ");
                                                                    var93_84.append(((RecordModel)this.recordlist.get(var53_45)).getJodi());
                                                                    var93_84.append(var42_34);
                                                                    var93_84.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(1));
                                                                    var93_84.append("\n");
                                                                    var93_84.append(var79_75.charAt(2));
                                                                    var93_84.append("         ");
                                                                    var93_84.append(((RecordModel)this.recordlist.get(var53_45)).getPana().charAt(2));
                                                                    var93_84.append("\n");
                                                                    var75_71.setText((CharSequence)var93_84.toString());
                                                                    var75_71.setGravity(17);
                                                                    var22_18.addView((View)var75_71);
                                                                    var108_85 = new TextView((Context)this);
                                                                    var108_85.setText((CharSequence)var42_34);
                                                                    var108_85.setTextColor(-1);
                                                                    var108_85.setGravity(17);
                                                                    var22_18.addView((View)var108_85);
                                                                    var80_76 = var48_40;
                                                                    var34_26 = false;
                                                                    var49_41 = false;
                                                                    var50_42 = false;
                                                                } else {
                                                                    var79_75 = var47_39;
                                                                    var80_76 = ((RecordModel)this.recordlist.get(var53_45)).getPana();
                                                                    var54_46 = ((RecordModel)this.recordlist.get(var53_45)).getJodi();
                                                                    if (this.redjodilist.contains((Object)var54_46)) {
                                                                        var75_71.setTextColor(-65536);
                                                                    } else {
                                                                        var75_71.setTextColor(-1);
                                                                    }
                                                                    var81_77 = new StringBuilder();
                                                                    var81_77.append(var79_75);
                                                                    var81_77.append(" ");
                                                                    var81_77.append(((RecordModel)this.recordlist.get(var53_45)).getJodi());
                                                                    var81_77.append(" ");
                                                                    var81_77.append(((RecordModel)this.recordlist.get(var53_45)).getPana());
                                                                    var75_71.setText((CharSequence)var81_77.toString());
                                                                    var75_71.setGravity(17);
                                                                    var34_26 = var58_49;
                                                                    var50_42 = true;
                                                                }
                                                                var87_78 = var51_43 + 1;
                                                                var88_79 = 6;
                                                                if (var45_37 > var88_79) break block58;
                                                                if (var87_78 <= 1) break block59;
                                                                var33_25 = var45_37 + 1;
                                                                if (++var53_45 != this.recordlist.size()) break block60;
                                                                var90_81 = this.recordlist.size();
                                                                var91_82 = new TextView((Context)this);
                                                                var91_82.setText((CharSequence)var60_51);
                                                                var91_82.setTextColor(-1);
                                                                var91_82.setGravity(17);
                                                                var22_18.addView((View)var91_82);
                                                                var92_83 = new TextView((Context)this);
                                                                var92_83.setText((CharSequence)var42_34);
                                                                var92_83.setTextColor(-1);
                                                                var92_83.setGravity(17);
                                                                var22_18.addView((View)var92_83);
                                                                var32_24 = var80_76;
                                                                var30_22 = var90_81;
                                                                var31_23 = var79_75;
                                                                ** GOTO lbl117
                                                            }
                                                            var71_67 = var60_51;
                                                            var45_37 = var33_25;
                                                            var48_40 = var80_76;
                                                            var47_39 = var79_75;
                                                            var77_73 = var52_44;
                                                        }
                                                        var51_43 = 0;
                                                        break block57;
                                                    }
                                                    var71_67 = var60_51;
                                                    var88_79 = 6;
                                                    break block61;
                                                }
                                                var71_67 = var60_51;
                                            }
                                            if (var45_37 <= var88_79) {
                                                ++var53_45;
                                                var51_43 = var87_78;
                                                var48_40 = var80_76;
                                                var47_39 = var79_75;
                                                var77_73 = var52_44;
                                            } else {
                                                var89_80 = var53_45 + 1;
                                                var32_24 = var80_76;
                                                var31_23 = var79_75;
                                                var33_25 = var45_37;
                                                var30_22 = var89_80;
                                                ** continue;
lbl400: // 1 sources:
                                                var76_72 = var47_39;
                                                var71_67 = var60_51;
                                                var47_39 = var76_72;
                                                var77_73 = var52_44;
                                                var34_26 = var58_49;
                                            }
                                        }
                                        if (var53_45 < this.recordlist.size()) {
                                            this.datecompare = ((RecordModel)this.recordlist.get(var53_45)).getDate();
                                        } else if (var34_26) {
                                            var22_18.addView((View)var77_73);
                                            var78_74 = new TextView((Context)this);
                                            var78_74.setText((CharSequence)var42_34);
                                            var78_74.setTextColor(-1);
                                            var78_74.setGravity(17);
                                            var22_18.addView((View)var78_74);
                                            var34_26 = false;
                                        }
                                        var52_44 = var77_73;
                                        break block62;
                                    }
                                    var41_33 = var7_7;
                                    var70_66 = var47_39;
                                    var71_67 = var60_51;
                                    var42_34 = var62_53;
                                    var72_68 = 6;
                                    if (var45_37 <= var72_68) {
                                        var73_69 = new TextView((Context)this);
                                        var73_69.setText((CharSequence)"*       *\n*  **  *\n*       *\n");
                                        var73_69.setTextColor(-1);
                                        var17_10 = 17;
                                        var73_69.setGravity(var17_10);
                                        var22_18.addView((View)var73_69);
                                        var74_70 = new TextView((Context)this);
                                        var74_70.setText((CharSequence)var42_34);
                                        var74_70.setTextColor(-1);
                                        var74_70.setGravity(var17_10);
                                        var22_18.addView((View)var74_70);
                                        var72_68 = 6;
                                    } else {
                                        var17_10 = 17;
                                    }
                                    if (var45_37 >= var72_68) break block63;
                                    ++var45_37;
                                    var47_39 = var70_66;
                                    var34_26 = var58_49;
                                }
                                var6_6 = var42_34;
                                var37_29 = var71_67;
                                var1_1 = var40_32;
                                var21_17 = var43_35;
                                var7_7 = var41_33;
                                continue;
                            }
                            var32_24 = var48_40;
                            var31_23 = var70_66;
                            var33_25 = var45_37;
                            var30_22 = var53_45;
                            var34_26 = var58_49;
                            break block43;
                        }
                        var40_32 = var1_1;
                        var41_33 = var7_7;
                        var42_34 = var6_6;
                        var43_35 = var21_17;
                        var56_47 = var47_39;
                        var17_10 = 17;
                        var32_24 = var48_40;
                        var31_23 = var56_47;
                        var33_25 = var45_37;
                        var30_22 = var46_38;
                    }
                    var44_36 = 1;
                }
                var33_25 += var44_36;
                var6_6 = var42_34;
                var1_1 = var40_32;
                var21_17 = var43_35;
                var7_7 = var41_33;
                var4_4 = -1;
            } while (true);
            break;
        } while (true);
    }

    public Bitmap getBitmapFromView(View view, int n, int n2) {
        Bitmap bitmap = Bitmap.createBitmap((int)n2, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable drawable2 = view.getBackground();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        } else {
            canvas.drawColor(-16777216);
        }
        view.draw(canvas);
        return bitmap;
    }

    public void layoutToImage() {
        View view = this.findViewById(2131296612);
        HorizontalScrollView horizontalScrollView = (HorizontalScrollView)this.findViewById(2131296612);
        Bitmap bitmap = this.getBitmapFromView(view, horizontalScrollView.getChildAt(0).getHeight(), horizontalScrollView.getChildAt(0).getWidth());
        File file = new File(Environment.getExternalStorageDirectory(), "panelchart.jpg");
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            MediaStore.Images.Media.insertImage((ContentResolver)this.getContentResolver(), (Bitmap)bitmap, (String)"Screen", (String)"screen");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        }
        PrintHelper printHelper = new PrintHelper((Context)this);
        printHelper.setScaleMode(1);
        BitmapFactory.decodeResource((Resources)this.getResources(), (int)2131165425);
        printHelper.printBitmap("droids.jpg - test print", bitmap);
    }

    public void onClick(View view) {
        if (view == this.search) {
            this.dtliststart.clear();
            this.dtlistend.clear();
            this.recordlist.clear();
            this.stk.removeAllViews();
            this.print.setVisibility(0);
            this.makesimplejson();
            this.getalldate();
            this.encryptstring = this.encryptjson(this.inputjson.toString());
            this.ResultApiList();
        }
        if (view == this.print) {
            this.layoutToImage();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493036);
        this.init();
        this.setUpToolbarByName("Panel Chart");
    }

    public void onValueChange(NumberPicker numberPicker, int n, int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(n2);
        Log.e((String)"value is", (String)stringBuilder.toString());
    }

    public String parseDateToddMMyyyy(String string2) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("dd-MMM-yyyy");
        try {
            String string3 = simpleDateFormat2.format(simpleDateFormat.parse(string2));
            return string3;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return null;
        }
    }

    public void show() {
        Dialog dialog = new Dialog((Context)this);
        dialog.setTitle((CharSequence)"NumberPicker");
        dialog.setContentView(2131492937);
        Button button = (Button)dialog.findViewById(2131296387);
        Button button2 = (Button)dialog.findViewById(2131296388);
        NumberPicker numberPicker = (NumberPicker)dialog.findViewById(2131296752);
        numberPicker.setMaxValue(2080);
        numberPicker.setMinValue(2014);
        numberPicker.setWrapSelectorWheel(false);
        numberPicker.setOnValueChangedListener((NumberPicker.OnValueChangeListener)this);
        button.setOnClickListener(new View.OnClickListener(this, numberPicker, dialog){
            final /* synthetic */ PanelChart this$0;
            final /* synthetic */ Dialog val$d;
            final /* synthetic */ NumberPicker val$np;
            {
                this.this$0 = panelChart;
                this.val$np = numberPicker;
                this.val$d = dialog;
            }

            public void onClick(View view) {
                this.this$0.edyear.setText((CharSequence)String.valueOf((int)this.val$np.getValue()));
                this.val$d.dismiss();
            }
        });
        button2.setOnClickListener(new View.OnClickListener(this, dialog){
            final /* synthetic */ PanelChart this$0;
            final /* synthetic */ Dialog val$d;
            {
                this.this$0 = panelChart;
                this.val$d = dialog;
            }

            public void onClick(View view) {
                this.val$d.dismiss();
            }
        });
        dialog.show();
    }

}

