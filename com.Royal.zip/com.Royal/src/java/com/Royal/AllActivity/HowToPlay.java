/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$GetRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import com.Royal.AllActivity.HowToPlay;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class HowToPlay
extends BaseAppCompactActivity {
    TextView txtlink;

    private void getWebServiceData() {
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/admin/youtube").addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

            public void onError(ANError aNError) {
                progressDialog.dismiss();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(aNError.getErrorDetail());
                Log.d((String)"error", (String)stringBuilder.toString());
            }

            public void onResponse(JSONObject jSONObject) {
                progressDialog.dismiss();
                Log.e((String)"Api_response", (String)jSONObject.toString());
                try {
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        HowToPlay.this.txtlink.setText((CharSequence)jSONObject.getString("youtubeLink"));
                        return;
                    }
                    jSONObject.getString("error");
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492894);
        this.setUpToolbarByName("How To Play");
        this.txtlink = (TextView)this.findViewById(2131297014);
        this.getWebServiceData();
        this.txtlink.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ HowToPlay this$0;
            {
                this.this$0 = howToPlay;
            }

            public void onClick(View view) {
                android.content.Intent intent = new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse((String)this.this$0.txtlink.getText().toString()));
                this.this$0.startActivity(intent);
            }
        });
    }

}

