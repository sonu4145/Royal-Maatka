/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.Royal.AllActivity.AppLockActivity;
import com.Royal.AllActivity.ProfileActivity;
import com.Royal.AllActivity.YourAccount;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.DefaultAccount;
import com.Royal.data.UserData;
import com.Royal.data.remote.AccountDataRepository;
import com.Royal.data.remote.AccountDataSource;
import com.Royal.data.remote.UserDataRepository;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class AddNewWallet
extends BaseAppCompactActivity
implements View.OnClickListener {
    ArrayList<String> accounts = new ArrayList();
    String decryptstring;
    ArrayList<DefaultAccount> defaultAccounts = new ArrayList();
    String encryptstring;
    JSONObject inputjson;
    AccountDataRepository mAccountDataRepository;
    Spinner spinner;
    Button submit;
    TextView txtnumber;
    UserDataRepository userDataRepository;
    String walletname;
    EditText walletno;
    EditText walletuser_name;

    private void AddAcount2() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/account/add-new").addBodyParameter("postData", this.encryptstring).setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    AddNewWallet.this.showToast("Something went wrong");
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        String string2 = jSONObject.getString("data");
                        AddNewWallet.this.decryptstring = AddNewWallet.this.decryptjson(string2);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("n");
                        stringBuilder.append(AddNewWallet.this.decryptstring);
                        Log.e((String)"decript", (String)stringBuilder.toString());
                        JSONObject jSONObject2 = new JSONObject(AddNewWallet.this.decryptstring);
                        boolean bl = jSONObject2.getString("status").equals((Object)"true");
                        if (bl) {
                            if (jSONObject2.getString("lock").equals((Object)"true")) {
                                AddNewWallet.this.sendToNextActivity(AppLockActivity.class);
                                AddNewWallet.this.finish();
                                return;
                            }
                            AddNewWallet.this.showToast("Your Account Added Sucessfully");
                            AddNewWallet.this.sendToNextActivity(YourAccount.class);
                            AddNewWallet.this.finish();
                            return;
                        }
                        if (jSONObject2.getString("lock").equals((Object)"true")) {
                            AddNewWallet.this.sendToNextActivity(AppLockActivity.class);
                            AddNewWallet.this.finish();
                        }
                        String string3 = jSONObject2.getString("error");
                        AddNewWallet.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void init() {
        Button button;
        this.spinner = (Spinner)this.findViewById(2131296305);
        this.walletuser_name = (EditText)this.findViewById(2131296546);
        this.txtnumber = (TextView)this.findViewById(2131297015);
        this.walletno = (EditText)this.findViewById(2131296545);
        this.submit = button = (Button)this.findViewById(2131296893);
        button.setOnClickListener((View.OnClickListener)this);
        if (this.walletname.equals((Object)"Paytm")) {
            this.txtnumber.setText((CharSequence)"PayTm number");
            this.walletno.setHint((CharSequence)"PayTm number");
        } else if (this.walletname.equals((Object)"PhonePe")) {
            this.txtnumber.setText((CharSequence)"PhonePe number");
            this.walletno.setHint((CharSequence)"PhonePe number");
        } else {
            this.txtnumber.setText((CharSequence)"Google Pay number");
            this.walletno.setHint((CharSequence)"Google Pay number");
        }
        SharedPreferences sharedPreferences = this.getSharedPreferences("WALLET", 0);
        if (sharedPreferences != null) {
            if (this.walletname.equals((Object)"Paytm")) {
                this.walletno.setText((CharSequence)sharedPreferences.getString("pnumber", ""));
            } else if (this.walletname.equals((Object)"PhonePe")) {
                this.walletno.setText((CharSequence)sharedPreferences.getString("phnumber", ""));
            } else {
                this.walletno.setText((CharSequence)sharedPreferences.getString("gnumber", ""));
            }
        }
        this.getDefaultAccounts();
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("type", (Object)"wallet");
            this.inputjson.put("accountName", (Object)this.walletname);
            this.inputjson.put("accountNumber", (Object)this.walletno.getText().toString());
            this.inputjson.put("accountHolderName", (Object)this.userDataRepository.getUserData().getDisplayName());
            this.inputjson.put("branchName", (Object)"");
            this.inputjson.put("ifscCode", (Object)"");
            this.inputjson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void AddAcount() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mAccountDataRepository.addAccount("wallet", this.walletname, this.walletno.getText().toString(), this.walletuser_name.getText().toString(), "", "", new AccountDataSource.GetAddAccountCallBack(){

            @Override
            public void onAccountAdded(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.showToast(string2);
                SharedPreferences.Editor editor = AddNewWallet.this.getSharedPreferences("WALLET", 0).edit();
                if (AddNewWallet.this.walletname.equals((Object)"Paytm")) {
                    editor.putString("pnumber", AddNewWallet.this.walletno.getText().toString());
                } else if (AddNewWallet.this.walletname.equals((Object)"PhonePe")) {
                    editor.putString("phnumber", AddNewWallet.this.walletno.getText().toString());
                } else {
                    editor.putString("gnumber", AddNewWallet.this.walletno.getText().toString());
                }
                editor.apply();
                AddNewWallet.this.sendToNextActivity(ProfileActivity.class);
                AddNewWallet.this.finish();
            }

            @Override
            public void onErrorInAccountName(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.showToast(string2);
            }

            @Override
            public void onErrorInAccountNumber(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.walletno.setError((CharSequence)string2);
            }

            @Override
            public void onErrorInBranchName(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.showToast(string2);
            }

            @Override
            public void onErrorInHolderName(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.walletuser_name.setError((CharSequence)string2);
            }

            @Override
            public void onErrorInIfsc(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.showToast(string2);
            }

            @Override
            public void onErrorInLoading(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)AddNewWallet.this);
            }
        });
    }

    public void getDefaultAccounts() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mAccountDataRepository.getDefaultAccount(new AccountDataSource.GetDefaultAccountCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.showToast(string2);
            }

            @Override
            public void onLoaded(ArrayList<DefaultAccount> arrayList, ArrayList<DefaultAccount> arrayList2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.defaultAccounts = arrayList2;
                for (DefaultAccount defaultAccount : AddNewWallet.this.defaultAccounts) {
                    AddNewWallet.this.accounts.add((Object)defaultAccount.getName());
                }
                AddNewWallet addNewWallet = AddNewWallet.this;
                ArrayAdapter arrayAdapter = new ArrayAdapter((Context)addNewWallet, 2131492952, addNewWallet.accounts);
                arrayAdapter.setDropDownViewResource(2131492951);
                AddNewWallet.this.spinner.setAdapter((SpinnerAdapter)arrayAdapter);
            }

            @Override
            public void onLocked(String string2) {
                AddNewWallet.this.showProgress(false);
                AddNewWallet.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)AddNewWallet.this);
            }
        });
    }

    public void onClick(View view) {
        if (this.walletno.getText().toString().trim().length() < 6) {
            this.walletno.setError((CharSequence)"Please enter wallet no");
            this.walletno.requestFocus();
            return;
        }
        this.makesimplejson();
        this.encryptstring = this.encryptjson(this.inputjson.toString());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.inputjson.toString());
        Log.e((String)"data", (String)stringBuilder.toString());
        this.AddAcount();
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492900);
        this.mAccountDataRepository = AccountDataRepository.getInstance((Context)this);
        this.userDataRepository = UserDataRepository.getInstance((Context)this);
        this.setUpToolbarByName("Add New Wallet");
        Intent intent = this.getIntent();
        if (intent != null) {
            this.walletname = intent.getStringExtra("walletname");
        }
        this.init();
    }

}

