/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RadioButton
 *  android.widget.RadioGroup
 *  android.widget.RadioGroup$OnCheckedChangeListener
 *  android.widget.Spinner
 *  android.widget.TextView
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 */
package com.Royal.AllActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.BidingAdapter;
import com.Royal.AllActivity.SPMotor;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utils.GameUtils;
import com.Royal.Utils.StringUtils;
import com.Royal.data.BazaarData;
import com.Royal.data.BazaarTimeData;
import com.Royal.data.BiddingData;
import com.Royal.data.GamesName;
import com.Royal.data.remote.UserDataRepository;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SPMotor
extends BaseAppCompactActivity {
    ArrayList<String> digitsList;
    EditText eddigit;
    EditText edpoints;
    TextView entereddigit;
    TextView subsetdigit;

    private void init() {
        this.imageBack = (ImageView)this.findViewById(2131296624);
        this.textMainTitle = (TextView)this.findViewById(2131296955);
        this.textTitle = (TextView)this.findViewById(2131296956);
        this.txtpoints = (TextView)this.findViewById(2131297019);
        this.imageBack.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SPMotor this$0;
            {
                this.this$0 = sPMotor;
            }

            public void onClick(View view) {
                this.this$0.onBackPressed();
            }
        });
        this.eddigit = (EditText)this.findViewById(2131296529);
        this.edpoints = (EditText)this.findViewById(2131296541);
        this.add = (Button)this.findViewById(2131296334);
        this.entereddigit = (TextView)this.findViewById(2131296554);
        this.subsetdigit = (TextView)this.findViewById(2131296895);
        this.dayspiner = (Spinner)this.findViewById(2131296845);
        this.hour = (TextView)this.findViewById(2131296610);
        this.minute = (TextView)this.findViewById(2131296688);
        this.second = (TextView)this.findViewById(2131296840);
        this.day = (TextView)this.findViewById(2131296473);
        this.totalbid = (TextView)this.findViewById(2131296985);
        this.totalpoint = (TextView)this.findViewById(2131296986);
        this.radioGroup = (RadioGroup)this.findViewById(2131296797);
        this.open = (RadioButton)this.findViewById(2131296757);
        this.close = (RadioButton)this.findViewById(2131296440);
        this.tvpoints = (TextView)this.findViewById(2131296785);
        this.layout_bid_container = (LinearLayout)this.findViewById(2131296647);
        this.goodluck = (Button)this.findViewById(2131296590);
        this.recyclerView = (RecyclerView)this.findViewById(2131296375);
        this.layout_bid_container.setVisibility(8);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getApplicationContext());
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.adapter = new BidingAdapter((Context)this, (List<BiddingData>)BiddingData.getBiddingData());
        this.recyclerView.setAdapter((RecyclerView.Adapter)this.adapter);
        this.digitsList = new ArrayList();
        this.dayspiner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(this){
            final /* synthetic */ SPMotor this$0;
            {
                this.this$0 = sPMotor;
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                if (n < this.this$0.daylist.size()) {
                    java.util.Calendar calendar = (java.util.Calendar)this.this$0.daylist.get(n);
                    this.this$0.loadDate(true, calendar);
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(this){
            final /* synthetic */ SPMotor this$0;
            {
                this.this$0 = sPMotor;
            }

            public void onCheckedChanged(RadioGroup radioGroup, int n) {
                if (this.this$0.selectDate != null) {
                    ((RadioButton)this.this$0.findViewById(n)).getText().toString();
                    if (this.this$0.dayspiner.getSelectedItemPosition() < this.this$0.daylist.size()) {
                        java.util.Calendar calendar = (java.util.Calendar)this.this$0.daylist.get(this.this$0.dayspiner.getSelectedItemPosition());
                        this.this$0.loadDate(true, calendar);
                    }
                }
            }
        });
        this.adapter.setBiddingDataListener(new BidingAdapter.BiddingDataListener(){

            @Override
            public void onDataChanged() {
                if (SPMotor.this.adapter.getAptList().size() > 0) {
                    SPMotor.this.layout_bid_container.setVisibility(0);
                } else {
                    SPMotor.this.layout_bid_container.setVisibility(8);
                }
                SPMotor.this.setBidTotal();
            }
        });
        this.eddigit.addTextChangedListener(new TextWatcher(this){
            final /* synthetic */ SPMotor this$0;
            {
                this.this$0 = sPMotor;
            }

            public void afterTextChanged(Editable editable) {
                this.this$0.setDigits(editable.toString());
            }

            public void beforeTextChanged(CharSequence charSequence, int n, int n2, int n3) {
            }

            public void onTextChanged(CharSequence charSequence, int n, int n2, int n3) {
            }
        });
        this.add.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SPMotor this$0;
            {
                this.this$0 = sPMotor;
            }

            public void onClick(View view) {
                if (this.this$0.eddigit.getText().toString().trim().length() < 4 && this.this$0.eddigit.getText().toString().trim().length() > 9) {
                    this.this$0.eddigit.setError((CharSequence)"Minimum 4 and maximum 9 digits required");
                    this.this$0.eddigit.requestFocus();
                    return;
                }
                if (this.this$0.edpoints.getText().toString().trim().length() == 0) {
                    this.this$0.edpoints.setError((CharSequence)"Minimum 10 points required");
                    this.this$0.edpoints.requestFocus();
                    return;
                }
                if (java.lang.Integer.parseInt((String)this.this$0.edpoints.getText().toString()) < 10) {
                    this.this$0.edpoints.setError((CharSequence)"Minimum 10 points required");
                    this.this$0.edpoints.requestFocus();
                    return;
                }
                if (java.lang.Integer.parseInt((String)this.this$0.edpoints.getText().toString()) % 5 != 0) {
                    this.this$0.edpoints.setError((CharSequence)"Point should be multiple of 5 ex. 5,10,20");
                    this.this$0.edpoints.requestFocus();
                    return;
                }
                if ((long)(BiddingData.getTotalPoints() + java.lang.Integer.parseInt((String)this.this$0.edpoints.getText().toString())) > BaseAppCompactActivity.myPoints) {
                    this.this$0.showToast("you don't have sufficent point for this bid");
                    return;
                }
                if (this.this$0.digitsList.size() < 1) {
                    this.this$0.eddigit.setError((CharSequence)"please enter valid digit");
                    this.this$0.eddigit.requestFocus();
                    this.this$0.subsetdigit.setText((CharSequence)"");
                    return;
                }
                int n = this.this$0.radioGroup.getCheckedRadioButtonId();
                String string2 = ((RadioButton)this.this$0.findViewById(n)).getText().toString();
                ArrayList arrayList = new ArrayList();
                for (int i = 0; i < this.this$0.digitsList.size(); ++i) {
                    BiddingData biddingData = new BiddingData();
                    biddingData.setGame(this.this$0.gamesName);
                    biddingData.setPoints(java.lang.Integer.parseInt((String)this.this$0.edpoints.getText().toString()));
                    biddingData.setDigit((String)this.this$0.digitsList.get(i));
                    biddingData.setSession(string2);
                    biddingData.setCalDateTime(this.this$0.selectDate);
                    arrayList.add((Object)biddingData);
                }
                BiddingData.addBiddingData((ArrayList<BiddingData>)arrayList, new com.Royal.data.BiddingData$GetBiddingDataCallBack(this){
                    final /* synthetic */ 6 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void onAdded(String string2) {
                        this.this$1.this$0.edpoints.setText((CharSequence)"");
                        this.this$1.this$0.eddigit.setText((CharSequence)"");
                        this.this$1.this$0.adapter.notifyDataSetChanged();
                        this.this$1.this$0.setBidTotal();
                        if (this.this$1.this$0.adapter.getAptList().size() > 0) {
                            this.this$1.this$0.layout_bid_container.setVisibility(0);
                            return;
                        }
                        this.this$1.this$0.layout_bid_container.setVisibility(8);
                    }

                    public void onError(String string2) {
                        this.this$1.this$0.showToast(string2);
                    }
                });
            }
        });
        this.goodluck.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SPMotor this$0;
            {
                this.this$0 = sPMotor;
            }

            public void onClick(View view) {
                this.this$0.AddBidding();
            }
        });
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493045);
        this.gamesName = GamesName.SP_MOTOR;
        this.init();
        this.loadPoints();
        UserDataRepository.getInstance((Context)this);
        this.txtpoints.setText((CharSequence)String.valueOf((long)myPoints));
        Intent intent = this.getIntent();
        if (intent.hasExtra("data") && intent.hasExtra("timeData")) {
            this.data = (BazaarData)intent.getSerializableExtra("data");
            this.timeData = (BazaarTimeData)intent.getSerializableExtra("timeData");
            this.textMainTitle.setText((CharSequence)StringUtils.toCamelCase(this.data.getName()));
            this.textTitle.setText((CharSequence)"SP Motor Board");
        }
    }

    void setDigits(String string2) {
        if (string2.trim().length() > 0) {
            TextView textView = this.entereddigit;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Entered Digit: ");
            stringBuilder.append(string2);
            textView.setText((CharSequence)stringBuilder.toString());
            this.entereddigit.setVisibility(0);
        } else {
            this.entereddigit.setText((CharSequence)"");
            this.entereddigit.setVisibility(8);
        }
        if (string2.length() > 1) {
            String string3 = string2.substring(string2.length() - 1);
            if (string2.substring(0, string2.length() - 1).contains((CharSequence)string3)) {
                String string4 = string2.substring(0, string2.length() - 1);
                this.eddigit.setText((CharSequence)string4);
                EditText editText = this.eddigit;
                editText.setSelection(editText.getText().length());
                return;
            }
        }
        if (string2.trim().length() > 3 && string2.trim().length() < 10) {
            if (string2.trim().length() == 9) {
                ((InputMethodManager)this.getApplicationContext().getSystemService("input_method")).hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(), 0);
            }
            ArrayList<String> arrayList = GameUtils.getSPMotorDigits(string2);
            this.digitsList = arrayList;
            if (arrayList.size() > 0) {
                this.eddigit.setError(null);
                TextView textView = this.subsetdigit;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("SP Motor Digits : ");
                stringBuilder.append(Arrays.toString((Object[])this.digitsList.toArray()));
                textView.setText((CharSequence)stringBuilder.toString());
                return;
            }
            this.eddigit.setError((CharSequence)"please enter valid digit");
            this.eddigit.requestFocus();
            this.subsetdigit.setText((CharSequence)"");
        }
    }

}

