/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.os.CountDownTimer
 *  android.os.IBinder
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.util.Log
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.CheckBox
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RadioButton
 *  android.widget.RadioGroup
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.widget.Toolbar
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.GregorianCalendar
 *  java.util.List
 *  java.util.Locale
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.BidingAdapter;
import com.Royal.AllActivity.StartPanaRule;
import com.Royal.Model.BidingModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.data.BiddingData;
import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class StartPanaRule
extends BaseAppCompactActivity
implements View.OnClickListener,
CompoundButton.OnCheckedChangeListener,
AdapterView.OnItemSelectedListener {
    public static TextView totalbid;
    public static TextView totalpoint;
    public static TextView tvpoints;
    BidingAdapter adapter;
    Button add;
    String bazarid;
    String bazarsideid;
    List<BidingModel> bidinglist;
    JSONObject bidjson;
    RadioButton close;
    private CountDownTimer countDownTimer;
    TextView day;
    List<String> daylist;
    Spinner dayspiner;
    String decryptstring;
    CheckBox dp;
    EditText eddigit;
    EditText edpoints;
    long elapsedHours;
    long elapsedMinutes;
    long elapsedSeconds;
    String encryptstring;
    CheckBox end;
    String enteredDigit;
    String fridayCloseTime;
    String fridayOpenTime;
    Button goodluck;
    TextView hour;
    ImageView imageBack;
    String isFriday;
    String isMonday;
    boolean isRunning = false;
    String isSaturday;
    String isSunday;
    String isThursday;
    String isTuesday;
    String isWednesday;
    boolean isclosetimepass = false;
    boolean isopentimepass = false;
    boolean issanmevalue = false;
    JSONArray jsonArray;
    LinearLayout layout_bid_container;
    CheckBox middle;
    TextView minute;
    String mondayCloseTime;
    String mondayOpenTime;
    long myPoints = 0L;
    String my_var;
    RadioButton open;
    List<String> output;
    TextView panadigit;
    RadioGroup radioGroup;
    RecyclerView recyclerView;
    String saturdayCloseTime;
    String saturdayOpenTime;
    TextView second;
    CheckBox sp;
    String sss;
    CheckBox start;
    String sttodaydate;
    String sundayCloseTime;
    String sundayOpenTime;
    TextView textMainTitle;
    TextView textTitle;
    String thursdayCloseTime;
    String thursdayOpenTime;
    String title;
    String todayday;
    CheckBox tp;
    String tuesdayCloseTime;
    String tuesdayOpenTime;
    String wednesdayCloseTime;
    String wednesdayOpenTime;

    private long calculatetimediif(String string2) {
        String string3 = new SimpleDateFormat("yyy-MM-dd", Locale.getDefault()).format(new Date());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String string4 = simpleDateFormat.format(date);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(string4);
        Log.e((String)"currenttime", (String)stringBuilder.toString());
        try {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string3);
            stringBuilder2.append(" ");
            stringBuilder2.append(string2);
            Date date2 = simpleDateFormat.parse(stringBuilder2.toString());
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("n");
            stringBuilder3.append((Object)date2);
            Log.e((String)"date2", (String)stringBuilder3.toString());
            long l = date2.getTime() - date.getTime();
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append("n");
            stringBuilder4.append(l);
            Log.e((String)"timediff", (String)stringBuilder4.toString());
            return l;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return 0L;
        }
    }

    private void checktime() {
        String string2 = new SimpleDateFormat("EEEE dd-MMM-yyyy").format(new Date());
        String string3 = this.changedateformate(string2);
        if (string2.contains((CharSequence)"Monday")) {
            String string4 = this.subtracttime(string3, this.mondayOpenTime);
            String string5 = this.subtracttime(string3, this.mondayCloseTime);
            long l = this.calculatetimediif(string4);
            if (String.valueOf((long)this.calculatetimediif(string5)).contains((CharSequence)"-")) {
                this.isclosetimepass = true;
            }
            if (String.valueOf((long)l).contains((CharSequence)"-")) {
                this.isopentimepass = true;
                this.open.setEnabled(false);
                this.close.setChecked(true);
            }
        }
        if (string2.contains((CharSequence)"Tuesday")) {
            String string6 = this.subtracttime(string3, this.tuesdayOpenTime);
            long l = this.calculatetimediif(this.subtracttime(string3, this.tuesdayCloseTime));
            long l2 = this.calculatetimediif(string6);
            if (String.valueOf((long)l).contains((CharSequence)"-")) {
                this.isclosetimepass = true;
            }
            if (String.valueOf((long)l2).contains((CharSequence)"-")) {
                this.isopentimepass = true;
                this.open.setEnabled(false);
                this.close.setChecked(true);
            }
        }
        if (string2.contains((CharSequence)"Wednesday")) {
            String string7 = this.subtracttime(string3, this.wednesdayOpenTime);
            long l = this.calculatetimediif(this.subtracttime(string3, this.wednesdayCloseTime));
            long l3 = this.calculatetimediif(string7);
            if (String.valueOf((long)l).contains((CharSequence)"-")) {
                this.isclosetimepass = true;
            }
            if (String.valueOf((long)l3).contains((CharSequence)"-")) {
                this.isopentimepass = true;
                this.open.setEnabled(false);
                this.close.setChecked(true);
            }
        }
        if (string2.contains((CharSequence)"Thursday")) {
            String string8 = this.subtracttime(string3, this.thursdayOpenTime);
            long l = this.calculatetimediif(this.subtracttime(string3, this.thursdayCloseTime));
            long l4 = this.calculatetimediif(string8);
            if (String.valueOf((long)l).contains((CharSequence)"-")) {
                this.isclosetimepass = true;
            }
            if (String.valueOf((long)l4).contains((CharSequence)"-")) {
                this.isopentimepass = true;
                this.open.setEnabled(false);
                this.close.setChecked(true);
            }
        }
        if (string2.contains((CharSequence)"Friday")) {
            String string9 = this.subtracttime(string3, this.fridayOpenTime);
            long l = this.calculatetimediif(this.subtracttime(string3, this.fridayCloseTime));
            long l5 = this.calculatetimediif(string9);
            if (String.valueOf((long)l).contains((CharSequence)"-")) {
                this.isclosetimepass = true;
            }
            if (String.valueOf((long)l5).contains((CharSequence)"-")) {
                this.isopentimepass = true;
                this.open.setEnabled(false);
                this.close.setChecked(true);
            }
        }
        if (string2.contains((CharSequence)"Saturday")) {
            String string10 = this.subtracttime(string3, this.saturdayOpenTime);
            String string11 = this.subtracttime(string3, this.saturdayCloseTime);
            long l = this.calculatetimediif(string11);
            long l6 = this.calculatetimediif(string10);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(string10);
            stringBuilder.append("//");
            stringBuilder.append(l6);
            stringBuilder.append("\n");
            stringBuilder.append(string11);
            stringBuilder.append("//");
            stringBuilder.append(l);
            Log.e((String)"minustime", (String)stringBuilder.toString());
            if (String.valueOf((long)l).contains((CharSequence)"-")) {
                this.isclosetimepass = true;
            }
            if (String.valueOf((long)l6).contains((CharSequence)"-")) {
                this.isopentimepass = true;
                this.open.setEnabled(false);
                this.close.setChecked(true);
            }
        }
        if (string2.contains((CharSequence)"Sunday")) {
            String string12 = this.subtracttime(string3, this.sundayOpenTime);
            long l = this.calculatetimediif(this.subtracttime(string3, this.sundayCloseTime));
            long l7 = this.calculatetimediif(string12);
            if (String.valueOf((long)l).contains((CharSequence)"-")) {
                this.isclosetimepass = true;
            }
            if (String.valueOf((long)l7).contains((CharSequence)"-")) {
                this.isopentimepass = true;
                this.open.setEnabled(false);
                this.close.setChecked(true);
            }
        }
        this.getnextdays();
    }

    private void getnextdays() {
        new SimpleDateFormat("EEEE dd-MMM-yyyy").format(new Date());
        this.calculate();
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, this.daylist);
        arrayAdapter.setDropDownViewResource(17367049);
        this.dayspiner.setAdapter((SpinnerAdapter)arrayAdapter);
        this.dayspiner.setSelection(0);
    }

    private void getvaluefromintent() {
        Intent intent = this.getIntent();
        this.mondayOpenTime = intent.getStringExtra("mondayopentime");
        this.mondayCloseTime = intent.getStringExtra("mondayclosetime");
        this.tuesdayOpenTime = intent.getStringExtra("tuesdayopentime");
        this.tuesdayCloseTime = intent.getStringExtra("tuesdayclosetime");
        this.wednesdayOpenTime = intent.getStringExtra("wednesdayopentime");
        this.wednesdayCloseTime = intent.getStringExtra("wednesdayclosetime");
        this.thursdayOpenTime = intent.getStringExtra("thursdayopentime");
        this.thursdayCloseTime = intent.getStringExtra("thursdayclosetime");
        this.fridayOpenTime = intent.getStringExtra("fridayopentime");
        this.fridayCloseTime = intent.getStringExtra("fridayclosetime");
        this.saturdayOpenTime = intent.getStringExtra("saturdayopentime");
        this.saturdayCloseTime = intent.getStringExtra("saturdayclosetime");
        this.sundayOpenTime = intent.getStringExtra("sundayopentime");
        this.sundayCloseTime = intent.getStringExtra("sundayclosetime");
        this.isMonday = intent.getStringExtra("ismonday");
        this.isTuesday = intent.getStringExtra("istuesday");
        this.isWednesday = intent.getStringExtra("iswednesday");
        this.isThursday = intent.getStringExtra("isthursday");
        this.isFriday = intent.getStringExtra("isfriday");
        this.isSaturday = intent.getStringExtra("issaturday");
        this.isSunday = intent.getStringExtra("issunday");
        this.dayspiner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)this);
        this.bazarid = intent.getStringExtra("bazarid");
        this.bazarsideid = intent.getStringExtra("bazarsideid");
        this.dayspiner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener)this);
    }

    private void init() {
        this.eddigit = (EditText)this.findViewById(2131296529);
        this.edpoints = (EditText)this.findViewById(2131296541);
        this.panadigit = (TextView)this.findViewById(2131296895);
        this.add = (Button)this.findViewById(2131296334);
        this.sp = (CheckBox)this.findViewById(2131296867);
        this.dp = (CheckBox)this.findViewById(2131296500);
        this.tp = (CheckBox)this.findViewById(2131296988);
        this.start = (CheckBox)this.findViewById(2131296883);
        this.middle = (CheckBox)this.findViewById(2131296686);
        this.end = (CheckBox)this.findViewById(2131296549);
        this.dayspiner = (Spinner)this.findViewById(2131296845);
        this.hour = (TextView)this.findViewById(2131296610);
        this.minute = (TextView)this.findViewById(2131296688);
        this.second = (TextView)this.findViewById(2131296840);
        this.day = (TextView)this.findViewById(2131296473);
        totalbid = (TextView)this.findViewById(2131296985);
        totalpoint = (TextView)this.findViewById(2131296986);
        this.radioGroup = (RadioGroup)this.findViewById(2131296797);
        this.open = (RadioButton)this.findViewById(2131296757);
        this.close = (RadioButton)this.findViewById(2131296440);
        tvpoints = (TextView)this.findViewById(2131296785);
        this.layout_bid_container = (LinearLayout)this.findViewById(2131296647);
        TextView textView = tvpoints;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Your Points ");
        stringBuilder.append(CommonParams.totalpoint);
        textView.setText((CharSequence)stringBuilder.toString());
        this.goodluck = (Button)this.findViewById(2131296590);
        this.recyclerView = (RecyclerView)this.findViewById(2131296375);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getApplicationContext());
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.bidinglist = new ArrayList();
        this.adapter = new BidingAdapter((Context)this, (List<BiddingData>)BiddingData.getBiddingData());
        this.layout_bid_container.setVisibility(8);
        this.adapter.setBiddingDataListener(new BidingAdapter.BiddingDataListener(){

            @Override
            public void onDataChanged() {
                if (StartPanaRule.this.adapter.getAptList().size() > 0) {
                    StartPanaRule.this.layout_bid_container.setVisibility(0);
                } else {
                    StartPanaRule.this.layout_bid_container.setVisibility(8);
                }
                StartPanaRule.this.setBidTotal();
            }
        });
        this.recyclerView.setAdapter((RecyclerView.Adapter)this.adapter);
        this.sp.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)this);
        this.dp.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)this);
        this.tp.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)this);
        this.start.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)this);
        this.middle.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)this);
        this.end.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)this);
        this.eddigit.addTextChangedListener(new TextWatcher(this){
            final /* synthetic */ StartPanaRule this$0;
            {
                this.this$0 = startPanaRule;
            }

            public void afterTextChanged(Editable editable) {
                if (editable.toString().length() > 0) {
                    this.this$0.setDigits(editable.toString());
                }
            }

            public void beforeTextChanged(CharSequence charSequence, int n, int n2, int n3) {
            }

            public void onTextChanged(CharSequence charSequence, int n, int n2, int n3) {
            }
        });
        this.add.setOnClickListener((View.OnClickListener)this);
        this.goodluck.setOnClickListener((View.OnClickListener)this);
    }

    private void makebidarray() {
        this.jsonArray = new JSONArray();
        for (int i = 0; i < this.bidinglist.size(); ++i) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("date", (Object)((BidingModel)this.bidinglist.get(i)).getDate());
                jSONObject.put("session", (Object)((BidingModel)this.bidinglist.get(i)).getType());
                jSONObject.put("digit", (Object)((BidingModel)this.bidinglist.get(i)).getDigit());
                jSONObject.put("point", (Object)((BidingModel)this.bidinglist.get(i)).getPonts());
                jSONObject.put("bazaarSideId", (Object)this.bazarsideid);
                jSONObject.put("bazaarId", (Object)this.bazarid);
                jSONObject.put("bazaar", (Object)this.title);
                jSONObject.put("game", (Object)"start pana");
                jSONObject.put("userId", (Object)CommonParams.userId);
                this.jsonArray.put((Object)jSONObject);
                continue;
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
            }
        }
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.makebidarray();
        this.bidjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("bazaarSide", (Object)"Bombay Side Games");
            this.bidjson.put("bazaarSideId", (Object)this.bazarsideid);
            this.bidjson.put("bidPoint", BiddingData.getTotalPoints());
            this.bidjson.put("numberOfBid", (Object)String.valueOf((int)this.bidinglist.size()));
            this.bidjson.put("userId", (Object)CommonParams.userId);
            this.bidjson.put("biddings", (Object)this.jsonArray.toString());
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void selectiondata(String string2) {
        if (string2.equals((Object)"Today")) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("s");
            stringBuilder.append(string2.toString());
            Log.e((String)"selected", (String)stringBuilder.toString());
            String string3 = new SimpleDateFormat("EEEE dd-MMM-yyyy").format(new Date());
            if (string3.contains((CharSequence)"Monday")) {
                String string4;
                if (this.isRunning) {
                    this.countDownTimer.cancel();
                }
                this.sttodaydate = string4 = this.changedateformate(string3);
                String string5 = this.subtracttime(string4, this.mondayOpenTime);
                String string6 = this.subtracttime(string4, this.mondayCloseTime);
                if (!this.isopentimepass) {
                    this.starttimer(string4, string5);
                }
                if (this.isopentimepass) {
                    this.starttimer(string4, string6);
                }
            }
            if (string3.contains((CharSequence)"Tuesday")) {
                String string7;
                if (this.isRunning) {
                    this.countDownTimer.cancel();
                }
                this.sttodaydate = string7 = this.changedateformate(string3);
                String string8 = this.subtracttime(string7, this.tuesdayOpenTime);
                String string9 = this.subtracttime(string7, this.tuesdayCloseTime);
                if (!this.isopentimepass) {
                    this.starttimer(string7, string8);
                }
                if (this.isopentimepass) {
                    this.starttimer(string7, string9);
                }
            }
            if (string3.contains((CharSequence)"Wednesday")) {
                String string10;
                if (this.isRunning) {
                    this.countDownTimer.cancel();
                }
                this.sttodaydate = string10 = this.changedateformate(string3);
                String string11 = this.subtracttime(string10, this.wednesdayOpenTime);
                String string12 = this.subtracttime(string10, this.wednesdayCloseTime);
                if (!this.isopentimepass) {
                    this.starttimer(string10, string11);
                }
                if (this.isopentimepass) {
                    this.starttimer(string10, string12);
                }
            }
            if (string3.contains((CharSequence)"Thursday")) {
                String string13;
                if (this.isRunning) {
                    this.countDownTimer.cancel();
                }
                this.sttodaydate = string13 = this.changedateformate(string3);
                String string14 = this.subtracttime(string13, this.thursdayOpenTime);
                String string15 = this.subtracttime(string13, this.thursdayCloseTime);
                if (!this.isopentimepass) {
                    this.starttimer(string13, string14);
                }
                if (this.isopentimepass) {
                    this.starttimer(string13, string15);
                }
            }
            if (string3.contains((CharSequence)"Friday")) {
                String string16;
                if (this.isRunning) {
                    this.countDownTimer.cancel();
                }
                this.sttodaydate = string16 = this.changedateformate(string3);
                String string17 = this.subtracttime(string16, this.fridayOpenTime);
                String string18 = this.subtracttime(string16, this.fridayCloseTime);
                if (!this.isopentimepass) {
                    this.starttimer(string16, string17);
                }
                if (this.isopentimepass) {
                    this.starttimer(string16, string18);
                }
            }
            if (string3.contains((CharSequence)"Saturday")) {
                String string19;
                if (this.isRunning) {
                    this.countDownTimer.cancel();
                }
                this.sttodaydate = string19 = this.changedateformate(string3);
                String string20 = this.subtracttime(string19, this.saturdayOpenTime);
                String string21 = this.subtracttime(string19, this.saturdayCloseTime);
                if (!this.isopentimepass) {
                    this.starttimer(string19, string20);
                }
                if (this.isopentimepass) {
                    this.starttimer(string19, string21);
                }
            }
            if (string3.contains((CharSequence)"Sunday")) {
                String string22;
                if (this.isRunning) {
                    this.countDownTimer.cancel();
                }
                this.sttodaydate = string22 = this.changedateformate(string3);
                String string23 = this.subtracttime(string22, this.sundayOpenTime);
                String string24 = this.subtracttime(string22, this.sundayCloseTime);
                if (!this.isopentimepass) {
                    this.starttimer(string22, string23);
                }
                if (this.isopentimepass) {
                    this.starttimer(string22, string24);
                    return;
                }
            }
        } else {
            if (string2.contains((CharSequence)"Monday")) {
                String string25;
                this.sttodaydate = string25 = this.changedateformate(string2);
                String string26 = this.subtracttime(string25, this.mondayOpenTime);
                if (!this.isRunning) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string25);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string25, string26);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                } else {
                    this.countDownTimer.cancel();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string25);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string25, string26);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                }
            }
            if (string2.contains((CharSequence)"Tuesday")) {
                String string27;
                this.sttodaydate = string27 = this.changedateformate(string2);
                String string28 = this.subtracttime(string27, this.tuesdayOpenTime);
                if (!this.isRunning) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string27);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string27, string28);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                } else {
                    this.countDownTimer.cancel();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string27);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string27, string28);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                }
            }
            if (string2.contains((CharSequence)"Wednesday")) {
                String string29;
                this.sttodaydate = string29 = this.changedateformate(string2);
                String string30 = this.subtracttime(string29, this.wednesdayOpenTime);
                if (!this.isRunning) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string29);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string29, string30);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                } else {
                    this.countDownTimer.cancel();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string29);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string29, string30);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                }
            }
            if (string2.contains((CharSequence)"Thursday")) {
                String string31;
                this.sttodaydate = string31 = this.changedateformate(string2);
                String string32 = this.subtracttime(string31, this.thursdayOpenTime);
                if (!this.isRunning) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string31);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string31, string32);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                } else {
                    this.countDownTimer.cancel();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string31);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string31, string32);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                }
            }
            if (string2.contains((CharSequence)"Friday")) {
                String string33;
                this.sttodaydate = string33 = this.changedateformate(string2);
                String string34 = this.subtracttime(string33, this.fridayOpenTime);
                if (!this.isRunning) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string33);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string33, string34);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                } else {
                    this.countDownTimer.cancel();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("s");
                    stringBuilder.append(string33);
                    Log.e((String)"selected", (String)stringBuilder.toString());
                    this.starttimer(string33, string34);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                }
            }
            if (string2.contains((CharSequence)"Saturday")) {
                String string35;
                this.sttodaydate = string35 = this.changedateformate(string2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("tt");
                stringBuilder.append(this.saturdayOpenTime);
                Log.e((String)"satopentime", (String)stringBuilder.toString());
                String string36 = this.subtracttime(string35, this.saturdayOpenTime);
                if (!this.isRunning) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("s");
                    stringBuilder2.append(string35);
                    Log.e((String)"selected", (String)stringBuilder2.toString());
                    this.starttimer(string35, string36);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                } else {
                    this.countDownTimer.cancel();
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append("s");
                    stringBuilder3.append(string35);
                    Log.e((String)"selected", (String)stringBuilder3.toString());
                    this.starttimer(string35, string36);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                }
            }
            if (string2.contains((CharSequence)"Sunday")) {
                String string37;
                this.sttodaydate = string37 = this.changedateformate(string2);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("tt");
                stringBuilder.append(this.sundayOpenTime);
                Log.e((String)"satopentime", (String)stringBuilder.toString());
                String string38 = this.subtracttime(string37, this.sundayOpenTime);
                if (!this.isRunning) {
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append("s");
                    stringBuilder4.append(string37);
                    Log.e((String)"selected", (String)stringBuilder4.toString());
                    this.starttimer(string37, string38);
                    this.open.setEnabled(true);
                    this.open.setChecked(true);
                    return;
                }
                this.countDownTimer.cancel();
                StringBuilder stringBuilder5 = new StringBuilder();
                stringBuilder5.append("s");
                stringBuilder5.append(string37);
                Log.e((String)"selected", (String)stringBuilder5.toString());
                this.starttimer(string37, string38);
                this.open.setEnabled(true);
                this.open.setChecked(true);
            }
        }
    }

    private long starttimer(String string2, String string3) {
        long l;
        CountDownTimer countDownTimer;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
        Date date = new Date();
        simpleDateFormat.format(date);
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(" ");
            stringBuilder.append(string3);
            Date date2 = simpleDateFormat.parse(stringBuilder.toString());
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("n");
            stringBuilder2.append((Object)date2);
            Log.e((String)"date2", (String)stringBuilder2.toString());
            l = date2.getTime() - date.getTime();
            this.elapsedHours = l / 3600000L;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return 0L;
        }
        long l2 = l % 3600000L;
        this.elapsedMinutes = l2 / 60000L;
        long l3 = l2 % 60000L;
        this.elapsedSeconds = l3 / 1000L;
        PrintStream printStream = System.out;
        Object[] arrobject = new Object[]{this.elapsedHours, this.elapsedMinutes, this.elapsedSeconds};
        printStream.printf("%d hours, %d minutes, %d seconds%n", arrobject);
        int n = 1000 * (int)this.elapsedSeconds;
        int n2 = 60000 * (int)this.elapsedMinutes;
        int n3 = 3600000 * (int)this.elapsedHours;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(n3);
        stringBuilder.append("\n");
        stringBuilder.append(n2);
        stringBuilder.append("\n");
        stringBuilder.append(n);
        Log.e((String)"hourmilisecond", (String)stringBuilder.toString());
        long l4 = n3 + (n + n2);
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("n");
        stringBuilder3.append(l4);
        Log.e((String)"time", (String)stringBuilder3.toString());
        long l5 = l4 / 1000L;
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append("n");
        stringBuilder4.append(l5);
        Log.e((String)"seconds", (String)stringBuilder4.toString());
        String string4 = String.valueOf((long)l5);
        int n4 = Integer.parseInt((String)string4);
        StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append("n");
        stringBuilder5.append(string4);
        Log.e((String)"millis", (String)stringBuilder5.toString());
        long l6 = n4 * 1000;
        this.countDownTimer = countDownTimer = new CountDownTimer(l6, 1000L){

            public void onFinish() {
                Log.e((String)"finish", (String)"f");
                StartPanaRule.this.isRunning = false;
                if (StartPanaRule.this.open.isChecked() && !StartPanaRule.this.close.isChecked()) {
                    StartPanaRule.this.isopentimepass = true;
                }
                if (StartPanaRule.this.close.isChecked() && StartPanaRule.this.open.isChecked()) {
                    StartPanaRule.this.isclosetimepass = true;
                }
                StartPanaRule.this.checktime();
                StartPanaRule.this.getnextdays();
            }

            public void onTick(long l) {
                StartPanaRule.this.isRunning = true;
                long l2 = l / 1000L;
                (int)l2 % 60;
                l / 60000L % 60L;
                l / 3600000L % 24L;
                long l3 = l2 / 60L;
                long l4 = l3 / 60L;
                long l5 = l4 / 24L;
                long l6 = l2 % 60L;
                long l7 = l4 % 24L;
                long l8 = l3 % 60L;
                Object[] arrobject = new Object[]{l5};
                String string2 = String.format((String)"%d", (Object[])arrobject);
                Object[] arrobject2 = new Object[]{l7};
                String string3 = String.format((String)"%02d", (Object[])arrobject2);
                Object[] arrobject3 = new Object[]{l8};
                String string4 = String.format((String)"%02d", (Object[])arrobject3);
                Object[] arrobject4 = new Object[]{l6};
                String string5 = String.format((String)"%02d", (Object[])arrobject4);
                if (l5 > 0L) {
                    TextView textView = StartPanaRule.this.day;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string2);
                    stringBuilder.append("D ");
                    textView.setText((CharSequence)stringBuilder.toString());
                } else {
                    StartPanaRule.this.day.setText((CharSequence)"");
                }
                TextView textView = StartPanaRule.this.hour;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string3);
                stringBuilder.append(":");
                textView.setText((CharSequence)stringBuilder.toString());
                TextView textView2 = StartPanaRule.this.minute;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(string4);
                stringBuilder2.append(":");
                textView2.setText((CharSequence)stringBuilder2.toString());
                StartPanaRule.this.second.setText((CharSequence)string5);
            }
        };
        countDownTimer.start();
        return l3;
    }

    public void addbid(String string2) {
        for (int i = 0; i < this.output.size(); ++i) {
            BidingModel bidingModel = new BidingModel();
            bidingModel.setDate(this.sttodaydate);
            bidingModel.setType(string2);
            bidingModel.setDigit((String)this.output.get(i));
            bidingModel.setPonts(this.edpoints.getText().toString());
            this.bidinglist.add((Object)bidingModel);
            this.adapter.notifyDataSetChanged();
        }
    }

    public void calculate() {
        ArrayList arrayList = new ArrayList();
        this.daylist = new ArrayList();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE dd-MMM-yyyy");
        int n = 7;
        for (int i = 0; i < n; ++i) {
            GregorianCalendar gregorianCalendar = new GregorianCalendar();
            gregorianCalendar.add(5, i);
            String string2 = simpleDateFormat.format(gregorianCalendar.getTime());
            Log.e((String)"nextdays", (String)string2);
            arrayList.add((Object)string2);
            if (string2.contains((CharSequence)"Monday") && this.isMonday.equals((Object)"inactive")) {
                arrayList.remove(arrayList.indexOf((Object)string2));
                ++n;
            }
            if (string2.contains((CharSequence)"Tuesday") && this.isTuesday.equals((Object)"inactive")) {
                arrayList.remove(arrayList.indexOf((Object)string2));
                ++n;
            }
            if (string2.contains((CharSequence)"Wednesday") && this.isWednesday.equals((Object)"inactive")) {
                arrayList.remove(arrayList.indexOf((Object)string2));
                ++n;
            }
            if (string2.contains((CharSequence)"Thursday") && this.isThursday.equals((Object)"inactive")) {
                arrayList.remove(arrayList.indexOf((Object)string2));
                ++n;
            }
            if (string2.contains((CharSequence)"Friday") && this.isFriday.equals((Object)"inactive")) {
                arrayList.remove(arrayList.indexOf((Object)string2));
                ++n;
            }
            if (string2.contains((CharSequence)"Saturday") && this.isSaturday.equals((Object)"inactive")) {
                arrayList.remove(arrayList.indexOf((Object)string2));
                ++n;
            }
            if (string2.contains((CharSequence)"Sunday") && this.isSunday.equals((Object)"inactive")) {
                arrayList.remove(arrayList.indexOf((Object)string2));
                ++n;
            }
            if (!string2.equals((Object)this.todayday) || !this.isclosetimepass) continue;
            arrayList.remove(arrayList.indexOf((Object)string2));
            ++n;
        }
        for (String string3 : arrayList) {
            if (string3.contains((CharSequence)this.todayday)) {
                string3 = "Today";
            }
            this.daylist.add((Object)string3);
        }
    }

    public String changedateformate(String string2) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE dd-MMM-yyyy");
        try {
            Date date = simpleDateFormat.parse(string2);
            SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyy-MM-dd");
            System.out.println(simpleDateFormat2.format(date));
            String string3 = simpleDateFormat2.format(date);
            return string3;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return string2;
        }
    }

    long getBiddingPoints() {
        long l = 0L;
        for (int i = 0; i < this.bidinglist.size(); ++i) {
            l += (long)Integer.parseInt((String)((BidingModel)this.bidinglist.get(i)).getPonts());
        }
        return l;
    }

    public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
        this.setDigits(this.eddigit.getText().toString());
        this.setBidTotal();
        if (this.sp.isChecked()) {
            Log.e((String)"sp", (String)"sp");
        }
        if (this.dp.isChecked()) {
            Log.e((String)"dp", (String)"dp");
        }
        if (this.tp.isChecked()) {
            Log.e((String)"tp", (String)"tp");
        }
        if (this.start.isChecked()) {
            Log.e((String)"start", (String)"start");
        }
        if (this.middle.isChecked()) {
            Log.e((String)"middle", (String)"middle");
        }
        if (this.end.isChecked()) {
            Log.e((String)"end", (String)"end");
        }
    }

    public void onClick(View view) {
        if (view == this.add) {
            if (this.eddigit.getText().toString().trim().length() == 0) {
                this.eddigit.setError((CharSequence)"please enter valid digit");
                this.eddigit.requestFocus();
            } else if (this.edpoints.getText().toString().trim().length() == 0) {
                this.edpoints.setError((CharSequence)"Minimum 10 points required");
                this.edpoints.requestFocus();
            } else if (Integer.parseInt((String)this.edpoints.getText().toString()) < 10) {
                this.edpoints.setError((CharSequence)"Minimum 10 points required");
                this.edpoints.requestFocus();
            } else if (Integer.parseInt((String)this.edpoints.getText().toString()) % 5 != 0) {
                this.edpoints.setError((CharSequence)"Point should be multiple of 5 ex. 5,10,20");
                this.edpoints.requestFocus();
            } else if (Integer.parseInt((String)CommonParams.totalpoint) < Integer.parseInt((String)this.edpoints.getText().toString())) {
                this.showToast("you don't have sufficent point for this bid");
            } else if (this.output.size() < 1) {
                this.showToast("Sorry select digit for this bid");
            } else {
                this.showToast("Bid added sucessfully");
                this.goodluck.setEnabled(true);
                this.layout_bid_container.setVisibility(0);
                String string2 = ((RadioButton)this.findViewById(this.radioGroup.getCheckedRadioButtonId())).getText().toString();
                if (this.bidinglist.size() > 0) {
                    int n = this.bidinglist.size();
                    String string3 = this.edpoints.getText().toString();
                    for (int i = 0; i < this.output.size(); ++i) {
                        String string4;
                        int n2;
                        String string5;
                        String string6;
                        String string7;
                        String string8;
                        boolean bl;
                        block19 : {
                            string7 = (String)this.output.get(i);
                            n2 = -1;
                            string4 = string5 = (string8 = (string6 = ""));
                            for (int j = 0; j < n; ++j) {
                                string6 = ((BidingModel)this.bidinglist.get(j)).getDate();
                                string8 = ((BidingModel)this.bidinglist.get(j)).getDigit();
                                string5 = ((BidingModel)this.bidinglist.get(j)).getType();
                                string4 = ((BidingModel)this.bidinglist.get(j)).getPonts();
                                if (!string6.equals((Object)this.sttodaydate) || !string8.equals((Object)string7) || !string5.equals((Object)string2)) continue;
                                n2 = j;
                                bl = true;
                                break block19;
                            }
                            bl = false;
                        }
                        if (bl) {
                            BidingModel bidingModel = new BidingModel();
                            bidingModel.setPonts(String.valueOf((int)(Integer.parseInt((String)string4) + Integer.parseInt((String)string3))));
                            bidingModel.setDate(string6);
                            bidingModel.setDigit(string8);
                            bidingModel.setType(string5);
                            this.bidinglist.set(n2, (Object)bidingModel);
                            this.adapter.notifyDataSetChanged();
                            continue;
                        }
                        BidingModel bidingModel = new BidingModel();
                        Integer.parseInt((String)string4);
                        Integer.parseInt((String)string3);
                        bidingModel.setPonts(this.edpoints.getText().toString());
                        bidingModel.setDate(this.sttodaydate);
                        bidingModel.setDigit(string7);
                        bidingModel.setType(string2);
                        this.bidinglist.add((Object)bidingModel);
                        this.adapter.notifyDataSetChanged();
                    }
                } else {
                    this.addbid(string2);
                }
                this.setBidTotal();
            }
        }
        if (view == this.goodluck) {
            this.makesimplejson();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(this.bidjson.toString());
            Log.e((String)"array", (String)stringBuilder.toString());
            this.encryptstring = this.encryptjson(this.bidjson.toString());
            this.AddBidding();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492914);
        this.title = this.getIntent().getStringExtra("title");
        this.imageBack = (ImageView)this.findViewById(2131296624);
        this.textMainTitle = (TextView)this.findViewById(2131296955);
        this.textTitle = (TextView)this.findViewById(2131296956);
        this.textMainTitle.setText((CharSequence)this.title);
        this.textTitle.setText((CharSequence)"Combine Pana");
        this.todayday = new SimpleDateFormat("EEEE dd-MMM-yyyy").format(new Date());
        this.init();
        this.getvaluefromintent();
        this.checktime();
        if (!this.isopentimepass) {
            this.open.setChecked(true);
        }
        try {
            this.myPoints = Long.parseLong((String)CommonParams.totalpoint);
        }
        catch (Exception exception) {}
        this.imageBack.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ StartPanaRule this$0;
            {
                this.this$0 = startPanaRule;
            }

            public void onClick(View view) {
                this.this$0.onBackPressed();
            }
        });
    }

    public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
        this.selectiondata(this.dayspiner.getSelectedItem().toString());
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        this.onBackPressed();
        return true;
    }

    void setDigits(String string2) {
        if (!this.sp.isChecked() && !this.dp.isChecked() && !this.tp.isChecked() || !this.start.isChecked() && !this.middle.isChecked() && !this.end.isChecked()) {
            this.output = new ArrayList();
            this.panadigit.setText((CharSequence)"");
            this.showToast("Please choose type & digit type first");
            return;
        }
        ((InputMethodManager)this.getApplicationContext().getSystemService("input_method")).hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(), 0);
        this.enteredDigit = string2.toString();
        this.output = new ArrayList();
        this.specialpanan();
        TextView textView = this.panadigit;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Special Pana Digits : ");
        stringBuilder.append(Arrays.toString((Object[])this.output.toArray()));
        textView.setText((CharSequence)stringBuilder.toString());
    }

    @Override
    public void setUpToolbarByName(String string2) {
        Toolbar toolbar = (Toolbar)this.findViewById(2131296976);
        this.setSupportActionBar(toolbar);
        ActionBar actionBar = this.getSupportActionBar();
        actionBar.setHomeAsUpIndicator(2131165350);
        actionBar.setDisplayHomeAsUpEnabled(true);
        toolbar.setTitleTextColor(-1);
        actionBar.setTitle((CharSequence)string2);
    }

    public void specialpanan() {
        for (int i = 100; i < 1000; ++i) {
            String[] arrstring = String.valueOf((int)i).split("");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(this.enteredDigit);
            stringBuilder.append("\n");
            stringBuilder.append(arrstring[1].toString());
            Log.e((String)"enterdigit", (String)stringBuilder.toString());
            if (this.start.isChecked() && this.enteredDigit.equals((Object)arrstring[1].toString())) {
                if (this.sp.isChecked() && this.FuncCheckSinglePana(arrstring[1], arrstring[2], arrstring[3]) != "") {
                    this.output.add((Object)String.valueOf((int)i));
                    continue;
                }
                if (this.dp.isChecked() && this.FuncCheckDoublePana(arrstring[1], arrstring[2], arrstring[3]) != "") {
                    this.output.add((Object)String.valueOf((int)i));
                    continue;
                }
                if (this.tp.isChecked() && this.FuncCheckTripplePana(arrstring[1], arrstring[2], arrstring[3]) != "") {
                    this.output.add((Object)String.valueOf((int)i));
                    continue;
                }
            }
            if (this.middle.isChecked() && this.enteredDigit.equals((Object)arrstring[2].toString())) {
                if (this.sp.isChecked() && this.FuncCheckSinglePana(arrstring[1], arrstring[2], arrstring[3]) != "") {
                    this.output.add((Object)String.valueOf((int)i));
                    continue;
                }
                if (this.dp.isChecked() && this.FuncCheckDoublePana(arrstring[1], arrstring[2], arrstring[3]) != "") {
                    this.output.add((Object)String.valueOf((int)i));
                    continue;
                }
                if (this.tp.isChecked() && this.FuncCheckTripplePana(arrstring[1], arrstring[2], arrstring[3]) != "") {
                    this.output.add((Object)String.valueOf((int)i));
                    continue;
                }
            }
            if (!this.end.isChecked() || !this.enteredDigit.equals((Object)arrstring[3].toString())) continue;
            if (this.sp.isChecked() && this.FuncCheckSinglePana(arrstring[1], arrstring[2], arrstring[3]) != "") {
                this.output.add((Object)String.valueOf((int)i));
                continue;
            }
            if (this.dp.isChecked() && this.FuncCheckDoublePana(arrstring[1], arrstring[2], arrstring[3]) != "") {
                this.output.add((Object)String.valueOf((int)i));
                continue;
            }
            if (!this.tp.isChecked() || this.FuncCheckTripplePana(arrstring[1], arrstring[2], arrstring[3]) == "") continue;
            this.output.add((Object)String.valueOf((int)i));
        }
        if (this.tp.isChecked() && this.enteredDigit.equals((Object)"0")) {
            this.output.add((Object)"000");
        }
    }

    public String subtracttime(String string2, String string3) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("HH:mm:ss");
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(" ");
            stringBuilder.append(string3);
            Date date = simpleDateFormat.parse(stringBuilder.toString());
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(12, 0);
            String string4 = simpleDateFormat2.format(calendar.getTime());
            return string4;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return null;
        }
    }

}

