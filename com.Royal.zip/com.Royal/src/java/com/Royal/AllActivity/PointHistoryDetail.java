/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Color
 *  android.os.Bundle
 *  android.text.Html
 *  android.util.Log
 *  android.view.View
 *  android.widget.TextView
 *  androidx.cardview.widget.CardView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class PointHistoryDetail
extends BaseAppCompactActivity {
    TextView accdetailtxt;
    TextView accountholdername;
    TextView accountname;
    TextView accountnumber;
    CardView cardView;
    TextView datetime;
    String decryptstring;
    TextView detailtxt;
    String encryptstring;
    JSONObject inputjson;
    TextView requestedon;
    TextView toptxt;
    String transaction_id;
    TextView transactiondate;
    TextView transactionid;
    String transactiontype;
    TextView transfer_point;
    TextView tvstatus;
    String urlToBeCalled = "";

    private void PointTransfer() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)this.urlToBeCalled).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").addBodyParameter("post", this.encryptstring).setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    PointHistoryDetail.this.showToast("Something went wrong");
                }

                /*
                 * Unable to fully structure code
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 * Lifted jumps to return sites
                 */
                public void onResponse(JSONObject var1_1) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)var1_1.toString());
                    if (!var1_1.getString("status").equals((Object)"true")) ** GOTO lbl96
                    var5_2 = PointHistoryDetail.this.urlToBeCalled.equals((Object)"http://www.balajimatka.com/api/v2/userPoint/transferDetail");
                    if (!var5_2) ** GOTO lbl40
                    PointHistoryDetail.this.cardView.setVisibility(0);
                    PointHistoryDetail.this.transfer_point.setText((CharSequence)var1_1.getString("point"));
                    var37_3 = PointHistoryDetail.getFormatedDateTime(var1_1.getString("createdOn"), "yyy-MM-dd HH:mm:ss", "EEEE dd-MMM-yyy hh:mm a");
                    PointHistoryDetail.this.datetime.setText((CharSequence)var37_3);
                    PointHistoryDetail.this.tvstatus.setText((CharSequence)"Success");
                    PointHistoryDetail.this.tvstatus.setBackgroundColor(Color.parseColor((String)"#0e8123"));
                    var38_4 = PointHistoryDetail.this.requestedon;
                    var39_5 = new StringBuilder();
                    var39_5.append("<b>Requested On</b><br>");
                    var39_5.append(var37_3);
                    var38_4.setText((CharSequence)Html.fromHtml((String)var39_5.toString()));
                    PointHistoryDetail.this.transactionid.setVisibility(8);
                    PointHistoryDetail.this.transactiondate.setVisibility(8);
                    {
                        catch (JSONException var3_28) {
                            var3_28.printStackTrace();
                            return;
                        }
                    }
                    try {
                        var42_6 = new JSONObject(var1_1.getString("senderOrReceiver"));
                        var44_7 = PointHistoryDetail.this.accountholdername;
                        var45_8 = new StringBuilder();
                        var45_8.append("<b>Name</b><br>");
                        var45_8.append(var42_6.getString("name"));
                        var44_7.setText((CharSequence)Html.fromHtml((String)var45_8.toString()));
                        var48_9 = PointHistoryDetail.this.accountnumber;
                        var49_10 = new StringBuilder();
                        var49_10.append("<b>Mobile Number</b><br>");
                        var49_10.append(var42_6.getString("mobile"));
                        var48_9.setText((CharSequence)Html.fromHtml((String)var49_10.toString()));
                        return;
                    }
                    catch (Throwable var43_11) {
                        var43_11.printStackTrace();
                        return;
lbl40: // 1 sources:
                        PointHistoryDetail.this.cardView.setVisibility(0);
                        PointHistoryDetail.this.transfer_point.setText((CharSequence)var1_1.getString("point"));
                        var6_12 = PointHistoryDetail.getFormatedDateTime(var1_1.getString("createdOn"), "yyy-MM-dd HH:mm:ss", "EEEE dd-MMM-yyy hh:mm a");
                        PointHistoryDetail.this.datetime.setText((CharSequence)var6_12);
                        PointHistoryDetail.this.tvstatus.setText((CharSequence)var1_1.getString("isStatus"));
                        var7_13 = var1_1.getString("isStatus").equals((Object)"decline");
                        if (var7_13) {
                            PointHistoryDetail.this.tvstatus.setBackgroundColor(Color.parseColor((String)"#DC3545"));
                        }
                        if (var1_1.getString("isStatus").equals((Object)"pending")) {
                            PointHistoryDetail.this.tvstatus.setBackgroundColor(Color.parseColor((String)"#17A2B8"));
                        }
                        if (var1_1.getString("isStatus").equals((Object)"cancel")) {
                            PointHistoryDetail.this.tvstatus.setBackgroundColor(Color.parseColor((String)"#DC3545"));
                        }
                        if (var1_1.getString("isStatus").equals((Object)"success")) {
                            PointHistoryDetail.this.tvstatus.setBackgroundColor(Color.parseColor((String)"#0e8123"));
                        }
                        var8_14 = PointHistoryDetail.this.requestedon;
                        var9_15 = new StringBuilder();
                        var9_15.append("<b>Requested On</b><br>");
                        var9_15.append(var6_12);
                        var8_14.setText((CharSequence)Html.fromHtml((String)var9_15.toString()));
                        if (!var1_1.getString("transactionId").equals((Object)"null")) {
                            var33_16 = PointHistoryDetail.this.transactionid;
                            var34_17 = new StringBuilder();
                            var34_17.append("<b>Transaction Id</b><br>");
                            var34_17.append(var1_1.getString("transactionId"));
                            var33_16.setText((CharSequence)Html.fromHtml((String)var34_17.toString()));
                        } else {
                            PointHistoryDetail.this.transactionid.setVisibility(8);
                        }
                        if (!var1_1.getString("transactionDate").equals((Object)"null")) {
                            var29_18 = PointHistoryDetail.this.transactiondate;
                            var30_19 = new StringBuilder();
                            var30_19.append("<b>Transaction Date</b><br>");
                            var30_19.append(var1_1.getString("transactionDate"));
                            var29_18.setText((CharSequence)Html.fromHtml((String)var30_19.toString()));
                        } else {
                            PointHistoryDetail.this.transactiondate.setVisibility(8);
                        }
                        var12_20 = PointHistoryDetail.this.accountname;
                        var13_21 = new StringBuilder();
                        var14_22 = new StringBuilder();
                        var14_22.append("<b>Acount Name</b><br>");
                        var14_22.append(var1_1.getString("accountName"));
                        var13_21.append((Object)Html.fromHtml((String)var14_22.toString()));
                        var13_21.append(" (");
                        var13_21.append(var1_1.getString("accountType"));
                        var13_21.append(" )");
                        var12_20.setText((CharSequence)var13_21.toString());
                        var21_23 = PointHistoryDetail.this.accountnumber;
                        var22_24 = new StringBuilder();
                        var22_24.append("<b>Account Number</b><br>");
                        var22_24.append(var1_1.getString("accountNumber"));
                        var21_23.setText((CharSequence)Html.fromHtml((String)var22_24.toString()));
                        var25_25 = PointHistoryDetail.this.accountholdername;
                        var26_26 = new StringBuilder();
                        var26_26.append("<b>Account Holder name</b><br>");
                        var26_26.append(var1_1.getString("accountHolderName"));
                        var25_25.setText((CharSequence)Html.fromHtml((String)var26_26.toString()));
                        return;
lbl96: // 1 sources:
                        var4_27 = var1_1.getString("error");
                        PointHistoryDetail.this.showToast(var4_27);
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    private void init() {
        String string2;
        this.toptxt = (TextView)this.findViewById(2131296605);
        this.datetime = (TextView)this.findViewById(2131296471);
        this.tvstatus = (TextView)this.findViewById(2131296889);
        this.transfer_point = (TextView)this.findViewById(2131296993);
        this.detailtxt = (TextView)this.findViewById(2131296992);
        this.requestedon = (TextView)this.findViewById(2131296803);
        this.transactionid = (TextView)this.findViewById(2131296991);
        this.transactiondate = (TextView)this.findViewById(2131296990);
        this.accdetailtxt = (TextView)this.findViewById(2131296483);
        this.accountname = (TextView)this.findViewById(2131296308);
        this.accountnumber = (TextView)this.findViewById(2131296309);
        this.accountholdername = (TextView)this.findViewById(2131296307);
        this.cardView = (CardView)this.findViewById(2131296415);
        Intent intent = this.getIntent();
        this.transaction_id = intent.getStringExtra("id");
        this.transactiontype = string2 = intent.getStringExtra("actiontype");
        if (string2.equals((Object)"userLockPoint")) {
            this.urlToBeCalled = "http://www.balajimatka.com/api/v2/userPoint/lockHistorydetail";
            this.transaction_id = intent.getStringExtra("actionId");
        } else if (!(this.transactiontype.equals((Object)"ticketNumber") || this.transactiontype.equals((Object)"userBidTransactionDetailId") || this.transactiontype.equals((Object)"resultWin") || this.transactiontype.equals((Object)"resultCancel"))) {
            if (this.transactiontype.equals((Object)"userPoint")) {
                this.urlToBeCalled = "http://www.balajimatka.com/api/v2/userPoint/transferDetail";
            }
        } else {
            this.urlToBeCalled = "http://www.balajimatka.com/api/v2/bidding/detail";
            this.transaction_id = intent.getStringExtra("actionId");
        }
        this.makesimplejson();
        this.encryptstring = this.encryptjson(this.inputjson.toString());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.inputjson.toString());
        Log.e((String)"encrypt", (String)stringBuilder.toString());
        this.PointTransfer();
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("userId", (Object)CommonParams.userId);
            this.inputjson.put("detailId", (Object)this.transaction_id);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493022);
        this.setUpToolbarByName("Transaction History");
        this.init();
    }

}

