/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  android.view.View
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  java.lang.String
 */
package com.Royal.AllActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.Royal.AllActivity.WebViewActivity;
import com.Royal.Utilities.BaseAppCompactActivity;

public class WebViewActivity
extends BaseAppCompactActivity {
    WebView webview;

    @Override
    protected void onCreate(Bundle bundle) {
        WebView webView;
        super.onCreate(bundle);
        this.setContentView(2131492897);
        this.setUpToolbarByName(this.getResources().getString(2131820578));
        Intent intent = this.getIntent();
        this.webview = webView = (WebView)this.findViewById(2131297052);
        webView.getSettings().setJavaScriptEnabled(true);
        this.webview.setWebViewClient(new WebViewClient(){

            public boolean shouldOverrideUrlLoading(WebView webView, String string2) {
                return true;
            }
        });
        this.webview.loadUrl(intent.getStringExtra("url"));
    }

    public boolean onKeyDown(int n, KeyEvent keyEvent) {
        if (n == 4 && this.webview.canGoBack()) {
            this.webview.goBack();
            return true;
        }
        return super.onKeyDown(n, keyEvent);
    }

}

