/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.os.Environment
 *  android.os.Handler
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.text.Html
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.webkit.WebView
 *  android.webkit.WebViewClient
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.HorizontalScrollView
 *  android.widget.ScrollView
 *  android.widget.TableLayout
 *  android.widget.TableRow
 *  android.widget.TextView
 *  androidx.print.PrintHelper
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.print.PrintHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.AllDateAdapter;
import com.Royal.Adapter.RecordAdapter;
import com.Royal.AllActivity.ResultActivity;
import com.Royal.Model.BazarModel;
import com.Royal.Model.DateModel;
import com.Royal.Model.RecordModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ResultActivity
extends BaseAppCompactActivity
implements View.OnClickListener {
    RecyclerView alldatelist;
    RecyclerView bazar;
    List<BazarModel> bazarlist;
    AllDateAdapter dateadapter;
    String decryptdtring;
    List<DateModel> dtlist;
    List<String> dtlistcompare;
    EditText edmonth;
    String encryptstring;
    SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd");
    JSONObject inputjson;
    int mday;
    String monthYearStr;
    ProgressDialog pDialog;
    Button print;
    RecordAdapter recordadapter;
    List<RecordModel> recordlist;
    ArrayList<String> redjodilist = new ArrayList();
    RecyclerView result;
    ScrollView scrollView;
    SimpleDateFormat sdf = new SimpleDateFormat("MMM - yyyy");
    Button search;
    TableLayout stk;
    String stmonth;
    String styear;
    WebView webView;

    private void ResultApiList() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.encryptstring);
        Log.e((String)"bazar", (String)stringBuilder.toString());
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/record/result").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.HIGH).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    ResultActivity.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"resultApi_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            String string2 = jSONObject.getString("results");
                            String string3 = jSONObject.getString("bazaars");
                            String string4 = jSONObject.getString("redJodiList");
                            ResultActivity.this.parseresultjson(string2);
                            ResultActivity.this.parsebazarjson(string3);
                            ResultActivity.this.parseredjodijson(string4);
                            return;
                        }
                        String string5 = jSONObject.getString("error");
                        ResultActivity.this.showToast(Html.fromHtml((String)string5).toString());
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void getalldate() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(2, this.mday - 1);
        calendar.set(5, 1);
        calendar.set(1, Integer.parseInt((String)this.styear));
        int n = calendar.getActualMaximum(5);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM,yyyy");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
        int n2 = 0;
        while (n2 < n) {
            DateModel dateModel = new DateModel();
            calendar.set(5, ++n2);
            dateModel.setStdate(simpleDateFormat.format(calendar.getTime()));
            this.dtlist.add((Object)dateModel);
            this.dtlistcompare.add((Object)simpleDateFormat2.format(calendar.getTime()));
        }
        this.dateadapter.notifyDataSetChanged();
    }

    private void init() {
        String string2;
        AllDateAdapter allDateAdapter;
        int n;
        this.edmonth = (EditText)this.findViewById(2131296536);
        this.search = (Button)this.findViewById(2131296829);
        this.print = (Button)this.findViewById(2131296789);
        this.bazar = (RecyclerView)this.findViewById(2131296367);
        this.result = (RecyclerView)this.findViewById(2131296808);
        this.alldatelist = (RecyclerView)this.findViewById(2131296470);
        this.webView = (WebView)this.findViewById(2131297052);
        this.stk = (TableLayout)this.findViewById(2131296901);
        this.search = (Button)this.findViewById(2131296829);
        this.scrollView = (ScrollView)this.findViewById(2131296827);
        this.search.setOnClickListener((View.OnClickListener)this);
        this.print.setOnClickListener((View.OnClickListener)this);
        this.webView.setWebViewClient(new WebViewClient());
        this.webView.setScrollBarStyle(0);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getApplicationContext());
        this.alldatelist.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.bazar.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager((Context)this, 0, true));
        this.bazarlist = new ArrayList();
        this.recordlist = new ArrayList();
        this.dtlist = new ArrayList();
        this.dtlistcompare = new ArrayList();
        this.dateadapter = allDateAdapter = new AllDateAdapter((Context)this, this.dtlist);
        this.alldatelist.setAdapter((RecyclerView.Adapter)allDateAdapter);
        Calendar calendar = Calendar.getInstance();
        int n2 = calendar.get(1);
        this.mday = n = 1 + calendar.get(2);
        this.styear = String.valueOf((int)n2);
        this.stmonth = string2 = String.valueOf((int)n);
        if (string2.trim().length() < 2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("0");
            stringBuilder.append(this.stmonth);
            this.stmonth = stringBuilder.toString();
        }
        String string3 = this.sdf.format(new Date());
        this.edmonth.setText((CharSequence)string3);
        this.edmonth.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ ResultActivity this$0;
            {
                this.this$0 = resultActivity;
            }

            public void onClick(View view) {
                com.Royal.Utilities.MonthYearPickerDialog monthYearPickerDialog = new com.Royal.Utilities.MonthYearPickerDialog();
                monthYearPickerDialog.setListener(new android.app.DatePickerDialog$OnDateSetListener(this){
                    final /* synthetic */ 1 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void onDateSet(android.widget.DatePicker datePicker, int n, int n2, int n3) {
                        ResultActivity resultActivity = this.this$1.this$0;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(n);
                        stringBuilder.append("-");
                        stringBuilder.append(n2 + 1);
                        stringBuilder.append("-");
                        stringBuilder.append(n3);
                        resultActivity.monthYearStr = stringBuilder.toString();
                        this.this$1.this$0.styear = String.valueOf((int)n);
                        this.this$1.this$0.mday = n2;
                        this.this$1.this$0.stmonth = String.valueOf((int)n2);
                        if (this.this$1.this$0.stmonth.trim().length() < 2) {
                            ResultActivity resultActivity2 = this.this$1.this$0;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("0");
                            stringBuilder2.append(this.this$1.this$0.stmonth);
                            resultActivity2.stmonth = stringBuilder2.toString();
                        }
                        this.this$1.this$0.edmonth.setText((CharSequence)this.this$1.this$0.formatMonthYear(this.this$1.this$0.monthYearStr));
                    }
                });
                monthYearPickerDialog.show(this.this$0.getSupportFragmentManager(), "MonthYearPickerDialog");
            }
        });
        this.pDialog = CommonParams.createProgressDialog((Context)this);
        this.makesimplejson();
        Log.e((String)"json", (String)this.inputjson.toString());
        this.encryptstring = this.encryptjson(this.inputjson.toString());
        this.ResultApiList();
        this.getalldate();
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("month", (Object)this.stmonth);
            this.inputjson.put("year", (Object)this.styear);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void parsebazarjson(String string2) {
        JSONArray jSONArray;
        block3 : {
            try {
                jSONArray = new JSONArray(string2);
                if (jSONArray.length() != 0) break block3;
                this.showToast("No data found");
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
                return;
            }
        }
        for (int i = 0; i < jSONArray.length(); ++i) {
            JSONObject jSONObject = jSONArray.getJSONObject(i);
            BazarModel bazarModel = new BazarModel();
            bazarModel.setId(jSONObject.getString("id"));
            bazarModel.setName(jSONObject.getString("name"));
            this.bazarlist.add((Object)bazarModel);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void parseredjodijson(String string2) {
        try {
            JSONArray jSONArray = new JSONArray(string2);
            if (jSONArray.length() == 0) {
                this.showToast("No data found");
            }
            for (int i = 0; i < jSONArray.length(); ++i) {
                this.redjodilist.add((Object)((String)jSONArray.get(i)));
            }
            this.setdataontable();
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void parseresultjson(String string2) {
        JSONArray jSONArray;
        block3 : {
            try {
                jSONArray = new JSONArray(string2);
                if (jSONArray.length() != 0) break block3;
                this.showToast("No data found");
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
                return;
            }
        }
        for (int i = 0; i < jSONArray.length(); ++i) {
            JSONObject jSONObject = jSONArray.getJSONObject(i);
            RecordModel recordModel = new RecordModel();
            recordModel.setBazarId(jSONObject.getString("bazaarId"));
            recordModel.setBazar(jSONObject.getString("bazaar"));
            recordModel.setPana(jSONObject.getString("pana"));
            recordModel.setJodi(jSONObject.getString("jodi"));
            recordModel.setAnk(jSONObject.getString("ank"));
            recordModel.setDate(jSONObject.getString("date"));
            recordModel.setSession(jSONObject.getString("session"));
            this.recordlist.add((Object)recordModel);
        }
    }

    private void setdataontable() {
        int n;
        TableRow tableRow = new TableRow((Context)this);
        TextView textView = new TextView((Context)this);
        textView.setText((CharSequence)"DATE/BAZAAR");
        int n2 = -1;
        textView.setTextColor(n2);
        tableRow.addView((View)textView);
        TextView textView2 = new TextView((Context)this);
        textView2.setText((CharSequence)"   ");
        textView2.setTextColor(n2);
        tableRow.addView((View)textView2);
        int n3 = 0;
        do {
            int n4 = this.bazarlist.size();
            n = 17;
            if (n3 >= n4) break;
            TextView textView3 = new TextView((Context)this);
            textView3.setText((CharSequence)((BazarModel)this.bazarlist.get(n3)).getName());
            textView3.setTextColor(n2);
            textView3.setGravity(n);
            tableRow.addView((View)textView3);
            TextView textView4 = new TextView((Context)this);
            textView4.setText((CharSequence)"  ");
            textView4.setTextColor(n2);
            textView4.setGravity(n);
            tableRow.addView((View)textView4);
            ++n3;
        } while (true);
        this.stk.addView((View)tableRow);
        for (int i = 0; i < this.dtlist.size(); ++i) {
            String string2;
            TableRow tableRow2 = new TableRow((Context)this);
            TextView textView5 = new TextView((Context)this);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(((DateModel)this.dtlist.get(i)).getStdate());
            textView5.setText((CharSequence)stringBuilder.toString());
            textView5.setTextColor(n2);
            textView5.setGravity(n);
            tableRow2.addView((View)textView5);
            TextView textView6 = new TextView((Context)this);
            textView6.setText((CharSequence)"   ");
            textView6.setTextColor(n2);
            textView6.setGravity(n);
            tableRow2.addView((View)textView6);
            String string3 = string2 = " ";
            boolean bl = false;
            for (int j = 0; j < this.bazarlist.size(); ++j) {
                TextView textView7 = new TextView((Context)this);
                String string4 = " ";
                boolean bl2 = true;
                boolean bl3 = false;
                boolean bl4 = false;
                for (int k = 0; k < this.recordlist.size(); ++k) {
                    if (!((RecordModel)this.recordlist.get(k)).getBazar().equals((Object)((BazarModel)this.bazarlist.get(j)).getName())) continue;
                    TextView textView8 = new TextView((Context)this);
                    if (((RecordModel)this.recordlist.get(k)).getSession().equals((Object)"open") && ((String)this.dtlistcompare.get(i)).equals((Object)((RecordModel)this.recordlist.get(k)).getDate())) {
                        if (bl3 && string4.equals((Object)" ")) {
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(((RecordModel)this.recordlist.get(k)).getPana());
                            stringBuilder2.append(" ");
                            stringBuilder2.append(((RecordModel)this.recordlist.get(k)).getAnk());
                            stringBuilder2.append(" ");
                            stringBuilder2.append(string2);
                            textView8.setText((CharSequence)stringBuilder2.toString());
                            textView8.setTextColor(-1);
                            textView8.setGravity(17);
                            tableRow2.addView((View)textView8);
                            TextView textView9 = new TextView((Context)this);
                            textView9.setText((CharSequence)"   ");
                            textView9.setTextColor(-1);
                            textView9.setGravity(17);
                            tableRow2.addView((View)textView9);
                        } else if (bl3 && !string4.equals((Object)" ")) {
                            if (this.redjodilist.contains((Object)string4)) {
                                textView8.setTextColor(-65536);
                            } else {
                                textView8.setTextColor(-1);
                            }
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append(((RecordModel)this.recordlist.get(k)).getPana());
                            stringBuilder3.append(" ");
                            stringBuilder3.append(string4);
                            stringBuilder3.append(" ");
                            stringBuilder3.append(string2);
                            textView8.setText((CharSequence)stringBuilder3.toString());
                            textView8.setGravity(17);
                            tableRow2.addView((View)textView8);
                            TextView textView10 = new TextView((Context)this);
                            textView10.setText((CharSequence)"   ");
                            textView10.setTextColor(-1);
                            textView10.setGravity(17);
                            tableRow2.addView((View)textView10);
                        } else {
                            string3 = ((RecordModel)this.recordlist.get(k)).getPana();
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append(((RecordModel)this.recordlist.get(k)).getPana());
                            stringBuilder4.append(" ");
                            stringBuilder4.append(((RecordModel)this.recordlist.get(k)).getAnk());
                            stringBuilder4.append("* ***");
                            textView8.setText((CharSequence)stringBuilder4.toString());
                            textView8.setTextColor(-1);
                            textView8.setGravity(17);
                            textView7 = textView8;
                            bl = true;
                        }
                        bl4 = true;
                        continue;
                    }
                    if (!((RecordModel)this.recordlist.get(k)).getSession().equals((Object)"close") || !((String)this.dtlistcompare.get(i)).equals((Object)((RecordModel)this.recordlist.get(k)).getDate())) continue;
                    if (bl4) {
                        if (this.redjodilist.contains((Object)((RecordModel)this.recordlist.get(k)).getJodi())) {
                            textView8.setTextColor(-65536);
                        } else {
                            textView8.setTextColor(-1);
                        }
                        StringBuilder stringBuilder5 = new StringBuilder();
                        stringBuilder5.append(string3);
                        stringBuilder5.append(" ");
                        stringBuilder5.append(((RecordModel)this.recordlist.get(k)).getJodi());
                        stringBuilder5.append(" ");
                        stringBuilder5.append(((RecordModel)this.recordlist.get(k)).getPana());
                        textView8.setText((CharSequence)stringBuilder5.toString());
                        textView8.setGravity(17);
                        tableRow2.addView((View)textView8);
                        TextView textView11 = new TextView((Context)this);
                        textView11.setText((CharSequence)"   ");
                        textView11.setTextColor(-1);
                        textView11.setGravity(17);
                        tableRow2.addView((View)textView11);
                        bl = false;
                    } else {
                        string2 = ((RecordModel)this.recordlist.get(k)).getPana();
                        string4 = ((RecordModel)this.recordlist.get(k)).getJodi();
                        if (this.redjodilist.contains((Object)string4)) {
                            textView8.setTextColor(-65536);
                        } else {
                            textView8.setTextColor(-1);
                        }
                        StringBuilder stringBuilder6 = new StringBuilder();
                        stringBuilder6.append(string3);
                        stringBuilder6.append(" ");
                        stringBuilder6.append(((RecordModel)this.recordlist.get(k)).getJodi());
                        stringBuilder6.append(" ");
                        stringBuilder6.append(((RecordModel)this.recordlist.get(k)).getPana());
                        textView8.setText((CharSequence)stringBuilder6.toString());
                        textView8.setGravity(17);
                    }
                    bl2 = false;
                    bl3 = true;
                }
                if (bl) {
                    tableRow2.addView((View)textView7);
                    TextView textView12 = new TextView((Context)this);
                    textView12.setText((CharSequence)"   ");
                    n2 = -1;
                    textView12.setTextColor(n2);
                    n = 17;
                    textView12.setGravity(n);
                    tableRow2.addView((View)textView12);
                    bl = false;
                    continue;
                }
                n2 = -1;
                n = 17;
                if (!bl2) continue;
                TextView textView13 = new TextView((Context)this);
                textView13.setText((CharSequence)"*** ** ***");
                textView13.setTextColor(n2);
                textView13.setGravity(n);
                tableRow2.addView((View)textView13);
                TextView textView14 = new TextView((Context)this);
                textView14.setText((CharSequence)"   ");
                textView14.setTextColor(n2);
                textView14.setGravity(n);
                tableRow2.addView((View)textView14);
            }
            this.stk.addView((View)tableRow2);
        }
        new Handler().postDelayed(new Runnable(this){
            final /* synthetic */ ResultActivity this$0;
            {
                this.this$0 = resultActivity;
            }

            public void run() {
                this.this$0.pDialog.dismiss();
            }
        }, 3000L);
    }

    String formatMonthYear(String string2) {
        Date date;
        try {
            date = this.input.parse(string2);
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            date = null;
        }
        return this.sdf.format(date);
    }

    public Bitmap getBitmapFromView(View view, int n, int n2) {
        Bitmap bitmap = Bitmap.createBitmap((int)n2, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable drawable2 = view.getBackground();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        } else {
            canvas.drawColor(-16777216);
        }
        view.draw(canvas);
        return bitmap;
    }

    public void layoutToImage() {
        View view = this.findViewById(2131296612);
        HorizontalScrollView horizontalScrollView = (HorizontalScrollView)this.findViewById(2131296612);
        Bitmap bitmap = this.getBitmapFromView(view, horizontalScrollView.getChildAt(0).getHeight(), horizontalScrollView.getChildAt(0).getWidth());
        File file = new File(Environment.getExternalStorageDirectory(), "result.jpg");
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            MediaStore.Images.Media.insertImage((ContentResolver)this.getContentResolver(), (Bitmap)bitmap, (String)"Screen", (String)"screen");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        }
        PrintHelper printHelper = new PrintHelper((Context)this);
        printHelper.setScaleMode(1);
        BitmapFactory.decodeResource((Resources)this.getResources(), (int)2131165425);
        printHelper.printBitmap("droids.jpg - test print", bitmap);
    }

    public void onClick(View view) {
        if (view == this.search) {
            this.pDialog.show();
            this.redjodilist.clear();
            this.redjodilist.clear();
            this.bazarlist.clear();
            this.dtlist.clear();
            this.dtlistcompare.clear();
            this.stk.removeAllViews();
            this.makesimplejson();
            Log.e((String)"json", (String)this.inputjson.toString());
            this.encryptstring = this.encryptjson(this.inputjson.toString());
            this.ResultApiList();
            this.getalldate();
        }
        if (view == this.print) {
            this.layoutToImage();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493033);
        this.setUpToolbarByName("ResultActivity");
        this.init();
    }

}

