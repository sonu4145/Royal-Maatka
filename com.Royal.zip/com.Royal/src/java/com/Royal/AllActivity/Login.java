/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.graphics.Rect
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.os.CountDownTimer
 *  android.text.Editable
 *  android.text.method.HideReturnsTransformationMethod
 *  android.text.method.PasswordTransformationMethod
 *  android.text.method.TransformationMethod
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnKeyListener
 *  android.view.ViewGroup
 *  android.view.Window
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.PopupWindow
 *  android.widget.TextView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$GetRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  com.google.android.material.textfield.TextInputLayout
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.Login;
import com.Royal.AllActivity.SignupFirst;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.DatabaseHandler;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.UserData;
import com.Royal.data.remote.UserDataRepository;
import com.Royal.data.remote.UserDataSource;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.material.textfield.TextInputLayout;
import org.json.JSONException;
import org.json.JSONObject;

public class Login
extends BaseAppCompactActivity
implements View.OnClickListener {
    String OTP = "";
    DatabaseHandler db;
    EditText edmobile;
    EditText edpassword;
    TextView forgotpass;
    Button login;
    UserDataRepository mUserDataRepository;
    TextView mobilenumber;
    TextView passshow;
    PopupWindow popup;
    String stmobile;
    String stpassword;
    TextView tvsignup;
    String userId = "";

    private void getWebServiceData() {
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/admin/contact").addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

            public void onError(ANError aNError) {
                progressDialog.dismiss();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(aNError.getErrorDetail());
                Log.d((String)"error", (String)stringBuilder.toString());
            }

            public void onResponse(JSONObject jSONObject) {
                progressDialog.dismiss();
                Log.e((String)"Api_response", (String)jSONObject.toString());
                try {
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        Dashboard.phone = jSONObject.getString("mobile");
                        Login.this.mobilenumber.setText((CharSequence)Dashboard.phone);
                        return;
                    }
                    jSONObject.getString("error");
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    private void init() {
        Button button;
        this.tvsignup = (TextView)this.findViewById(2131297010);
        this.passshow = (TextView)this.findViewById(2131296462);
        this.edmobile = (EditText)this.findViewById(2131297032);
        this.edpassword = (EditText)this.findViewById(2131296773);
        this.forgotpass = (TextView)this.findViewById(2131296578);
        this.mobilenumber = (TextView)this.findViewById(2131296689);
        this.login = button = (Button)this.findViewById(2131296659);
        button.setOnClickListener((View.OnClickListener)this);
        this.tvsignup.setOnClickListener((View.OnClickListener)this);
        this.passshow.setOnClickListener((View.OnClickListener)this);
        this.forgotpass.setOnClickListener((View.OnClickListener)this);
        this.getWebServiceData();
    }

    public void LoginApi() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mUserDataRepository.getDetailAndLoginUser(this.stmobile, this.stpassword, new UserDataSource.GetUserLoginCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                Login.this.showProgress(false);
                Login.this.showToast(string2);
            }

            @Override
            public void onErrorInPassword(String string2) {
                Login.this.showProgress(false);
                Login.this.showToast(string2);
            }

            @Override
            public void onErrorInUserName(String string2) {
                Login.this.showProgress(false);
                Login.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                Login.this.showProgress(false);
                ScreenUtils.showLockScreen((Activity)Login.this);
            }

            @Override
            public void onUserDataLoaded(UserData userData) {
                Login.this.showProgress(false);
                CommonParams.userId = userData.getUserId();
                CommonParams.totalpoint = String.valueOf((int)userData.getTotalPoint());
                BaseAppCompactActivity.myPoints = Long.parseLong((String)String.valueOf((int)userData.getTotalPoint()));
                CommonParams.lockpoint = String.valueOf((int)userData.getLockPoint());
                SharedPreferences.Editor editor = Login.this.getSharedPreferences("shared", 0).edit();
                editor.putString("id", userData.getUserId());
                editor.putString("di", userData.dealerId);
                editor.putString("dn", userData.displayName);
                editor.putString("email", userData.emailAddress);
                editor.putString("cc", userData.countryCode);
                editor.putString("mob", userData.mobileNumber);
                editor.putString("pass", userData.password);
                editor.putString("pi", userData.profileImage);
                editor.putString("co", userData.createdOn);
                editor.putString("uo", userData.updatedOn);
                editor.putString("ub", userData.updatedBy);
                editor.putString("is", userData.isStatus);
                editor.putString("ge", userData.gender);
                editor.putInt("lp", userData.lockPoint);
                editor.putInt("tp", userData.totalPoint);
                editor.putInt("bp", userData.bidPoint);
                editor.putInt("wp", userData.winPoint);
                editor.putInt("wlp", userData.withdrawLockPoint);
                editor.putBoolean("login", true);
                editor.apply();
                DatabaseHandler databaseHandler = Login.this.db;
                String string2 = userData.getUserId();
                String string3 = userData.getDisplayName();
                String string4 = userData.getMobileNumber();
                String string5 = userData.getEmailAddress();
                String string6 = userData.getCountryCode();
                String string7 = userData.getGender();
                String string8 = userData.getIsStatus();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(userData.getLockPoint());
                String string9 = stringBuilder.toString();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("");
                stringBuilder2.append(userData.getTotalPoint());
                databaseHandler.addUserDetail(string2, string3, string4, string5, string6, string7, string8, string9, stringBuilder2.toString());
                Login.this.showToast("Login Sucessfully");
                Login.this.sendToNextActivity(Dashboard.class);
                Login.this.finish();
            }
        });
    }

    public void onClick(View view) {
        TextView textView;
        if (view == this.login) {
            if (this.edmobile.getText().toString().trim().length() < 10) {
                this.edmobile.setError((CharSequence)"Please enter valid mobile number");
                this.edmobile.requestFocus();
            } else if (this.edpassword.getText().toString().trim().length() == 0) {
                this.edpassword.setError((CharSequence)"Please enter  password");
                this.edpassword.requestFocus();
            } else {
                this.stmobile = this.edmobile.getText().toString();
                this.stpassword = this.edpassword.getText().toString();
                this.LoginApi();
            }
        }
        if (view == this.tvsignup) {
            this.sendToNextActivity(SignupFirst.class);
        }
        if (view == (textView = this.passshow)) {
            if (textView.getText().toString().equals((Object)"Show")) {
                this.edpassword.setTransformationMethod((TransformationMethod)HideReturnsTransformationMethod.getInstance());
                this.passshow.setText((CharSequence)"Hide");
            } else {
                this.edpassword.setTransformationMethod((TransformationMethod)PasswordTransformationMethod.getInstance());
                this.passshow.setText((CharSequence)"Show");
            }
        }
        if (view == this.forgotpass) {
            this.showForgotPasswordPopup();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492957);
        this.setToolbarName("Login");
        this.db = new DatabaseHandler((Context)this);
        this.mUserDataRepository = UserDataRepository.getInstance((Context)this);
        this.init();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void showForgotPasswordPopup() {
        void var1_23;
        block6 : {
            PopupWindow popupWindow;
            this.OTP = "";
            Rect rect = new Rect();
            this.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
            View view = ((LayoutInflater)this.getSystemService("layout_inflater")).inflate(2131492953, null);
            this.popup = popupWindow = new PopupWindow(view, -1, -1, true);
            popupWindow.setBackgroundDrawable((Drawable)new BitmapDrawable());
            ImageView imageView = (ImageView)view.findViewById(2131296622);
            TextInputLayout textInputLayout = (TextInputLayout)view.findViewById(2131296646);
            TextInputLayout textInputLayout2 = (TextInputLayout)view.findViewById(2131296644);
            TextInputLayout textInputLayout3 = (TextInputLayout)view.findViewById(2131296643);
            TextInputLayout textInputLayout4 = (TextInputLayout)view.findViewById(2131296642);
            LinearLayout linearLayout = (LinearLayout)view.findViewById(2131296645);
            TextView textView = (TextView)view.findViewById(2131296930);
            Button button = (Button)view.findViewById(2131296384);
            EditText editText = (EditText)view.findViewById(2131296520);
            EditText editText2 = (EditText)view.findViewById(2131296519);
            EditText editText3 = (EditText)view.findViewById(2131296518);
            EditText editText4 = (EditText)view.findViewById(2131296517);
            TextView textView2 = (TextView)view.findViewById(2131296383);
            TextView textView3 = (TextView)view.findViewById(2131296385);
            textInputLayout2.setVisibility(8);
            textInputLayout3.setVisibility(8);
            textInputLayout4.setVisibility(8);
            editText2.setEnabled(false);
            editText3.setEnabled(false);
            editText4.setEnabled(false);
            linearLayout.setVisibility(8);
            CountDownTimer countDownTimer = new CountDownTimer(this, 60000L, 1000L, textView, button){
                final /* synthetic */ Login this$0;
                final /* synthetic */ Button val$btnResend;
                final /* synthetic */ TextView val$textCounter;
                {
                    this.this$0 = login;
                    this.val$textCounter = textView;
                    this.val$btnResend = button;
                    super(l, l2);
                }

                public void onFinish() {
                    this.val$textCounter.setVisibility(8);
                    this.val$btnResend.setEnabled(true);
                }

                public void onTick(long l) {
                    TextView textView = this.val$textCounter;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(" In ");
                    stringBuilder.append(l / 1000L);
                    stringBuilder.append(" Second");
                    textView.setText((CharSequence)stringBuilder.toString());
                }
            };
            this.popup.getContentView().setFocusableInTouchMode(true);
            this.popup.getContentView().setOnKeyListener(new View.OnKeyListener(this){
                final /* synthetic */ Login this$0;
                {
                    this.this$0 = login;
                }

                public boolean onKey(View view, int n, android.view.KeyEvent keyEvent) {
                    if (n == 4) {
                        if (this.this$0.popup.isShowing()) {
                            this.this$0.popup.dismiss();
                        }
                        return true;
                    }
                    return false;
                }
            });
            imageView.setOnClickListener(new View.OnClickListener(this){
                final /* synthetic */ Login this$0;
                {
                    this.this$0 = login;
                }

                public void onClick(View view) {
                    if (this.this$0.popup.isShowing()) {
                        this.this$0.popup.dismiss();
                    }
                }
            });
            textView2.setOnClickListener(new View.OnClickListener(this){
                final /* synthetic */ Login this$0;
                {
                    this.this$0 = login;
                }

                public void onClick(View view) {
                    if (this.this$0.popup.isShowing()) {
                        this.this$0.popup.dismiss();
                    }
                }
            });
            try {
                View.OnClickListener onClickListener = new View.OnClickListener(this, textView3, textInputLayout, editText, button, linearLayout, countDownTimer, textInputLayout2, textInputLayout3, textInputLayout4, editText2, editText3, editText4){
                    final /* synthetic */ Login this$0;
                    final /* synthetic */ Button val$btnResend;
                    final /* synthetic */ TextView val$btnUpdate;
                    final /* synthetic */ EditText val$edConformPassword;
                    final /* synthetic */ EditText val$edNewPassword;
                    final /* synthetic */ EditText val$edOTP;
                    final /* synthetic */ EditText val$edUserName;
                    final /* synthetic */ TextInputLayout val$layoutConformPassword;
                    final /* synthetic */ TextInputLayout val$layoutNewPassword;
                    final /* synthetic */ TextInputLayout val$layoutOtp;
                    final /* synthetic */ LinearLayout val$layoutResend;
                    final /* synthetic */ TextInputLayout val$layoutUserName;
                    final /* synthetic */ CountDownTimer val$mCountDownTimer;
                    {
                        this.this$0 = login;
                        this.val$btnUpdate = textView;
                        this.val$layoutUserName = textInputLayout;
                        this.val$edUserName = editText;
                        this.val$btnResend = button;
                        this.val$layoutResend = linearLayout;
                        this.val$mCountDownTimer = countDownTimer;
                        this.val$layoutOtp = textInputLayout2;
                        this.val$layoutNewPassword = textInputLayout3;
                        this.val$layoutConformPassword = textInputLayout4;
                        this.val$edOTP = editText2;
                        this.val$edNewPassword = editText3;
                        this.val$edConformPassword = editText4;
                    }

                    public void onClick(View view) {
                        if (!this.this$0.isInternetOn()) {
                            return;
                        }
                        if (this.val$btnUpdate.getText().toString().contentEquals((CharSequence)"CONTINUE")) {
                            this.val$layoutUserName.setError(null);
                            this.val$layoutUserName.setErrorEnabled(false);
                            if (!com.Royal.Utils.ValidationUtils.isValidPhone(this.val$edUserName.getText().toString())) {
                                this.val$layoutUserName.setErrorEnabled(true);
                                this.val$layoutUserName.setError((CharSequence)"Please input a correct username");
                                return;
                            }
                            this.this$0.showProgress(true);
                            this.this$0.OTP = com.Royal.Utils.OTPUtils.randomOTP(6);
                            this.this$0.mUserDataRepository.sendVerificationCode(this.val$edUserName.getText().toString(), this.this$0.OTP, "", new com.Royal.data.remote.UserDataSource$GetUserOtpCallBack(this){
                                final /* synthetic */ 7 this$1;
                                {
                                    this.this$1 = var1_1;
                                }

                                public void onErrorInLoading(String string2) {
                                    this.this$1.this$0.showProgress(false);
                                    this.this$1.this$0.showToast(string2);
                                }

                                public void onErrorInMobile(String string2) {
                                    this.this$1.this$0.showProgress(false);
                                    this.this$1.val$layoutUserName.setErrorEnabled(true);
                                    this.this$1.val$layoutUserName.setError((CharSequence)string2);
                                }

                                public void onLocked(String string2) {
                                    this.this$1.this$0.showProgress(false);
                                    ScreenUtils.showLockScreen((Activity)this.this$1.this$0);
                                }

                                public void onUserOtpSent(String string2, String string3) {
                                    this.this$1.this$0.showProgress(false);
                                    this.this$1.this$0.showToast(string2);
                                    this.this$1.this$0.userId = string3;
                                    this.this$1.val$btnUpdate.setText((CharSequence)"SUBMIT");
                                    this.this$1.val$btnResend.setEnabled(false);
                                    this.this$1.val$edUserName.setEnabled(false);
                                    this.this$1.val$layoutResend.setVisibility(0);
                                    this.this$1.val$mCountDownTimer.start();
                                    this.this$1.val$layoutOtp.setVisibility(0);
                                    this.this$1.val$layoutNewPassword.setVisibility(0);
                                    this.this$1.val$layoutConformPassword.setVisibility(0);
                                    this.this$1.val$edOTP.setEnabled(true);
                                    this.this$1.val$edNewPassword.setEnabled(true);
                                    this.this$1.val$edConformPassword.setEnabled(true);
                                    this.this$1.val$edOTP.requestFocus();
                                }
                            });
                            return;
                        }
                        if (this.this$0.OTP.contentEquals((CharSequence)this.val$edOTP.getText().toString())) {
                            this.val$layoutOtp.setError(null);
                            this.val$layoutOtp.setErrorEnabled(false);
                            this.val$layoutOtp.setError(null);
                            this.val$layoutNewPassword.setError(null);
                            this.val$layoutConformPassword.setError(null);
                            this.val$layoutOtp.setErrorEnabled(false);
                            this.val$layoutNewPassword.setErrorEnabled(false);
                            this.val$layoutConformPassword.setErrorEnabled(false);
                            if (!this.this$0.OTP.contentEquals((CharSequence)this.val$edOTP.getText().toString())) {
                                this.val$layoutOtp.setErrorEnabled(true);
                                this.val$layoutOtp.setError((CharSequence)"Please Input Correct OTP");
                                this.val$layoutOtp.requestFocus();
                                return;
                            }
                            if (this.val$edNewPassword.getText().toString().length() < 6 && this.val$edNewPassword.getText().toString().length() > 50) {
                                this.val$layoutNewPassword.setErrorEnabled(true);
                                this.val$layoutNewPassword.setError((CharSequence)"Please Input Correct Password");
                                return;
                            }
                            if (!this.val$edConformPassword.getText().toString().contentEquals((CharSequence)this.val$edNewPassword.getText().toString())) {
                                this.val$layoutConformPassword.setErrorEnabled(true);
                                this.val$layoutConformPassword.setError((CharSequence)"Sorry, Password Doesn't Matched");
                                return;
                            }
                            this.this$0.showProgress(true);
                            this.this$0.mUserDataRepository.setNewPassword(this.this$0.userId, this.val$edUserName.getText().toString(), this.val$edNewPassword.getText().toString(), "", new com.Royal.data.remote.UserDataSource$SetNewPasswordCallBack(this){
                                final /* synthetic */ 7 this$1;
                                {
                                    this.this$1 = var1_1;
                                }

                                public void onErrorInLoading(String string2) {
                                    this.this$1.this$0.showProgress(false);
                                    this.this$1.this$0.showToast(string2);
                                }

                                public void onErrorInPassword(String string2) {
                                    this.this$1.this$0.showProgress(false);
                                    this.this$1.val$layoutNewPassword.setErrorEnabled(true);
                                    this.this$1.val$layoutNewPassword.setError((CharSequence)string2);
                                }

                                public void onErrorInUserName(String string2) {
                                    this.this$1.this$0.showProgress(false);
                                    this.this$1.val$layoutUserName.setErrorEnabled(true);
                                    this.this$1.val$layoutUserName.setError((CharSequence)string2);
                                }

                                public void onLocked(String string2) {
                                    this.this$1.this$0.showProgress(false);
                                    ScreenUtils.showLockScreen((Activity)this.this$1.this$0);
                                }

                                public void onSetNewPassword(String string2) {
                                    this.this$1.this$0.showProgress(false);
                                    this.this$1.this$0.showToast(string2);
                                    if (this.this$1.this$0.popup.isShowing()) {
                                        this.this$1.this$0.popup.dismiss();
                                    }
                                }
                            });
                            return;
                        }
                        this.val$layoutOtp.setErrorEnabled(true);
                        this.val$layoutOtp.setError((CharSequence)"Please input correct OTP");
                    }
                };
                textView3.setOnClickListener(onClickListener);
            }
            catch (Exception exception) {}
            try {
                button.setOnClickListener(new View.OnClickListener(this, textInputLayout3, textInputLayout2, textView3){
                    final /* synthetic */ Login this$0;
                    final /* synthetic */ TextView val$btnUpdate;
                    final /* synthetic */ TextInputLayout val$layoutNewPassword;
                    final /* synthetic */ TextInputLayout val$layoutOtp;
                    {
                        this.this$0 = login;
                        this.val$layoutNewPassword = textInputLayout;
                        this.val$layoutOtp = textInputLayout2;
                        this.val$btnUpdate = textView;
                    }

                    public void onClick(View view) {
                        if (!this.this$0.isInternetOn()) {
                            return;
                        }
                        this.val$layoutNewPassword.setError(null);
                        this.val$layoutNewPassword.setErrorEnabled(false);
                        this.val$layoutOtp.setError(null);
                        this.val$layoutOtp.setErrorEnabled(false);
                        this.val$btnUpdate.setText((CharSequence)"CONTINUE");
                        this.val$btnUpdate.performClick();
                    }
                });
                this.popup.showAtLocation(view, 17, 0, 0);
                return;
            }
            catch (Exception exception) {}
            break block6;
            catch (Exception exception) {
                // empty catch block
            }
        }
        var1_23.printStackTrace();
    }

}

