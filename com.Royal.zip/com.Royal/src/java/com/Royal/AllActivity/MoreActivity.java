/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  java.lang.Class
 *  java.lang.String
 */
package com.Royal.AllActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.Royal.AllActivity.AllNews;
import com.Royal.Utilities.BaseAppCompactActivity;

public class MoreActivity
extends BaseAppCompactActivity
implements View.OnClickListener {
    TextView guestform;
    TextView news;

    private void init() {
        this.news = (TextView)this.findViewById(2131296736);
        this.guestform = (TextView)this.findViewById(2131296600);
        this.news.setOnClickListener((View.OnClickListener)this);
    }

    public void onClick(View view) {
        if (view == this.news) {
            this.sendToNextActivity(AllNews.class);
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492979);
        this.setUpToolbarByName("More");
        this.init();
    }
}

