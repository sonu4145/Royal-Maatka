/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.SharedPreferences
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$GetRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import androidx.appcompat.app.AlertDialog;
import com.Royal.AllActivity.SplashActivity;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.data.UserData;
import com.Royal.data.remote.UserDataRepository;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class SplashActivity
extends BaseAppCompactActivity {
    private static final int SPLASH_TIME = 3000;
    String compareversion;
    Handler handler;
    UserDataRepository mUserDataRepository;
    Runnable runnable;
    String version;

    private void GetVersion() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/appSetting/android").addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    SplashActivity.this.showToast("Something went wrong");
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (!jSONObject.getString("status").equals((Object)"true")) {
                            String string2 = jSONObject.getString("error");
                            SplashActivity.this.showToast(string2);
                            return;
                        }
                        SplashActivity.this.compareversion = jSONObject.getString("currentVersion");
                        try {
                            PackageInfo packageInfo = SplashActivity.this.getPackageManager().getPackageInfo(SplashActivity.this.getPackageName(), 0);
                            SplashActivity.this.version = packageInfo.versionName;
                        }
                        catch (PackageManager.NameNotFoundException nameNotFoundException) {
                            nameNotFoundException.printStackTrace();
                        }
                        SharedPreferences sharedPreferences = SplashActivity.this.getSharedPreferences("shared", 0);
                        if (sharedPreferences != null) {
                            UserData userData = UserData.getInstance((Context)SplashActivity.this);
                            userData.setUserId(sharedPreferences.getString("id", ""));
                            CommonParams.userId = sharedPreferences.getString("id", "");
                            userData.setDealerId(sharedPreferences.getString("di", ""));
                            userData.setDisplayName(sharedPreferences.getString("dn", ""));
                            userData.setEmailAddress(sharedPreferences.getString("email", ""));
                            userData.setCountryCode(sharedPreferences.getString("cc", ""));
                            userData.setMobileNumber(sharedPreferences.getString("mob", ""));
                            userData.setPassword(sharedPreferences.getString("pass", ""));
                            userData.setProfileImage(sharedPreferences.getString("pi", ""));
                            userData.setCreatedOn(sharedPreferences.getString("co", ""));
                            userData.setUpdatedOn(sharedPreferences.getString("uo", ""));
                            userData.setUpdatedBy(sharedPreferences.getString("ub", ""));
                            userData.setIsStatus(sharedPreferences.getString("is", ""));
                            userData.setGender(sharedPreferences.getString("ge", ""));
                            userData.setLockPoint(sharedPreferences.getInt("lp", 0));
                            userData.setTotalPoint(sharedPreferences.getInt("tp", 0));
                            userData.setBidPoint(sharedPreferences.getInt("bp", 0));
                            userData.setWinPoint(sharedPreferences.getInt("wp", 0));
                            userData.setWithdrawLockPoint(sharedPreferences.getInt("wlp", 0));
                            userData.setIsLogin(sharedPreferences.getBoolean("login", false));
                            CommonParams.totalpoint = String.valueOf((int)userData.getTotalPoint());
                            BaseAppCompactActivity.myPoints = Long.parseLong((String)String.valueOf((int)userData.getTotalPoint()));
                            CommonParams.lockpoint = String.valueOf((int)userData.getLockPoint());
                        }
                        try {
                            SplashActivity.this.runnable = new Runnable(this){
                                final /* synthetic */ 3 this$1;
                                {
                                    this.this$1 = var1_1;
                                }

                                public void run() {
                                    if (this.this$1.SplashActivity.this.mUserDataRepository.getUserData().getIsLogin() && (this.this$1.SplashActivity.this.version.equals((Object)this.this$1.SplashActivity.this.compareversion) || java.lang.Float.parseFloat((String)this.this$1.SplashActivity.this.version) <= java.lang.Float.parseFloat((String)"1.7"))) {
                                        android.content.Intent intent = new android.content.Intent(this.this$1.SplashActivity.this.getApplicationContext(), com.Royal.AllActivity.Dashboard.class);
                                        this.this$1.SplashActivity.this.startActivity(intent);
                                        this.this$1.SplashActivity.this.overridePendingTransition(2130771983, 2130771980);
                                        this.this$1.SplashActivity.this.finish();
                                        return;
                                    }
                                    if (!this.this$1.SplashActivity.this.version.equals((Object)this.this$1.SplashActivity.this.compareversion) && !(java.lang.Float.parseFloat((String)this.this$1.SplashActivity.this.version) <= java.lang.Float.parseFloat((String)"1.7"))) {
                                        SplashActivity.access$000(this.this$1.SplashActivity.this);
                                        return;
                                    }
                                    android.content.Intent intent = new android.content.Intent(this.this$1.SplashActivity.this.getApplicationContext(), com.Royal.AllActivity.Login.class);
                                    this.this$1.SplashActivity.this.startActivity(intent);
                                    this.this$1.SplashActivity.this.overridePendingTransition(2130771983, 2130771980);
                                    this.this$1.SplashActivity.this.finish();
                                }
                            };
                            SplashActivity.this.handler.postDelayed(SplashActivity.this.runnable, 3000L);
                            return;
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                            return;
                        }
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    static /* synthetic */ void access$000(SplashActivity splashActivity) {
        splashActivity.showUpdateDialog();
    }

    private void showUpdateDialog() {
        new AlertDialog.Builder((Context)this).setTitle((CharSequence)"Update Available").setMessage((CharSequence)"New Version is Available on playstore please update ").setPositiveButton(17039379, new DialogInterface.OnClickListener(this){
            final /* synthetic */ SplashActivity this$0;
            {
                this.this$0 = splashActivity;
            }

            public void onClick(DialogInterface dialogInterface, int n) {
                this.this$0.startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse((String)"market://details?id=com.Royal")));
            }
        }).setNegativeButton(17039369, new DialogInterface.OnClickListener(this){
            final /* synthetic */ SplashActivity this$0;
            {
                this.this$0 = splashActivity;
            }

            public void onClick(DialogInterface dialogInterface, int n) {
                this.this$0.finish();
            }
        }).setIcon(17301543).show();
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493044);
        this.mUserDataRepository = UserDataRepository.getInstance((Context)this);
        this.handler = new Handler();
    }

    protected void onResume() {
        super.onResume();
        this.GetVersion();
    }

    protected void onStart() {
        super.onStart();
    }

}

