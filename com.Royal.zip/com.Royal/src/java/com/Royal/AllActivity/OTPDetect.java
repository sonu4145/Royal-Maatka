/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.graphics.Color
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.Button
 *  android.widget.TextView
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import com.Royal.AllActivity.AppLockActivity;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.OTPDetect;
import com.Royal.AllActivity.SignupSecond;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.DatabaseHandler;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.remote.UserDataRepository;
import com.Royal.data.remote.UserDataSource;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.hololo.library.otpview.OTPListener;
import com.hololo.library.otpview.OTPView;
import com.stfalcon.smsverifycatcher.OnSmsCatchListener;
import com.stfalcon.smsverifycatcher.SmsVerifyCatcher;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class OTPDetect
extends BaseAppCompactActivity
implements View.OnClickListener {
    DatabaseHandler db;
    String decryptstring;
    String encryptstring;
    JSONObject inputjson;
    UserDataRepository mUserDataRepository;
    OTPView otpView;
    JSONObject resendjson;
    TextView resendotp;
    private SmsVerifyCatcher smsVerifyCatcher;
    String stdailcode;
    String stmobile;
    String stname;
    String stotp;
    String stpassword;
    TextView tvmobile;
    Button verify;

    private void SignupApi2() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/registration").addBodyParameter("postData", this.encryptstring).setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    OTPDetect.this.showToast("Something went wrong");
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        String string2 = jSONObject.getString("data");
                        OTPDetect.this.decryptstring = OTPDetect.this.decryptjson(string2);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("n");
                        stringBuilder.append(OTPDetect.this.decryptstring);
                        Log.e((String)"decript", (String)stringBuilder.toString());
                        JSONObject jSONObject2 = new JSONObject(OTPDetect.this.decryptstring);
                        boolean bl = jSONObject2.getString("status").equals((Object)"true");
                        if (bl) {
                            if (jSONObject2.getString("lock").equals((Object)"true")) {
                                OTPDetect.this.sendToNextActivity(AppLockActivity.class);
                                OTPDetect.this.finish();
                                return;
                            }
                            String string3 = jSONObject2.getString("id");
                            String string4 = jSONObject2.getString("name");
                            String string5 = jSONObject2.getString("mobile");
                            String string6 = jSONObject2.getString("email");
                            String string7 = jSONObject2.getString("dailCode");
                            String string8 = jSONObject2.getString("gender");
                            String string9 = jSONObject2.getString("isStatus");
                            String string10 = jSONObject2.getString("lockPoint");
                            String string11 = jSONObject2.getString("totalPoint");
                            OTPDetect.this.db.addUserDetail(string3, string4, string5, string6, string7, string8, string9, string10, string11);
                            OTPDetect.this.sendToNextActivity(SignupSecond.class);
                            OTPDetect.this.finish();
                            return;
                        }
                        if (jSONObject2.getString("lock").equals((Object)"true")) {
                            OTPDetect.this.sendToNextActivity(AppLockActivity.class);
                            OTPDetect.this.finish();
                        }
                        String string12 = jSONObject2.getString("error");
                        OTPDetect.this.showToast(string12);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void init() {
        this.tvmobile = (TextView)this.findViewById(2131297009);
        this.verify = (Button)this.findViewById(2131297033);
        this.resendotp = (TextView)this.findViewById(2131296804);
        this.verify.setOnClickListener((View.OnClickListener)this);
        this.resendotp.setOnClickListener((View.OnClickListener)this);
        Intent intent = this.getIntent();
        this.stname = intent.getStringExtra("name");
        this.stmobile = intent.getStringExtra("mobile");
        this.stdailcode = intent.getStringExtra("dailcode");
        this.stpassword = intent.getStringExtra("password");
        this.stotp = intent.getStringExtra("otp");
        String string2 = this.stmobile;
        char c = string2.charAt(0);
        string2.charAt(1);
        string2.charAt(2);
        string2.charAt(3);
        string2.charAt(4);
        string2.charAt(5);
        string2.charAt(6);
        string2.charAt(7);
        char c2 = string2.charAt(8);
        char c3 = string2.charAt(9);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(c);
        stringBuilder.append("*******");
        stringBuilder.append(c2);
        stringBuilder.append(c3);
        String string3 = stringBuilder.toString();
        this.tvmobile.setText((CharSequence)string3);
    }

    private void makeresendjson() {
        JSONObject jSONObject;
        this.resendjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("mobile", (Object)this.stmobile);
            this.resendjson.put("otp", (Object)this.stotp);
            this.resendjson.put("dailCode", (Object)"91");
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("name", (Object)this.stname);
            this.inputjson.put("password", (Object)this.stpassword);
            this.inputjson.put("mobile", (Object)this.stmobile);
            this.inputjson.put("dailCode", (Object)"91");
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private String parseCode(String string2) {
        Matcher matcher = Pattern.compile((String)"\\b\\d{6}\\b").matcher((CharSequence)string2);
        String string3 = "";
        while (matcher.find()) {
            string3 = matcher.group(0);
        }
        return string3;
    }

    public void OTPAPI() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mUserDataRepository.sendOtpMsg(this.stmobile, this.stotp, "mobile", new UserDataSource.GetUserOtpCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                OTPDetect.this.showProgress(false);
                OTPDetect.this.showToast(string2);
            }

            @Override
            public void onErrorInMobile(String string2) {
                OTPDetect.this.showProgress(false);
                OTPDetect.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                OTPDetect.this.showProgress(false);
                ScreenUtils.showLockScreen((Activity)OTPDetect.this);
            }

            @Override
            public void onUserOtpSent(String string2, String string3) {
                OTPDetect.this.showToast(string2);
                OTPDetect.this.showProgress(false);
            }
        });
    }

    public void SignupApi() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mUserDataRepository.registerNewUser(this.stname, this.stdailcode, this.stmobile, this.stpassword, new UserDataSource.GetUserRegistrationCallBack(){

            @Override
            public void onErrorInCountryCode(String string2) {
                OTPDetect.this.showProgress(false);
                OTPDetect.this.showToast(string2);
            }

            @Override
            public void onErrorInLoading(String string2) {
                OTPDetect.this.showProgress(false);
                OTPDetect.this.showToast(string2);
            }

            @Override
            public void onErrorInMobileNumber(String string2) {
                OTPDetect.this.showProgress(false);
                OTPDetect.this.showToast(string2);
            }

            @Override
            public void onErrorInName(String string2) {
                OTPDetect.this.showProgress(false);
                OTPDetect.this.showToast(string2);
            }

            @Override
            public void onErrorInPassword(String string2) {
                OTPDetect.this.showProgress(false);
                OTPDetect.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                OTPDetect.this.showProgress(false);
                ScreenUtils.showLockScreen((Activity)OTPDetect.this);
            }

            @Override
            public void onUserRegisteredSuccessFully(String string2) {
                OTPDetect.this.showProgress(false);
                OTPDetect.this.showToast(string2);
                View view = LayoutInflater.from((Context)OTPDetect.this).inflate(2131493070, null);
                TextView textView = (TextView)view.findViewById(2131296963);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Welcome To Royal Matka - Official Play Online App\n\nTo Add Points in Your wallet Kindly\nCall / Whatsapp Us On\n");
                stringBuilder.append(Dashboard.phone);
                stringBuilder.append("\n\nGame Rates :\n\nSingle Ank 10 Rs = 90 Rs\nJodi 10 Rs = 950 Rs\nSingle Pana 10 Rs = 1400 Rs\nDouble Pana 10 Rs = 2800 Rs\nTriple Pana 10 Rs = 6000 Rs\nHalf Sangam 10 Rs = 10000 Rs\nFull Sangam 10 Rs = 100000 Rs\n\nMinimum Deposit : 1000/- Rs\nMinimum Withdrawal : 1000/-  Rs\n\nWithdraws 24 Hours Available\n\nFor More Information Call On +91 8181883355\n\nBest Of Luck !!!");
                textView.setText((CharSequence)stringBuilder.toString());
                AlertDialog.Builder builder = new AlertDialog.Builder((Context)OTPDetect.this);
                builder.setView(view);
                builder.setPositiveButton((CharSequence)"OK", new DialogInterface.OnClickListener(this){
                    final /* synthetic */ 3 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void onClick(DialogInterface dialogInterface, int n) {
                        ScreenUtils.showLoginScreen((Activity)this.this$1.OTPDetect.this);
                    }
                });
                builder.create().show();
            }
        });
    }

    public void onClick(View view) {
        if (view == this.verify) {
            if (this.otpView.getOtp().toString().trim().length() == 0) {
                this.showToast("please enter otp");
            } else if (!this.otpView.getOtp().toString().equals((Object)this.stotp)) {
                this.showToast("Otp does not match");
            } else {
                this.makesimplejson();
                this.encryptstring = this.encryptjson(this.inputjson.toString());
                this.SignupApi();
            }
        }
        if (view == this.resendotp) {
            this.makeresendjson();
            this.encryptstring = this.encryptjson(this.resendjson.toString());
            this.OTPAPI();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        OTPView oTPView;
        SmsVerifyCatcher smsVerifyCatcher;
        super.onCreate(bundle);
        this.setContentView(2131493021);
        this.setUpToolbarByName("Confirmation");
        this.mUserDataRepository = UserDataRepository.getInstance((Context)this);
        this.db = new DatabaseHandler((Context)this);
        this.init();
        this.otpView = oTPView = (OTPView)this.findViewById(2131296762);
        oTPView.setTextColor(Color.parseColor((String)"#0e8123")).setHintColor(2131034170).setCount(6).setInputType(2).setViewsPadding(22).setListener(new OTPListener(){

            @Override
            public void otpFinished(String string2) {
            }
        }).fillLayout();
        this.smsVerifyCatcher = smsVerifyCatcher = new SmsVerifyCatcher((Activity)this, new OnSmsCatchListener<String>(){

            @Override
            public void onSmsCatch(String string2) {
                String string3 = OTPDetect.this.parseCode(string2);
                OTPDetect.this.otpView.setOtp(string3);
            }
        });
        smsVerifyCatcher.setPhoneNumberFilter("IM-Maatka");
    }

    public void onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
        super.onRequestPermissionsResult(n, arrstring, arrn);
        this.smsVerifyCatcher.onRequestPermissionsResult(n, arrstring, arrn);
    }

    protected void onStart() {
        super.onStart();
        this.smsVerifyCatcher.onStart();
    }

    protected void onStop() {
        super.onStop();
        this.smsVerifyCatcher.onStop();
    }

}

