/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.Royal.AllActivity.AppLockActivity;
import com.Royal.AllActivity.Dashboard;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class RegisterFinal
extends BaseAppCompactActivity
implements View.OnClickListener {
    TextView accounttxt;
    String decryptstring;
    String encryptstring;
    JSONObject inputjson;
    Button register;
    TextView skip;
    Spinner spinner;
    Button submit;
    EditText walletno;
    TextView wallettxt;
    EditText walletuser_name;

    private void AddAcount() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/account/add-new").addBodyParameter("postData", this.encryptstring).setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    RegisterFinal.this.showToast("Something went wrong");
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        String string2 = jSONObject.getString("data");
                        RegisterFinal.this.decryptstring = RegisterFinal.this.decryptjson(string2);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("n");
                        stringBuilder.append(RegisterFinal.this.decryptstring);
                        Log.e((String)"decript", (String)stringBuilder.toString());
                        JSONObject jSONObject2 = new JSONObject(RegisterFinal.this.decryptstring);
                        boolean bl = jSONObject2.getString("status").equals((Object)"true");
                        if (bl) {
                            if (jSONObject2.getString("lock").equals((Object)"true")) {
                                RegisterFinal.this.sendToNextActivity(AppLockActivity.class);
                                RegisterFinal.this.finish();
                                return;
                            }
                            RegisterFinal.this.showToast("Your Account Added Sucessfully");
                            RegisterFinal.this.sendToNextActivity(Dashboard.class);
                            RegisterFinal.this.finish();
                            return;
                        }
                        if (jSONObject2.getString("lock").equals((Object)"true")) {
                            RegisterFinal.this.sendToNextActivity(AppLockActivity.class);
                            RegisterFinal.this.finish();
                        }
                        String string3 = jSONObject2.getString("error");
                        RegisterFinal.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void init() {
        Button button;
        this.register = (Button)this.findViewById(2131296893);
        this.accounttxt = (TextView)this.findViewById(2131296310);
        this.wallettxt = (TextView)this.findViewById(2131297051);
        this.skip = (TextView)this.findViewById(2131296858);
        this.register.setOnClickListener((View.OnClickListener)this);
        this.skip.setOnClickListener((View.OnClickListener)this);
        this.spinner = (Spinner)this.findViewById(2131296305);
        this.walletuser_name = (EditText)this.findViewById(2131296546);
        this.walletno = (EditText)this.findViewById(2131296545);
        this.submit = button = (Button)this.findViewById(2131296893);
        button.setOnClickListener((View.OnClickListener)this);
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])CommonParams.walletname);
        this.spinner.setAdapter((SpinnerAdapter)arrayAdapter);
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("type", (Object)"wallet");
            this.inputjson.put("accountName", (Object)this.spinner.getSelectedItem().toString());
            this.inputjson.put("accountNumber", (Object)this.walletno.getText().toString());
            this.inputjson.put("accountHolderName", (Object)this.walletuser_name.getText().toString());
            this.inputjson.put("branchName", (Object)"");
            this.inputjson.put("ifscCode", (Object)"");
            this.inputjson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void onClick(View view) {
        if (view == this.register) {
            if (this.spinner.getSelectedItem().toString().equals((Object)"Select Account Name")) {
                this.showToast("Please select account name");
            } else if (this.walletuser_name.getText().toString().trim().length() == 0) {
                this.walletuser_name.setError((CharSequence)"Please enter user name");
                this.walletuser_name.requestFocus();
            } else if (this.walletno.getText().toString().trim().length() < 6) {
                this.walletno.setError((CharSequence)"Please enter wallet no");
                this.walletno.requestFocus();
            } else {
                this.makesimplejson();
                this.encryptstring = this.encryptjson(this.inputjson.toString());
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(this.inputjson.toString());
                Log.e((String)"data", (String)stringBuilder.toString());
                this.AddAcount();
            }
        }
        if (view == this.skip) {
            this.sendToNextActivity(Dashboard.class);
            this.finish();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493029);
        this.init();
    }

}

