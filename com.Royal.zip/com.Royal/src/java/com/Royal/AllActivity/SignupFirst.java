/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.method.HideReturnsTransformationMethod
 *  android.text.method.PasswordTransformationMethod
 *  android.text.method.TransformationMethod
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.CheckBox
 *  android.widget.EditText
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.core.app.ActivityCompat
 *  androidx.core.content.ContextCompat
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.Royal.AllActivity.Login;
import com.Royal.AllActivity.OTPDetect;
import com.Royal.AllActivity.SignupFirst;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utils.OTPUtils;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.remote.UserDataRepository;
import com.Royal.data.remote.UserDataSource;
import org.json.JSONObject;

public class SignupFirst
extends BaseAppCompactActivity
implements View.OnClickListener {
    private static final int PERMISSION_REQUEST_CODE = 1;
    TextView accounttxt;
    String[] countryCodes = new String[]{"91", "92", "93", "94", "95", "960", "965", "967", "968", "971", "973", "974", "975", "977"};
    TextView cpassshow;
    String decryptstring;
    EditText edconpassword;
    EditText edmobile;
    EditText edname;
    EditText edpassword;
    String encryptstring;
    JSONObject inputjson;
    UserDataRepository mUserDataRepository;
    Button next;
    TextView passshow;
    Spinner spCountryCode;
    String stdailcode;
    String stmobile;
    String stname;
    String stotp;
    String stpassword;
    CheckBox terms;
    TextView termstext;
    TextView tvlogin;

    private void checkPermissionForApps() {
        int n = ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.RECEIVE_MMS");
        int n2 = ContextCompat.checkSelfPermission((Context)this, (String)"android.permission.READ_SMS");
        if (n == -1 || n2 == -1) {
            ActivityCompat.requestPermissions((Activity)this, (String[])new String[]{"android.permission.RECEIVE_MMS", "android.permission.READ_SMS"}, (int)1);
        }
    }

    private void init() {
        Spinner spinner;
        this.next = (Button)this.findViewById(2131296738);
        this.tvlogin = (TextView)this.findViewById(2131297008);
        this.passshow = (TextView)this.findViewById(2131296855);
        this.cpassshow = (TextView)this.findViewById(2131296462);
        this.edpassword = (EditText)this.findViewById(2131296540);
        this.edconpassword = (EditText)this.findViewById(2131296527);
        this.edname = (EditText)this.findViewById(2131297032);
        this.edmobile = (EditText)this.findViewById(2131296535);
        this.spCountryCode = spinner = (Spinner)this.findViewById(2131296528);
        spinner.setVisibility(8);
        this.accounttxt = (TextView)this.findViewById(2131296310);
        this.terms = (CheckBox)this.findViewById(2131296917);
        this.termstext = (TextView)this.findViewById(2131296918);
        this.next.setOnClickListener((View.OnClickListener)this);
        this.tvlogin.setOnClickListener((View.OnClickListener)this);
        this.passshow.setOnClickListener((View.OnClickListener)this);
        this.cpassshow.setOnClickListener((View.OnClickListener)this);
        this.termstext.setOnClickListener((View.OnClickListener)this);
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, (Object[])this.countryCodes);
        arrayAdapter.setDropDownViewResource(2131492951);
        this.spCountryCode.setAdapter((SpinnerAdapter)arrayAdapter);
        this.stdailcode = this.countryCodes[0];
        this.spCountryCode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(this){
            final /* synthetic */ SignupFirst this$0;
            {
                this.this$0 = signupFirst;
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                SignupFirst signupFirst = this.this$0;
                signupFirst.stdailcode = signupFirst.countryCodes[n];
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    public void OTPAPI() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mUserDataRepository.sendOtpMsg(this.stmobile, this.stotp, "mobile", new UserDataSource.GetUserOtpCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                SignupFirst.this.showProgress(false);
                SignupFirst.this.showToast(string2);
            }

            @Override
            public void onErrorInMobile(String string2) {
                SignupFirst.this.showProgress(false);
                SignupFirst.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                SignupFirst.this.showProgress(false);
                ScreenUtils.showLockScreen((Activity)SignupFirst.this);
            }

            @Override
            public void onUserOtpSent(String string2, String string3) {
                SignupFirst.this.showToast(string2);
                SignupFirst.this.showProgress(false);
                Intent intent = new Intent(SignupFirst.this.getApplicationContext(), OTPDetect.class);
                intent.putExtra("name", SignupFirst.this.stname);
                intent.putExtra("mobile", SignupFirst.this.stmobile);
                intent.putExtra("dailcode", "91");
                intent.putExtra("password", SignupFirst.this.stpassword);
                intent.putExtra("otp", SignupFirst.this.stotp);
                SignupFirst.this.startActivity(intent);
            }
        });
    }

    public void onClick(View view) {
        TextView textView;
        TextView textView2;
        if (view == this.next) {
            if (this.edname.getText().toString().trim().length() == 0) {
                this.edname.setError((CharSequence)"Please enter valid name");
                this.edname.requestFocus();
            } else if (this.edmobile.getText().toString().trim().length() < 10) {
                this.edmobile.setError((CharSequence)"Please enter valid mobile number");
                this.edmobile.requestFocus();
            } else if (this.edpassword.getText().toString().trim().length() < 6) {
                this.edpassword.setError((CharSequence)"Password should be minimum 6 character");
                this.edpassword.requestFocus();
            } else if (this.edconpassword.getText().toString().trim().length() < 6) {
                this.edconpassword.setError((CharSequence)"Password should be minimum 6 character");
                this.edconpassword.requestFocus();
            } else if (!this.edpassword.getText().toString().equals((Object)this.edconpassword.getText().toString())) {
                this.edconpassword.setError((CharSequence)"The confirm password field does not match the password field.");
                this.edconpassword.requestFocus();
            } else {
                this.stname = this.edname.getText().toString();
                this.stmobile = this.edmobile.getText().toString();
                this.stpassword = this.edpassword.getText().toString();
                this.stotp = OTPUtils.randomOTP(6);
                this.OTPAPI();
            }
        }
        if (view == this.tvlogin) {
            this.sendToNextActivity(Login.class);
            this.finish();
        }
        if (view == (textView2 = this.passshow)) {
            if (textView2.getText().toString().equals((Object)"Show")) {
                this.edpassword.setTransformationMethod((TransformationMethod)HideReturnsTransformationMethod.getInstance());
                this.passshow.setText((CharSequence)"Hide");
            } else {
                this.edpassword.setTransformationMethod((TransformationMethod)PasswordTransformationMethod.getInstance());
                this.passshow.setText((CharSequence)"Show");
            }
        }
        if (view == (textView = this.cpassshow)) {
            if (textView.getText().toString().equals((Object)"Show")) {
                this.edconpassword.setTransformationMethod((TransformationMethod)HideReturnsTransformationMethod.getInstance());
                this.cpassshow.setText((CharSequence)"Hide");
            } else {
                this.edconpassword.setTransformationMethod((TransformationMethod)PasswordTransformationMethod.getInstance());
                this.cpassshow.setText((CharSequence)"Show");
            }
        }
        if (view == this.termstext) {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse((String)"http://project.avengingsecurity.com/superstarmatka/web/term-and-condition"));
            this.startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493030);
        this.mUserDataRepository = UserDataRepository.getInstance((Context)this);
        this.init();
        this.checkPermissionForApps();
    }

    public void onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
        super.onRequestPermissionsResult(n, arrstring, arrn);
        if (n == 1) {
            if (arrn.length > 0 && arrn[0] == 0) {
                Log.e((String)"aftergranted", (String)"granted");
                return;
            }
            Log.e((String)"alreadygranted", (String)"granted");
            return;
        }
        Toast.makeText((Context)this, (CharSequence)"something happen wrong", (int)0).show();
    }

}

