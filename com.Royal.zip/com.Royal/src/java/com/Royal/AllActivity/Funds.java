/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.String
 */
package com.Royal.AllActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.Funds;
import com.Royal.Utilities.BaseAppCompactActivity;

public class Funds
extends BaseAppCompactActivity {
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492892);
        this.setUpToolbarByName("Funds");
        ((TextView)this.findViewById(2131296689)).setText((CharSequence)Dashboard.phone);
        this.findViewById(2131297011).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ Funds this$0;
            {
                this.this$0 = funds;
            }

            public void onClick(View view) {
                this.this$0.sendToNextActivity(com.Royal.AllActivity.DepositPoint.class);
            }
        });
        this.findViewById(2131297023).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ Funds this$0;
            {
                this.this$0 = funds;
            }

            public void onClick(View view) {
                this.this$0.sendToNextActivity(com.Royal.AllActivity.WidthrawPoint.class);
            }
        });
        this.findViewById(2131297022).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ Funds this$0;
            {
                this.this$0 = funds;
            }

            public void onClick(View view) {
                this.this$0.sendToNextActivity(com.Royal.AllActivity.TransferPoint.class);
            }
        });
        this.findViewById(2131297018).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ Funds this$0;
            {
                this.this$0 = funds;
            }

            public void onClick(View view) {
                this.this$0.sendToNextActivity(com.Royal.AllActivity.PointHistory.class);
            }
        });
    }
}

