/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Color
 *  android.os.Bundle
 *  android.text.Html
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.cardview.widget.CardView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.LockPointHistoryDetail;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class LockPointHistoryDetail
extends BaseAppCompactActivity {
    TextView accdetailtxt;
    TextView accountholdername;
    TextView accountname;
    TextView accountnumber;
    ImageView cancelwithdraw;
    CardView cardView;
    TextView datetime;
    String decryptstring;
    TextView detailtxt;
    String encryptstring;
    JSONObject inputjson;
    TextView requestedon;
    TextView toptxt;
    String transaction_id;
    TextView transactiondate;
    TextView transactionid;
    TextView transfer_point;
    TextView tvstatus;

    private void CancelWithdraw() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userPoint/withdrawCancel").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    LockPointHistoryDetail.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            LockPointHistoryDetail.this.showToast("Cancelled request");
                            LockPointHistoryDetail.this.sendToNextActivity(Dashboard.class);
                            LockPointHistoryDetail.this.finish();
                            return;
                        }
                        String string2 = jSONObject.getString("error");
                        LockPointHistoryDetail.this.showToast(string2);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void PointTransfer() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userPoint/lockHistoryDetail").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    LockPointHistoryDetail.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            LockPointHistoryDetail.this.cardView.setVisibility(0);
                            LockPointHistoryDetail.this.transfer_point.setText((CharSequence)jSONObject.getString("point"));
                            String string2 = LockPointHistoryDetail.getFormatedDateTime(jSONObject.getString("createdOn"), "yyy-MM-dd HH:mm:ss", "EEEE dd-MMM-yyy hh:mm a");
                            LockPointHistoryDetail.this.datetime.setText((CharSequence)string2);
                            LockPointHistoryDetail.this.tvstatus.setText((CharSequence)jSONObject.getString("isStatus"));
                            if (jSONObject.getString("isStatus").equals((Object)"decline")) {
                                LockPointHistoryDetail.this.tvstatus.setBackgroundColor(Color.parseColor((String)"#DC3545"));
                            }
                            if (jSONObject.getString("isStatus").equals((Object)"success")) {
                                LockPointHistoryDetail.this.tvstatus.setBackgroundColor(Color.parseColor((String)"#0e8123"));
                            }
                            if (jSONObject.getString("isStatus").equals((Object)"pending")) {
                                LockPointHistoryDetail.this.tvstatus.setBackgroundColor(Color.parseColor((String)"#17A2B8"));
                            }
                            TextView textView = LockPointHistoryDetail.this.requestedon;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("<b>Requested On</b><br>");
                            stringBuilder.append(string2);
                            textView.setText((CharSequence)Html.fromHtml((String)stringBuilder.toString()));
                            if (!jSONObject.getString("transactionId").equals((Object)"null")) {
                                TextView textView2 = LockPointHistoryDetail.this.transactionid;
                                StringBuilder stringBuilder2 = new StringBuilder();
                                stringBuilder2.append("<b>Transaction Id</b><br>");
                                stringBuilder2.append(jSONObject.getString("transactionId"));
                                textView2.setText((CharSequence)Html.fromHtml((String)stringBuilder2.toString()));
                            } else {
                                LockPointHistoryDetail.this.transactionid.setVisibility(8);
                            }
                            if (!jSONObject.getString("transactionDate").equals((Object)"null")) {
                                TextView textView3 = LockPointHistoryDetail.this.transactiondate;
                                StringBuilder stringBuilder3 = new StringBuilder();
                                stringBuilder3.append("<b>Transaction Date</b><br>");
                                stringBuilder3.append(jSONObject.getString("transactionDate"));
                                textView3.setText((CharSequence)Html.fromHtml((String)stringBuilder3.toString()));
                            } else {
                                LockPointHistoryDetail.this.transactiondate.setVisibility(8);
                            }
                            TextView textView4 = LockPointHistoryDetail.this.accountname;
                            StringBuilder stringBuilder4 = new StringBuilder();
                            stringBuilder4.append("<b>Account Name</b><br>");
                            stringBuilder4.append(jSONObject.getString("accountName"));
                            textView4.setText((CharSequence)Html.fromHtml((String)stringBuilder4.toString()));
                            TextView textView5 = LockPointHistoryDetail.this.accountnumber;
                            StringBuilder stringBuilder5 = new StringBuilder();
                            stringBuilder5.append("<b>Account Number</b><br>");
                            stringBuilder5.append(jSONObject.getString("accountNumber"));
                            textView5.setText((CharSequence)Html.fromHtml((String)stringBuilder5.toString()));
                            TextView textView6 = LockPointHistoryDetail.this.accountholdername;
                            StringBuilder stringBuilder6 = new StringBuilder();
                            stringBuilder6.append("<b>Account Holder name</b><br>");
                            stringBuilder6.append(jSONObject.getString("accountHolderName"));
                            textView6.setText((CharSequence)Html.fromHtml((String)stringBuilder6.toString()));
                            return;
                        }
                        String string3 = jSONObject.getString("error");
                        LockPointHistoryDetail.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    static /* synthetic */ void access$000(LockPointHistoryDetail lockPointHistoryDetail) {
        lockPointHistoryDetail.CancelWithdraw();
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    private void init() {
        this.toptxt = (TextView)this.findViewById(2131296605);
        this.datetime = (TextView)this.findViewById(2131296471);
        this.tvstatus = (TextView)this.findViewById(2131296889);
        this.transfer_point = (TextView)this.findViewById(2131296993);
        this.detailtxt = (TextView)this.findViewById(2131296992);
        this.requestedon = (TextView)this.findViewById(2131296803);
        this.transactionid = (TextView)this.findViewById(2131296991);
        this.transactiondate = (TextView)this.findViewById(2131296990);
        this.accdetailtxt = (TextView)this.findViewById(2131296483);
        this.accountname = (TextView)this.findViewById(2131296308);
        this.accountnumber = (TextView)this.findViewById(2131296309);
        this.accountholdername = (TextView)this.findViewById(2131296307);
        this.cancelwithdraw = (ImageView)this.findViewById(2131296396);
        this.cardView = (CardView)this.findViewById(2131296415);
        Intent intent = this.getIntent();
        this.transaction_id = intent.getStringExtra("id");
        if (intent.getStringExtra("cancel").equals((Object)"yes")) {
            this.cancelwithdraw.setVisibility(0);
        }
        this.cancelwithdraw.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ LockPointHistoryDetail this$0;
            {
                this.this$0 = lockPointHistoryDetail;
            }

            public void onClick(View view) {
                LockPointHistoryDetail.access$000(this.this$0);
            }
        });
        this.makesimplejson();
        this.encryptstring = this.encryptjson(this.inputjson.toString());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.inputjson.toString());
        Log.e((String)"encrypt", (String)stringBuilder.toString());
        this.PointTransfer();
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("userId", (Object)CommonParams.userId);
            this.inputjson.put("detailId", (Object)this.transaction_id);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492955);
        this.setUpToolbarByName("Transaction History");
        this.init();
    }

}

