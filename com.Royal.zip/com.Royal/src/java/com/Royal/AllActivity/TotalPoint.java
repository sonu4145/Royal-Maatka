/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import com.Royal.AllActivity.TotalPoint;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class TotalPoint
extends BaseAppCompactActivity {
    String decryptstring;
    String encryptstring;
    JSONObject inputjson;
    TextView lock_point;
    String stemail;
    String stname;
    String stuserId;
    TextView total_point;

    private void GetPoint() {
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/point").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

            public void onError(ANError aNError) {
                progressDialog.dismiss();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(aNError.getErrorDetail());
                Log.d((String)"error", (String)stringBuilder.toString());
                TotalPoint.this.showToast("Something went wrong");
            }

            public void onResponse(JSONObject jSONObject) {
                progressDialog.dismiss();
                Log.e((String)"Api_response", (String)jSONObject.toString());
                try {
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        String string2 = jSONObject.getString("totalPoint");
                        String string3 = jSONObject.getString("lockPoint");
                        jSONObject.getString("bidPoint");
                        jSONObject.getString("winPoint");
                        TotalPoint.this.total_point.setText((CharSequence)string2);
                        TotalPoint.this.lock_point.setText((CharSequence)string3);
                        return;
                    }
                    jSONObject.getString("error");
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    private void makepointjson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493064);
        this.setUpToolbarByName("Your Point");
        this.total_point = (TextView)this.findViewById(2131296984);
        this.lock_point = (TextView)this.findViewById(2131296658);
        this.findViewById(2131297021).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ TotalPoint this$0;
            {
                this.this$0 = totalPoint;
            }

            public void onClick(View view) {
                this.this$0.sendToNextActivity(com.Royal.AllActivity.TransferPoint.class);
            }
        });
        this.makepointjson();
        this.encryptstring = this.encryptjson(this.inputjson.toString());
        this.GetPoint();
    }

}

