/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.Royal.AllActivity.AppLockActivity;
import com.Royal.AllActivity.Login;
import com.Royal.AllActivity.RegisterFinal;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class SignupSecond
extends BaseAppCompactActivity
implements View.OnClickListener {
    EditText acchodername;
    EditText accountno;
    TextView accounttxt;
    Spinner bankname;
    EditText branchname;
    String decryptstring;
    String encryptstring;
    EditText ifscno;
    JSONObject inputjson;
    Button next;
    TextView personaltxt;
    TextView skip;
    Button submit;
    TextView tvlogin;

    private void AddAcount() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/account/add-new").addBodyParameter("postData", this.encryptstring).setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    SignupSecond.this.showToast("Something went wrong");
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        String string2 = jSONObject.getString("data");
                        SignupSecond.this.decryptstring = SignupSecond.this.decryptjson(string2);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("n");
                        stringBuilder.append(SignupSecond.this.decryptstring);
                        Log.e((String)"decript", (String)stringBuilder.toString());
                        JSONObject jSONObject2 = new JSONObject(SignupSecond.this.decryptstring);
                        boolean bl = jSONObject2.getString("status").equals((Object)"true");
                        if (bl) {
                            if (jSONObject2.getString("lock").equals((Object)"true")) {
                                SignupSecond.this.sendToNextActivity(AppLockActivity.class);
                                SignupSecond.this.finish();
                                return;
                            }
                            SignupSecond.this.showToast("Your Account Added Sucessfully");
                            SignupSecond.this.sendToNextActivity(RegisterFinal.class);
                            SignupSecond.this.finish();
                            return;
                        }
                        if (jSONObject2.getString("lock").equals((Object)"true")) {
                            SignupSecond.this.sendToNextActivity(AppLockActivity.class);
                            SignupSecond.this.finish();
                        }
                        String string3 = jSONObject2.getString("error");
                        SignupSecond.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void init() {
        Button button;
        this.next = (Button)this.findViewById(2131296738);
        this.tvlogin = (TextView)this.findViewById(2131297008);
        this.accounttxt = (TextView)this.findViewById(2131296310);
        this.personaltxt = (TextView)this.findViewById(2131296362);
        this.skip = (TextView)this.findViewById(2131296858);
        this.next.setOnClickListener((View.OnClickListener)this);
        this.tvlogin.setOnClickListener((View.OnClickListener)this);
        this.skip.setOnClickListener((View.OnClickListener)this);
        this.bankname = (Spinner)this.findViewById(2131296361);
        this.acchodername = (EditText)this.findViewById(2131296521);
        this.accountno = (EditText)this.findViewById(2131296522);
        this.branchname = (EditText)this.findViewById(2131296524);
        this.ifscno = (EditText)this.findViewById(2131296531);
        this.submit = button = (Button)this.findViewById(2131296738);
        button.setOnClickListener((View.OnClickListener)this);
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367043, (Object[])CommonParams.bankname);
        this.bankname.setAdapter((SpinnerAdapter)arrayAdapter);
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("type", (Object)"bank");
            this.inputjson.put("accountName", (Object)this.bankname.getSelectedItem().toString());
            this.inputjson.put("accountNumber", (Object)this.accountno.getText().toString());
            this.inputjson.put("accountHolderName", (Object)this.acchodername.getText().toString());
            this.inputjson.put("branchName", (Object)this.branchname.getText().toString());
            this.inputjson.put("ifscCode", (Object)this.ifscno.getText().toString());
            this.inputjson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void onClick(View view) {
        if (view == this.next) {
            if (this.bankname.getSelectedItem().toString().equals((Object)"Select Bank Name")) {
                this.showToast("Please select bank name");
            } else if (this.acchodername.getText().toString().trim().length() == 0) {
                this.acchodername.setError((CharSequence)"Please enter Account Holder Name");
                this.acchodername.requestFocus();
            } else if (this.accountno.getText().toString().trim().length() < 6) {
                this.accountno.setError((CharSequence)"please enter valid Account Number");
                this.accountno.requestFocus();
            } else if (this.branchname.getText().toString().trim().length() == 0) {
                this.branchname.setError((CharSequence)"Please enter Branch Name");
                this.branchname.requestFocus();
            } else if (this.ifscno.getText().toString().trim().length() == 0) {
                this.ifscno.setError((CharSequence)"Please enter IFSC Number");
                this.ifscno.requestFocus();
            } else {
                this.makesimplejson();
                this.encryptstring = this.encryptjson(this.inputjson.toString());
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(this.inputjson.toString());
                Log.e((String)"data", (String)stringBuilder.toString());
                this.AddAcount();
            }
        }
        if (view == this.skip) {
            this.sendToNextActivity(RegisterFinal.class);
            this.finish();
        }
        if (view == this.tvlogin) {
            this.sendToNextActivity(Login.class);
            this.finish();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493031);
        this.init();
    }

}

