/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import com.Royal.AllActivity.ProfileActivity;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class AddNewAccount
extends BaseAppCompactActivity
implements View.OnClickListener {
    EditText acchodername;
    EditText accountno;
    Spinner bankname;
    EditText branchname;
    String decryptstring;
    EditText edbankname;
    String encryptstring;
    EditText ifscno;
    JSONObject inputjson;
    Button submit;

    private void AddAcount() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/account/add-new").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    AddNewAccount.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            SharedPreferences.Editor editor = AddNewAccount.this.getSharedPreferences("BANK", 0).edit();
                            editor.putString("Bankname", AddNewAccount.this.edbankname.getText().toString());
                            editor.putString("Accountholdername", AddNewAccount.this.acchodername.getText().toString());
                            editor.putString("Accountnumber", AddNewAccount.this.accountno.getText().toString());
                            editor.putString("Ifsc", AddNewAccount.this.ifscno.getText().toString());
                            editor.apply();
                            AddNewAccount.this.showToast("Your Account Added Sucessfully");
                            AddNewAccount.this.sendToNextActivity(ProfileActivity.class);
                            AddNewAccount.this.finish();
                            return;
                        }
                        String string2 = jSONObject.getString("error");
                        AddNewAccount.this.showToast(string2);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void init() {
        Button button;
        this.bankname = (Spinner)this.findViewById(2131296361);
        this.acchodername = (EditText)this.findViewById(2131296521);
        this.edbankname = (EditText)this.findViewById(2131296523);
        this.accountno = (EditText)this.findViewById(2131296522);
        this.branchname = (EditText)this.findViewById(2131296524);
        this.ifscno = (EditText)this.findViewById(2131296531);
        this.submit = button = (Button)this.findViewById(2131296738);
        button.setOnClickListener((View.OnClickListener)this);
        SharedPreferences sharedPreferences = this.getSharedPreferences("BANK", 0);
        if (sharedPreferences != null) {
            this.edbankname.setText((CharSequence)sharedPreferences.getString("Bankname", ""));
            this.acchodername.setText((CharSequence)sharedPreferences.getString("Accountholdername", ""));
            this.accountno.setText((CharSequence)sharedPreferences.getString("Accountnumber", ""));
            this.ifscno.setText((CharSequence)sharedPreferences.getString("Ifsc", ""));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 2131492952, (Object[])CommonParams.bankname);
        arrayAdapter.setDropDownViewResource(2131492951);
        this.bankname.setAdapter((SpinnerAdapter)arrayAdapter);
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("type", (Object)"bank");
            this.inputjson.put("accountName", (Object)this.edbankname.getText().toString());
            this.inputjson.put("accountNumber", (Object)this.accountno.getText().toString());
            this.inputjson.put("accountHolderName", (Object)this.acchodername.getText().toString());
            this.inputjson.put("branchName", (Object)"india");
            this.inputjson.put("ifscCode", (Object)this.ifscno.getText().toString());
            this.inputjson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void onClick(View view) {
        if (this.edbankname.getText().toString().trim().length() == 0) {
            this.showToast("Please select bank name");
            return;
        }
        if (this.acchodername.getText().toString().trim().length() == 0) {
            this.acchodername.setError((CharSequence)"Please enter Account Holder Name");
            this.acchodername.requestFocus();
            return;
        }
        if (this.accountno.getText().toString().trim().length() < 6) {
            this.accountno.setError((CharSequence)"please enter valid Account Number");
            this.accountno.requestFocus();
            return;
        }
        if (this.ifscno.getText().toString().trim().length() == 0) {
            this.ifscno.setError((CharSequence)"Please enter IFSC Number");
            this.ifscno.requestFocus();
            return;
        }
        this.makesimplejson();
        this.encryptstring = this.encryptjson(this.inputjson.toString());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.inputjson.toString());
        Log.e((String)"data", (String)stringBuilder.toString());
        this.AddAcount();
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492898);
        this.setUpToolbarByName("Add New Account");
        this.init();
    }

}

