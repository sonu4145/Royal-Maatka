/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  android.widget.TextView
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.widget.Toolbar
 *  java.lang.CharSequence
 */
package com.Royal.AllActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import com.Royal.Utilities.BaseAppCompactActivity;

public class AppLockActivity
extends BaseAppCompactActivity {
    public void onBackPressed() {
        super.onBackPressed();
        this.finishAffinity();
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492905);
        Toolbar toolbar = (Toolbar)this.findViewById(2131296976);
        ((TextView)toolbar.findViewById(2131296978)).setText((CharSequence)"SUPER STAR MATKA");
        this.setSupportActionBar(toolbar);
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            this.getSupportActionBar().setDisplayShowHomeEnabled(false);
            this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }
}

