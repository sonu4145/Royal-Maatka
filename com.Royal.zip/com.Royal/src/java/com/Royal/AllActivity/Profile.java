/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.database.Cursor
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.Royal.AllActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.Royal.AllActivity.EditProfile;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utils.DatabaseHandler;

public class Profile
extends BaseAppCompactActivity
implements View.OnClickListener {
    DatabaseHandler db;
    ImageView editimg;
    String stemail;
    String stgender;
    String stmobile;
    String stname;
    String stpassword;
    String stuserId;
    TextView tvemail;
    TextView tvgender;
    TextView tvmobile;
    TextView user_name;

    private void getUserId() {
        Cursor cursor = this.db.getUserDetail();
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); ++i) {
                this.stuserId = cursor.getString(1);
                this.stname = cursor.getString(2);
                this.stmobile = cursor.getString(3);
                this.stemail = cursor.getString(4);
                this.stgender = cursor.getString(6);
                cursor.moveToNext();
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("nn");
            stringBuilder.append(this.stname);
            Log.e((String)"user", (String)stringBuilder.toString());
            cursor.close();
        }
    }

    private void init() {
        this.user_name = (TextView)this.findViewById(2131297031);
        this.tvgender = (TextView)this.findViewById(2131297007);
        this.tvmobile = (TextView)this.findViewById(2131297009);
        this.tvemail = (TextView)this.findViewById(2131297006);
        this.editimg = (ImageView)this.findViewById(2131296534);
        this.db = new DatabaseHandler((Context)this);
        this.getUserId();
        this.user_name.setText((CharSequence)this.stname);
        this.tvgender.setText((CharSequence)this.stgender);
        this.tvmobile.setText((CharSequence)this.stmobile);
        this.tvemail.setText((CharSequence)this.stemail);
        this.editimg.setOnClickListener((View.OnClickListener)this);
    }

    public void onClick(View view) {
        if (view == this.editimg) {
            Intent intent = new Intent(this.getApplicationContext(), EditProfile.class);
            intent.putExtra("userid", this.stuserId);
            intent.putExtra("name", this.stname);
            intent.putExtra("mobile", this.stmobile);
            intent.putExtra("email", this.stemail);
            intent.putExtra("gender", this.stgender);
            intent.putExtra("password", this.stpassword);
            this.startActivity(intent);
            this.finish();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493024);
        this.setUpToolbarByName("Your Profile");
        this.init();
    }
}

