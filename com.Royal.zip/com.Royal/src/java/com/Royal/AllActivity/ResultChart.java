/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.app.ProgressDialog
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.BitmapFactory
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.os.Environment
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.text.Editable
 *  android.text.Html
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.HorizontalScrollView
 *  android.widget.NumberPicker
 *  android.widget.NumberPicker$OnValueChangeListener
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TableLayout
 *  android.widget.TableRow
 *  android.widget.TextView
 *  androidx.print.PrintHelper
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$GetRequestBuilder
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.OutputStream
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 *  org.joda.time.LocalDate
 *  org.joda.time.ReadablePartial
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.print.PrintHelper;
import com.Royal.Adapter.AllDateAdapter;
import com.Royal.Adapter.ResultBazarAdapter;
import com.Royal.AllActivity.ResultChart;
import com.Royal.Model.BazarModel;
import com.Royal.Model.DateModel;
import com.Royal.Model.RecordModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.joda.time.LocalDate;
import org.joda.time.ReadablePartial;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ResultChart
extends BaseAppCompactActivity
implements NumberPicker.OnValueChangeListener,
View.OnClickListener {
    AllDateAdapter adapter;
    String bazarid;
    JSONObject bazarjson;
    List<BazarModel> bazarlist;
    Spinner bazarspin;
    String decryptdtring;
    List<DateModel> dtlistend;
    List<DateModel> dtliststart;
    EditText edyear;
    String encryptstring;
    JSONObject inputjson;
    ProgressDialog pDialog;
    Button print;
    List<RecordModel> recordlist = new ArrayList();
    ArrayList<String> redjodilist = new ArrayList();
    ResultBazarAdapter resultadapter;
    Button search;
    List<String> simplebazarlist;
    TableLayout stk;
    List<String> vallist;
    int year;

    private void BazarList() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.encryptstring);
        Log.e((String)"bazar", (String)stringBuilder.toString());
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/bazaar/all").addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    ResultChart.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            String string2 = jSONObject.getString("bazaars");
                            ResultChart.this.parseoperatorjson(string2);
                            return;
                        }
                        String string3 = jSONObject.getString("error");
                        ResultChart.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void ResultApiList() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.encryptstring);
        Log.e((String)"bazar", (String)stringBuilder.toString());
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/record/resultChart").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    ResultChart.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"resultApi_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            String string2 = jSONObject.getString("results");
                            String string3 = jSONObject.getString("redJodiList");
                            ResultChart.this.parseresultjson(string2);
                            ResultChart.this.parseredjodijson(string3);
                            return;
                        }
                        String string4 = jSONObject.getString("error");
                        ResultChart.this.showToast(Html.fromHtml((String)string4).toString());
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    static /* synthetic */ void access$000(ResultChart resultChart) {
        resultChart.getalldate();
    }

    private void getalldate() {
        this.dtlistend.clear();
        this.dtliststart.clear();
        LocalDate localDate = new LocalDate(this.year, 1, 1);
        LocalDate localDate2 = new LocalDate(this.year, 1, 1);
        LocalDate localDate3 = new LocalDate(this.year, 12, 31);
        LocalDate localDate4 = localDate.withDayOfWeek(1);
        LocalDate localDate5 = localDate2.withDayOfWeek(7);
        if (localDate.isAfter((ReadablePartial)localDate4)) {
            localDate4 = localDate4.plusWeeks(1);
        }
        if (localDate2.isAfter((ReadablePartial)localDate5)) {
            localDate5 = localDate5.plusWeeks(1);
        }
        do {
            if (!localDate4.isBefore((ReadablePartial)localDate3) && !localDate4.equals((Object)localDate3)) {
                do {
                    if (!localDate5.isBefore((ReadablePartial)localDate3) && !localDate5.equals((Object)localDate3)) {
                        String string2 = ((DateModel)this.dtliststart.get(0)).getStdate();
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(this.year);
                        stringBuilder.append("-01-01");
                        if (!string2.equals((Object)stringBuilder.toString())) {
                            String string3 = ((DateModel)this.dtlistend.get(0)).getStdate();
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append(this.year);
                            stringBuilder2.append("-01-01");
                            if (!string3.equals((Object)stringBuilder2.toString())) {
                                DateModel dateModel = new DateModel();
                                StringBuilder stringBuilder3 = new StringBuilder();
                                stringBuilder3.append(this.year);
                                stringBuilder3.append("-01-01");
                                dateModel.setStdate(stringBuilder3.toString());
                                this.dtliststart.add(0, (Object)dateModel);
                            }
                        }
                        List<DateModel> list = this.dtliststart;
                        String string4 = ((DateModel)list.get(list.size() - 1)).getStdate();
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(this.year);
                        stringBuilder4.append("-12-31");
                        if (!string4.equals((Object)stringBuilder4.toString())) {
                            List<DateModel> list2 = this.dtlistend;
                            String string5 = ((DateModel)list2.get(list2.size() - 1)).getStdate();
                            StringBuilder stringBuilder5 = new StringBuilder();
                            stringBuilder5.append(this.year);
                            stringBuilder5.append("-12-31");
                            if (!string5.equals((Object)stringBuilder5.toString())) {
                                DateModel dateModel = new DateModel();
                                StringBuilder stringBuilder6 = new StringBuilder();
                                stringBuilder6.append(this.year);
                                stringBuilder6.append("-12-31");
                                dateModel.setStdate(stringBuilder6.toString());
                                List<DateModel> list3 = this.dtlistend;
                                list3.add(list3.size(), (Object)dateModel);
                            }
                        }
                        return;
                    }
                    System.out.println((Object)localDate4);
                    DateModel dateModel = new DateModel();
                    dateModel.setStdate(String.valueOf((Object)localDate5));
                    this.dtlistend.add((Object)dateModel);
                    localDate5 = localDate5.plusWeeks(1);
                } while (true);
            }
            System.out.println((Object)localDate4);
            DateModel dateModel = new DateModel();
            dateModel.setStdate(String.valueOf((Object)localDate4));
            this.dtliststart.add((Object)dateModel);
            localDate4 = localDate4.plusWeeks(1);
        } while (true);
    }

    private void makebazarjson() {
        JSONObject jSONObject;
        this.bazarjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("bazaarSideId", (Object)"1");
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("bazaarId", (Object)this.bazarid);
            this.inputjson.put("year", (Object)this.edyear.getText().toString());
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void parseoperatorjson(String string2) {
        JSONArray jSONArray = new JSONArray(string2);
        int n = 0;
        do {
            if (n >= jSONArray.length()) break;
            JSONObject jSONObject = jSONArray.getJSONObject(n);
            BazarModel bazarModel = new BazarModel();
            bazarModel.setId(jSONObject.getString("id"));
            bazarModel.setBazaarSideId(jSONObject.getString("todayOpenTime"));
            bazarModel.setBazaarSideId(jSONObject.getString("todayCloseTime"));
            bazarModel.setName(jSONObject.getString("name"));
            this.simplebazarlist.add((Object)jSONObject.getString("name"));
            this.bazarlist.add((Object)bazarModel);
            ++n;
        } while (true);
        try {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, this.simplebazarlist);
            arrayAdapter.setDropDownViewResource(17367049);
            this.bazarspin.setAdapter((SpinnerAdapter)arrayAdapter);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void parseredjodijson(String string2) {
        try {
            JSONArray jSONArray = new JSONArray(string2);
            if (jSONArray.length() == 0) {
                this.showToast("No data found");
            }
            for (int i = 0; i < jSONArray.length(); ++i) {
                this.redjodilist.add((Object)((String)jSONArray.get(i)));
            }
            this.setdataontable();
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void parseresultjson(String string2) {
        JSONArray jSONArray;
        block3 : {
            try {
                jSONArray = new JSONArray(string2);
                if (jSONArray.length() != 0) break block3;
                this.showToast("No data found");
            }
            catch (JSONException jSONException) {
                jSONException.printStackTrace();
                return;
            }
        }
        for (int i = 0; i < jSONArray.length(); ++i) {
            JSONObject jSONObject = jSONArray.getJSONObject(i);
            RecordModel recordModel = new RecordModel();
            recordModel.setJodi(jSONObject.getString("jodi"));
            recordModel.setDate(jSONObject.getString("date"));
            this.recordlist.add((Object)recordModel);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void setdataontable() {
        var1_1 = new TableRow((Context)this);
        var2_2 = new TextView((Context)this);
        var2_2.setText((CharSequence)"DATE RANGE/DAYS");
        var3_3 = -1;
        var2_2.setTextColor(var3_3);
        var1_1.addView((View)var2_2);
        var4_4 = new TextView((Context)this);
        var4_4.setText((CharSequence)"   ");
        var4_4.setTextColor(var3_3);
        var1_1.addView((View)var4_4);
        var5_5 = new ArrayList();
        var5_5.add((Object)"Monday");
        var5_5.add((Object)"Tuesday");
        var5_5.add((Object)"Wednesday");
        var5_5.add((Object)"Thursday");
        var5_5.add((Object)"Friday");
        var5_5.add((Object)"Saturday");
        var5_5.add((Object)"Sunday");
        var13_6 = 0;
        do {
            var14_9 = var5_5.size();
            var15_10 = 17;
            if (var13_6 >= var14_9) break;
            var16_7 = new TextView((Context)this);
            var16_7.setText((CharSequence)var5_5.get(var13_6));
            var16_7.setTextColor(var3_3);
            var16_7.setGravity(var15_10);
            var1_1.addView((View)var16_7);
            var17_8 = new TextView((Context)this);
            var17_8.setText((CharSequence)"  ");
            var17_8.setTextColor(var3_3);
            var17_8.setGravity(var15_10);
            var1_1.addView((View)var17_8);
            ++var13_6;
        } while (true);
        this.stk.addView((View)var1_1);
        if (this.dtliststart.size() > this.dtlistend.size()) {
            var52_11 = this.dtlistend;
            var53_12 = var52_11.size();
            var54_13 = this.dtliststart;
            var52_11.add(var53_12, (Object)((DateModel)var54_13.get(-1 + var54_13.size())));
        }
        if (this.dtlistend.size() > this.dtliststart.size()) {
            this.dtliststart.add(0, (Object)((DateModel)this.dtlistend.get(0)));
        }
        if (this.dtliststart.size() != this.dtlistend.size()) return;
        var18_14 = 0;
        var19_15 = 0;
        block11 : do {
            if (var19_15 >= this.dtliststart.size()) return;
            var20_16 = new TableRow((Context)this);
            var21_17 = new TextView((Context)this);
            var22_18 = new StringBuilder();
            var22_18.append(this.parseDateToddMMyyyy(((DateModel)this.dtliststart.get(var19_15)).getStdate()));
            var22_18.append("\n to \n");
            var22_18.append(this.parseDateToddMMyyyy(((DateModel)this.dtlistend.get(var19_15)).getStdate()));
            var21_17.setText((CharSequence)var22_18.toString());
            var21_17.setTextColor(var3_3);
            var21_17.setGravity(var15_10);
            var20_16.addView((View)var21_17);
            var26_19 = new TextView((Context)this);
            var26_19.setText((CharSequence)"   ");
            var26_19.setTextColor(var3_3);
            var26_19.setGravity(var15_10);
            var20_16.addView((View)var26_19);
            var27_20 = var18_14;
            var28_21 = 0;
            do {
                block24 : {
                    block27 : {
                        block25 : {
                            block26 : {
                                if (var28_21 >= var5_5.size()) break block25;
                                if (var27_20 != this.recordlist.size()) break block26;
                                var29_22 = new TextView((Context)this);
                                var29_22.setText((CharSequence)"**");
                                var29_22.setTextColor(var3_3);
                                var29_22.setGravity(var15_10);
                                var20_16.addView((View)var29_22);
                                var30_23 = new TextView((Context)this);
                                var30_23.setText((CharSequence)"   ");
                                var30_23.setTextColor(var3_3);
                                var30_23.setGravity(var15_10);
                                var20_16.addView((View)var30_23);
                                break block24;
                            }
                            var31_24 = var28_21;
                            var32_25 = var27_20;
                            break block27;
                        }
                        this.stk.addView((View)var20_16);
                        ++var19_15;
                        var18_14 = var27_20;
                        continue block11;
                    }
                    while (var32_25 < this.recordlist.size()) {
                        block28 : {
                            block21 : {
                                block22 : {
                                    block23 : {
                                        var33_26 = Calendar.getInstance();
                                        var34_27 = Calendar.getInstance();
                                        try {
                                            var33_26.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(((RecordModel)this.recordlist.get(var32_25)).getDate()));
                                            var34_27.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(((DateModel)this.dtliststart.get(var19_15)).getStdate()));
                                        }
                                        catch (ParseException var35_28) {
                                            var35_28.printStackTrace();
                                        }
                                        var37_33 = new SimpleDateFormat("yyyy-MM-dd").parse(((DateModel)this.dtliststart.get(var19_15)).getStdate());
                                        try {
                                            var38_34 = new SimpleDateFormat("yyyy-MM-dd").parse(((DateModel)this.dtlistend.get(var19_15)).getStdate());
                                        }
                                        catch (ParseException var36_31) {
                                            break block23;
                                        }
                                        try {
                                            var39_35 = new SimpleDateFormat("yyyy-MM-dd").parse(((RecordModel)this.recordlist.get(var32_25)).getDate());
                                            break block21;
                                        }
                                        catch (ParseException var36_30) {
                                            break block22;
                                        }
                                        catch (ParseException var36_32) {
                                            var37_33 = null;
                                        }
                                    }
                                    var38_34 = null;
                                }
                                var36_29.printStackTrace();
                                var39_35 = null;
                            }
                            try {
                                var41_37 = new SimpleDateFormat("EEEE").format(new SimpleDateFormat("yyyy-MM-dd").parse(((RecordModel)this.recordlist.get(var32_25)).getDate()));
                            }
                            catch (ParseException var40_36) {
                                var40_36.printStackTrace();
                                var41_37 = "";
                            }
                            if (var37_33.compareTo(var39_35) * var39_35.compareTo(var38_34) < 0 || !var41_37.equals(var5_5.get(var31_24))) break block28;
                            var44_40 = new TextView((Context)this);
                            var45_41 = ((RecordModel)this.recordlist.get(var32_25)).getJodi();
                            var44_40.setText((CharSequence)((RecordModel)this.recordlist.get(var32_25)).getJodi());
                            if (this.redjodilist.contains((Object)var45_41)) {
                                var44_40.setTextColor(-65536);
                                var46_42 = -1;
                            } else {
                                var46_42 = -1;
                                var44_40.setTextColor(var46_42);
                            }
                            var44_40.setGravity(17);
                            var20_16.addView((View)var44_40);
                            var47_43 = new TextView((Context)this);
                            var47_43.setText((CharSequence)"   ");
                            var47_43.setTextColor(var46_42);
                            var47_43.setGravity(17);
                            var20_16.addView((View)var47_43);
                            if (var31_24 >= 6) ** GOTO lbl161
                            var28_21 = var31_24 + 1;
                            if (++var32_25 == this.recordlist.size()) {
                                var49_45 = this.recordlist.size();
                                var50_46 = new TextView((Context)this);
                                var50_46.setText((CharSequence)"**");
                                var50_46.setTextColor(-1);
                                var50_46.setGravity(17);
                                var20_16.addView((View)var50_46);
                                var51_47 = new TextView((Context)this);
                                var51_47.setText((CharSequence)"   ");
                                var51_47.setTextColor(-1);
                                var51_47.setGravity(17);
                                var20_16.addView((View)var51_47);
                                var27_20 = var49_45;
                            } else {
                                var31_24 = var28_21;
                                var3_3 = -1;
                                var15_10 = 17;
                                continue;
lbl161: // 1 sources:
                                var48_44 = var32_25 + 1;
                                var28_21 = var31_24;
                                var27_20 = var48_44;
                            }
                            var3_3 = -1;
                            var15_10 = 17;
                            break block24;
                        }
                        var42_38 = new TextView((Context)this);
                        var42_38.setText((CharSequence)"**");
                        var3_3 = -1;
                        var42_38.setTextColor(var3_3);
                        var15_10 = 17;
                        var42_38.setGravity(var15_10);
                        var20_16.addView((View)var42_38);
                        var43_39 = new TextView((Context)this);
                        var43_39.setText((CharSequence)"   ");
                        var43_39.setTextColor(var3_3);
                        var43_39.setGravity(var15_10);
                        var20_16.addView((View)var43_39);
                        if (var31_24 < 6) {
                            ++var31_24;
                            continue;
                        }
                        var28_21 = var31_24;
                        var27_20 = var32_25;
                        break block24;
                    }
                    var28_21 = var31_24;
                }
                ++var28_21;
            } while (true);
            break;
        } while (true);
    }

    public Bitmap getBitmapFromView(View view, int n, int n2) {
        Bitmap bitmap = Bitmap.createBitmap((int)n2, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable drawable2 = view.getBackground();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        } else {
            canvas.drawColor(-16777216);
        }
        view.draw(canvas);
        return bitmap;
    }

    public void layoutToImage() {
        View view = this.findViewById(2131296612);
        HorizontalScrollView horizontalScrollView = (HorizontalScrollView)this.findViewById(2131296612);
        Bitmap bitmap = this.getBitmapFromView(view, horizontalScrollView.getChildAt(0).getHeight(), horizontalScrollView.getChildAt(0).getWidth());
        File file = new File(Environment.getExternalStorageDirectory(), "resultchart.jpg");
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            MediaStore.Images.Media.insertImage((ContentResolver)this.getContentResolver(), (Bitmap)bitmap, (String)"Screen", (String)"screen");
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        }
        PrintHelper printHelper = new PrintHelper((Context)this);
        printHelper.setScaleMode(1);
        BitmapFactory.decodeResource((Resources)this.getResources(), (int)2131165425);
        printHelper.printBitmap("droids.jpg - test print", bitmap);
    }

    public void onClick(View view) {
        if (view == this.search) {
            this.dtliststart.clear();
            this.dtlistend.clear();
            this.recordlist.clear();
            this.stk.removeAllViews();
            this.print.setVisibility(0);
            this.makesimplejson();
            this.getalldate();
            this.encryptstring = this.encryptjson(this.inputjson.toString());
            this.ResultApiList();
        }
        if (view == this.print) {
            this.layoutToImage();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493036);
        this.setUpToolbarByName("Result Chart");
        this.bazarspin = (Spinner)this.findViewById(2131296432);
        this.edyear = (EditText)this.findViewById(2131296547);
        this.search = (Button)this.findViewById(2131296829);
        this.print = (Button)this.findViewById(2131296790);
        this.stk = (TableLayout)this.findViewById(2131296901);
        this.search.setOnClickListener((View.OnClickListener)this);
        this.dtliststart = new ArrayList();
        this.dtlistend = new ArrayList();
        this.bazarlist = new ArrayList();
        this.vallist = new ArrayList();
        this.simplebazarlist = new ArrayList();
        this.makebazarjson();
        this.encryptstring = this.encryptjson(this.bazarjson.toString());
        this.BazarList();
        this.year = Calendar.getInstance().get(1);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("nn");
        stringBuilder.append(this.year);
        Log.e((String)"year", (String)stringBuilder.toString());
        this.edyear.setText((CharSequence)String.valueOf((int)this.year));
        this.edyear.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ ResultChart this$0;
            {
                this.this$0 = resultChart;
            }

            public void onClick(View view) {
                this.this$0.show();
            }
        });
        this.getalldate();
        this.print.setOnClickListener((View.OnClickListener)this);
        this.bazarspin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(this){
            final /* synthetic */ ResultChart this$0;
            {
                this.this$0 = resultChart;
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                if (this.this$0.bazarlist.size() > 0) {
                    ResultChart resultChart = this.this$0;
                    resultChart.bazarid = ((BazarModel)resultChart.bazarlist.get(n)).getId();
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    public void onValueChange(NumberPicker numberPicker, int n, int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(n2);
        Log.e((String)"value is", (String)stringBuilder.toString());
    }

    public String parseDateToddMMyyyy(String string2) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("dd-MMM-yyyy");
        try {
            String string3 = simpleDateFormat2.format(simpleDateFormat.parse(string2));
            return string3;
        }
        catch (ParseException parseException) {
            parseException.printStackTrace();
            return null;
        }
    }

    public void show() {
        Dialog dialog = new Dialog((Context)this);
        dialog.setTitle((CharSequence)"NumberPicker");
        dialog.setContentView(2131492937);
        Button button = (Button)dialog.findViewById(2131296387);
        Button button2 = (Button)dialog.findViewById(2131296388);
        NumberPicker numberPicker = (NumberPicker)dialog.findViewById(2131296752);
        numberPicker.setMaxValue(2080);
        numberPicker.setMinValue(2014);
        numberPicker.setWrapSelectorWheel(false);
        numberPicker.setOnValueChangedListener((NumberPicker.OnValueChangeListener)this);
        button.setOnClickListener(new View.OnClickListener(this, numberPicker, dialog){
            final /* synthetic */ ResultChart this$0;
            final /* synthetic */ Dialog val$d;
            final /* synthetic */ NumberPicker val$np;
            {
                this.this$0 = resultChart;
                this.val$np = numberPicker;
                this.val$d = dialog;
            }

            public void onClick(View view) {
                this.this$0.edyear.setText((CharSequence)String.valueOf((int)this.val$np.getValue()));
                this.this$0.year = this.val$np.getValue();
                ResultChart.access$000(this.this$0);
                this.val$d.dismiss();
            }
        });
        button2.setOnClickListener(new View.OnClickListener(this, dialog){
            final /* synthetic */ ResultChart this$0;
            final /* synthetic */ Dialog val$d;
            {
                this.this$0 = resultChart;
                this.val$d = dialog;
            }

            public void onClick(View view) {
                this.val$d.dismiss();
            }
        });
        dialog.show();
    }

}

