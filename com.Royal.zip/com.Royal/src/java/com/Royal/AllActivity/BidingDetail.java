/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.widget.TextView
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.BidingDetailAdapter;
import com.Royal.Model.BidingDetailModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BidingDetail
extends BaseAppCompactActivity {
    public static String userbidid;
    BidingDetailAdapter adapter;
    TextView bidpoint;
    String decryptstring;
    String encryptstring;
    String id;
    JSONObject inpujson;
    List<BidingDetailModel> list;
    TextView namedate;
    RecyclerView recyclerView;
    String todayRemaningCancelDayForBid;
    String todayRemaningCancelTimeForCloseBid;
    String todayRemaningCancelTimeForOpenBid;

    private void TransactionList() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.encryptstring);
        Log.e((String)"bazar", (String)stringBuilder.toString());
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/bidding/detail").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    BidingDetail.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            JSONObject jSONObject2 = jSONObject.getJSONObject("bidTransaction");
                            TextView textView = BidingDetail.this.bidpoint;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Bids - ");
                            stringBuilder.append(jSONObject2.getString("numberOfBid"));
                            stringBuilder.append(" | Points - ");
                            stringBuilder.append(jSONObject2.getString("bidPoint"));
                            textView.setText((CharSequence)stringBuilder.toString());
                            String string2 = jSONObject.getString("bidTransactionDetails");
                            BidingDetail.this.parseoperatorjson(string2);
                            return;
                        }
                        String string3 = jSONObject.getString("error");
                        BidingDetail.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    /*
     * Exception decompiling
     */
    public static String getFormatedDateTime(String var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    private void init() {
        BidingDetailAdapter bidingDetailAdapter;
        String string2;
        ArrayList arrayList;
        this.namedate = (TextView)this.findViewById(2131296724);
        this.bidpoint = (TextView)this.findViewById(2131296376);
        this.recyclerView = (RecyclerView)this.findViewById(2131296375);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getApplicationContext());
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.list = arrayList = new ArrayList();
        this.adapter = bidingDetailAdapter = new BidingDetailAdapter((Context)this, (List<BidingDetailModel>)arrayList);
        this.recyclerView.setAdapter((RecyclerView.Adapter)bidingDetailAdapter);
        this.id = string2 = this.getIntent().getStringExtra("id");
        userbidid = string2;
        this.makesimplejson();
        Log.e((String)"json", (String)this.inpujson.toString());
        this.encryptstring = this.encryptjson(this.inpujson.toString());
        this.TransactionList();
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inpujson = jSONObject = new JSONObject();
        try {
            jSONObject.put("detailId", (Object)this.id);
            this.inpujson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void parseoperatorjson(String string2) {
        try {
            JSONArray jSONArray = new JSONArray(string2);
            if (jSONArray.length() == 0) {
                this.showToast("No data found");
            }
            for (int i = 0; i < jSONArray.length(); ++i) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                BidingDetailModel bidingDetailModel = new BidingDetailModel();
                bidingDetailModel.setUserBidTransactionDetailId(jSONObject.getString("userBidTransactionDetailId"));
                bidingDetailModel.setBazaar(jSONObject.getString("bazaar"));
                bidingDetailModel.setGame(jSONObject.getString("game"));
                bidingDetailModel.setDate(jSONObject.getString("date"));
                bidingDetailModel.setSession(jSONObject.getString("session"));
                bidingDetailModel.setDigit(jSONObject.getString("digit"));
                bidingDetailModel.setWinpoint(jSONObject.getString("winPoint"));
                bidingDetailModel.setPoint(jSONObject.getString("point"));
                bidingDetailModel.setIsStatus(jSONObject.getString("isStatus"));
                bidingDetailModel.setCreatedOn(jSONObject.getString("createdOn"));
                bidingDetailModel.setResultId(jSONObject.getString("resultId"));
                bidingDetailModel.setTodayRemaningCancelDayForBid(jSONObject.getString("cancelPanelty"));
                bidingDetailModel.setTodayRemaningCancelTimeForOpenBid(jSONObject.getString("isOpenBidCancel"));
                bidingDetailModel.setTodayRemaningCancelTimeForCloseBid(jSONObject.getString("isCloseBidCancel"));
                String string3 = BidingDetail.getFormatedDateTime(bidingDetailModel.getCreatedOn(), "yyy-MM-dd HH:mm:ss", "EEEE dd-MMM-yyy hh:mm a");
                TextView textView = this.namedate;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Bombay Side - ");
                stringBuilder.append(string3);
                textView.setText((CharSequence)stringBuilder.toString());
                this.list.add((Object)bidingDetailModel);
            }
            this.adapter.notifyDataSetChanged();
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492909);
        this.setUpToolbarByName("Bid Transaction History");
        this.init();
    }

}

