/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.database.Cursor
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.Html
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.TextView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.Funds;
import com.Royal.AllActivity.TransferPoint;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.DatabaseHandler;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class TransferPoint
extends BaseAppCompactActivity
implements View.OnClickListener {
    TextView available_point;
    Button cancel;
    Button confirm;
    DatabaseHandler db;
    String decryptstring;
    EditText edmobile;
    EditText edpoint;
    String encryptstring;
    JSONObject inputjson;
    TextView mobilenumber;
    Button next;
    JSONObject pointjson;
    TextView pointtxt;
    String reciverid;
    String recivermobile;
    String recivername;
    TextView statustxt;
    String stmobile;
    String stname;
    String stpoint;
    String stsendermobile;
    TextView transfer_point;
    TextView walletlink;

    private void ConfirmApi() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userPoint/transferConfirm").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    TransferPoint.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            TransferPoint.this.reciverid = jSONObject.getString("receiverId");
                            TransferPoint.this.recivermobile = jSONObject.getString("receiverMobile");
                            TransferPoint.this.recivername = jSONObject.getString("receiverName");
                            TransferPoint.this.setContentView(2131492915);
                            TransferPoint.this.setUpToolbarByName("Point Transfer");
                            TransferPoint.this.statustxt = (TextView)TransferPoint.this.findViewById(2131296896);
                            TransferPoint.this.walletlink = (TextView)TransferPoint.this.findViewById(2131297049);
                            TransferPoint.this.pointtxt = (TextView)TransferPoint.this.findViewById(2131296786);
                            TransferPoint.this.confirm = (Button)TransferPoint.this.findViewById(2131296449);
                            TransferPoint.this.cancel = (Button)TransferPoint.this.findViewById(2131296394);
                            TransferPoint.this.transfer_point = (TextView)TransferPoint.this.findViewById(2131296993);
                            TransferPoint.this.available_point = (TextView)TransferPoint.this.findViewById(2131296357);
                            TextView textView = TransferPoint.this.walletlink;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("in wallet linked to  ");
                            stringBuilder.append(TransferPoint.this.recivermobile);
                            textView.setText((CharSequence)stringBuilder.toString());
                            TransferPoint.this.transfer_point.setText((CharSequence)TransferPoint.this.recivername);
                            TextView textView2 = TransferPoint.this.available_point;
                            StringBuilder stringBuilder2 = new StringBuilder();
                            stringBuilder2.append("will receive ");
                            stringBuilder2.append(TransferPoint.this.stpoint);
                            textView2.setText((CharSequence)stringBuilder2.toString());
                            TransferPoint.this.cancel.setOnClickListener(new View.OnClickListener(this){
                                final /* synthetic */ 1 this$1;
                                {
                                    this.this$1 = var1_1;
                                }

                                public void onClick(View view) {
                                    this.this$1.TransferPoint.this.sendToNextActivity(TransferPoint.class);
                                    this.this$1.TransferPoint.this.finish();
                                }
                            });
                            TransferPoint.this.confirm.setOnClickListener(new View.OnClickListener(this){
                                final /* synthetic */ 1 this$1;
                                {
                                    this.this$1 = var1_1;
                                }

                                public void onClick(View view) {
                                    TransferPoint.access$000(this.this$1.TransferPoint.this);
                                    this.this$1.TransferPoint.this.encryptstring = this.this$1.TransferPoint.this.encryptjson(this.this$1.TransferPoint.this.pointjson.toString());
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("n");
                                    stringBuilder.append(this.this$1.TransferPoint.this.pointjson.toString());
                                    Log.e((String)"encrypt", (String)stringBuilder.toString());
                                    TransferPoint.access$100(this.this$1.TransferPoint.this);
                                }
                            });
                            return;
                        }
                        String string2 = jSONObject.getString("error");
                        TransferPoint.this.showToast(string2);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void PointTransfer() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userPoint/transfer").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    TransferPoint.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            TransferPoint transferPoint = TransferPoint.this;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Successfully transferred  ");
                            stringBuilder.append(TransferPoint.this.stpoint);
                            stringBuilder.append(" point to ");
                            stringBuilder.append(TransferPoint.this.recivername);
                            transferPoint.showToast(stringBuilder.toString());
                            TransferPoint.this.sendToNextActivity(Funds.class);
                            TransferPoint.this.finish();
                            return;
                        }
                        String string2 = jSONObject.getString("error");
                        TransferPoint.this.showToast(Html.fromHtml((String)string2).toString());
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    static /* synthetic */ void access$000(TransferPoint transferPoint) {
        transferPoint.makepointjson();
    }

    static /* synthetic */ void access$100(TransferPoint transferPoint) {
        transferPoint.PointTransfer();
    }

    private void getUserId() {
        Cursor cursor = this.db.getUserDetail();
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); ++i) {
                this.stname = cursor.getString(2);
                this.stsendermobile = cursor.getString(3);
                cursor.moveToNext();
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("nn");
            stringBuilder.append(this.stsendermobile);
            Log.e((String)"user", (String)stringBuilder.toString());
            cursor.close();
        }
    }

    private void init() {
        TextView textView;
        this.transfer_point = (TextView)this.findViewById(2131296993);
        this.available_point = (TextView)this.findViewById(2131296357);
        this.edmobile = (EditText)this.findViewById(2131296535);
        this.edpoint = (EditText)this.findViewById(2131296541);
        this.next = (Button)this.findViewById(2131296738);
        this.mobilenumber = textView = (TextView)this.findViewById(2131296689);
        textView.setText((CharSequence)Dashboard.phone);
        this.next.setOnClickListener((View.OnClickListener)this);
        int n = -1000 + Integer.parseInt((String)String.valueOf((long)myPoints));
        TextView textView2 = this.transfer_point;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Transferable Point ");
        stringBuilder.append(String.valueOf((int)n));
        textView2.setText((CharSequence)stringBuilder.toString());
        TextView textView3 = this.available_point;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Available Point ");
        stringBuilder2.append(String.valueOf((long)myPoints));
        textView3.setText((CharSequence)stringBuilder2.toString());
        this.getUserId();
    }

    private void makepointjson() {
        JSONObject jSONObject;
        this.pointjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("senderId", (Object)CommonParams.userId);
            this.pointjson.put("senderMobile", (Object)this.stmobile);
            this.pointjson.put("receiverId", (Object)this.reciverid);
            this.pointjson.put("receiverMobile", (Object)this.recivermobile);
            this.pointjson.put("point", (Object)this.stpoint);
            this.pointjson.put("senderName", (Object)this.stname);
            this.pointjson.put("receiverName", (Object)this.recivername);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("senderId", (Object)CommonParams.userId);
            this.inputjson.put("receiverMobile", (Object)this.stmobile);
            this.inputjson.put("point", (Object)this.stpoint);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void onClick(View view) {
        if (view == this.next) {
            if (this.edmobile.getText().toString().trim().length() < 10) {
                this.edmobile.setError((CharSequence)"Please enter valid mobile no");
                this.edmobile.requestFocus();
                return;
            }
            if (this.edmobile.getText().toString().equals((Object)this.stsendermobile)) {
                this.edmobile.setError((CharSequence)"You can not transfer point to own account");
                this.edmobile.requestFocus();
                return;
            }
            if (this.edpoint.getText().toString().trim().length() == 0) {
                this.edpoint.setError((CharSequence)"Minimum 10 points required");
                this.edpoint.requestFocus();
                return;
            }
            if (Long.parseLong((String)this.edpoint.getText().toString()) < 1L) {
                this.edpoint.setError((CharSequence)"Minimum 1 points required");
                this.edpoint.requestFocus();
                return;
            }
            if (Long.parseLong((String)String.valueOf((long)myPoints)) < Long.parseLong((String)this.edpoint.getText().toString())) {
                this.edpoint.setError((CharSequence)"You Don't have sufficient Point");
                return;
            }
            this.stmobile = this.edmobile.getText().toString();
            this.stpoint = this.edpoint.getText().toString();
            this.makesimplejson();
            this.encryptstring = this.encryptjson(this.inputjson.toString());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(this.inputjson.toString());
            Log.e((String)"encrypt", (String)stringBuilder.toString());
            this.ConfirmApi();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493065);
        this.setUpToolbarByName("Point Transfer");
        this.db = new DatabaseHandler((Context)this);
        this.init();
    }

}

