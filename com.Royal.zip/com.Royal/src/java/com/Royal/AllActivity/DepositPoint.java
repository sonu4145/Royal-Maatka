/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.DatePickerDialog
 *  android.app.DatePickerDialog$OnDateSetListener
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.Html
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.EditText
 *  android.widget.RadioButton
 *  android.widget.RadioGroup
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.List
 *  java.util.Locale
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.DepositPoint;
import com.Royal.AllActivity.Funds;
import com.Royal.Model.BankModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.data.helper.CalenderHelper;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DepositPoint
extends BaseAppCompactActivity
implements View.OnClickListener {
    JSONObject accjson;
    List<String> acclist;
    Spinner accountname;
    RadioButton accounttype;
    RadioButton bank;
    String decryptstring;
    Button deposit;
    JSONObject depositjson;
    EditText edpoint;
    EditText edtransactiondate;
    EditText edtransactionid;
    String encryptstring;
    DatePickerDialog.OnDateSetListener fdate;
    List<BankModel> list;
    int mDay;
    int mMonth;
    int mYear;
    Calendar myCalendar;
    RadioGroup radioGroup;
    String staccholdername;
    String staccname;
    String staccno;
    String stdate;
    String stpoint;
    String sttransaction_id;
    String sttype;
    DatePickerDialog.OnDateSetListener tdate;
    RadioButton wallet;

    static /* synthetic */ void access$000(DepositPoint depositPoint) {
        depositPoint.makesimplejson();
    }

    static /* synthetic */ void access$100(DepositPoint depositPoint, String string2) {
        depositPoint.getAdminAcc(string2);
    }

    static /* synthetic */ void access$200(DepositPoint depositPoint) {
        depositPoint.updatefromLabel();
    }

    private void deposit_point() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userPoint/deposit").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    DepositPoint.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            DepositPoint.this.showToast("Add point request has been send to ADMIN");
                            DepositPoint.this.sendToNextActivity(Funds.class);
                            return;
                        }
                        String string2 = jSONObject.getString("error");
                        DepositPoint.this.showToast(Html.fromHtml((String)string2).toString());
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void getAdminAcc(final String string2) {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/adminAccount/defaultList").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.HIGH).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    DepositPoint.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            String string22 = jSONObject.getString(string2);
                            DepositPoint.this.parseoperatorjson(string22);
                            return;
                        }
                        String string3 = jSONObject.getString("error");
                        DepositPoint.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void init() {
        this.radioGroup = (RadioGroup)this.findViewById(2131296797);
        this.bank = (RadioButton)this.findViewById(2131296359);
        this.wallet = (RadioButton)this.findViewById(2131297048);
        this.bank.setChecked(true);
        this.accountname = (Spinner)this.findViewById(2131296337);
        this.edpoint = (EditText)this.findViewById(2131296541);
        this.edtransactiondate = (EditText)this.findViewById(2131296542);
        this.edtransactionid = (EditText)this.findViewById(2131296543);
        this.deposit = (Button)this.findViewById(2131296334);
        ((TextView)this.findViewById(2131296689)).setText((CharSequence)Dashboard.phone);
        this.deposit.setOnClickListener((View.OnClickListener)this);
        this.list = new ArrayList();
        this.acclist = new ArrayList();
        this.makesimplejson();
        this.encryptstring = this.encryptjson(this.accjson.toString());
        this.getAdminAcc("banks");
        this.bank.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this){
            final /* synthetic */ DepositPoint this$0;
            {
                this.this$0 = depositPoint;
            }

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                if (bl) {
                    DepositPoint depositPoint = this.this$0;
                    depositPoint.encryptstring = depositPoint.encryptjson(depositPoint.accjson.toString());
                    this.this$0.list = new ArrayList();
                    this.this$0.acclist = new ArrayList();
                    DepositPoint.access$000(this.this$0);
                    DepositPoint depositPoint2 = this.this$0;
                    depositPoint2.encryptstring = depositPoint2.encryptjson(depositPoint2.accjson.toString());
                    DepositPoint.access$100(this.this$0, "banks");
                }
            }
        });
        this.wallet.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this){
            final /* synthetic */ DepositPoint this$0;
            {
                this.this$0 = depositPoint;
            }

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                if (bl) {
                    DepositPoint depositPoint = this.this$0;
                    depositPoint.encryptstring = depositPoint.encryptjson(depositPoint.accjson.toString());
                    this.this$0.list = new ArrayList();
                    this.this$0.acclist = new ArrayList();
                    DepositPoint.access$000(this.this$0);
                    DepositPoint depositPoint2 = this.this$0;
                    depositPoint2.encryptstring = depositPoint2.encryptjson(depositPoint2.accjson.toString());
                    DepositPoint.access$100(this.this$0, "wallets");
                }
            }
        });
        this.fdate = new DatePickerDialog.OnDateSetListener(this){
            final /* synthetic */ DepositPoint this$0;
            {
                this.this$0 = depositPoint;
            }

            public void onDateSet(android.widget.DatePicker datePicker, int n, int n2, int n3) {
                this.this$0.myCalendar = Calendar.getInstance();
                this.this$0.myCalendar.set(1, n);
                this.this$0.myCalendar.set(2, n2);
                this.this$0.myCalendar.set(5, n3);
                DepositPoint.access$200(this.this$0);
            }
        };
        this.edtransactiondate.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ DepositPoint this$0;
            {
                this.this$0 = depositPoint;
            }

            public void onClick(View view) {
                this.this$0.myCalendar = Calendar.getInstance();
                DepositPoint depositPoint = this.this$0;
                depositPoint.mYear = depositPoint.myCalendar.get(1);
                DepositPoint depositPoint2 = this.this$0;
                depositPoint2.mMonth = depositPoint2.myCalendar.get(2);
                DepositPoint depositPoint3 = this.this$0;
                depositPoint3.mDay = depositPoint3.myCalendar.get(5);
                DepositPoint depositPoint4 = this.this$0;
                DatePickerDialog datePickerDialog = new DatePickerDialog((Context)depositPoint4, depositPoint4.fdate, this.this$0.mYear, this.this$0.mMonth, this.this$0.mDay);
                datePickerDialog.getDatePicker().setMaxDate(this.this$0.myCalendar.getTimeInMillis());
                datePickerDialog.show();
            }
        });
        this.accountname.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(this){
            final /* synthetic */ DepositPoint this$0;
            {
                this.this$0 = depositPoint;
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                Log.e((String)"select", (String)"n");
                DepositPoint depositPoint = this.this$0;
                depositPoint.staccname = ((BankModel)depositPoint.list.get(n)).getAccountName();
                DepositPoint depositPoint2 = this.this$0;
                depositPoint2.staccholdername = ((BankModel)depositPoint2.list.get(n)).getAccountHolderName();
                DepositPoint depositPoint3 = this.this$0;
                depositPoint3.staccno = ((BankModel)depositPoint3.list.get(n)).getAccountNumber();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    private void makedepositjson() {
        JSONObject jSONObject;
        Calendar calendar = Calendar.getInstance();
        calendar.add(6, -2);
        Date date = calendar.getTime();
        this.depositjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("senderId", (Object)CommonParams.userId);
            this.depositjson.put("receiverAccountHolderName", (Object)"admin");
            this.depositjson.put("receiverAccountNumber", (Object)"1234567899876543");
            this.depositjson.put("receiverAccountName", (Object)"bank");
            this.depositjson.put("type", (Object)"bank");
            this.depositjson.put("point", (Object)this.stpoint);
            this.depositjson.put("transactionDate", (Object)CalenderHelper.dateFormat.format(date));
            this.depositjson.put("transactionId", (Object)"a1s2c3v5");
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.accjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void parseoperatorjson(String string2) {
        JSONArray jSONArray = new JSONArray(string2);
        jSONArray.length();
        int n = 0;
        do {
            if (n >= jSONArray.length()) break;
            JSONObject jSONObject = jSONArray.getJSONObject(n);
            BankModel bankModel = new BankModel();
            bankModel.setAccountHolderName(jSONObject.getString("accountHolderName"));
            bankModel.setAccountNumber(jSONObject.getString("accountNumber"));
            bankModel.setAccountName(jSONObject.getString("accountName"));
            List<String> list = this.acclist;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(jSONObject.getString("accountName"));
            stringBuilder.append(" - ");
            stringBuilder.append(jSONObject.getString("accountNumber"));
            list.add((Object)stringBuilder.toString());
            this.list.add((Object)bankModel);
            ++n;
        } while (true);
        try {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, this.acclist);
            arrayAdapter.setDropDownViewResource(2131492951);
            this.accountname.setAdapter((SpinnerAdapter)arrayAdapter);
            this.accountname.setSelection(0);
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    private void updatefromLabel() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyy", Locale.US);
        this.edtransactiondate.setText((CharSequence)simpleDateFormat.format(this.myCalendar.getTime()));
    }

    public void onClick(View view) {
        if (view == this.deposit) {
            String string2;
            RadioButton radioButton;
            if (this.edpoint.getText().toString().trim().length() == 0) {
                this.edpoint.setError((CharSequence)"Minimum 1000 points required");
                this.edpoint.requestFocus();
                return;
            }
            if (Long.parseLong((String)this.edpoint.getText().toString()) < 500L) {
                this.edpoint.setError((CharSequence)"Please enter point more than 500");
                return;
            }
            this.accounttype = radioButton = (RadioButton)this.findViewById(this.radioGroup.getCheckedRadioButtonId());
            this.sttype = string2 = radioButton.getText().toString();
            this.sttype = string2.toLowerCase();
            this.stpoint = this.edpoint.getText().toString();
            this.makedepositjson();
            this.encryptstring = this.encryptjson(this.depositjson.toString());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(this.depositjson.toString());
            Log.e((String)"json", (String)stringBuilder.toString());
            this.deposit_point();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492921);
        this.setUpToolbarByName("Add Funds");
        this.init();
    }

}

