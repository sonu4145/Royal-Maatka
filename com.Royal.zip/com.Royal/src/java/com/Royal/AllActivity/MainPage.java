/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.os.Handler
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.ActionBarDrawerToggle
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  androidx.appcompat.widget.Toolbar
 *  androidx.core.content.res.ResourcesCompat
 *  androidx.drawerlayout.widget.DrawerLayout
 *  com.google.android.material.navigation.NavigationView
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.res.ResourcesCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.Royal.AllActivity.AllNews;
import com.Royal.AllActivity.BidingTransaction;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.DepositPoint;
import com.Royal.AllActivity.LockPointHistory;
import com.Royal.AllActivity.MainPage;
import com.Royal.AllActivity.PanelChart;
import com.Royal.AllActivity.PasswordSecurity;
import com.Royal.AllActivity.PointHistory;
import com.Royal.AllActivity.Profile;
import com.Royal.AllActivity.PurchaseReport;
import com.Royal.AllActivity.ResultActivity;
import com.Royal.AllActivity.ResultChart;
import com.Royal.AllActivity.TotalPoint;
import com.Royal.AllActivity.TransferPoint;
import com.Royal.AllActivity.WebViewActivity;
import com.Royal.AllActivity.WidthrawPoint;
import com.Royal.AllActivity.YourAccount;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.UserData;
import com.Royal.data.remote.UserDataRepository;
import com.Royal.data.remote.UserDataSource;
import com.google.android.material.navigation.NavigationView;
import org.json.JSONObject;

public class MainPage
extends BaseAppCompactActivity
implements View.OnClickListener {
    LinearLayout bidingtransaction;
    LinearLayout depositpoint;
    boolean doubleBackToExitPressedOnce = false;
    private DrawerLayout drawerLayout;
    String encryptstring;
    LinearLayout gamewinratio;
    LinearLayout howtoplay;
    JSONObject inpujson;
    LinearLayout letusplay;
    LinearLayout logout;
    UserDataRepository mUserDataRepository;
    LinearLayout more;
    private NavigationView navigationView;
    LinearLayout panel_chart;
    LinearLayout passwordsecurity;
    LinearLayout point_loack_history;
    LinearLayout point_transaction_history;
    LinearLayout privacyandpolicy;
    LinearLayout profile;
    LinearLayout purchasereport;
    String regId;
    LinearLayout result;
    LinearLayout result_chart;
    LinearLayout termsandconditon;
    private Toolbar toolbar;
    LinearLayout transfer_point;
    TextView tv_userName;
    TextView tv_useremail;
    TextView tvbid;
    TextView tvbiddinghistory;
    TextView tvearn;
    TextView tvlockpoint;
    TextView tvpoints;
    TextView tvresult;
    UserData userData;
    LinearLayout widthrawpoint;
    LinearLayout youraccount;
    LinearLayout yourpoint;

    private void GetPoint() {
        if (!this.isInternetOn()) {
            return;
        }
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        this.mUserDataRepository.getUserPoints(new UserDataSource.GetUserPointsCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                progressDialog.dismiss();
                MainPage.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                progressDialog.dismiss();
                ScreenUtils.showLockScreen((Activity)MainPage.this);
            }

            @Override
            public void onUserPointLoaded(UserData userData) {
                progressDialog.dismiss();
                TextView textView = MainPage.this.tvpoints;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(userData.getTotalPoint());
                textView.setText((CharSequence)stringBuilder.toString());
                TextView textView2 = MainPage.this.tvlockpoint;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("");
                stringBuilder2.append(userData.getLockPoint());
                textView2.setText((CharSequence)stringBuilder2.toString());
                TextView textView3 = MainPage.this.tvbid;
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("");
                stringBuilder3.append(userData.getBidPoint());
                textView3.setText((CharSequence)stringBuilder3.toString());
                TextView textView4 = MainPage.this.tvearn;
                StringBuilder stringBuilder4 = new StringBuilder();
                stringBuilder4.append("");
                stringBuilder4.append(userData.getWinPoint());
                textView4.setText((CharSequence)stringBuilder4.toString());
            }
        });
    }

    static /* synthetic */ DrawerLayout access$000(MainPage mainPage) {
        return mainPage.drawerLayout;
    }

    private void init() {
        this.tvresult = (TextView)this.findViewById(2131296806);
        this.tvbiddinghistory = (TextView)this.findViewById(2131296372);
        this.tvearn = (TextView)this.findViewById(2131296983);
        this.tvbid = (TextView)this.findViewById(2131296982);
        this.tvpoints = (TextView)this.findViewById(2131296984);
        this.tvlockpoint = (TextView)this.findViewById(2131296658);
        this.tvresult.setOnClickListener((View.OnClickListener)this);
        this.tvbiddinghistory.setOnClickListener((View.OnClickListener)this);
        this.GetPoint();
    }

    private void initDrawerLayout() {
        DrawerLayout drawerLayout;
        this.drawerLayout = drawerLayout = (DrawerLayout)this.findViewById(2131296510);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle((Activity)this, drawerLayout, this.toolbar, 2131820718, 2131820597);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(false);
        actionBarDrawerToggle.setHomeAsUpIndicator(ResourcesCompat.getDrawable((Resources)this.getResources(), (int)2131165387, (Resources.Theme)this.getApplicationContext().getTheme()));
        actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener(this){
            final /* synthetic */ MainPage this$0;
            {
                this.this$0 = mainPage;
            }

            public void onClick(View view) {
                MainPage.access$000(this.this$0).openDrawer(8388611);
            }
        });
    }

    private void initNavigationDrawer() {
        NavigationView navigationView;
        TextView textView;
        this.navigationView = navigationView = (NavigationView)this.findViewById(2131296732);
        this.tv_userName = (TextView)navigationView.findViewById(2131297031);
        this.tv_useremail = textView = (TextView)this.navigationView.findViewById(2131297030);
        textView.setText((CharSequence)this.userData.getMobileNumber());
        this.tv_userName.setText((CharSequence)this.userData.getDisplayName());
        this.logout = (LinearLayout)this.navigationView.findViewById(2131296660);
        this.gamewinratio = (LinearLayout)this.navigationView.findViewById(2131296585);
        this.howtoplay = (LinearLayout)this.navigationView.findViewById(2131296611);
        this.privacyandpolicy = (LinearLayout)this.navigationView.findViewById(2131296791);
        this.termsandconditon = (LinearLayout)this.navigationView.findViewById(2131296916);
        this.letusplay = (LinearLayout)this.navigationView.findViewById(2131296651);
        this.bidingtransaction = (LinearLayout)this.navigationView.findViewById(2131296374);
        this.youraccount = (LinearLayout)this.navigationView.findViewById(2131297065);
        this.yourpoint = (LinearLayout)this.navigationView.findViewById(2131297066);
        this.depositpoint = (LinearLayout)this.navigationView.findViewById(2131296482);
        this.widthrawpoint = (LinearLayout)this.navigationView.findViewById(2131297056);
        this.profile = (LinearLayout)this.navigationView.findViewById(2131296792);
        this.passwordsecurity = (LinearLayout)this.navigationView.findViewById(2131296773);
        this.more = (LinearLayout)this.navigationView.findViewById(2131296696);
        this.transfer_point = (LinearLayout)this.navigationView.findViewById(2131296994);
        this.point_transaction_history = (LinearLayout)this.navigationView.findViewById(2131297037);
        this.point_loack_history = (LinearLayout)this.navigationView.findViewById(2131297035);
        this.result = (LinearLayout)this.navigationView.findViewById(2131296806);
        this.result_chart = (LinearLayout)this.navigationView.findViewById(2131296807);
        this.panel_chart = (LinearLayout)this.navigationView.findViewById(2131296767);
        this.purchasereport = (LinearLayout)this.navigationView.findViewById(2131296472);
        this.logout.setOnClickListener((View.OnClickListener)this);
        this.letusplay.setOnClickListener((View.OnClickListener)this);
        this.bidingtransaction.setOnClickListener((View.OnClickListener)this);
        this.youraccount.setOnClickListener((View.OnClickListener)this);
        this.yourpoint.setOnClickListener((View.OnClickListener)this);
        this.depositpoint.setOnClickListener((View.OnClickListener)this);
        this.widthrawpoint.setOnClickListener((View.OnClickListener)this);
        this.profile.setOnClickListener((View.OnClickListener)this);
        this.passwordsecurity.setOnClickListener((View.OnClickListener)this);
        this.more.setOnClickListener((View.OnClickListener)this);
        this.gamewinratio.setOnClickListener((View.OnClickListener)this);
        this.privacyandpolicy.setOnClickListener((View.OnClickListener)this);
        this.howtoplay.setOnClickListener((View.OnClickListener)this);
        this.termsandconditon.setOnClickListener((View.OnClickListener)this);
        this.transfer_point.setOnClickListener((View.OnClickListener)this);
        this.point_transaction_history.setOnClickListener((View.OnClickListener)this);
        this.point_loack_history.setOnClickListener((View.OnClickListener)this);
        this.result.setOnClickListener((View.OnClickListener)this);
        this.result_chart.setOnClickListener((View.OnClickListener)this);
        this.panel_chart.setOnClickListener((View.OnClickListener)this);
        this.purchasereport.setOnClickListener((View.OnClickListener)this);
    }

    private void initToolbar() {
        Toolbar toolbar;
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131296976);
        TextView textView = (TextView)toolbar.findViewById(2131296978);
        ((TextView)this.toolbar.findViewById(2131296977)).setText((CharSequence)String.valueOf((int)this.userData.getTotalPoint()));
        textView.setText((CharSequence)this.getResources().getString(2131820578));
        this.setSupportActionBar(this.toolbar);
        this.getSupportActionBar();
        if (this.getSupportActionBar() != null) {
            this.getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            this.getSupportActionBar().setDisplayShowHomeEnabled(false);
            this.getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
    }

    private void logoutConfirmAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this);
        builder.setMessage((CharSequence)"Are you sure you want to logout.").setCancelable(false).setPositiveButton((CharSequence)"Ok", new DialogInterface.OnClickListener(this){
            final /* synthetic */ MainPage this$0;
            {
                this.this$0 = mainPage;
            }

            public void onClick(DialogInterface dialogInterface, int n) {
                this.this$0.userData.setIsLogin(false);
                android.content.SharedPreferences$Editor editor = this.this$0.getSharedPreferences("shared", 0).edit();
                editor.clear();
                editor.commit();
                this.this$0.sendToNextActivity(com.Royal.AllActivity.Login.class);
                this.this$0.finish();
            }
        });
        builder.setNegativeButton((CharSequence)"Cancel", new DialogInterface.OnClickListener(this){
            final /* synthetic */ MainPage this$0;
            {
                this.this$0 = mainPage;
            }

            public void onClick(DialogInterface dialogInterface, int n) {
                dialogInterface.dismiss();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.setTitle((CharSequence)"Confirmation");
        alertDialog.show();
    }

    public void onBackPressed() {
        if (this.drawerLayout.isDrawerOpen(8388611)) {
            this.drawerLayout.closeDrawers();
        }
        if (this.doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        Toast.makeText((Context)this, (CharSequence)"Please click BACK again to exit", (int)0).show();
        new Handler().postDelayed(new Runnable(this){
            final /* synthetic */ MainPage this$0;
            {
                this.this$0 = mainPage;
            }

            public void run() {
                this.this$0.doubleBackToExitPressedOnce = false;
            }
        }, 2000L);
    }

    public void onClick(View view) {
        this.drawerLayout.closeDrawers();
        if (view == this.logout) {
            this.logoutConfirmAlert();
        }
        if (view == this.bidingtransaction) {
            this.sendToNextActivity(BidingTransaction.class);
        }
        if (view == this.youraccount) {
            this.sendToNextActivity(YourAccount.class);
        }
        if (view == this.letusplay) {
            this.sendToNextActivity(Dashboard.class);
        }
        if (view == this.tvresult) {
            this.sendToNextActivity(Dashboard.class);
        }
        if (view == this.tvbiddinghistory) {
            this.sendToNextActivity(BidingTransaction.class);
        }
        if (view == this.depositpoint) {
            this.sendToNextActivity(DepositPoint.class);
        }
        if (view == this.widthrawpoint) {
            this.sendToNextActivity(WidthrawPoint.class);
        }
        if (view == this.profile) {
            this.sendToNextActivity(Profile.class);
        }
        if (view == this.passwordsecurity) {
            this.sendToNextActivity(PasswordSecurity.class);
        }
        if (view == this.yourpoint) {
            this.sendToNextActivity(TotalPoint.class);
        }
        if (view == this.more) {
            this.sendToNextActivity(AllNews.class);
        }
        if (view == this.transfer_point) {
            this.sendToNextActivity(TransferPoint.class);
        }
        if (view == this.point_transaction_history) {
            this.sendToNextActivity(PointHistory.class);
        }
        if (view == this.point_loack_history) {
            this.sendToNextActivity(LockPointHistory.class);
        }
        if (view == this.result) {
            this.sendToNextActivity(ResultActivity.class);
        }
        if (view == this.result_chart) {
            this.sendToNextActivity(ResultChart.class);
        }
        if (view == this.panel_chart) {
            this.sendToNextActivity(PanelChart.class);
        }
        if (view == this.purchasereport) {
            this.sendToNextActivity(PurchaseReport.class);
        }
        if (view == this.gamewinratio) {
            Intent intent = new Intent((Context)this, WebViewActivity.class);
            intent.putExtra("url", "https://www.balajimatka.com/matka-game-win-ratio");
            this.startActivity(intent);
            this.overridePendingTransition(2130771983, 2130771980);
        }
        if (view == this.privacyandpolicy) {
            Intent intent = new Intent((Context)this, WebViewActivity.class);
            intent.putExtra("url", "https://www.balajimatka.com/privacy-and-policy");
            this.startActivity(intent);
            this.overridePendingTransition(2130771983, 2130771980);
        }
        if (view == this.termsandconditon) {
            Intent intent = new Intent((Context)this, WebViewActivity.class);
            intent.putExtra("url", "https://www.balajimatka.com/term-and-condition");
            this.startActivity(intent);
            this.overridePendingTransition(2130771983, 2130771980);
        }
        if (view == this.howtoplay) {
            Intent intent = new Intent((Context)this, WebViewActivity.class);
            intent.putExtra("url", "https://www.balajimatka.com/how-to-play-online-balaji-matka-in-india");
            this.startActivity(intent);
            this.overridePendingTransition(2130771983, 2130771980);
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        UserDataRepository userDataRepository;
        super.onCreate(bundle);
        this.setContentView(2131492947);
        this.mUserDataRepository = userDataRepository = UserDataRepository.getInstance((Context)this);
        this.userData = userDataRepository.getUserData();
        this.init();
        this.initToolbar();
        this.initNavigationDrawer();
        this.initDrawerLayout();
    }

}

