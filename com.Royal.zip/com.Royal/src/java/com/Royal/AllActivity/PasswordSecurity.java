/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.database.Cursor
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.Html
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.Button
 *  android.widget.EditText
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.Royal.AllActivity.Login;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.DatabaseHandler;
import com.Royal.Utils.ScreenUtils;
import com.Royal.Utils.UserFunctions;
import com.Royal.data.remote.UserDataRepository;
import com.Royal.data.remote.UserDataSource;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class PasswordSecurity
extends BaseAppCompactActivity
implements View.OnClickListener {
    EditText confirmpass;
    DatabaseHandler db;
    String decryptstring;
    String encryptstring;
    JSONObject inputjson;
    UserDataRepository mUserDataRepository;
    EditText newpass;
    EditText oldpass;
    Button reset;
    String stconfirmpass;
    String stnewpass;
    String stoldpass;
    String stuserId;
    UserFunctions uf;

    private void LoginApi() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/user/changePassword").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    PasswordSecurity.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            PasswordSecurity.this.sendToNextActivity(Login.class);
                            PasswordSecurity.this.finish();
                            return;
                        }
                        String string2 = jSONObject.getString("error");
                        PasswordSecurity.this.showToast(Html.fromHtml((String)string2).toString());
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void getUserId() {
        Cursor cursor = this.db.getUserDetail();
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); ++i) {
                this.stuserId = cursor.getString(1);
                cursor.moveToNext();
            }
            cursor.close();
        }
    }

    private void init() {
        this.oldpass = (EditText)this.findViewById(2131296538);
        this.newpass = (EditText)this.findViewById(2131296537);
        this.confirmpass = (EditText)this.findViewById(2131296527);
        this.reset = (Button)this.findViewById(2131296805);
        this.getUserId();
        this.reset.setOnClickListener((View.OnClickListener)this);
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("userId", (Object)this.stuserId);
            this.inputjson.put("currentPassword", (Object)this.stoldpass);
            this.inputjson.put("newPassword", (Object)this.stnewpass);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void ChangePassword() {
        if (!this.isInternetOn()) {
            return;
        }
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        this.mUserDataRepository.changePassword(this.stoldpass, this.stnewpass, new UserDataSource.ChangePasswordCallBack(){

            @Override
            public void onErrorInCurrentPassword(String string2) {
                progressDialog.dismiss();
                PasswordSecurity.this.showToast(string2);
            }

            @Override
            public void onErrorInLoading(String string2) {
                progressDialog.dismiss();
                PasswordSecurity.this.showToast(string2);
            }

            @Override
            public void onErrorInNewPassword(String string2) {
                progressDialog.dismiss();
                PasswordSecurity.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                progressDialog.dismiss();
                ScreenUtils.showLockScreen((Activity)PasswordSecurity.this);
            }

            @Override
            public void onPasswordChanged(String string2) {
                progressDialog.dismiss();
                PasswordSecurity.this.uf.logoutUser((Context)PasswordSecurity.this);
                PasswordSecurity.this.showToast("Your Password Reset Sucessfully");
                ScreenUtils.showLoginScreen((Activity)PasswordSecurity.this);
            }
        });
    }

    public void onClick(View view) {
        if (view == this.reset) {
            if (this.oldpass.getText().toString().trim().length() == 0) {
                this.oldpass.setError((CharSequence)"Please enter old password");
                this.oldpass.requestFocus();
                return;
            }
            if (this.newpass.getText().toString().trim().length() == 0) {
                this.newpass.setError((CharSequence)"Please enter new password");
                this.newpass.requestFocus();
                return;
            }
            if (this.confirmpass.getText().toString().trim().length() == 0) {
                this.confirmpass.setError((CharSequence)"Please confirm the password");
                this.confirmpass.requestFocus();
                return;
            }
            if (!this.confirmpass.getText().toString().equals((Object)this.newpass.getText().toString())) {
                this.confirmpass.setError((CharSequence)"Please confirm the password");
                this.confirmpass.requestFocus();
                return;
            }
            this.stoldpass = this.oldpass.getText().toString();
            this.stnewpass = this.newpass.getText().toString();
            this.stconfirmpass = this.confirmpass.getText().toString();
            this.makesimplejson();
            this.encryptstring = this.encryptjson(this.inputjson.toString());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(this.inputjson.toString());
            Log.e((String)"encrypt", (String)stringBuilder.toString());
            this.ChangePassword();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493032);
        this.setUpToolbarByName("Password & Security");
        this.mUserDataRepository = UserDataRepository.getInstance((Context)this);
        this.db = new DatabaseHandler((Context)this);
        this.uf = new UserFunctions();
        this.init();
    }

}

