/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.text.Editable
 *  android.text.Html
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.EditText
 *  android.widget.RadioButton
 *  android.widget.RadioGroup
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.Funds;
import com.Royal.AllActivity.WidthrawPoint;
import com.Royal.Model.BankModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class WidthrawPoint
extends BaseAppCompactActivity
implements View.OnClickListener {
    JSONObject accjson;
    List<String> acclist;
    Spinner accname;
    RadioButton acctype;
    RadioButton bank;
    String decryptstring;
    Button deposit;
    JSONObject depositjson;
    EditText edpoint;
    String encryptstring;
    List<BankModel> list;
    TextView mobilenumber;
    RadioGroup radioGroup;
    String staccholdername;
    String staccname;
    String staccno;
    String stdate;
    String stpoint;
    String sttransaction_id;
    String sttype;
    RadioButton wallet;

    private void GetAllBank(final String string2) {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userAccount/all").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    WidthrawPoint.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            String string22 = jSONObject.getString(string2);
                            WidthrawPoint.this.parseoperatorjson(string22);
                            return;
                        }
                        String string3 = jSONObject.getString("error");
                        WidthrawPoint.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    static /* synthetic */ void access$000(WidthrawPoint widthrawPoint) {
        widthrawPoint.makesimplejson();
    }

    static /* synthetic */ void access$100(WidthrawPoint widthrawPoint, String string2) {
        widthrawPoint.GetAllBank(string2);
    }

    private void deposit_point() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userPoint/withdraw").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    WidthrawPoint.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            WidthrawPoint.this.showToast("Withdraw point request has been send to ADMIN");
                            WidthrawPoint.this.sendToNextActivity(Funds.class);
                            return;
                        }
                        String string2 = jSONObject.getString("error");
                        WidthrawPoint.this.showToast(Html.fromHtml((String)string2).toString());
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void init() {
        TextView textView;
        this.radioGroup = (RadioGroup)this.findViewById(2131296797);
        this.bank = (RadioButton)this.findViewById(2131296359);
        this.wallet = (RadioButton)this.findViewById(2131297048);
        this.bank.setChecked(true);
        this.accname = (Spinner)this.findViewById(2131296305);
        this.edpoint = (EditText)this.findViewById(2131296541);
        this.deposit = (Button)this.findViewById(2131296334);
        this.mobilenumber = textView = (TextView)this.findViewById(2131296689);
        textView.setText((CharSequence)Dashboard.phone);
        this.deposit.setOnClickListener((View.OnClickListener)this);
        this.list = new ArrayList();
        this.acclist = new ArrayList();
        this.makesimplejson();
        this.encryptstring = this.encryptjson(this.accjson.toString());
        this.GetAllBank("banks");
        this.bank.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this){
            final /* synthetic */ WidthrawPoint this$0;
            {
                this.this$0 = widthrawPoint;
            }

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                if (bl) {
                    WidthrawPoint widthrawPoint = this.this$0;
                    widthrawPoint.encryptstring = widthrawPoint.encryptjson(widthrawPoint.accjson.toString());
                    this.this$0.list = new ArrayList();
                    this.this$0.acclist = new ArrayList();
                    WidthrawPoint.access$000(this.this$0);
                    WidthrawPoint widthrawPoint2 = this.this$0;
                    widthrawPoint2.encryptstring = widthrawPoint2.encryptjson(widthrawPoint2.accjson.toString());
                    WidthrawPoint.access$100(this.this$0, "banks");
                }
            }
        });
        this.wallet.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this){
            final /* synthetic */ WidthrawPoint this$0;
            {
                this.this$0 = widthrawPoint;
            }

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                if (bl) {
                    WidthrawPoint widthrawPoint = this.this$0;
                    widthrawPoint.encryptstring = widthrawPoint.encryptjson(widthrawPoint.accjson.toString());
                    this.this$0.list = new ArrayList();
                    this.this$0.acclist = new ArrayList();
                    WidthrawPoint.access$000(this.this$0);
                    WidthrawPoint widthrawPoint2 = this.this$0;
                    widthrawPoint2.encryptstring = widthrawPoint2.encryptjson(widthrawPoint2.accjson.toString());
                    WidthrawPoint.access$100(this.this$0, "wallets");
                }
            }
        });
        this.accname.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(this){
            final /* synthetic */ WidthrawPoint this$0;
            {
                this.this$0 = widthrawPoint;
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                WidthrawPoint widthrawPoint = this.this$0;
                widthrawPoint.staccholdername = ((BankModel)widthrawPoint.list.get(n)).getAccountHolderName();
                WidthrawPoint widthrawPoint2 = this.this$0;
                widthrawPoint2.staccname = ((BankModel)widthrawPoint2.list.get(n)).getAccountName();
                WidthrawPoint widthrawPoint3 = this.this$0;
                widthrawPoint3.staccno = ((BankModel)widthrawPoint3.list.get(n)).getAccountNumber();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    private void makedepositjson() {
        JSONObject jSONObject;
        this.depositjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("receiverId", (Object)CommonParams.userId);
            this.depositjson.put("receiverAccountHolderName", (Object)this.staccholdername);
            this.depositjson.put("receiverAccountNumber", (Object)this.staccno);
            this.depositjson.put("receiverAccountName", (Object)this.staccname);
            this.depositjson.put("type", (Object)this.sttype);
            this.depositjson.put("point", (Object)this.stpoint);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.accjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    private void parseoperatorjson(String string2) {
        JSONArray jSONArray = new JSONArray(string2);
        int n = 0;
        do {
            if (n >= jSONArray.length()) break;
            JSONObject jSONObject = jSONArray.getJSONObject(n);
            BankModel bankModel = new BankModel();
            bankModel.setId(jSONObject.getString("id"));
            bankModel.setAccountHolderName(jSONObject.getString("accountHolderName"));
            bankModel.setAccountNumber(jSONObject.getString("accountNumber"));
            bankModel.setAccountName(jSONObject.getString("accountName"));
            bankModel.setIfscCode(jSONObject.getString("ifscCode"));
            bankModel.setBranchName(jSONObject.getString("branchName"));
            bankModel.setType(jSONObject.getString("type"));
            bankModel.setIsStatus(jSONObject.getString("isStatus"));
            List<String> list = this.acclist;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(jSONObject.getString("accountName"));
            stringBuilder.append(" - ");
            stringBuilder.append(jSONObject.getString("accountNumber"));
            list.add((Object)stringBuilder.toString());
            this.list.add((Object)bankModel);
            ++n;
        } while (true);
        try {
            ArrayAdapter arrayAdapter = new ArrayAdapter((Context)this, 17367048, this.acclist);
            arrayAdapter.setDropDownViewResource(2131492951);
            this.accname.setAdapter((SpinnerAdapter)arrayAdapter);
            if (this.list.size() > 0) {
                this.accname.setSelection(0);
                this.staccholdername = ((BankModel)this.list.get(0)).getAccountHolderName();
                this.staccname = ((BankModel)this.list.get(0)).getAccountName();
                this.staccno = ((BankModel)this.list.get(0)).getAccountNumber();
                return;
            }
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
        }
    }

    public void onClick(View view) {
        if (view == this.deposit) {
            String string2;
            RadioButton radioButton;
            if (this.edpoint.getText().toString().trim().length() == 0) {
                this.edpoint.setError((CharSequence)"Minimum 1 points required");
                this.edpoint.requestFocus();
                return;
            }
            if (Long.parseLong((String)this.edpoint.getText().toString()) < 1L) {
                this.edpoint.setError((CharSequence)"Minimum 1 points required");
                return;
            }
            if (Long.parseLong((String)String.valueOf((long)myPoints)) < Long.parseLong((String)this.edpoint.getText().toString())) {
                this.edpoint.setError((CharSequence)"You Don't have sufficient Point");
                return;
            }
            this.acctype = radioButton = (RadioButton)this.findViewById(this.radioGroup.getCheckedRadioButtonId());
            this.sttype = string2 = radioButton.getText().toString();
            this.sttype = string2.toLowerCase();
            this.stpoint = this.edpoint.getText().toString();
            this.makedepositjson();
            this.encryptstring = this.encryptjson(this.depositjson.toString());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("n");
            stringBuilder.append(this.depositjson.toString());
            Log.e((String)"json", (String)stringBuilder.toString());
            this.deposit_point();
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131493068);
        this.setUpToolbarByName("Withdraw Point");
        this.init();
    }

}

