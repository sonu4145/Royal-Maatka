/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.String
 */
package com.Royal.AllActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.Royal.AllActivity.Dashboard;
import com.Royal.Utilities.BaseAppCompactActivity;

public class GameRates
extends BaseAppCompactActivity {
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492893);
        this.setUpToolbarByName("Game Rates");
        ((TextView)this.findViewById(2131296689)).setText((CharSequence)Dashboard.phone);
    }
}

