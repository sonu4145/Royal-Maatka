/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.TextView
 *  androidx.fragment.app.FragmentActivity
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.google.android.material.floatingactionbutton.FloatingActionButton
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.AllBankAdapter;
import com.Royal.AllActivity.AddNewAccount;
import com.Royal.Utilities.BaseAppFragments;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.AccountData;
import com.Royal.data.remote.AccountDataRepository;
import com.Royal.data.remote.AccountDataSource;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.json.JSONObject;

public class BankAccount
extends BaseAppFragments
implements View.OnClickListener {
    AllBankAdapter adapter;
    String decryptstring;
    String encryptstring;
    FloatingActionButton fabadd;
    JSONObject inputjson;
    List<AccountData> list;
    AccountDataRepository mAccountDataRepository;
    TextView notetext;
    RecyclerView recyclerView;

    private void initview(View view) {
        AllBankAdapter allBankAdapter;
        this.notetext = (TextView)view.findViewById(2131296746);
        this.recyclerView = (RecyclerView)view.findViewById(2131296360);
        this.fabadd = (FloatingActionButton)view.findViewById(2131296559);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager((Context)this.getActivity());
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.list = new ArrayList();
        this.adapter = allBankAdapter = new AllBankAdapter((Context)this.getActivity(), this.list);
        this.recyclerView.setAdapter((RecyclerView.Adapter)allBankAdapter);
        this.makesimplejson();
        this.encryptstring = this.encryptjson(this.inputjson.toString());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.encryptstring);
        Log.e((String)"encrypt", (String)stringBuilder.toString());
        this.GetAllBank();
        this.fabadd.setOnClickListener((View.OnClickListener)this);
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void GetAllBank() {
        if (!this.isInternetOn()) {
            return;
        }
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this.getActivity());
        this.mAccountDataRepository.getBankAccount(new AccountDataSource.GetAccountCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                progressDialog.dismiss();
                BankAccount.this.showToast(string2);
            }

            @Override
            public void onLoaded(ArrayList<AccountData> arrayList) {
                progressDialog.dismiss();
                BankAccount.this.list.addAll(arrayList);
                BankAccount.this.adapter.notifyDataSetChanged();
            }

            @Override
            public void onLocked(String string2) {
                progressDialog.dismiss();
                BankAccount.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)BankAccount.this.getActivity());
            }
        });
    }

    public void onClick(View view) {
        if (view == this.fabadd) {
            this.startActivity(new Intent((Context)this.getActivity(), AddNewAccount.class));
            this.getActivity().finish();
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View view = layoutInflater.inflate(2131492901, viewGroup, false);
        this.mAccountDataRepository = AccountDataRepository.getInstance(this.getContext());
        this.initview(view);
        return view;
    }

}

