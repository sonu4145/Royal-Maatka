/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.Royal.AllActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.Royal.AllActivity.Dashboard;
import com.Royal.AllActivity.ProfileActivity;
import com.Royal.Utilities.BaseAppCompactActivity;

public class ProfileActivity
extends BaseAppCompactActivity {
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492896);
        this.setUpToolbarByName("Profile");
        TextView textView = (TextView)this.findViewById(2131296689);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Note :- For Any Query Call us on :");
        stringBuilder.append(Dashboard.phone);
        textView.setText((CharSequence)stringBuilder.toString());
        this.findViewById(2131297012).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ ProfileActivity this$0;
            {
                this.this$0 = profileActivity;
            }

            public void onClick(View view) {
                this.this$0.startActivity(new android.content.Intent((android.content.Context)this.this$0, com.Royal.AllActivity.AddNewAccount.class));
            }
        });
        this.findViewById(2131297016).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ ProfileActivity this$0;
            {
                this.this$0 = profileActivity;
            }

            public void onClick(View view) {
                android.content.Intent intent = new android.content.Intent((android.content.Context)this.this$0, com.Royal.AllActivity.AddNewWallet.class);
                intent.putExtra("walletname", "Paytm");
                this.this$0.startActivity(intent);
            }
        });
        this.findViewById(2131297017).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ ProfileActivity this$0;
            {
                this.this$0 = profileActivity;
            }

            public void onClick(View view) {
                android.content.Intent intent = new android.content.Intent((android.content.Context)this.this$0, com.Royal.AllActivity.AddNewWallet.class);
                intent.putExtra("walletname", "PhonePe");
                this.this$0.startActivity(intent);
            }
        });
        this.findViewById(2131297020).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ ProfileActivity this$0;
            {
                this.this$0 = profileActivity;
            }

            public void onClick(View view) {
                android.content.Intent intent = new android.content.Intent((android.content.Context)this.this$0, com.Royal.AllActivity.AddNewWallet.class);
                intent.putExtra("walletname", "Google Pay");
                this.this$0.startActivity(intent);
            }
        });
    }
}

