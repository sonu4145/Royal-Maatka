/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import com.Royal.AllActivity.AppLockActivity;
import com.Royal.AllActivity.YourAccount;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.AccountData;
import com.Royal.data.DefaultAccount;
import com.Royal.data.remote.AccountDataRepository;
import com.Royal.data.remote.AccountDataSource;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class EditWalletAccount
extends BaseAppCompactActivity
implements View.OnClickListener {
    AccountData accountData = null;
    ArrayList<String> accounts = new ArrayList();
    ArrayAdapter<String> adapter;
    String decryptstring;
    ArrayList<DefaultAccount> defaultAccounts = new ArrayList();
    String encryptstring;
    JSONObject inputjson;
    AccountDataRepository mAccountDataRepository;
    Spinner spinner;
    String staccholdername;
    String staccno;
    String staccountid;
    String stbankname;
    String stbranch;
    String stifsc;
    Button submit;
    EditText walletno;
    EditText walletuser_name;

    private void AddAcount2() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/account/edit").addBodyParameter("postData", this.encryptstring).setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    EditWalletAccount.this.showToast("Something went wrong");
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        String string2 = jSONObject.getString("data");
                        EditWalletAccount.this.decryptstring = EditWalletAccount.this.decryptjson(string2);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("n");
                        stringBuilder.append(EditWalletAccount.this.decryptstring);
                        Log.e((String)"decript", (String)stringBuilder.toString());
                        JSONObject jSONObject2 = new JSONObject(EditWalletAccount.this.decryptstring);
                        boolean bl = jSONObject2.getString("status").equals((Object)"true");
                        if (bl) {
                            if (jSONObject2.getString("lock").equals((Object)"true")) {
                                EditWalletAccount.this.sendToNextActivity(AppLockActivity.class);
                                EditWalletAccount.this.finish();
                                return;
                            }
                            EditWalletAccount.this.showToast("Your Account Updated Sucessfully");
                            EditWalletAccount.this.sendToNextActivity(YourAccount.class);
                            EditWalletAccount.this.finish();
                            return;
                        }
                        if (jSONObject2.getString("lock").equals((Object)"true")) {
                            EditWalletAccount.this.sendToNextActivity(AppLockActivity.class);
                            EditWalletAccount.this.finish();
                        }
                        String string3 = jSONObject2.getString("error");
                        EditWalletAccount.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void getvalue() {
        Intent intent = this.getIntent();
        if (intent.hasExtra("data")) {
            this.accountData = (AccountData)intent.getSerializableExtra("data");
            return;
        }
        this.sendToNextActivity(YourAccount.class);
        this.finish();
    }

    private void init() {
        Button button;
        this.spinner = (Spinner)this.findViewById(2131296305);
        this.walletuser_name = (EditText)this.findViewById(2131296546);
        this.walletno = (EditText)this.findViewById(2131296545);
        this.submit = button = (Button)this.findViewById(2131296893);
        button.setOnClickListener((View.OnClickListener)this);
        this.getDefaultAccounts();
    }

    public void AddAcount() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mAccountDataRepository.updateAccount(this.accountData.getId(), "wallet", ((DefaultAccount)this.defaultAccounts.get(this.spinner.getSelectedItemPosition())).getValue(), this.walletno.getText().toString(), this.walletuser_name.getText().toString(), "", "", new AccountDataSource.GetAddAccountCallBack(){

            @Override
            public void onAccountAdded(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.showToast(string2);
                EditWalletAccount.this.sendToNextActivity(YourAccount.class);
                EditWalletAccount.this.finish();
            }

            @Override
            public void onErrorInAccountName(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.showToast(string2);
            }

            @Override
            public void onErrorInAccountNumber(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.walletno.setError((CharSequence)string2);
            }

            @Override
            public void onErrorInBranchName(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.showToast(string2);
            }

            @Override
            public void onErrorInHolderName(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.walletuser_name.setError((CharSequence)string2);
            }

            @Override
            public void onErrorInIfsc(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.showToast(string2);
            }

            @Override
            public void onErrorInLoading(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)EditWalletAccount.this);
            }
        });
    }

    public void getDefaultAccounts() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mAccountDataRepository.getDefaultAccount(new AccountDataSource.GetDefaultAccountCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.showToast(string2);
            }

            @Override
            public void onLoaded(ArrayList<DefaultAccount> arrayList, ArrayList<DefaultAccount> arrayList2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.defaultAccounts = arrayList2;
                for (DefaultAccount defaultAccount : EditWalletAccount.this.defaultAccounts) {
                    EditWalletAccount.this.accounts.add((Object)defaultAccount.getName());
                }
                EditWalletAccount editWalletAccount = EditWalletAccount.this;
                ArrayAdapter arrayAdapter = new ArrayAdapter((Context)editWalletAccount, 2131492952, editWalletAccount.accounts);
                arrayAdapter.setDropDownViewResource(2131492951);
                EditWalletAccount.this.spinner.setAdapter((SpinnerAdapter)arrayAdapter);
                int n = arrayAdapter.getPosition((Object)EditWalletAccount.this.accountData.getAccountName());
                EditWalletAccount.this.spinner.setSelection(n);
                EditWalletAccount.this.walletuser_name.setText((CharSequence)EditWalletAccount.this.accountData.getAccountHolderName());
                EditWalletAccount.this.walletno.setText((CharSequence)EditWalletAccount.this.accountData.getAccountNumber());
            }

            @Override
            public void onLocked(String string2) {
                EditWalletAccount.this.showProgress(false);
                EditWalletAccount.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)EditWalletAccount.this);
            }
        });
    }

    public void onClick(View view) {
        if (this.spinner.getSelectedItem().toString().equals((Object)"Select Account Name")) {
            this.showToast("Please select account name");
            return;
        }
        if (this.walletuser_name.getText().toString().trim().length() == 0) {
            this.walletuser_name.setError((CharSequence)"Please enter user name");
            this.walletuser_name.requestFocus();
            return;
        }
        if (this.walletno.getText().toString().trim().length() < 6) {
            this.walletno.setError((CharSequence)"Please enter wallet no");
            this.walletno.requestFocus();
            return;
        }
        this.AddAcount();
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mAccountDataRepository = AccountDataRepository.getInstance((Context)this);
        this.setContentView(2131492900);
        this.setUpToolbarByName("Edit Account");
        this.getvalue();
        this.init();
    }

}

