/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.text.Editable
 *  android.util.Log
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.EditText
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import com.Royal.AllActivity.AppLockActivity;
import com.Royal.AllActivity.YourAccount;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.ScreenUtils;
import com.Royal.data.AccountData;
import com.Royal.data.DefaultAccount;
import com.Royal.data.remote.AccountDataRepository;
import com.Royal.data.remote.AccountDataSource;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

public class EditBankAccount
extends BaseAppCompactActivity
implements View.OnClickListener {
    EditText acchodername;
    AccountData accountData = null;
    EditText accountno;
    ArrayList<String> accounts = new ArrayList();
    ArrayAdapter<String> adapter;
    Spinner bankname;
    EditText branchname;
    String decryptstring;
    ArrayList<DefaultAccount> defaultAccounts = new ArrayList();
    String encryptstring;
    EditText ifscno;
    JSONObject inputjson;
    AccountDataRepository mAccountDataRepository;
    String staccholdername;
    String staccno;
    String staccountid;
    String stbankname;
    String stbranch;
    String stifsc;
    Button submit;

    private void AddAcount2() {
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/account/edit").addBodyParameter("postData", this.encryptstring).setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    EditBankAccount.this.showToast("Something went wrong");
                }

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        String string2 = jSONObject.getString("data");
                        EditBankAccount.this.decryptstring = EditBankAccount.this.decryptjson(string2);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("n");
                        stringBuilder.append(EditBankAccount.this.decryptstring);
                        Log.e((String)"decript", (String)stringBuilder.toString());
                        JSONObject jSONObject2 = new JSONObject(EditBankAccount.this.decryptstring);
                        boolean bl = jSONObject2.getString("status").equals((Object)"true");
                        if (bl) {
                            if (jSONObject2.getString("lock").equals((Object)"true")) {
                                EditBankAccount.this.sendToNextActivity(AppLockActivity.class);
                                EditBankAccount.this.finish();
                                return;
                            }
                            EditBankAccount.this.showToast("Your Account Updated Sucessfully");
                            EditBankAccount.this.sendToNextActivity(YourAccount.class);
                            EditBankAccount.this.finish();
                            return;
                        }
                        if (jSONObject2.getString("lock").equals((Object)"true")) {
                            EditBankAccount.this.sendToNextActivity(AppLockActivity.class);
                            EditBankAccount.this.finish();
                        }
                        String string3 = jSONObject2.getString("error");
                        EditBankAccount.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void getvalue() {
        Intent intent = this.getIntent();
        if (intent.hasExtra("data")) {
            this.accountData = (AccountData)intent.getSerializableExtra("data");
            return;
        }
        this.sendToNextActivity(YourAccount.class);
        this.finish();
    }

    private void init() {
        Button button;
        this.bankname = (Spinner)this.findViewById(2131296361);
        this.acchodername = (EditText)this.findViewById(2131296521);
        this.accountno = (EditText)this.findViewById(2131296522);
        this.branchname = (EditText)this.findViewById(2131296524);
        this.ifscno = (EditText)this.findViewById(2131296531);
        this.submit = button = (Button)this.findViewById(2131296738);
        button.setOnClickListener((View.OnClickListener)this);
        this.getDefaultAccounts();
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inputjson = jSONObject = new JSONObject();
        try {
            jSONObject.put("userAccountId", (Object)this.staccountid);
            this.inputjson.put("type", (Object)"bank");
            this.inputjson.put("accountName", (Object)this.bankname.getSelectedItem().toString());
            this.inputjson.put("accountNumber", (Object)this.accountno.getText().toString());
            this.inputjson.put("accountHolderName", (Object)this.acchodername.getText().toString());
            this.inputjson.put("branchName", (Object)this.branchname.getText().toString());
            this.inputjson.put("ifscCode", (Object)this.ifscno.getText().toString());
            this.inputjson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void AddAcount() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mAccountDataRepository.updateAccount(this.accountData.getId(), "bank", ((DefaultAccount)this.defaultAccounts.get(this.bankname.getSelectedItemPosition())).getValue(), this.accountno.getText().toString(), this.acchodername.getText().toString(), this.branchname.getText().toString(), this.ifscno.getText().toString(), new AccountDataSource.GetAddAccountCallBack(){

            @Override
            public void onAccountAdded(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.showToast(string2);
                EditBankAccount.this.sendToNextActivity(YourAccount.class);
                EditBankAccount.this.finish();
            }

            @Override
            public void onErrorInAccountName(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.showToast(string2);
            }

            @Override
            public void onErrorInAccountNumber(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.accountno.setError((CharSequence)string2);
            }

            @Override
            public void onErrorInBranchName(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.branchname.setError((CharSequence)string2);
            }

            @Override
            public void onErrorInHolderName(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.acchodername.setError((CharSequence)string2);
            }

            @Override
            public void onErrorInIfsc(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.showToast(string2);
            }

            @Override
            public void onErrorInLoading(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.showToast(string2);
            }

            @Override
            public void onLocked(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)EditBankAccount.this);
            }
        });
    }

    public void getDefaultAccounts() {
        if (!this.isInternetOn()) {
            return;
        }
        this.showProgress(true);
        this.mAccountDataRepository.getDefaultAccount(new AccountDataSource.GetDefaultAccountCallBack(){

            @Override
            public void onErrorInLoading(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.showToast(string2);
            }

            @Override
            public void onLoaded(ArrayList<DefaultAccount> arrayList, ArrayList<DefaultAccount> arrayList2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.defaultAccounts = arrayList;
                for (DefaultAccount defaultAccount : EditBankAccount.this.defaultAccounts) {
                    EditBankAccount.this.accounts.add((Object)defaultAccount.getName());
                }
                EditBankAccount editBankAccount = EditBankAccount.this;
                ArrayAdapter arrayAdapter = new ArrayAdapter((Context)editBankAccount, 2131492952, editBankAccount.accounts);
                arrayAdapter.setDropDownViewResource(2131492951);
                EditBankAccount.this.bankname.setAdapter((SpinnerAdapter)arrayAdapter);
                int n = arrayAdapter.getPosition((Object)EditBankAccount.this.accountData.getAccountName());
                EditBankAccount.this.bankname.setSelection(n);
                EditBankAccount.this.acchodername.setText((CharSequence)EditBankAccount.this.accountData.getAccountHolderName());
                EditBankAccount.this.accountno.setText((CharSequence)EditBankAccount.this.accountData.getAccountNumber());
                EditBankAccount.this.branchname.setText((CharSequence)EditBankAccount.this.accountData.getBranchName());
                EditBankAccount.this.ifscno.setText((CharSequence)EditBankAccount.this.accountData.getIfscCode());
            }

            @Override
            public void onLocked(String string2) {
                EditBankAccount.this.showProgress(false);
                EditBankAccount.this.showToast(string2);
                ScreenUtils.showLockScreen((Activity)EditBankAccount.this);
            }
        });
    }

    public void onClick(View view) {
        if (this.bankname.getSelectedItem().toString().equals((Object)"Select Bank Name")) {
            this.showToast("Please select bank name");
            return;
        }
        if (this.acchodername.getText().toString().trim().length() == 0) {
            this.acchodername.setError((CharSequence)"Please enter Account Holder Name");
            this.acchodername.requestFocus();
            return;
        }
        if (this.accountno.getText().toString().trim().length() < 6) {
            this.accountno.setError((CharSequence)"please enter valid Account Number");
            this.accountno.requestFocus();
            return;
        }
        if (this.branchname.getText().toString().trim().length() == 0) {
            this.branchname.setError((CharSequence)"Please enter Branch Name");
            this.branchname.requestFocus();
            return;
        }
        if (this.ifscno.getText().toString().trim().length() == 0) {
            this.ifscno.setError((CharSequence)"Please enter IFSC Number");
            this.ifscno.requestFocus();
            return;
        }
        this.makesimplejson();
        this.encryptstring = this.encryptjson(this.inputjson.toString());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(this.inputjson.toString());
        Log.e((String)"data", (String)stringBuilder.toString());
        this.AddAcount();
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492898);
        this.mAccountDataRepository = AccountDataRepository.getInstance((Context)this);
        this.setUpToolbarByName("Edit Account");
        this.getvalue();
        this.init();
    }

}

