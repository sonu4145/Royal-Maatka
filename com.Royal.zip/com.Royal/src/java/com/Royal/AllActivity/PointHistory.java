/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.View
 *  android.widget.LinearLayout
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$PostRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.Royal.Adapter.PointHistoryAdapter;
import com.Royal.Model.PointHistoryModel;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PointHistory
extends BaseAppCompactActivity {
    PointHistoryAdapter adapter;
    String decryptdtring;
    String encryptstring;
    JSONObject inpujson;
    List<PointHistoryModel> list;
    RecyclerView recyclerView;
    LinearLayout topll;

    private void TransactionList() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("n");
        stringBuilder.append(this.encryptstring);
        Log.e((String)"bazar", (String)stringBuilder.toString());
        if (this.isInternetOn()) {
            final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
            AndroidNetworking.post((String)"http://www.royalmatka.net/api/v1/userPoint/history").addBodyParameter("post", this.encryptstring).addHeaders("X-Auth-Token", "esuegTUuBzKq/Kll6dcmyIgtR4LsnSgzh5K+WqRFQeVQ//nMDJYljcpsNDlfDtGr8c3f3oZNa75Rf3SAVqQ5oQ==").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

                public void onError(ANError aNError) {
                    progressDialog.dismiss();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(aNError.getErrorDetail());
                    Log.d((String)"error", (String)stringBuilder.toString());
                    PointHistory.this.showToast("Something went wrong");
                }

                public void onResponse(JSONObject jSONObject) {
                    progressDialog.dismiss();
                    Log.e((String)"Api_response", (String)jSONObject.toString());
                    try {
                        if (jSONObject.getString("status").equals((Object)"true")) {
                            String string2 = jSONObject.getString("data");
                            PointHistory.this.parseoperatorjson(string2);
                            return;
                        }
                        String string3 = jSONObject.getString("error");
                        PointHistory.this.showToast(string3);
                        return;
                    }
                    catch (JSONException jSONException) {
                        jSONException.printStackTrace();
                        return;
                    }
                }
            });
            return;
        }
        this.showToast("No internet connection");
    }

    private void init() {
        ArrayList arrayList;
        LinearLayout linearLayout;
        PointHistoryAdapter pointHistoryAdapter;
        this.topll = linearLayout = (LinearLayout)this.findViewById(2131296981);
        linearLayout.setVisibility(8);
        this.recyclerView = (RecyclerView)this.findViewById(2131296989);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.getApplicationContext());
        this.recyclerView.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.list = arrayList = new ArrayList();
        this.adapter = pointHistoryAdapter = new PointHistoryAdapter((Context)this, (List<PointHistoryModel>)arrayList);
        this.recyclerView.setAdapter((RecyclerView.Adapter)pointHistoryAdapter);
        this.makesimplejson();
        Log.e((String)"json", (String)this.inpujson.toString());
        this.encryptstring = this.encryptjson(this.inpujson.toString());
        this.TransactionList();
    }

    private void makesimplejson() {
        JSONObject jSONObject;
        this.inpujson = jSONObject = new JSONObject();
        try {
            jSONObject.put("offset", (Object)"0");
            this.inpujson.put("perPage", (Object)"1500");
            this.inpujson.put("userId", (Object)CommonParams.userId);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void parseoperatorjson(String string2) {
        try {
            JSONArray jSONArray = new JSONArray(string2);
            if (jSONArray.length() == 0) {
                this.showToast("No data found");
            }
            for (int i = 0; i < jSONArray.length(); ++i) {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                PointHistoryModel pointHistoryModel = new PointHistoryModel();
                pointHistoryModel.setId(jSONObject.getString("id"));
                pointHistoryModel.setUserid(jSONObject.getString("userId"));
                pointHistoryModel.setAvailablepoint(jSONObject.getString("availablePoint"));
                pointHistoryModel.setRequestType(jSONObject.getString("requestType"));
                pointHistoryModel.setPoint(jSONObject.getString("point"));
                pointHistoryModel.setActionid(jSONObject.getString("actionId"));
                pointHistoryModel.setActiontype(jSONObject.getString("actionType"));
                pointHistoryModel.setSenderorreciever(jSONObject.getString("senderOrReceiver"));
                pointHistoryModel.setCreatedOn(jSONObject.getString("createdOn"));
                this.list.add((Object)pointHistoryModel);
            }
            this.adapter.notifyDataSetChanged();
            return;
        }
        catch (JSONException jSONException) {
            jSONException.printStackTrace();
            return;
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492912);
        this.setUpToolbarByName("Point History");
        this.init();
    }

}

