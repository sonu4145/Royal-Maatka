/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.widget.Toolbar
 *  androidx.cardview.widget.CardView
 *  com.androidnetworking.AndroidNetworking
 *  com.androidnetworking.common.ANRequest
 *  com.androidnetworking.common.ANRequest$GetRequestBuilder
 *  com.androidnetworking.common.Priority
 *  com.androidnetworking.error.ANError
 *  com.androidnetworking.interfaces.JSONObjectRequestListener
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.Royal.AllActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.Royal.AllActivity.AnkRule;
import com.Royal.AllActivity.BulkJodi;
import com.Royal.AllActivity.CPMotor;
import com.Royal.AllActivity.CombinePana;
import com.Royal.AllActivity.DPMotor;
import com.Royal.AllActivity.DoublePanaRule;
import com.Royal.AllActivity.FamilyJodi;
import com.Royal.AllActivity.FamilyPanaRule;
import com.Royal.AllActivity.FullSangam;
import com.Royal.AllActivity.HalfSangam;
import com.Royal.AllActivity.JodiRule;
import com.Royal.AllActivity.MultiplePanaRule;
import com.Royal.AllActivity.RedJodi;
import com.Royal.AllActivity.SPDPMotor;
import com.Royal.AllActivity.SPDPTP_Rule;
import com.Royal.AllActivity.SPMotor;
import com.Royal.AllActivity.SinglePanaRule;
import com.Royal.AllActivity.TriplePanaRule;
import com.Royal.Utilities.BaseAppCompactActivity;
import com.Royal.Utilities.CommonParams;
import com.Royal.Utils.ScreenUtils;
import com.Royal.Utils.StringUtils;
import com.Royal.data.BazaarData;
import com.Royal.data.BazaarTimeData;
import com.Royal.data.remote.GameDataRepository;
import com.Royal.data.remote.GameDataSource;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.ANRequest;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import java.io.Serializable;
import org.json.JSONException;
import org.json.JSONObject;

public class AllGames
extends BaseAppCompactActivity
implements View.OnClickListener {
    TextView ankplay;
    String bazarid;
    String bazarsideid;
    TextView bulkjodi;
    CardView card_ankplay;
    CardView card_bulkjodi;
    CardView card_combine_pana;
    CardView card_cpmotor;
    CardView card_doubleplay;
    CardView card_dpmotor;
    CardView card_family_jodi;
    CardView card_family_pana;
    CardView card_fullsangam;
    CardView card_halfsangam;
    CardView card_jodi;
    CardView card_multiple_pana;
    CardView card_red_jodi;
    CardView card_singleplay;
    CardView card_spdpmotor;
    CardView card_spdptpplay;
    CardView card_spmotor;
    CardView card_tripleplay;
    TextView combine_pana;
    TextView cpmotor;
    BazaarData data;
    String decryptstring;
    TextView doubleplay;
    TextView dpmotor;
    TextView family_jodi;
    TextView family_pana;
    String fridayCloseTime;
    String fridayOpenTime;
    TextView fullsangam;
    TextView halfsangam;
    String isFriday;
    String isMonday;
    String isSaturday;
    String isSunday;
    String isThursday;
    String isTuesday;
    String isWednesday;
    TextView jodi;
    GameDataRepository mGameDataRepository;
    String mondayCloseTime;
    String mondayOpenTime;
    TextView multiple_pana;
    TextView red_jodi;
    String saturdayCloseTime;
    String saturdayOpenTime;
    TextView singleplay;
    TextView spdpmotor;
    TextView spdptpplay;
    TextView spmotor;
    String sundayCloseTime;
    String sundayOpenTime;
    String thursdayCloseTime;
    String thursdayOpenTime;
    BazaarTimeData timeData;
    String title;
    Toolbar toolbar;
    TextView tripleplay;
    String tuesdayCloseTime;
    String tuesdayOpenTime;
    String wednesdayCloseTime;
    String wednesdayOpenTime;

    private void GetBidTime() {
        if (!this.isInternetOn()) {
            return;
        }
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        this.mGameDataRepository.getBazaarTime(this.data, new GameDataSource.GetBazaarTimeCallBack(){

            @Override
            public void onBazaarTimeLoaded(BazaarTimeData bazaarTimeData) {
                progressDialog.dismiss();
                AllGames.this.timeData = bazaarTimeData;
            }

            @Override
            public void onErrorInLoading(String string2) {
                progressDialog.dismiss();
                AllGames.this.showToast(string2);
                AllGames.this.onBackPressed();
            }

            @Override
            public void onLocked(String string2) {
                progressDialog.dismiss();
                ScreenUtils.showLockScreen((Activity)AllGames.this);
            }
        });
    }

    private void GetBidTime2() {
        final ProgressDialog progressDialog = CommonParams.createProgressDialog((Context)this);
        AndroidNetworking.get((String)"http://www.royalmatka.net/api/v1/app-setting/forBidding").setPriority(Priority.MEDIUM).build().getAsJSONObject(new JSONObjectRequestListener(){

            public void onError(ANError aNError) {
                progressDialog.dismiss();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(aNError.getErrorDetail());
                Log.d((String)"lockerror", (String)stringBuilder.toString());
                AllGames.this.showToast("Something went wrong");
            }

            public void onResponse(JSONObject jSONObject) {
                progressDialog.dismiss();
                Log.e((String)"lockresponse", (String)jSONObject.toString());
                try {
                    if (jSONObject.getString("status").equals((Object)"true")) {
                        String string2 = jSONObject.getString("cancelBidTimeGap");
                        String string3 = jSONObject.getString("addBidTimeGap");
                        CommonParams.cancelBidTimeGap = string2;
                        CommonParams.addBidTimeGap = string3;
                        return;
                    }
                    String string4 = jSONObject.getString("error");
                    AllGames.this.showToast(string4);
                    return;
                }
                catch (JSONException jSONException) {
                    jSONException.printStackTrace();
                    return;
                }
            }
        });
    }

    private void init() {
        this.ankplay = (TextView)this.findViewById(2131296345);
        this.singleplay = (TextView)this.findViewById(2131296857);
        this.doubleplay = (TextView)this.findViewById(2131296499);
        this.tripleplay = (TextView)this.findViewById(2131297003);
        this.jodi = (TextView)this.findViewById(2131296637);
        this.spdptpplay = (TextView)this.findViewById(2131296870);
        this.spmotor = (TextView)this.findViewById(2131296874);
        this.spdpmotor = (TextView)this.findViewById(2131296869);
        this.dpmotor = (TextView)this.findViewById(2131296501);
        this.bulkjodi = (TextView)this.findViewById(2131296386);
        this.cpmotor = (TextView)this.findViewById(2131296460);
        this.combine_pana = (TextView)this.findViewById(2131296447);
        this.family_pana = (TextView)this.findViewById(2131296562);
        this.multiple_pana = (TextView)this.findViewById(2131296721);
        this.family_jodi = (TextView)this.findViewById(2131296561);
        this.red_jodi = (TextView)this.findViewById(2131296802);
        this.halfsangam = (TextView)this.findViewById(2131296602);
        this.fullsangam = (TextView)this.findViewById(2131296583);
        this.card_ankplay = (CardView)this.findViewById(2131296397);
        this.card_singleplay = (CardView)this.findViewById(2131296410);
        this.card_doubleplay = (CardView)this.findViewById(2131296401);
        this.card_tripleplay = (CardView)this.findViewById(2131296414);
        this.card_jodi = (CardView)this.findViewById(2131296407);
        this.card_spdptpplay = (CardView)this.findViewById(2131296412);
        this.card_spmotor = (CardView)this.findViewById(2131296413);
        this.card_spdpmotor = (CardView)this.findViewById(2131296411);
        this.card_dpmotor = (CardView)this.findViewById(2131296402);
        this.card_bulkjodi = (CardView)this.findViewById(2131296398);
        this.card_cpmotor = (CardView)this.findViewById(2131296400);
        this.card_combine_pana = (CardView)this.findViewById(2131296399);
        this.card_family_pana = (CardView)this.findViewById(2131296404);
        this.card_multiple_pana = (CardView)this.findViewById(2131296408);
        this.card_family_jodi = (CardView)this.findViewById(2131296403);
        this.card_red_jodi = (CardView)this.findViewById(2131296409);
        this.card_halfsangam = (CardView)this.findViewById(2131296406);
        this.card_fullsangam = (CardView)this.findViewById(2131296405);
        this.card_ankplay.setOnClickListener((View.OnClickListener)this);
        this.card_singleplay.setOnClickListener((View.OnClickListener)this);
        this.card_doubleplay.setOnClickListener((View.OnClickListener)this);
        this.card_tripleplay.setOnClickListener((View.OnClickListener)this);
        this.card_jodi.setOnClickListener((View.OnClickListener)this);
        this.card_spdptpplay.setOnClickListener((View.OnClickListener)this);
        this.card_spmotor.setOnClickListener((View.OnClickListener)this);
        this.card_spdpmotor.setOnClickListener((View.OnClickListener)this);
        this.card_dpmotor.setOnClickListener((View.OnClickListener)this);
        this.card_bulkjodi.setOnClickListener((View.OnClickListener)this);
        this.card_cpmotor.setOnClickListener((View.OnClickListener)this);
        this.card_combine_pana.setOnClickListener((View.OnClickListener)this);
        this.card_family_pana.setOnClickListener((View.OnClickListener)this);
        this.card_multiple_pana.setOnClickListener((View.OnClickListener)this);
        this.card_family_jodi.setOnClickListener((View.OnClickListener)this);
        this.card_red_jodi.setOnClickListener((View.OnClickListener)this);
        this.card_halfsangam.setOnClickListener((View.OnClickListener)this);
        this.card_fullsangam.setOnClickListener((View.OnClickListener)this);
    }

    public void onClick(View view) {
        if (view == this.card_ankplay) {
            Intent intent = new Intent(this.getApplicationContext(), AnkRule.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        } else if (view == this.card_singleplay) {
            Intent intent = new Intent(this.getApplicationContext(), SinglePanaRule.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        } else if (view == this.card_doubleplay) {
            Intent intent = new Intent(this.getApplicationContext(), DoublePanaRule.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        } else if (view == this.card_tripleplay) {
            Intent intent = new Intent(this.getApplicationContext(), TriplePanaRule.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        } else if (view == this.card_spdptpplay) {
            Intent intent = new Intent(this.getApplicationContext(), SPDPTP_Rule.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_combine_pana) {
            Intent intent = new Intent(this.getApplicationContext(), CombinePana.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_family_pana) {
            Intent intent = new Intent(this.getApplicationContext(), FamilyPanaRule.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_multiple_pana) {
            Intent intent = new Intent(this.getApplicationContext(), MultiplePanaRule.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_spmotor) {
            Intent intent = new Intent(this.getApplicationContext(), SPMotor.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_dpmotor) {
            Intent intent = new Intent(this.getApplicationContext(), DPMotor.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_spdpmotor) {
            Intent intent = new Intent(this.getApplicationContext(), SPDPMotor.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_cpmotor) {
            Intent intent = new Intent(this.getApplicationContext(), CPMotor.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_jodi) {
            Intent intent = new Intent(this.getApplicationContext(), JodiRule.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_bulkjodi) {
            Intent intent = new Intent(this.getApplicationContext(), BulkJodi.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_family_jodi) {
            Intent intent = new Intent(this.getApplicationContext(), FamilyJodi.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_red_jodi) {
            Intent intent = new Intent(this.getApplicationContext(), RedJodi.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_halfsangam) {
            Intent intent = new Intent(this.getApplicationContext(), HalfSangam.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
        if (view == this.card_fullsangam) {
            Intent intent = new Intent(this.getApplicationContext(), FullSangam.class);
            intent.putExtra("data", (Serializable)this.data);
            intent.putExtra("timeData", (Serializable)this.timeData);
            this.startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492902);
        this.mGameDataRepository = GameDataRepository.getInstance((Context)this);
        Intent intent = this.getIntent();
        if (intent.hasExtra("data")) {
            this.data = (BazaarData)intent.getSerializableExtra("data");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(StringUtils.toCamelCase(this.data.getName()));
            stringBuilder.append(" Dashboard");
            this.title = stringBuilder.toString();
        }
        this.setUpToolbarByName(this.title);
        this.init();
        this.GetBidTime();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() != 16908332) {
            return super.onOptionsItemSelected(menuItem);
        }
        this.onBackPressed();
        return true;
    }

    @Override
    public void setUpToolbarByName(String string2) {
        Toolbar toolbar;
        this.toolbar = toolbar = (Toolbar)this.findViewById(2131296976);
        this.setSupportActionBar(toolbar);
        ActionBar actionBar = this.getSupportActionBar();
        actionBar.setHomeAsUpIndicator(2131165350);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle((CharSequence)string2);
        this.toolbar.setTitleTextColor(-1);
    }

}

