/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.Royal.Utils;

public class StringUtils {
    public static String toCamelCase(String string2) {
        if (string2 == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder(string2.length());
        for (String string3 : string2.split(" ")) {
            if (!string3.isEmpty()) {
                stringBuilder.append(string3.substring(0, 1).toUpperCase());
                stringBuilder.append(string3.substring(1).toLowerCase());
            }
            if (stringBuilder.length() == string2.length()) continue;
            stringBuilder.append(" ");
        }
        return stringBuilder.toString();
    }
}

