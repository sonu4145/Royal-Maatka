/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.NoSuchAlgorithmException
 *  java.security.SecureRandom
 */
package com.Royal.Utils;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class OTPUtils {
    public static String randomOTP(int n) {
        StringBuilder stringBuilder = new StringBuilder();
        SecureRandom secureRandom = SecureRandom.getInstance((String)"SHA1PRNG");
        for (int i = 0; i < n; ++i) {
            try {
                stringBuilder.append(secureRandom.nextInt(9));
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                noSuchAlgorithmException.printStackTrace();
                break;
            }
            continue;
        }
        return stringBuilder.toString();
    }
}

