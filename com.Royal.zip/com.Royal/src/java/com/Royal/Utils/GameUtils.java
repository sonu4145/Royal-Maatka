/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Calendar
 *  java.util.Collections
 *  java.util.Date
 *  java.util.List
 */
package com.Royal.Utils;

import com.Royal.data.BazaarTimeData;
import com.Royal.data.DayData;
import com.Royal.data.DaysName;
import com.Royal.data.GamesName;
import com.Royal.data.helper.CalenderHelper;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class GameUtils {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static ArrayList<Calendar> calculateDates(BazaarTimeData var0, GamesName var1_1) {
        var2_2 = new ArrayList();
        var3_3 = Calendar.getInstance();
        var3_3.setTime(CalenderHelper.currentCalendar.getTime());
        var4_4 = 0;
        var5_5 = 0;
        while (var4_4 < 7) {
            block19 : {
                block20 : {
                    block25 : {
                        block24 : {
                            block23 : {
                                block22 : {
                                    block21 : {
                                        block18 : {
                                            if (var5_5 >= 30) return var2_2;
                                            var6_6 = Calendar.getInstance();
                                            var6_6.setTime(CalenderHelper.currentCalendar.getTime());
                                            var6_6.add(5, var5_5);
                                            var7_7 = CalenderHelper.weekDayFullNameFormat.format(var6_6.getTime()).equalsIgnoreCase("sunday");
                                            var8_8 = true;
                                            if (!var7_7) break block18;
                                            var27_15 = var0.getDayData(DaysName.SUNDAY);
                                            if (!var27_15.getIsActive()) break block19;
                                            if (!var0.hasOpenSession(var1_1) || var27_15.getCalOpenTime() == null) ** GOTO lbl-1000
                                            var6_6.set(11, var27_15.getCalOpenTime().get(11));
                                            var6_6.set(12, var27_15.getCalOpenTime().get(12));
                                            var6_6.set(13, var27_15.getCalOpenTime().get(13));
                                            if (!var0.hasOpenResult(var6_6) && !CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) {
                                                var2_2.add((Object)var6_6);
                                                ++var4_4;
                                            } else lbl-1000: // 2 sources:
                                            {
                                                var8_8 = false;
                                            }
                                            if (!var0.hasCloseSession(var1_1) || var27_15.getCalCloseTime() == null || var8_8) break block19;
                                            var6_6.set(11, var27_15.getCalCloseTime().get(11));
                                            var6_6.set(12, var27_15.getCalCloseTime().get(12));
                                            var6_6.set(13, var27_15.getCalCloseTime().get(13));
                                            if (var0.hasCloseResult(var6_6) || CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) break block19;
                                            var2_2.add((Object)var6_6);
                                            break block20;
                                        }
                                        if (!CalenderHelper.weekDayFullNameFormat.format(var6_6.getTime()).equalsIgnoreCase("monday")) break block21;
                                        var24_14 = var0.getDayData(DaysName.MONDAY);
                                        if (!var24_14.getIsActive()) break block19;
                                        if (!var0.hasOpenSession(var1_1) || var24_14.getCalOpenTime() == null) ** GOTO lbl-1000
                                        var6_6.set(11, var24_14.getCalOpenTime().get(11));
                                        var6_6.set(12, var24_14.getCalOpenTime().get(12));
                                        var6_6.set(13, var24_14.getCalOpenTime().get(13));
                                        if (!var0.hasOpenResult(var6_6) && !CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) {
                                            var2_2.add((Object)var6_6);
                                            ++var4_4;
                                        } else lbl-1000: // 2 sources:
                                        {
                                            var8_8 = false;
                                        }
                                        if (!var0.hasCloseSession(var1_1) || var24_14.getCalCloseTime() == null || var8_8) break block19;
                                        var6_6.set(11, var24_14.getCalCloseTime().get(11));
                                        var6_6.set(12, var24_14.getCalCloseTime().get(12));
                                        var6_6.set(13, var24_14.getCalCloseTime().get(13));
                                        if (var0.hasCloseResult(var6_6) || CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) break block19;
                                        var2_2.add((Object)var6_6);
                                        break block20;
                                    }
                                    if (!CalenderHelper.weekDayFullNameFormat.format(var6_6.getTime()).equalsIgnoreCase("tuesday")) break block22;
                                    var21_13 = var0.getDayData(DaysName.TUESDAY);
                                    if (!var21_13.getIsActive()) break block19;
                                    if (!var0.hasOpenSession(var1_1) || var21_13.getCalOpenTime() == null) ** GOTO lbl-1000
                                    var6_6.set(11, var21_13.getCalOpenTime().get(11));
                                    var6_6.set(12, var21_13.getCalOpenTime().get(12));
                                    var6_6.set(13, var21_13.getCalOpenTime().get(13));
                                    if (!var0.hasOpenResult(var6_6) && !CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) {
                                        var2_2.add((Object)var6_6);
                                        ++var4_4;
                                    } else lbl-1000: // 2 sources:
                                    {
                                        var8_8 = false;
                                    }
                                    if (!var0.hasCloseSession(var1_1) || var21_13.getCalCloseTime() == null || var8_8) break block19;
                                    var6_6.set(11, var21_13.getCalCloseTime().get(11));
                                    var6_6.set(12, var21_13.getCalCloseTime().get(12));
                                    var6_6.set(13, var21_13.getCalCloseTime().get(13));
                                    if (var0.hasCloseResult(var6_6) || CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) break block19;
                                    var2_2.add((Object)var6_6);
                                    break block20;
                                }
                                if (!CalenderHelper.weekDayFullNameFormat.format(var6_6.getTime()).equalsIgnoreCase("wednesday")) break block23;
                                var18_12 = var0.getDayData(DaysName.WEDNESDAY);
                                if (!var18_12.getIsActive()) break block19;
                                if (!var0.hasOpenSession(var1_1) || var18_12.getCalOpenTime() == null) ** GOTO lbl-1000
                                var6_6.set(11, var18_12.getCalOpenTime().get(11));
                                var6_6.set(12, var18_12.getCalOpenTime().get(12));
                                var6_6.set(13, var18_12.getCalOpenTime().get(13));
                                if (!var0.hasOpenResult(var6_6) && !CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) {
                                    var2_2.add((Object)var6_6);
                                    ++var4_4;
                                } else lbl-1000: // 2 sources:
                                {
                                    var8_8 = false;
                                }
                                if (!var0.hasCloseSession(var1_1) || var18_12.getCalCloseTime() == null || var8_8) break block19;
                                var6_6.set(11, var18_12.getCalCloseTime().get(11));
                                var6_6.set(12, var18_12.getCalCloseTime().get(12));
                                var6_6.set(13, var18_12.getCalCloseTime().get(13));
                                if (var0.hasCloseResult(var6_6) || CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) break block19;
                                var2_2.add((Object)var6_6);
                                break block20;
                            }
                            if (!CalenderHelper.weekDayFullNameFormat.format(var6_6.getTime()).equalsIgnoreCase("thursday")) break block24;
                            var15_11 = var0.getDayData(DaysName.THURSDAY);
                            if (!var15_11.getIsActive()) break block19;
                            if (!var0.hasOpenSession(var1_1) || var15_11.getCalOpenTime() == null) ** GOTO lbl-1000
                            var6_6.set(11, var15_11.getCalOpenTime().get(11));
                            var6_6.set(12, var15_11.getCalOpenTime().get(12));
                            var6_6.set(13, var15_11.getCalOpenTime().get(13));
                            if (!var0.hasOpenResult(var6_6) && !CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) {
                                var2_2.add((Object)var6_6);
                                ++var4_4;
                            } else lbl-1000: // 2 sources:
                            {
                                var8_8 = false;
                            }
                            if (!var0.hasCloseSession(var1_1) || var15_11.getCalCloseTime() == null || var8_8) break block19;
                            var6_6.set(11, var15_11.getCalCloseTime().get(11));
                            var6_6.set(12, var15_11.getCalCloseTime().get(12));
                            var6_6.set(13, var15_11.getCalCloseTime().get(13));
                            if (var0.hasCloseResult(var6_6) || CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) break block19;
                            var2_2.add((Object)var6_6);
                            break block20;
                        }
                        if (!CalenderHelper.weekDayFullNameFormat.format(var6_6.getTime()).equalsIgnoreCase("friday")) break block25;
                        var12_10 = var0.getDayData(DaysName.FRIDAY);
                        if (!var12_10.getIsActive()) break block19;
                        if (!var0.hasOpenSession(var1_1) || var12_10.getCalOpenTime() == null) ** GOTO lbl-1000
                        var6_6.set(11, var12_10.getCalOpenTime().get(11));
                        var6_6.set(12, var12_10.getCalOpenTime().get(12));
                        var6_6.set(13, var12_10.getCalOpenTime().get(13));
                        if (!var0.hasOpenResult(var6_6) && !CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) {
                            var2_2.add((Object)var6_6);
                            ++var4_4;
                        } else lbl-1000: // 2 sources:
                        {
                            var8_8 = false;
                        }
                        if (!var0.hasCloseSession(var1_1) || var12_10.getCalCloseTime() == null || var8_8) break block19;
                        var6_6.set(11, var12_10.getCalCloseTime().get(11));
                        var6_6.set(12, var12_10.getCalCloseTime().get(12));
                        var6_6.set(13, var12_10.getCalCloseTime().get(13));
                        if (var0.hasCloseResult(var6_6) || CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) break block19;
                        var2_2.add((Object)var6_6);
                        break block20;
                    }
                    if (!CalenderHelper.weekDayFullNameFormat.format(var6_6.getTime()).equalsIgnoreCase("saturday") || !(var9_9 = var0.getDayData(DaysName.SATURDAY)).getIsActive()) break block19;
                    if (!var0.hasOpenSession(var1_1) || var9_9.getCalOpenTime() == null) ** GOTO lbl-1000
                    var6_6.set(11, var9_9.getCalOpenTime().get(11));
                    var6_6.set(12, var9_9.getCalOpenTime().get(12));
                    var6_6.set(13, var9_9.getCalOpenTime().get(13));
                    if (!var0.hasOpenResult(var6_6) && !CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) {
                        var2_2.add((Object)var6_6);
                        ++var4_4;
                    } else lbl-1000: // 2 sources:
                    {
                        var8_8 = false;
                    }
                    if (!var0.hasCloseSession(var1_1) || var9_9.getCalCloseTime() == null || var8_8) break block19;
                    var6_6.set(11, var9_9.getCalCloseTime().get(11));
                    var6_6.set(12, var9_9.getCalCloseTime().get(12));
                    var6_6.set(13, var9_9.getCalCloseTime().get(13));
                    if (var0.hasCloseResult(var6_6) || CalenderHelper.isTimeInPast(var3_3, var6_6, var0.getCreateBidTimeGapInMinute())) break block19;
                    var2_2.add((Object)var6_6);
                }
                ++var4_4;
            }
            ++var5_5;
        }
        return var2_2;
    }

    public static ArrayList<String> getBulkJodiDigits(String string2, String string3) {
        String string4;
        String string5;
        ArrayList arrayList = new ArrayList();
        if (string2.contains((CharSequence)"0")) {
            String string6 = GameUtils.getSortedString(string2.replace((CharSequence)"0", (CharSequence)""));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string6);
            stringBuilder.append("0");
            string5 = stringBuilder.toString();
        } else {
            string5 = GameUtils.getSortedString(string2);
        }
        if (string3.contains((CharSequence)"0")) {
            String string7 = GameUtils.getSortedString(string3.replace((CharSequence)"0", (CharSequence)""));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string7);
            stringBuilder.append("0");
            string4 = stringBuilder.toString();
        } else {
            string4 = GameUtils.getSortedString(string3);
        }
        for (int i = 0; i < string5.length(); ++i) {
            for (int j = 0; j < string4.length(); ++j) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string5.charAt(i));
                stringBuilder.append("");
                stringBuilder.append(string4.charAt(j));
                arrayList.add((Object)stringBuilder.toString());
            }
        }
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public static ArrayList<String> getCPMotorDigits(String string2) {
        ArrayList arrayList = new ArrayList();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(string2.charAt(0));
        String string3 = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("");
        stringBuilder2.append(string2.charAt(1));
        String string4 = stringBuilder2.toString();
        for (int i = 0; i < 10; ++i) {
            ArrayList arrayList2 = new ArrayList();
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(string3);
            stringBuilder3.append("");
            stringBuilder3.append(string4);
            stringBuilder3.append("");
            stringBuilder3.append(i);
            arrayList2.add((Object)stringBuilder3.toString());
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append(i);
            stringBuilder4.append("");
            stringBuilder4.append(string3);
            stringBuilder4.append("");
            stringBuilder4.append(string4);
            arrayList2.add((Object)stringBuilder4.toString());
            StringBuilder stringBuilder5 = new StringBuilder();
            stringBuilder5.append(string3);
            stringBuilder5.append("");
            stringBuilder5.append(i);
            stringBuilder5.append("");
            stringBuilder5.append(string4);
            arrayList2.add((Object)stringBuilder5.toString());
            StringBuilder stringBuilder6 = new StringBuilder();
            stringBuilder6.append(string4);
            stringBuilder6.append("");
            stringBuilder6.append(i);
            stringBuilder6.append("");
            stringBuilder6.append(string3);
            arrayList2.add((Object)stringBuilder6.toString());
            for (int j = 0; j < arrayList2.size(); ++j) {
                if (arrayList.contains(arrayList2.get(j))) continue;
                if (GameUtils.isSinglePana((String)arrayList2.get(j))) {
                    arrayList.add((Object)((String)arrayList2.get(j)));
                    continue;
                }
                if (GameUtils.isDoublePana((String)arrayList2.get(j))) {
                    arrayList.add((Object)((String)arrayList2.get(j)));
                    continue;
                }
                if (!GameUtils.isTriplePana((String)arrayList2.get(j))) continue;
                arrayList.add((Object)((String)arrayList2.get(j)));
            }
        }
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public static ArrayList<String> getCPMotorDigits2(String string2) {
        String string3;
        ArrayList arrayList = new ArrayList();
        if (string2.contains((CharSequence)"0")) {
            String string4 = GameUtils.getSortedString(string2.replace((CharSequence)"0", (CharSequence)""));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string4);
            stringBuilder.append("0");
            string3 = stringBuilder.toString();
        } else {
            string3 = GameUtils.getSortedString(string2);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(string3.charAt(0));
        String string5 = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("");
        stringBuilder2.append(string3.charAt(1));
        String string6 = stringBuilder2.toString();
        for (int i = 0; i < 10; ++i) {
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append(string5);
            stringBuilder3.append("");
            stringBuilder3.append(string6);
            stringBuilder3.append("");
            stringBuilder3.append(i);
            String string7 = stringBuilder3.toString();
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append(i);
            stringBuilder4.append("");
            stringBuilder4.append(string5);
            stringBuilder4.append("");
            stringBuilder4.append(string6);
            String string8 = stringBuilder4.toString();
            StringBuilder stringBuilder5 = new StringBuilder();
            stringBuilder5.append(string5);
            stringBuilder5.append("");
            stringBuilder5.append(i);
            stringBuilder5.append("");
            stringBuilder5.append(string6);
            String string9 = stringBuilder5.toString();
            StringBuilder stringBuilder6 = new StringBuilder();
            stringBuilder6.append(string6);
            stringBuilder6.append("");
            stringBuilder6.append(i);
            stringBuilder6.append("");
            stringBuilder6.append(string5);
            String string10 = stringBuilder6.toString();
            if (GameUtils.isSinglePana(string7)) {
                arrayList.add((Object)string7);
            }
            if (GameUtils.isSinglePana(string8)) {
                arrayList.add((Object)string8);
            }
            if (GameUtils.isSinglePana(string9)) {
                arrayList.add((Object)string9);
            }
            if (GameUtils.isSinglePana(string10)) {
                arrayList.add((Object)string10);
            }
            if (GameUtils.isDoublePana(string7)) {
                arrayList.add((Object)string7);
            }
            if (GameUtils.isDoublePana(string8)) {
                arrayList.add((Object)string8);
            }
            if (!GameUtils.isTriplePana(string7)) continue;
            arrayList.add((Object)string7);
        }
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public static ArrayList<String> getDPMotorDigits(String string2) {
        String string3;
        ArrayList arrayList = new ArrayList();
        if (string2.contains((CharSequence)"0")) {
            String string4 = GameUtils.getSortedString(string2.replace((CharSequence)"0", (CharSequence)""));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string4);
            stringBuilder.append("0");
            string3 = stringBuilder.toString();
        } else {
            string3 = GameUtils.getSortedString(string2);
        }
        for (int i = 0; i < -1 + string3.length(); ++i) {
            for (int j = i; j < string3.length(); ++j) {
                if (Character.getNumericValue((char)string3.charAt(i)) < Character.getNumericValue((char)string3.charAt(j))) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string3.charAt(i));
                    stringBuilder.append("");
                    stringBuilder.append(string3.charAt(j));
                    stringBuilder.append("");
                    stringBuilder.append(string3.charAt(j));
                    String string5 = stringBuilder.toString();
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(string3.charAt(i));
                    stringBuilder2.append("");
                    stringBuilder2.append(string3.charAt(i));
                    stringBuilder2.append("");
                    stringBuilder2.append(string3.charAt(j));
                    String string6 = stringBuilder2.toString();
                    arrayList.add((Object)string5);
                    arrayList.add((Object)string6);
                    continue;
                }
                if (Character.getNumericValue((char)string3.charAt(j)) != 0) continue;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string3.charAt(i));
                stringBuilder.append("");
                stringBuilder.append(string3.charAt(j));
                stringBuilder.append("");
                stringBuilder.append(string3.charAt(j));
                arrayList.add((Object)stringBuilder.toString());
            }
        }
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public static ArrayList<String> getDoublePanaDigits() {
        ArrayList arrayList = new ArrayList();
        for (int i = 100; i < 1000; ++i) {
            String string2 = String.valueOf((int)i);
            if (!GameUtils.isDoublePana(string2)) continue;
            arrayList.add((Object)string2);
        }
        return arrayList;
    }

    public static ArrayList<String> getFamilyJodiDigits(String string2) {
        ArrayList arrayList = new ArrayList();
        if (string2.length() == 2) {
            String string3 = string2.substring(0, -1 + string2.length());
            String string4 = string2.substring(-1 + string2.length());
            int n = Integer.parseInt((String)string3);
            int n2 = Integer.parseInt((String)string4);
            int n3 = (n + 5) % 10;
            int n4 = (n2 + 5) % 10;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(n);
            stringBuilder.append("");
            stringBuilder.append(n2);
            stringBuilder.append("");
            stringBuilder.append(n3);
            stringBuilder.append("");
            stringBuilder.append(n4);
            String string5 = stringBuilder.toString();
            for (int i = 0; i < string5.length(); ++i) {
                for (int j = 0; j < string5.length(); ++j) {
                    if (i == j || n == Character.getNumericValue((char)string5.charAt(i)) && n3 == Character.getNumericValue((char)string5.charAt(j)) || n == Character.getNumericValue((char)string5.charAt(j)) && n3 == Character.getNumericValue((char)string5.charAt(i)) || n2 == Character.getNumericValue((char)string5.charAt(i)) && n4 == Character.getNumericValue((char)string5.charAt(j)) || n2 == Character.getNumericValue((char)string5.charAt(j)) && n4 == Character.getNumericValue((char)string5.charAt(i))) continue;
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(string5.charAt(i));
                    stringBuilder2.append("");
                    stringBuilder2.append(string5.charAt(j));
                    arrayList.add((Object)stringBuilder2.toString());
                }
            }
        }
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public static ArrayList<String> getFamilyPanaDigits() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)"000");
        for (int i = 100; i < 1000; ++i) {
            String string2 = String.valueOf((int)i);
            if (GameUtils.isSinglePana(string2)) {
                arrayList.add((Object)string2);
                continue;
            }
            if (GameUtils.isDoublePana(string2)) {
                arrayList.add((Object)string2);
                continue;
            }
            if (!GameUtils.isTriplePana(string2)) continue;
            arrayList.add((Object)string2);
        }
        return arrayList;
    }

    public static ArrayList<String> getJodiDigits() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < 100; ++i) {
            Object[] arrobject = new Object[]{i};
            arrayList.add((Object)String.format((String)"%02d", (Object[])arrobject));
        }
        return arrayList;
    }

    public static ArrayList<String> getMultiplePanaDigits(boolean bl) {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)"0");
        arrayList.add((Object)"000");
        if (bl) {
            arrayList.add((Object)"00");
        }
        for (int i = 1; i < 1000; ++i) {
            String string2 = String.valueOf((int)i);
            if (i > 99) {
                if (GameUtils.isSinglePana(string2)) {
                    arrayList.add((Object)string2);
                    continue;
                }
                if (GameUtils.isDoublePana(string2)) {
                    arrayList.add((Object)string2);
                    continue;
                }
                if (!GameUtils.isTriplePana(string2)) continue;
                arrayList.add((Object)string2);
                continue;
            }
            if (bl) {
                arrayList.add((Object)string2);
                continue;
            }
            if (i >= 10) continue;
            arrayList.add((Object)string2);
        }
        return arrayList;
    }

    public static ArrayList<String> getRedJodiDigits(String string2) {
        ArrayList arrayList = new ArrayList();
        if (string2.length() == 1) {
            int n = Integer.parseInt((String)string2);
            int n2 = (n + 5) % 10;
            int n3 = (n2 + 5) % 10;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(n);
            stringBuilder.append("");
            stringBuilder.append(n2);
            String string3 = stringBuilder.toString();
            for (int i = 0; i < string3.length(); ++i) {
                for (int j = 0; j < string3.length(); ++j) {
                    if (i == j) {
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(string3.charAt(i));
                        stringBuilder2.append("");
                        stringBuilder2.append(string3.charAt(j));
                        arrayList.add((Object)stringBuilder2.toString());
                        continue;
                    }
                    if (n == Character.getNumericValue((char)string3.charAt(i)) && n2 == Character.getNumericValue((char)string3.charAt(j))) {
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append(string3.charAt(i));
                        stringBuilder3.append("");
                        stringBuilder3.append(string3.charAt(j));
                        arrayList.add((Object)stringBuilder3.toString());
                        continue;
                    }
                    if (n == Character.getNumericValue((char)string3.charAt(j)) && n2 == Character.getNumericValue((char)string3.charAt(i))) {
                        StringBuilder stringBuilder4 = new StringBuilder();
                        stringBuilder4.append(string3.charAt(i));
                        stringBuilder4.append("");
                        stringBuilder4.append(string3.charAt(j));
                        arrayList.add((Object)stringBuilder4.toString());
                        continue;
                    }
                    if (n2 == Character.getNumericValue((char)string3.charAt(i)) && n3 == Character.getNumericValue((char)string3.charAt(j))) {
                        StringBuilder stringBuilder5 = new StringBuilder();
                        stringBuilder5.append(string3.charAt(i));
                        stringBuilder5.append("");
                        stringBuilder5.append(string3.charAt(j));
                        arrayList.add((Object)stringBuilder5.toString());
                        continue;
                    }
                    if (n2 != Character.getNumericValue((char)string3.charAt(j)) || n3 != Character.getNumericValue((char)string3.charAt(i))) continue;
                    StringBuilder stringBuilder6 = new StringBuilder();
                    stringBuilder6.append(string3.charAt(i));
                    stringBuilder6.append("");
                    stringBuilder6.append(string3.charAt(j));
                    arrayList.add((Object)stringBuilder6.toString());
                }
            }
        }
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public static ArrayList<String> getSPDPMotorDigits(String string2) {
        String string3;
        ArrayList arrayList = new ArrayList();
        if (string2.contains((CharSequence)"0")) {
            String string4 = GameUtils.getSortedString(string2.replace((CharSequence)"0", (CharSequence)""));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string4);
            stringBuilder.append("0");
            string3 = stringBuilder.toString();
        } else {
            string3 = GameUtils.getSortedString(string2);
        }
        int n = 0;
        do {
            int n2 = -2 + string3.length();
            if (n >= n2) break;
            for (int i = n; i < -1 + string3.length(); ++i) {
                for (int j = i; j < string3.length(); ++j) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string3.charAt(n));
                    stringBuilder.append("");
                    stringBuilder.append(string3.charAt(i));
                    stringBuilder.append("");
                    stringBuilder.append(string3.charAt(j));
                    String string5 = stringBuilder.toString();
                    if (!GameUtils.isSinglePana(string5)) continue;
                    arrayList.add((Object)string5);
                }
            }
            ++n;
        } while (true);
        for (int i = 0; i < -1 + string3.length(); ++i) {
            for (int j = i; j < string3.length(); ++j) {
                if (Character.getNumericValue((char)string3.charAt(i)) < Character.getNumericValue((char)string3.charAt(j))) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string3.charAt(i));
                    stringBuilder.append("");
                    stringBuilder.append(string3.charAt(j));
                    stringBuilder.append("");
                    stringBuilder.append(string3.charAt(j));
                    String string6 = stringBuilder.toString();
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(string3.charAt(i));
                    stringBuilder2.append("");
                    stringBuilder2.append(string3.charAt(i));
                    stringBuilder2.append("");
                    stringBuilder2.append(string3.charAt(j));
                    String string7 = stringBuilder2.toString();
                    arrayList.add((Object)string6);
                    arrayList.add((Object)string7);
                    continue;
                }
                if (Character.getNumericValue((char)string3.charAt(j)) != 0) continue;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string3.charAt(i));
                stringBuilder.append("");
                stringBuilder.append(string3.charAt(j));
                stringBuilder.append("");
                stringBuilder.append(string3.charAt(j));
                arrayList.add((Object)stringBuilder.toString());
            }
        }
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public static ArrayList<String> getSPMotorDigits(String string2) {
        String string3;
        ArrayList arrayList = new ArrayList();
        if (string2.contains((CharSequence)"0")) {
            String string4 = GameUtils.getSortedString(string2.replace((CharSequence)"0", (CharSequence)""));
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string4);
            stringBuilder.append("0");
            string3 = stringBuilder.toString();
        } else {
            string3 = GameUtils.getSortedString(string2);
        }
        for (int i = 0; i < -2 + string3.length(); ++i) {
            for (int j = i; j < -1 + string3.length(); ++j) {
                for (int k = j; k < string3.length(); ++k) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string3.charAt(i));
                    stringBuilder.append("");
                    stringBuilder.append(string3.charAt(j));
                    stringBuilder.append("");
                    stringBuilder.append(string3.charAt(k));
                    String string5 = stringBuilder.toString();
                    if (!GameUtils.isSinglePana(string5)) continue;
                    arrayList.add((Object)string5);
                }
            }
        }
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public static ArrayList<String> getSinglePanaDigits() {
        ArrayList arrayList = new ArrayList();
        for (int i = 100; i < 1000; ++i) {
            String string2 = String.valueOf((int)i);
            if (!GameUtils.isSinglePana(string2)) continue;
            arrayList.add((Object)string2);
        }
        return arrayList;
    }

    public static String getSortedString(String string2) {
        char[] arrc = string2.toCharArray();
        Arrays.sort((char[])arrc);
        return new String(arrc);
    }

    public static ArrayList<String> getTriplePanaDigits() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)"000");
        for (int i = 100; i < 1000; ++i) {
            String string2 = String.valueOf((int)i);
            if (!GameUtils.isTriplePana(string2)) continue;
            arrayList.add((Object)string2);
        }
        return arrayList;
    }

    public static boolean isAnk(String string2) {
        if (string2.length() == 1) {
            int n = Character.getNumericValue((char)string2.charAt(0));
            for (int i = 0; i < 10; ++i) {
                if (n != i) continue;
                return true;
            }
        }
        return false;
    }

    public static boolean isDoublePana(String string2) {
        if (string2.length() == 3) {
            int n = Character.getNumericValue((char)string2.charAt(0));
            int n2 = Character.getNumericValue((char)string2.charAt(1));
            int n3 = Character.getNumericValue((char)string2.charAt(2));
            if (n > 0 && (n > 0 && n2 == n3 && n3 == 0 || n < n2 && n2 == n3 || n == n2 && (n2 < n3 || n3 == 0))) {
                return true;
            }
        }
        return false;
    }

    public static boolean isJodi(String string2) {
        if (string2.length() == 2) {
            for (int i = 0; i < 100; ++i) {
                Object[] arrobject = new Object[]{i};
                String string3 = String.format((String)"%02d", (Object[])arrobject);
                if (!string3.equalsIgnoreCase(string3)) continue;
                return true;
            }
        }
        return false;
    }

    public static boolean isSinglePana(String string2) {
        if (string2.length() == 3) {
            int n = Character.getNumericValue((char)string2.charAt(0));
            int n2 = Character.getNumericValue((char)string2.charAt(1));
            int n3 = Character.getNumericValue((char)string2.charAt(2));
            if (n > 0 && n < n2 && (n2 < n3 || n3 == 0)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isTriplePana(String string2) {
        if (string2.length() == 3) {
            int n = Character.getNumericValue((char)string2.charAt(0));
            int n2 = Character.getNumericValue((char)string2.charAt(1));
            int n3 = Character.getNumericValue((char)string2.charAt(2));
            if (n == n2 && n2 == n3) {
                return true;
            }
            if (string2.equalsIgnoreCase("000")) {
                return true;
            }
        }
        return false;
    }

    public static ArrayList<String> searchCombinePanaDigits(String string2, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5, boolean bl6) {
        ArrayList arrayList = new ArrayList();
        if (bl3 && string2.equalsIgnoreCase("0")) {
            arrayList.add((Object)"000");
        }
        for (int i = 100; i < 1000; ++i) {
            String string3 = String.valueOf((int)i);
            if (bl4 && Character.getNumericValue((char)string3.charAt(0)) == Character.getNumericValue((char)string2.charAt(0))) {
                if (bl && GameUtils.isSinglePana(string3)) {
                    arrayList.add((Object)string3);
                    continue;
                }
                if (bl2 && GameUtils.isDoublePana(string3)) {
                    arrayList.add((Object)string3);
                    continue;
                }
                if (bl3 && GameUtils.isTriplePana(string3)) {
                    arrayList.add((Object)string3);
                    continue;
                }
            }
            if (bl5 && Character.getNumericValue((char)string3.charAt(1)) == Character.getNumericValue((char)string2.charAt(0))) {
                if (bl && GameUtils.isSinglePana(string3)) {
                    arrayList.add((Object)string3);
                    continue;
                }
                if (bl2 && GameUtils.isDoublePana(string3)) {
                    arrayList.add((Object)string3);
                    continue;
                }
                if (bl3 && GameUtils.isTriplePana(string3)) {
                    arrayList.add((Object)string3);
                    continue;
                }
            }
            if (!bl6 || Character.getNumericValue((char)string3.charAt(2)) != Character.getNumericValue((char)string2.charAt(0))) continue;
            if (bl && GameUtils.isSinglePana(string3)) {
                arrayList.add((Object)string3);
                continue;
            }
            if (bl2 && GameUtils.isDoublePana(string3)) {
                arrayList.add((Object)string3);
                continue;
            }
            if (!bl3 || !GameUtils.isTriplePana(string3)) continue;
            arrayList.add((Object)string3);
        }
        return arrayList;
    }

    public static ArrayList<String> searchFamilyPanaDigits(String string2) {
        ArrayList arrayList = new ArrayList();
        ArrayList<String> arrayList2 = GameUtils.getFamilyPanaDigits();
        if (string2.length() == 3) {
            int n = Character.getNumericValue((char)string2.charAt(0));
            int n2 = Character.getNumericValue((char)string2.charAt(1));
            int n3 = Character.getNumericValue((char)string2.charAt(2));
            int n4 = (n3 + (n + n2)) % 10;
            int n5 = (n + 5) % 10;
            int n6 = (n2 + 5) % 10;
            int n7 = (n3 + 5) % 10;
            int n8 = (n7 + (n5 + n6)) % 10;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(n);
            stringBuilder.append("");
            stringBuilder.append(n2);
            stringBuilder.append("");
            stringBuilder.append(n3);
            stringBuilder.append("");
            stringBuilder.append(n5);
            stringBuilder.append("");
            stringBuilder.append(n6);
            stringBuilder.append("");
            stringBuilder.append(n7);
            String string3 = stringBuilder.toString();
            for (int i = 0; i < string3.length(); ++i) {
                for (int j = 0; j < string3.length(); ++j) {
                    for (int k = 0; k < string3.length(); ++k) {
                        if (i == j && j == k) continue;
                        StringBuilder stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(string3.charAt(i));
                        stringBuilder2.append("");
                        stringBuilder2.append(string3.charAt(j));
                        stringBuilder2.append("");
                        stringBuilder2.append(string3.charAt(k));
                        String string4 = stringBuilder2.toString();
                        int n9 = (Character.getNumericValue((char)string3.charAt(i)) + Character.getNumericValue((char)string3.charAt(j)) + Character.getNumericValue((char)string3.charAt(k))) % 10;
                        if (n9 != n4 && n9 != n8 || !arrayList2.contains((Object)string4) || arrayList.contains((Object)string4)) continue;
                        arrayList.add((Object)string4);
                    }
                }
            }
        }
        Collections.sort((List)arrayList);
        return arrayList;
    }

    public static ArrayList<String> searchSPDPTPDigits(String string2, boolean bl, boolean bl2, boolean bl3) {
        ArrayList arrayList = new ArrayList();
        if (bl3 && string2.equalsIgnoreCase("0")) {
            arrayList.add((Object)"000");
        }
        for (int i = 100; i < 1000; ++i) {
            String string3 = String.valueOf((int)i);
            int n = (Character.getNumericValue((char)string3.charAt(0)) + Character.getNumericValue((char)string3.charAt(1)) + Character.getNumericValue((char)string3.charAt(2))) % 10;
            if (Character.getNumericValue((char)string2.charAt(0)) != n) continue;
            if (bl && GameUtils.isSinglePana(string3)) {
                arrayList.add((Object)string3);
                continue;
            }
            if (bl2 && GameUtils.isDoublePana(string3)) {
                arrayList.add((Object)string3);
                continue;
            }
            if (!bl3 || !GameUtils.isTriplePana(string3)) continue;
            arrayList.add((Object)string3);
        }
        return arrayList;
    }
}

