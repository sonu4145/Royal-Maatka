/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.org.apache.commons.codec.binary.Base64
 *  java.io.PrintStream
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.security.Key
 *  java.security.NoSuchAlgorithmException
 *  java.security.spec.AlgorithmParameterSpec
 *  javax.crypto.Cipher
 *  javax.crypto.NoSuchPaddingException
 *  javax.crypto.spec.IvParameterSpec
 *  javax.crypto.spec.SecretKeySpec
 */
package com.Royal.Utils;

import android.org.apache.commons.codec.binary.Base64;
import java.io.PrintStream;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoHelper {
    private static final String SecretKey = "qaz127mlp[;.8yt&";
    private Cipher cipher;
    private IvParameterSpec ivspec = new IvParameterSpec("qaz127mlp[;.8yt&".getBytes());
    private SecretKeySpec keyspec = new SecretKeySpec("qaz127mlp[;.8yt&".getBytes(), "AES");

    public CryptoHelper() {
        try {
            this.cipher = Cipher.getInstance((String)"AES/CBC/PKCS5Padding");
            return;
        }
        catch (NoSuchPaddingException noSuchPaddingException) {
            noSuchPaddingException.printStackTrace();
            return;
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            noSuchAlgorithmException.printStackTrace();
            return;
        }
    }

    public static String decrypt(String string2) throws Exception {
        return new String(new CryptoHelper().decryptInternal(string2));
    }

    private byte[] decryptInternal(String string2) throws Exception {
        if (string2 != null && string2.length() != 0) {
            try {
                this.cipher.init(2, (Key)this.keyspec, (AlgorithmParameterSpec)this.ivspec);
                byte[] arrby = this.cipher.doFinal(Base64.decodeBase64((String)string2));
                return arrby;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("[decrypt] ");
                stringBuilder.append(exception.getMessage());
                throw new Exception(stringBuilder.toString());
            }
        }
        throw new Exception("Empty string");
    }

    public static String encrypt(String string2) throws Exception {
        return Base64.encodeBase64String((byte[])new CryptoHelper().encryptInternal(string2));
    }

    private byte[] encryptInternal(String string2) throws Exception {
        if (string2 != null && string2.length() != 0) {
            try {
                this.cipher.init(1, (Key)this.keyspec, (AlgorithmParameterSpec)this.ivspec);
                byte[] arrby = this.cipher.doFinal(string2.getBytes());
                return arrby;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("[encrypt] ");
                stringBuilder.append(exception.getMessage());
                throw new Exception(stringBuilder.toString());
            }
        }
        throw new Exception("Empty string");
    }

    public static void main(String[] arrstring) throws Exception {
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("input:");
        stringBuilder.append("Text to encryp");
        printStream.println(stringBuilder.toString());
        String string2 = CryptoHelper.encrypt("Text to encryp");
        PrintStream printStream2 = System.out;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("cipher:");
        stringBuilder2.append(string2);
        printStream2.println(stringBuilder2.toString());
        PrintStream printStream3 = System.out;
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("cipher:");
        stringBuilder3.append(string2);
        printStream3.println(stringBuilder3.toString());
        String string3 = CryptoHelper.decrypt(string2);
        PrintStream printStream4 = System.out;
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append("output:");
        stringBuilder4.append(string3);
        printStream4.println(stringBuilder4.toString());
    }
}

