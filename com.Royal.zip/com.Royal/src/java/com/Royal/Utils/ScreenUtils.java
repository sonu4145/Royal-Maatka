/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  com.Royal.AllActivity.AppLockActivity
 *  com.Royal.AllActivity.Login
 *  java.lang.Class
 *  java.lang.Object
 */
package com.Royal.Utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import com.Royal.AllActivity.AppLockActivity;
import com.Royal.AllActivity.Login;

public class ScreenUtils {
    public static void showLockScreen(Activity activity) {
        Intent intent = new Intent((Context)activity, AppLockActivity.class);
        intent.setFlags(268468224);
        activity.startActivity(intent);
    }

    public static void showLoginScreen(Activity activity) {
        Intent intent = new Intent((Context)activity, Login.class);
        intent.setFlags(268468224);
        activity.startActivity(intent);
    }
}

