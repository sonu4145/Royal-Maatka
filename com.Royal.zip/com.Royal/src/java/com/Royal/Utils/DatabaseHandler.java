/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteDatabase$CursorFactory
 *  android.database.sqlite.SQLiteOpenHelper
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 */
package com.Royal.Utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;

public class DatabaseHandler
extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "matka";
    private static final int DATABASE_VERSION = 1;
    private static final String KEY_City = "city";
    private static final String KEY_DOB = "dob";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_EMERGENCE_1 = "emgone";
    private static final String KEY_EMERGENCE_2 = "emgtwo";
    private static final String KEY_EMERGENCE_3 = "emgthree";
    private static final String KEY_Fname = "fname";
    private static final String KEY_Gender = "gender";
    private static final String KEY_Insurance = "insurance";
    private static final String KEY_Lname = "lname";
    private static final String KEY_Mobile = "mobile";
    private static final String KEY_Polutiondate = "polutiondate";
    private static final String KEY_State = "state";
    private static final String KEY_UserId = "userid";
    private static final String KEY_Veh_reg_no = "regno";
    private static final String KEY_occupation = "occupation";
    private static final String KEY_policy_exp_date = "expdate";
    private static final String KEY_vehicletype = "vehicletype";
    private static final String TABLE_USER_DETAIL = "user_detail";
    String CREATE_USER_DETAIL_TABLE = "CREATE TABLE user_detail(userid TEXT,fname TEXT,lname TEXT,email TEXT,mobile TEXT,dob TEXT,gender TEXT,city TEXT,state TEXT,vehicletype TEXT,regno TEXT,insurance TEXT,expdate TEXT,emgone TEXT,emgtwo TEXT,emgthree TEXT,polutiondate TEXT,occupation TEXT)";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    public boolean CheckIsDataAlreadyInDBorNotSetting() {
        boolean bl;
        Cursor cursor = this.getReadableDatabase().rawQuery("Select * from happiness", null);
        if (cursor.getCount() > 0) {
            bl = true;
            cursor.close();
        } else {
            bl = false;
        }
        cursor.close();
        return bl;
    }

    public boolean CheckIsGCMAlreadyInHometable() {
        boolean bl;
        Cursor cursor = this.getReadableDatabase().rawQuery("Select * from gcmtoken ", null);
        if (cursor.getCount() > 0) {
            bl = true;
            cursor.close();
        } else {
            bl = false;
        }
        cursor.close();
        return bl;
    }

    public boolean CheckIsLanguageAlreadyInHometable() {
        boolean bl;
        Cursor cursor = this.getReadableDatabase().rawQuery("Select * from language ", null);
        if (cursor.getCount() > 0) {
            bl = true;
            cursor.close();
        } else {
            bl = false;
        }
        cursor.close();
        return bl;
    }

    public boolean CheckIsOperatorAlreadyInDBorNotSetting() {
        boolean bl;
        Cursor cursor = this.getReadableDatabase().rawQuery("Select * from city", null);
        if (cursor.getCount() > 0) {
            bl = true;
            cursor.close();
        } else {
            bl = false;
        }
        cursor.close();
        return bl;
    }

    public void addUrlList(String string2) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("gcmid", string2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("null");
        stringBuilder.append(contentValues.toString());
        Log.e((String)"inservalue", (String)stringBuilder.toString());
        sQLiteDatabase.insert("gcmtoken", null, contentValues);
        sQLiteDatabase.close();
    }

    public void addUserDetail(String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_UserId, string2);
        contentValues.put("name", string3);
        contentValues.put(KEY_Mobile, string4);
        contentValues.put(KEY_EMAIL, string5);
        contentValues.put("dailcode", string6);
        contentValues.put(KEY_Gender, string7);
        contentValues.put("isstatus", string8);
        contentValues.put("lockpoint", string9);
        contentValues.put("totalpoint", string10);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("null");
        stringBuilder.append(contentValues.toString());
        Log.e((String)"inservalue", (String)stringBuilder.toString());
        sQLiteDatabase.insert("user", null, contentValues);
        sQLiteDatabase.close();
    }

    public void addcityList(String string2, String string3) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("cityid", string2);
        contentValues.put("cityname", string3);
        sQLiteDatabase.insert(KEY_City, null, contentValues);
        sQLiteDatabase.close();
    }

    public void addfeedback(String string2) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("feedback", string2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("null");
        stringBuilder.append(contentValues.toString());
        Log.e((String)"inservalue", (String)stringBuilder.toString());
        sQLiteDatabase.insert("happiness", null, contentValues);
        sQLiteDatabase.close();
    }

    public void addlanguage(String string2) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("lng", string2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("null");
        stringBuilder.append(contentValues.toString());
        Log.e((String)"inservalue", (String)stringBuilder.toString());
        sQLiteDatabase.insert("language", null, contentValues);
        sQLiteDatabase.close();
    }

    public HashMap<String, String> getDetails() {
        HashMap hashMap = new HashMap();
        SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sQLiteDatabase.rawQuery("SELECT  userid ,fname ,lname ,email ,dob ,gender ,mobile ,occupation ,city ,vehicletype ,regno ,insurance ,expdate ,emgone ,emgtwo ,emgthree ,polutiondate ,state FROM user_detail", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            hashMap.put((Object)KEY_UserId, (Object)cursor.getString(0));
            hashMap.put((Object)KEY_Fname, (Object)cursor.getString(1));
            hashMap.put((Object)KEY_Lname, (Object)cursor.getString(2));
            hashMap.put((Object)KEY_EMAIL, (Object)cursor.getString(3));
            hashMap.put((Object)KEY_DOB, (Object)cursor.getString(4));
            hashMap.put((Object)KEY_Gender, (Object)cursor.getString(5));
            hashMap.put((Object)KEY_Mobile, (Object)cursor.getString(6));
            hashMap.put((Object)KEY_occupation, (Object)cursor.getString(7));
            hashMap.put((Object)KEY_City, (Object)cursor.getString(8));
            hashMap.put((Object)KEY_vehicletype, (Object)cursor.getString(9));
            hashMap.put((Object)KEY_Veh_reg_no, (Object)cursor.getString(10));
            hashMap.put((Object)KEY_Insurance, (Object)cursor.getString(11));
            hashMap.put((Object)KEY_policy_exp_date, (Object)cursor.getString(12));
            hashMap.put((Object)KEY_EMERGENCE_1, (Object)cursor.getString(13));
            hashMap.put((Object)KEY_EMERGENCE_2, (Object)cursor.getString(14));
            hashMap.put((Object)KEY_EMERGENCE_3, (Object)cursor.getString(15));
            hashMap.put((Object)KEY_Polutiondate, (Object)cursor.getString(16));
            hashMap.put((Object)KEY_State, (Object)cursor.getString(17));
        }
        cursor.close();
        sQLiteDatabase.close();
        return hashMap;
    }

    public HashMap<String, String> getDetailsTest() {
        HashMap hashMap = new HashMap();
        SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sQLiteDatabase.rawQuery("SELECT  questions ,answers ,attempt_answer ,correct_marks ,negative_marks ,total_question ,total_marks ,attempt_question ,position FROM testtable", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            hashMap.put((Object)"questions", (Object)cursor.getString(0));
            hashMap.put((Object)"answers", (Object)cursor.getString(1));
            hashMap.put((Object)"attempt_answer", (Object)cursor.getString(2));
            hashMap.put((Object)"correct_marks", (Object)cursor.getString(3));
            hashMap.put((Object)"negative_marks", (Object)cursor.getString(4));
            hashMap.put((Object)"total_question", (Object)cursor.getString(5));
            hashMap.put((Object)"total_marks", (Object)cursor.getString(6));
            hashMap.put((Object)"attempt_question", (Object)cursor.getString(7));
            hashMap.put((Object)"position", (Object)cursor.getString(8));
        }
        cursor.close();
        sQLiteDatabase.close();
        return hashMap;
    }

    public Cursor getExamName() {
        Cursor cursor = this.getWritableDatabase().query("examlist", new String[]{"examname"}, "", null, null, null, null);
        cursor.moveToFirst();
        return cursor;
    }

    public Cursor getGcm() {
        return this.getWritableDatabase().rawQuery("Select gcmid  from  gcmtoken ", null);
    }

    public int getRowCount() {
        SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sQLiteDatabase.rawQuery("SELECT  * FROM user", null);
        int n = cursor.getCount();
        sQLiteDatabase.close();
        cursor.close();
        return n;
    }

    public String getTestAns(String string2) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select  attempt_answer from  testtable  where  position ='");
        stringBuilder.append(string2);
        stringBuilder.append("'");
        Cursor cursor = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        String string3 = null;
        if (cursor != null) {
            cursor.moveToFirst();
            for (int i = 0; i < cursor.getCount(); ++i) {
                string3 = cursor.getString(0);
                cursor.moveToNext();
            }
            cursor.close();
        }
        return string3;
    }

    public Cursor getUserDetail() {
        return this.getWritableDatabase().rawQuery("Select * from  user ", null);
    }

    public ArrayList<String> get_active_exam_name_list() {
        ArrayList arrayList = new ArrayList();
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT examname from examlist", null);
        if (cursor.moveToFirst()) {
            do {
                arrayList.add((Object)cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return arrayList;
    }

    public ArrayList<String> getallattempt() {
        ArrayList arrayList = new ArrayList();
        Cursor cursor = this.getReadableDatabase().rawQuery("SELECT attempt_answer from testtable", null);
        if (cursor.moveToFirst()) {
            do {
                arrayList.add((Object)cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return arrayList;
    }

    public Cursor getcapsulelist(String string2, String string3) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select  detail ,views ,days from  capusletable  where examname='");
        stringBuilder.append(string2);
        stringBuilder.append("'AND category='");
        stringBuilder.append(string3);
        stringBuilder.append("'");
        return sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    }

    public Cursor getchildconcept(String string2, String string3, String string4) {
        SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select test ,attemp from childConcept where examname='");
        stringBuilder.append(string2);
        stringBuilder.append("'AND category='");
        stringBuilder.append(string3);
        stringBuilder.append("'AND parent='");
        stringBuilder.append(string4);
        stringBuilder.append("'");
        return sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    }

    public Cursor getchildtest(String string2, String string3, String string4) {
        SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select test ,attemp from childTest where examname='");
        stringBuilder.append(string2);
        stringBuilder.append("'AND category='");
        stringBuilder.append(string3);
        stringBuilder.append("'AND parent='");
        stringBuilder.append(string4);
        stringBuilder.append("'");
        return sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    }

    public Cursor getcity(String string2) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select  cityid from city where cityname ='");
        stringBuilder.append(string2);
        stringBuilder.append("'");
        String string3 = stringBuilder.toString();
        Cursor cursor = sQLiteDatabase.rawQuery(string3, null);
        Log.e((String)"query", (String)string3);
        cursor.moveToFirst();
        return cursor;
    }

    public Cursor getconceptlist(String string2, String string3) {
        SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select english ,hindi from concepttable where examname='");
        stringBuilder.append(string2);
        stringBuilder.append("'AND category='");
        stringBuilder.append(string3);
        stringBuilder.append("'");
        return sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    }

    public Cursor getfeedback() {
        return this.getWritableDatabase().rawQuery("Select feedback  from  happiness ", null);
    }

    public Cursor getpdflist(String string2, String string3, String string4) {
        SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select pdfenglish ,pdfhindi from pdflist where examname='");
        stringBuilder.append(string2);
        stringBuilder.append("'AND category='");
        stringBuilder.append(string3);
        stringBuilder.append("'AND title='");
        stringBuilder.append(string4);
        stringBuilder.append("'");
        return sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    }

    public Cursor getquizlist(String string2, String string3) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select  detail ,views ,days from  quiztable  where examname='");
        stringBuilder.append(string2);
        stringBuilder.append("'AND category='");
        stringBuilder.append(string3);
        stringBuilder.append("'");
        return sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    }

    public Cursor getsettingList() {
        Cursor cursor = this.getWritableDatabase().query("settinglist", new String[]{"sms", "call", KEY_Insurance, "service", "polution", "autorespond"}, "", null, null, null, null);
        cursor.moveToFirst();
        return cursor;
    }

    public Cursor getstudyimage(String string2) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select  image from  studypacakges  where  examname ='");
        stringBuilder.append(string2);
        stringBuilder.append("'");
        Cursor cursor = sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
        cursor.moveToFirst();
        return cursor;
    }

    public Cursor gettestnameD(String string2, String string3) {
        SQLiteDatabase sQLiteDatabase = this.getReadableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select english ,hindi from testnametable where examname='");
        stringBuilder.append(string2);
        stringBuilder.append("'AND category='");
        stringBuilder.append(string3);
        stringBuilder.append("'");
        return sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    }

    public Cursor getvideolist(String string2, String string3) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Select  detail ,views ,days from  videotable  where examname='");
        stringBuilder.append(string2);
        stringBuilder.append("'AND category='");
        stringBuilder.append(string3);
        stringBuilder.append("'");
        return sQLiteDatabase.rawQuery(stringBuilder.toString(), null);
    }

    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS user ( Id INTEGER PRIMARY KEY, userid TEXT, name TEXT, mobile TEXT, email TEXT, dailcode TEXT, gender TEXT, isstatus TEXT, lockpoint TEXT, totalpoint TEXT, password TEXT)");
        sQLiteDatabase.execSQL(this.CREATE_USER_DETAIL_TABLE);
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS gcmtoken ( Id INTEGER PRIMARY KEY, gcmid TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS city ( Id INTEGER PRIMARY KEY, cityid TEXT, cityname TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS language ( Id INTEGER PRIMARY KEY, lng TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS happiness ( Id INTEGER PRIMARY KEY, feedback TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS quiztable ( Id INTEGER PRIMARY KEY, detail TEXT, views TEXT, days TEXT, examname TEXT, category TEXT, position TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS capusletable ( Id INTEGER PRIMARY KEY, detail TEXT, views TEXT, days TEXT, examname TEXT, category TEXT, position TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS concepttable ( Id INTEGER PRIMARY KEY, english TEXT, hindi TEXT, examname TEXT, category TEXT, position TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS testnametable ( Id INTEGER PRIMARY KEY, english TEXT, hindi TEXT, examname TEXT, category TEXT, position TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS childConcept ( Id INTEGER PRIMARY KEY, test TEXT, attemp TEXT, examname TEXT, category TEXT,parent TEXT, position TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS childTest ( Id INTEGER PRIMARY KEY, test TEXT, attemp TEXT, examname TEXT, category TEXT,parent TEXT, position TEXT)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS pdflist ( Id INTEGER PRIMARY KEY, pdfenglish TEXT, pdfhindi TEXT, examname TEXT, category TEXT,title TEXT, position TEXT)");
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int n, int n2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS user_detail");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS user");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS urllist");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS city");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS testtable");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS happiness");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS quiztable");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS capusletable");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS concepttable");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS testnametable");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS childConcept");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS childTest");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS pdflist");
        this.onCreate(sQLiteDatabase);
    }

    public void removeHomemenu() {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.execSQL("delete from homemenu");
        sQLiteDatabase.close();
    }

    public void removeLanguage() {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.execSQL("delete from language");
        sQLiteDatabase.close();
    }

    public void removeTestTable() {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.delete("testtable", null, null);
        sQLiteDatabase.close();
    }

    public void resetTables() {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.delete("user", null, null);
        sQLiteDatabase.close();
    }

    public void updateUrlList(String string2) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.delete("gcmtoken", null, null);
        ContentValues contentValues = new ContentValues();
        contentValues.put("gcmid", string2);
        sQLiteDatabase.insert("gcmtoken", null, contentValues);
        sQLiteDatabase.close();
    }

    public void updatecityList(String string2, String string3) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.delete(KEY_City, null, null);
        ContentValues contentValues = new ContentValues();
        contentValues.put("cityid", string2);
        contentValues.put("cityname", string3);
        sQLiteDatabase.insert(KEY_City, null, contentValues);
        sQLiteDatabase.close();
    }

    public void updatefeedback(String string2) {
        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
        sQLiteDatabase.delete("happiness", null, null);
        ContentValues contentValues = new ContentValues();
        contentValues.put("feedback", string2);
        sQLiteDatabase.insert("happiness", null, contentValues);
        sQLiteDatabase.close();
    }
}

