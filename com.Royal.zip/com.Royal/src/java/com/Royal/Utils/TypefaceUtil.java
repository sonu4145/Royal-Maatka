/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  android.graphics.Typeface
 *  android.util.Log
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Field
 */
package com.Royal.Utils;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.util.Log;
import java.lang.reflect.Field;

public class TypefaceUtil {
    public static void overrideFont(Context context, String string2, String string3) {
        try {
            Typeface typeface = Typeface.createFromAsset((AssetManager)context.getAssets(), (String)string3);
            Field field = Typeface.class.getDeclaredField(string2);
            field.setAccessible(true);
            field.set(null, (Object)typeface);
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string3);
            stringBuilder.append(" instead of ");
            stringBuilder.append(string2);
            Log.e((String)"Can not setcustomfont", (String)stringBuilder.toString());
            return;
        }
    }
}

