/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  android.util.Patterns
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.Royal.Utils;

import android.text.TextUtils;
import android.util.Patterns;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationUtils {
    public static boolean isValidEmail(CharSequence charSequence) {
        return !TextUtils.isEmpty((CharSequence)charSequence) && Patterns.EMAIL_ADDRESS.matcher(charSequence).matches();
    }

    public static boolean isValidPhone(CharSequence charSequence) {
        return !TextUtils.isEmpty((CharSequence)charSequence) && Patterns.PHONE.matcher(charSequence).matches();
    }
}

