/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package com.Royal.Utils;

import android.content.Context;
import com.Royal.Utils.DatabaseHandler;

public class UserFunctions {
    DatabaseHandler db;

    public boolean isUserLoggedIn(Context context) {
        DatabaseHandler databaseHandler;
        this.db = databaseHandler = new DatabaseHandler(context);
        return databaseHandler.getRowCount() > 0;
    }

    public boolean logoutUser(Context context) {
        new DatabaseHandler(context).resetTables();
        return true;
    }
}

