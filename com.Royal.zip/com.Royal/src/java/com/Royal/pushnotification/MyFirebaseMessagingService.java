/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.media.RingtoneManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.Html
 *  android.util.Log
 *  android.widget.RemoteViews
 *  androidx.core.app.NotificationCompat
 *  androidx.core.app.NotificationCompat$Builder
 *  com.google.firebase.messaging.FirebaseMessagingService
 *  com.google.firebase.messaging.RemoteMessage
 *  com.google.firebase.messaging.RemoteMessage$Notification
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Map
 */
package com.Royal.pushnotification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.Build;
import android.text.Html;
import android.util.Log;
import android.widget.RemoteViews;
import androidx.core.app.NotificationCompat;
import com.Royal.AllActivity.Dashboard;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

public class MyFirebaseMessagingService
extends FirebaseMessagingService {
    private static final String TAG = "MyFirebaseMsgService";

    private void sendNotification(String string2, String string3) {
        Intent intent = new Intent((Context)this, Dashboard.class);
        intent.putExtra("message", string2);
        PendingIntent pendingIntent = PendingIntent.getActivity((Context)this, (int)0, (Intent)intent, (int)134217728);
        RingtoneManager.getDefaultUri((int)2);
        NotificationManager notificationManager = (NotificationManager)this.getSystemService("notification");
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel("my_channel_01", (CharSequence)"my_channel", 4);
            notificationChannel.setDescription("This is my channel");
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(-65536);
            notificationChannel.enableVibration(true);
            notificationChannel.setVibrationPattern(new long[]{100L, 200L, 300L, 400L, 500L, 400L, 300L, 200L, 400L});
            notificationChannel.setShowBadge(true);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        NotificationCompat.Builder builder = new NotificationCompat.Builder((Context)this).setSmallIcon(2131165425);
        RemoteViews remoteViews = new RemoteViews(this.getPackageName(), 2131493057);
        remoteViews.setTextViewText(2131296970, (CharSequence)Html.fromHtml((String)string3));
        remoteViews.setTextViewText(2131296923, (CharSequence)Html.fromHtml((String)string2));
        builder.setContent(remoteViews);
        builder.setContentIntent(pendingIntent);
        builder.setShowWhen(true);
        notificationManager.notify(100, builder.build());
    }

    public void onMessageReceived(RemoteMessage remoteMessage) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("From: ");
        stringBuilder.append(remoteMessage.getFrom());
        Log.d((String)TAG, (String)stringBuilder.toString());
        if (remoteMessage.getData().size() > 0) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Message data payload: ");
            stringBuilder2.append((Object)remoteMessage.getData());
            Log.d((String)TAG, (String)stringBuilder2.toString());
            this.sendNotification((String)remoteMessage.getData().get((Object)"body"), (String)remoteMessage.getData().get((Object)"title"));
        }
        if (remoteMessage.getNotification() != null) {
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Message Notification Body: ");
            stringBuilder3.append(remoteMessage.getNotification().getBody());
            Log.d((String)TAG, (String)stringBuilder3.toString());
            this.sendNotification(remoteMessage.getNotification().getBody(), (String)remoteMessage.getData().get((Object)"title"));
        }
    }

    public void onNewToken(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Refreshed token: ");
        stringBuilder.append(string2);
        Log.d((String)TAG, (String)stringBuilder.toString());
    }
}

