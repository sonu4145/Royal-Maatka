/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.util.Log
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  com.google.firebase.messaging.FirebaseMessagingService
 *  java.lang.String
 */
package com.Royal.pushnotification;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.google.firebase.messaging.FirebaseMessagingService;

public class MyFirebaseInstanceIDService
extends FirebaseMessagingService {
    private static final String TAG = "MyFirebaseIIDService";

    private void sendRegistrationToServer(String string2) {
    }

    public void onNewToken(String string2) {
        super.onNewToken(string2);
        Log.d((String)"NEW_TOKEN", (String)string2);
        this.sendRegistrationToServer(string2);
        Intent intent = new Intent("tokenReceiver");
        LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance((Context)this);
        intent.putExtra("token", string2);
        localBroadcastManager.sendBroadcast(intent);
    }
}

