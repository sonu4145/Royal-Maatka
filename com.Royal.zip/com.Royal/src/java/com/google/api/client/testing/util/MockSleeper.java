/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.InterruptedException
 *  java.lang.Object
 */
package com.google.api.client.testing.util;

import com.google.api.client.util.Sleeper;

public class MockSleeper
implements Sleeper {
    private int count;
    private long lastMillis;

    public final int getCount() {
        return this.count;
    }

    public final long getLastMillis() {
        return this.lastMillis;
    }

    @Override
    public void sleep(long l) throws InterruptedException {
        this.count = 1 + this.count;
        this.lastMillis = l;
    }
}

