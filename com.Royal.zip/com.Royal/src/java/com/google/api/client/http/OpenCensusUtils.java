/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.http.HttpHeaders
 *  com.google.api.client.http.OpenCensusUtils$1
 *  com.google.common.collect.ImmutableList
 *  io.opencensus.contrib.http.util.HttpPropagationUtil
 *  io.opencensus.trace.BlankSpan
 *  io.opencensus.trace.EndSpanOptions
 *  io.opencensus.trace.EndSpanOptions$Builder
 *  io.opencensus.trace.MessageEvent
 *  io.opencensus.trace.MessageEvent$Builder
 *  io.opencensus.trace.MessageEvent$Type
 *  io.opencensus.trace.Span
 *  io.opencensus.trace.SpanContext
 *  io.opencensus.trace.Status
 *  io.opencensus.trace.Tracer
 *  io.opencensus.trace.Tracing
 *  io.opencensus.trace.export.SampledSpanStore
 *  io.opencensus.trace.propagation.TextFormat
 *  io.opencensus.trace.propagation.TextFormat$Setter
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.concurrent.atomic.AtomicLong
 *  java.util.logging.Level
 *  java.util.logging.Logger
 *  javax.annotation.Nullable
 */
package com.google.api.client.http;

import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpStatusCodes;
import com.google.api.client.http.OpenCensusUtils;
import com.google.api.client.util.Preconditions;
import com.google.common.collect.ImmutableList;
import io.opencensus.contrib.http.util.HttpPropagationUtil;
import io.opencensus.trace.BlankSpan;
import io.opencensus.trace.EndSpanOptions;
import io.opencensus.trace.MessageEvent;
import io.opencensus.trace.Span;
import io.opencensus.trace.SpanContext;
import io.opencensus.trace.Status;
import io.opencensus.trace.Tracer;
import io.opencensus.trace.Tracing;
import io.opencensus.trace.export.SampledSpanStore;
import io.opencensus.trace.propagation.TextFormat;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;

public class OpenCensusUtils {
    public static final String SPAN_NAME_HTTP_REQUEST_EXECUTE;
    private static final AtomicLong idGenerator;
    private static volatile boolean isRecordEvent;
    private static final Logger logger;
    @Nullable
    static volatile TextFormat propagationTextFormat;
    @Nullable
    static volatile TextFormat.Setter propagationTextFormatSetter;
    private static final Tracer tracer;

    static {
        logger = Logger.getLogger((String)OpenCensusUtils.class.getName());
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Sent.");
        stringBuilder.append(HttpRequest.class.getName());
        stringBuilder.append(".execute");
        SPAN_NAME_HTTP_REQUEST_EXECUTE = stringBuilder.toString();
        tracer = Tracing.getTracer();
        idGenerator = new AtomicLong();
        isRecordEvent = true;
        propagationTextFormat = null;
        propagationTextFormatSetter = null;
        try {
            propagationTextFormat = HttpPropagationUtil.getCloudTraceFormat();
            propagationTextFormatSetter = new 1();
        }
        catch (Exception exception) {
            logger.log(Level.WARNING, "Cannot initialize default OpenCensus HTTP propagation text format.", (Throwable)exception);
        }
        try {
            Tracing.getExportComponent().getSampledSpanStore().registerSpanNamesForCollection((Collection)ImmutableList.of((Object)SPAN_NAME_HTTP_REQUEST_EXECUTE));
        }
        catch (Exception exception) {
            logger.log(Level.WARNING, "Cannot register default OpenCensus span names for collection.", (Throwable)exception);
        }
    }

    private OpenCensusUtils() {
    }

    public static EndSpanOptions getEndSpanOptions(@Nullable Integer n) {
        EndSpanOptions.Builder builder = EndSpanOptions.builder();
        if (n == null) {
            builder.setStatus(Status.UNKNOWN);
        } else if (!HttpStatusCodes.isSuccess(n)) {
            int n2 = n;
            if (n2 != 400) {
                if (n2 != 401) {
                    if (n2 != 403) {
                        if (n2 != 404) {
                            if (n2 != 412) {
                                if (n2 != 500) {
                                    builder.setStatus(Status.UNKNOWN);
                                } else {
                                    builder.setStatus(Status.UNAVAILABLE);
                                }
                            } else {
                                builder.setStatus(Status.FAILED_PRECONDITION);
                            }
                        } else {
                            builder.setStatus(Status.NOT_FOUND);
                        }
                    } else {
                        builder.setStatus(Status.PERMISSION_DENIED);
                    }
                } else {
                    builder.setStatus(Status.UNAUTHENTICATED);
                }
            } else {
                builder.setStatus(Status.INVALID_ARGUMENT);
            }
        } else {
            builder.setStatus(Status.OK);
        }
        return builder.build();
    }

    public static Tracer getTracer() {
        return tracer;
    }

    public static boolean isRecordEvent() {
        return isRecordEvent;
    }

    public static void propagateTracingContext(Span span, HttpHeaders httpHeaders) {
        boolean bl = true;
        boolean bl2 = span != null;
        Preconditions.checkArgument(bl2, "span should not be null.");
        if (httpHeaders == null) {
            bl = false;
        }
        Preconditions.checkArgument(bl, "headers should not be null.");
        if (propagationTextFormat != null && propagationTextFormatSetter != null && !span.equals((Object)BlankSpan.INSTANCE)) {
            propagationTextFormat.inject(span.getContext(), (Object)httpHeaders, propagationTextFormatSetter);
        }
    }

    static void recordMessageEvent(Span span, long l, MessageEvent.Type type) {
        boolean bl = span != null;
        Preconditions.checkArgument(bl, "span should not be null.");
        if (l < 0L) {
            l = 0L;
        }
        span.addMessageEvent(MessageEvent.builder((MessageEvent.Type)type, (long)idGenerator.getAndIncrement()).setUncompressedMessageSize(l).build());
    }

    public static void recordReceivedMessageEvent(Span span, long l) {
        OpenCensusUtils.recordMessageEvent(span, l, MessageEvent.Type.RECEIVED);
    }

    public static void recordSentMessageEvent(Span span, long l) {
        OpenCensusUtils.recordMessageEvent(span, l, MessageEvent.Type.SENT);
    }

    public static void setIsRecordEvent(boolean bl) {
        isRecordEvent = bl;
    }

    public static void setPropagationTextFormat(@Nullable TextFormat textFormat) {
        propagationTextFormat = textFormat;
    }

    public static void setPropagationTextFormatSetter(@Nullable TextFormat.Setter setter) {
        propagationTextFormatSetter = setter;
    }
}

