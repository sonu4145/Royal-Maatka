/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CloneNotSupportedException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.MalformedURLException
 *  java.net.URI
 *  java.net.URISyntaxException
 *  java.net.URL
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.google.api.client.http;

import com.google.api.client.http.UrlEncodedParser;
import com.google.api.client.util.GenericData;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.escape.CharEscapers;
import com.google.api.client.util.escape.Escaper;
import com.google.api.client.util.escape.PercentEscaper;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class GenericUrl
extends GenericData {
    private static final Escaper URI_FRAGMENT_ESCAPER = new PercentEscaper("=&-_.!~*'()@:$,;/?:");
    private String fragment;
    private String host;
    private List<String> pathParts;
    private int port = -1;
    private String scheme;
    private String userInfo;
    private boolean verbatim;

    public GenericUrl() {
    }

    public GenericUrl(String string2) {
        this(string2, false);
    }

    private GenericUrl(String string2, String string3, int n, String string4, String string5, String string6, String string7, boolean bl) {
        this.scheme = string2.toLowerCase(Locale.US);
        this.host = string3;
        this.port = n;
        this.pathParts = GenericUrl.toPathParts(string4, bl);
        this.verbatim = bl;
        if (bl) {
            this.fragment = string5;
            if (string6 != null) {
                UrlEncodedParser.parse(string6, (Object)this, false);
            }
            this.userInfo = string7;
            return;
        }
        String string8 = string5 != null ? CharEscapers.decodeUri(string5) : null;
        this.fragment = string8;
        if (string6 != null) {
            UrlEncodedParser.parse(string6, (Object)this);
        }
        String string9 = null;
        if (string7 != null) {
            string9 = CharEscapers.decodeUri(string7);
        }
        this.userInfo = string9;
    }

    public GenericUrl(String string2, boolean bl) {
        this(GenericUrl.parseURL(string2), bl);
    }

    public GenericUrl(URI uRI) {
        this(uRI, false);
    }

    public GenericUrl(URI uRI, boolean bl) {
        this(uRI.getScheme(), uRI.getHost(), uRI.getPort(), uRI.getRawPath(), uRI.getRawFragment(), uRI.getRawQuery(), uRI.getRawUserInfo(), bl);
    }

    public GenericUrl(URL uRL) {
        this(uRL, false);
    }

    public GenericUrl(URL uRL, boolean bl) {
        this(uRL.getProtocol(), uRL.getHost(), uRL.getPort(), uRL.getPath(), uRL.getRef(), uRL.getQuery(), uRL.getUserInfo(), bl);
    }

    static void addQueryParams(Set<Map.Entry<String, Object>> set, StringBuilder stringBuilder, boolean bl) {
        Iterator iterator = set.iterator();
        boolean bl2 = true;
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            Object object = entry.getValue();
            if (object == null) continue;
            String string2 = bl ? (String)entry.getKey() : CharEscapers.escapeUriQuery((String)entry.getKey());
            if (object instanceof Collection) {
                Iterator iterator2 = ((Collection)object).iterator();
                while (iterator2.hasNext()) {
                    bl2 = GenericUrl.appendParam(bl2, stringBuilder, string2, iterator2.next(), bl);
                }
                continue;
            }
            bl2 = GenericUrl.appendParam(bl2, stringBuilder, string2, object, bl);
        }
    }

    private static boolean appendParam(boolean bl, StringBuilder stringBuilder, String string2, Object object, boolean bl2) {
        if (bl) {
            stringBuilder.append('?');
            bl = false;
        } else {
            stringBuilder.append('&');
        }
        stringBuilder.append(string2);
        String string3 = bl2 ? object.toString() : CharEscapers.escapeUriQuery(object.toString());
        if (string3.length() != 0) {
            stringBuilder.append('=');
            stringBuilder.append(string3);
        }
        return bl;
    }

    private void appendRawPathFromParts(StringBuilder stringBuilder) {
        int n = this.pathParts.size();
        for (int i = 0; i < n; ++i) {
            String string2 = (String)this.pathParts.get(i);
            if (i != 0) {
                stringBuilder.append('/');
            }
            if (string2.length() == 0) continue;
            if (!this.verbatim) {
                string2 = CharEscapers.escapeUriPath(string2);
            }
            stringBuilder.append(string2);
        }
    }

    private static URL parseURL(String string2) {
        try {
            URL uRL = new URL(string2);
            return uRL;
        }
        catch (MalformedURLException malformedURLException) {
            throw new IllegalArgumentException((Throwable)malformedURLException);
        }
    }

    public static List<String> toPathParts(String string2) {
        return GenericUrl.toPathParts(string2, false);
    }

    public static List<String> toPathParts(String string2, boolean bl) {
        if (string2 != null && string2.length() != 0) {
            ArrayList arrayList = new ArrayList();
            boolean bl2 = true;
            int n = 0;
            while (bl2) {
                int n2 = string2.indexOf(47, n);
                boolean bl3 = n2 != -1;
                String string3 = bl3 ? string2.substring(n, n2) : string2.substring(n);
                if (!bl) {
                    string3 = CharEscapers.decodeUriPath(string3);
                }
                arrayList.add((Object)string3);
                n = n2 + 1;
                bl2 = bl3;
            }
            return arrayList;
        }
        return null;
    }

    private static URI toURI(String string2) {
        try {
            URI uRI = new URI(string2);
            return uRI;
        }
        catch (URISyntaxException uRISyntaxException) {
            throw new IllegalArgumentException((Throwable)uRISyntaxException);
        }
    }

    public void appendRawPath(String string2) {
        if (string2 != null && string2.length() != 0) {
            List<String> list = GenericUrl.toPathParts(string2, this.verbatim);
            List<String> list2 = this.pathParts;
            if (list2 != null && !list2.isEmpty()) {
                int n = this.pathParts.size();
                List<String> list3 = this.pathParts;
                int n2 = n - 1;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append((String)this.pathParts.get(n2));
                stringBuilder.append((String)list.get(0));
                list3.set(n2, (Object)stringBuilder.toString());
                this.pathParts.addAll((Collection)list.subList(1, list.size()));
                return;
            }
            this.pathParts = list;
        }
    }

    public final String build() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.buildAuthority());
        stringBuilder.append(this.buildRelativeUrl());
        return stringBuilder.toString();
    }

    public final String buildAuthority() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Preconditions.checkNotNull(this.scheme));
        stringBuilder.append("://");
        String string2 = this.userInfo;
        if (string2 != null) {
            if (!this.verbatim) {
                string2 = CharEscapers.escapeUriUserInfo(string2);
            }
            stringBuilder.append(string2);
            stringBuilder.append('@');
        }
        stringBuilder.append(Preconditions.checkNotNull(this.host));
        int n = this.port;
        if (n != -1) {
            stringBuilder.append(':');
            stringBuilder.append(n);
        }
        return stringBuilder.toString();
    }

    public final String buildRelativeUrl() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.pathParts != null) {
            this.appendRawPathFromParts(stringBuilder);
        }
        GenericUrl.addQueryParams(this.entrySet(), stringBuilder, this.verbatim);
        String string2 = this.fragment;
        if (string2 != null) {
            stringBuilder.append('#');
            if (!this.verbatim) {
                string2 = URI_FRAGMENT_ESCAPER.escape(string2);
            }
            stringBuilder.append(string2);
        }
        return stringBuilder.toString();
    }

    @Override
    public GenericUrl clone() {
        GenericUrl genericUrl = (GenericUrl)super.clone();
        if (this.pathParts != null) {
            genericUrl.pathParts = new ArrayList(this.pathParts);
        }
        return genericUrl;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (super.equals(object) && object instanceof GenericUrl) {
            GenericUrl genericUrl = (GenericUrl)((Object)object);
            return this.build().equals((Object)genericUrl.build());
        }
        return false;
    }

    public Collection<Object> getAll(String string2) {
        Object object = this.get(string2);
        if (object == null) {
            return Collections.emptySet();
        }
        if (object instanceof Collection) {
            return Collections.unmodifiableCollection((Collection)((Collection)object));
        }
        return Collections.singleton((Object)object);
    }

    public Object getFirst(String string2) {
        Object object = this.get(string2);
        if (object instanceof Collection) {
            Iterator iterator = ((Collection)object).iterator();
            if (iterator.hasNext()) {
                return iterator.next();
            }
            object = null;
        }
        return object;
    }

    public String getFragment() {
        return this.fragment;
    }

    public String getHost() {
        return this.host;
    }

    public List<String> getPathParts() {
        return this.pathParts;
    }

    public int getPort() {
        return this.port;
    }

    public String getRawPath() {
        if (this.pathParts == null) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        this.appendRawPathFromParts(stringBuilder);
        return stringBuilder.toString();
    }

    public final String getScheme() {
        return this.scheme;
    }

    public final String getUserInfo() {
        return this.userInfo;
    }

    @Override
    public int hashCode() {
        return this.build().hashCode();
    }

    @Override
    public GenericUrl set(String string2, Object object) {
        return (GenericUrl)super.set(string2, object);
    }

    public final void setFragment(String string2) {
        this.fragment = string2;
    }

    public final void setHost(String string2) {
        this.host = Preconditions.checkNotNull(string2);
    }

    public void setPathParts(List<String> list) {
        this.pathParts = list;
    }

    public final void setPort(int n) {
        boolean bl = n >= -1;
        Preconditions.checkArgument(bl, "expected port >= -1");
        this.port = n;
    }

    public void setRawPath(String string2) {
        this.pathParts = GenericUrl.toPathParts(string2, this.verbatim);
    }

    public final void setScheme(String string2) {
        this.scheme = Preconditions.checkNotNull(string2);
    }

    public final void setUserInfo(String string2) {
        this.userInfo = string2;
    }

    @Override
    public String toString() {
        return this.build();
    }

    public final URI toURI() {
        return GenericUrl.toURI(this.build());
    }

    public final URL toURL() {
        return GenericUrl.parseURL(this.build());
    }

    public final URL toURL(String string2) {
        try {
            URL uRL = new URL(this.toURL(), string2);
            return uRL;
        }
        catch (MalformedURLException malformedURLException) {
            throw new IllegalArgumentException((Throwable)malformedURLException);
        }
    }
}

