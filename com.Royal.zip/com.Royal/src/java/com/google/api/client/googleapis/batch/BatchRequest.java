/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.googleapis.batch.BatchRequest$BatchInterceptor
 *  com.google.api.client.googleapis.batch.HttpRequestContent
 *  com.google.api.client.http.GenericUrl
 *  com.google.api.client.http.HttpContent
 *  com.google.api.client.http.HttpHeaders
 *  com.google.api.client.http.MultipartContent
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.logging.Level
 *  java.util.logging.Logger
 */
package com.google.api.client.googleapis.batch;

import com.google.api.client.googleapis.batch.BatchCallback;
import com.google.api.client.googleapis.batch.BatchRequest;
import com.google.api.client.googleapis.batch.BatchUnparsedResponse;
import com.google.api.client.googleapis.batch.HttpRequestContent;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpContent;
import com.google.api.client.http.HttpExecuteInterceptor;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpMediaType;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.MultipartContent;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Sleeper;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Exception performing whole class analysis.
 */
public final class BatchRequest {
    private static final String GLOBAL_BATCH_ENDPOINT = "https://www.googleapis.com/batch";
    private static final String GLOBAL_BATCH_ENDPOINT_WARNING = "You are using the global batch endpoint which will soon be shut down. Please instantiate your BatchRequest via your service client's `batch(HttpRequestInitializer)` method. For an example, please see https://github.com/googleapis/google-api-java-client#batching.";
    private static final Logger LOGGER;
    private GenericUrl batchUrl;
    private final HttpRequestFactory requestFactory;
    List<RequestInfo<?, ?>> requestInfos;
    private Sleeper sleeper;

    static {
        LOGGER = Logger.getLogger((String)BatchRequest.class.getName());
    }

    @Deprecated
    public BatchRequest(HttpTransport httpTransport, HttpRequestInitializer httpRequestInitializer) {
        this.batchUrl = new GenericUrl(GLOBAL_BATCH_ENDPOINT);
        this.requestInfos = new ArrayList();
        this.sleeper = Sleeper.DEFAULT;
        HttpRequestFactory httpRequestFactory = httpRequestInitializer == null ? httpTransport.createRequestFactory() : httpTransport.createRequestFactory(httpRequestInitializer);
        this.requestFactory = httpRequestFactory;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void execute() throws IOException {
        boolean bl;
        HttpResponse httpResponse;
        Preconditions.checkState(true ^ this.requestInfos.isEmpty());
        if (GLOBAL_BATCH_ENDPOINT.equals((Object)this.batchUrl.toString())) {
            LOGGER.log(Level.WARNING, GLOBAL_BATCH_ENDPOINT_WARNING);
        }
        HttpRequest httpRequest = this.requestFactory.buildPostRequest(this.batchUrl, null);
        httpRequest.setInterceptor((HttpExecuteInterceptor)new /* Unavailable Anonymous Inner Class!! */);
        int n = httpRequest.getNumberOfRetries();
        do {
            bl = n > 0;
            MultipartContent multipartContent = new MultipartContent();
            multipartContent.getMediaType().setSubType("mixed");
            Iterator iterator = this.requestInfos.iterator();
            int n2 = 1;
            while (iterator.hasNext()) {
                RequestInfo requestInfo = (RequestInfo)iterator.next();
                HttpHeaders httpHeaders = new HttpHeaders().setAcceptEncoding(null);
                int n3 = n2 + 1;
                multipartContent.addPart(new MultipartContent.Part(httpHeaders.set("Content-ID", (Object)n2), (HttpContent)new HttpRequestContent(requestInfo.request)));
                n2 = n3;
            }
            httpRequest.setContent((HttpContent)multipartContent);
            httpResponse = httpRequest.execute();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("--");
            stringBuilder.append(httpResponse.getMediaType().getParameter("boundary"));
            String string2 = stringBuilder.toString();
            BatchUnparsedResponse batchUnparsedResponse = new BatchUnparsedResponse(httpResponse.getContent(), string2, this.requestInfos, bl);
            while (batchUnparsedResponse.hasNext) {
                batchUnparsedResponse.parseNextResponse();
            }
            List<RequestInfo<?, ?>> list = batchUnparsedResponse.unsuccessfulRequestInfos;
            if (list.isEmpty()) break;
            this.requestInfos = list;
            --n;
        } while (bl);
        this.requestInfos.clear();
        return;
        finally {
            httpResponse.disconnect();
        }
    }

    public GenericUrl getBatchUrl() {
        return this.batchUrl;
    }

    public Sleeper getSleeper() {
        return this.sleeper;
    }

    public <T, E> BatchRequest queue(HttpRequest httpRequest, Class<T> class_, Class<E> class_2, BatchCallback<T, E> batchCallback) throws IOException {
        Preconditions.checkNotNull(httpRequest);
        Preconditions.checkNotNull(batchCallback);
        Preconditions.checkNotNull(class_);
        Preconditions.checkNotNull(class_2);
        this.requestInfos.add(new RequestInfo<T, E>(batchCallback, class_, class_2, httpRequest));
        return this;
    }

    public BatchRequest setBatchUrl(GenericUrl genericUrl) {
        this.batchUrl = genericUrl;
        return this;
    }

    public BatchRequest setSleeper(Sleeper sleeper) {
        this.sleeper = Preconditions.checkNotNull(sleeper);
        return this;
    }

    public int size() {
        return this.requestInfos.size();
    }

    static class RequestInfo<T, E> {
        final BatchCallback<T, E> callback;
        final Class<T> dataClass;
        final Class<E> errorClass;
        final HttpRequest request;

        RequestInfo(BatchCallback<T, E> batchCallback, Class<T> class_, Class<E> class_2, HttpRequest httpRequest) {
            this.callback = batchCallback;
            this.dataClass = class_;
            this.errorClass = class_2;
            this.request = httpRequest;
        }
    }

}

