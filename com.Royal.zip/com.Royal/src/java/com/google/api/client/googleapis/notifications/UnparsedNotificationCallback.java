/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.googleapis.notifications.UnparsedNotification
 *  java.io.IOException
 *  java.io.Serializable
 *  java.lang.Object
 */
package com.google.api.client.googleapis.notifications;

import com.google.api.client.googleapis.notifications.StoredChannel;
import com.google.api.client.googleapis.notifications.UnparsedNotification;
import java.io.IOException;
import java.io.Serializable;

public interface UnparsedNotificationCallback
extends Serializable {
    public void onNotification(StoredChannel var1, UnparsedNotification var2) throws IOException;
}

