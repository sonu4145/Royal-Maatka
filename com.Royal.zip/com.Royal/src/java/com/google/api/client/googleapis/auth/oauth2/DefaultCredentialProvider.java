/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Enum
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.InstantiationException
 *  java.lang.Integer
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Field
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.nio.charset.Charset
 *  java.security.AccessControlException
 *  java.util.Locale
 */
package com.google.api.client.googleapis.auth.oauth2;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.CloudShellCredential;
import com.google.api.client.googleapis.auth.oauth2.DefaultCredentialProvider;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.auth.oauth2.OAuth2Utils;
import com.google.api.client.googleapis.auth.oauth2.SystemEnvironmentProvider;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonObjectParser;
import com.google.api.client.util.ObjectParser;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.security.AccessControlException;
import java.util.Locale;

class DefaultCredentialProvider
extends SystemEnvironmentProvider {
    static final String APP_ENGINE_CREDENTIAL_CLASS = "com.google.api.client.googleapis.extensions.appengine.auth.oauth2.AppIdentityCredential$AppEngineCredentialWrapper";
    static final String CLOUDSDK_CONFIG_DIRECTORY = "gcloud";
    static final String CLOUD_SHELL_ENV_VAR = "DEVSHELL_CLIENT_PORT";
    static final String CREDENTIAL_ENV_VAR = "GOOGLE_APPLICATION_CREDENTIALS";
    static final String HELP_PERMALINK = "https://developers.google.com/accounts/docs/application-default-credentials";
    static final String WELL_KNOWN_CREDENTIALS_FILE = "application_default_credentials.json";
    private GoogleCredential cachedCredential = null;
    private Environment detectedEnvironment = null;

    DefaultCredentialProvider() {
    }

    private final Environment detectEnvironment(HttpTransport httpTransport) throws IOException {
        if (this.runningUsingEnvironmentVariable()) {
            return Environment.ENVIRONMENT_VARIABLE;
        }
        if (this.runningUsingWellKnownFile()) {
            return Environment.WELL_KNOWN_FILE;
        }
        if (this.useGAEStandardAPI()) {
            return Environment.APP_ENGINE;
        }
        if (this.runningOnCloudShell()) {
            return Environment.CLOUD_SHELL;
        }
        if (OAuth2Utils.runningOnComputeEngine(httpTransport, this)) {
            return Environment.COMPUTE_ENGINE;
        }
        return Environment.UNKNOWN;
    }

    private final GoogleCredential getAppEngineCredential(HttpTransport httpTransport, JsonFactory jsonFactory) throws IOException {
        void var3_9;
        try {
            GoogleCredential googleCredential = (GoogleCredential)this.forName(APP_ENGINE_CREDENTIAL_CLASS).getConstructor(new Class[]{HttpTransport.class, JsonFactory.class}).newInstance(new Object[]{httpTransport, jsonFactory});
            return googleCredential;
        }
        catch (InvocationTargetException invocationTargetException) {
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (InstantiationException instantiationException) {
        }
        catch (NoSuchMethodException noSuchMethodException) {
        }
        catch (ClassNotFoundException classNotFoundException) {
            // empty catch block
        }
        throw OAuth2Utils.exceptionWithCause(new IOException(String.format((String)"Application Default Credentials failed to create the Google App Engine service account credentials class %s. Check that the component 'google-api-client-appengine' is deployed.", (Object[])new Object[]{APP_ENGINE_CREDENTIAL_CLASS})), (Throwable)var3_9);
    }

    private GoogleCredential getCloudShellCredential(JsonFactory jsonFactory) {
        return new CloudShellCredential(Integer.parseInt((String)this.getEnv(CLOUD_SHELL_ENV_VAR)), jsonFactory);
    }

    private final GoogleCredential getComputeCredential(HttpTransport httpTransport, JsonFactory jsonFactory) {
        return new ComputeGoogleCredential(httpTransport, jsonFactory);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private GoogleCredential getCredentialUsingEnvironmentVariable(HttpTransport var1_1, JsonFactory var2_2) throws IOException {
        block7 : {
            var3_3 = this.getEnv("GOOGLE_APPLICATION_CREDENTIALS");
            var4_4 = null;
            var5_5 = new FileInputStream(var3_3);
            try {
                var9_6 = GoogleCredential.fromStream((InputStream)var5_5, var1_1, var2_2);
            }
            catch (Throwable var8_7) {
                var4_4 = var5_5;
                break block7;
            }
            catch (IOException var6_10) {
                var4_4 = var5_5;
                ** GOTO lbl-1000
            }
            var5_5.close();
            return var9_6;
            catch (Throwable var8_8) {
                break block7;
            }
            catch (IOException var6_11) {
                // empty catch block
            }
lbl-1000: // 2 sources:
            {
                var7_13 = new Object[]{"GOOGLE_APPLICATION_CREDENTIALS", var3_3, var6_12.getMessage()};
                throw OAuth2Utils.exceptionWithCause(new IOException(String.format((String)"Error reading credential file from environment variable %s, value '%s': %s", (Object[])var7_13)), (Throwable)var6_12);
            }
        }
        if (var4_4 == null) throw var8_9;
        var4_4.close();
        throw var8_9;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private GoogleCredential getCredentialUsingWellKnownFile(HttpTransport var1_1, JsonFactory var2_2) throws IOException {
        block7 : {
            var3_3 = this.getWellKnownCredentialsFile();
            var4_4 = null;
            var5_5 = new FileInputStream(var3_3);
            try {
                var9_6 = GoogleCredential.fromStream((InputStream)var5_5, var1_1, var2_2);
            }
            catch (Throwable var8_7) {
                var4_4 = var5_5;
                break block7;
            }
            catch (IOException var6_10) {
                var4_4 = var5_5;
                ** GOTO lbl-1000
            }
            var5_5.close();
            return var9_6;
            catch (Throwable var8_8) {
                break block7;
            }
            catch (IOException var6_11) {
                // empty catch block
            }
lbl-1000: // 2 sources:
            {
                var7_13 = new Object[]{var3_3, var6_12.getMessage()};
                throw new IOException(String.format((String)"Error reading credential file from location %s: %s", (Object[])var7_13));
            }
        }
        if (var4_4 == null) throw var8_9;
        var4_4.close();
        throw var8_9;
    }

    private final GoogleCredential getDefaultCredentialUnsynchronized(HttpTransport httpTransport, JsonFactory jsonFactory) throws IOException {
        int n;
        if (this.detectedEnvironment == null) {
            this.detectedEnvironment = this.detectEnvironment(httpTransport);
        }
        if ((n = 1.$SwitchMap$com$google$api$client$googleapis$auth$oauth2$DefaultCredentialProvider$Environment[this.detectedEnvironment.ordinal()]) != 1) {
            if (n != 2) {
                if (n != 3) {
                    if (n != 4) {
                        if (n != 5) {
                            return null;
                        }
                        return this.getComputeCredential(httpTransport, jsonFactory);
                    }
                    return this.getCloudShellCredential(jsonFactory);
                }
                return this.getAppEngineCredential(httpTransport, jsonFactory);
            }
            return this.getCredentialUsingWellKnownFile(httpTransport, jsonFactory);
        }
        return this.getCredentialUsingEnvironmentVariable(httpTransport, jsonFactory);
    }

    private final File getWellKnownCredentialsFile() {
        File file = this.getProperty("os.name", "").toLowerCase(Locale.US).indexOf("windows") >= 0 ? new File(new File(this.getEnv("APPDATA")), CLOUDSDK_CONFIG_DIRECTORY) : new File(new File(this.getProperty("user.home", ""), ".config"), CLOUDSDK_CONFIG_DIRECTORY);
        return new File(file, WELL_KNOWN_CREDENTIALS_FILE);
    }

    private boolean runningOnCloudShell() {
        return this.getEnv(CLOUD_SHELL_ENV_VAR) != null;
    }

    /*
     * Exception decompiling
     */
    private boolean runningUsingEnvironmentVariable() throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl41.1 : ICONST_0 : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    private boolean runningUsingWellKnownFile() {
        File file = this.getWellKnownCredentialsFile();
        try {
            boolean bl = this.fileExists(file);
            return bl;
        }
        catch (AccessControlException accessControlException) {
            return false;
        }
    }

    private boolean useGAEStandardAPI() {
        Class<?> class_;
        void var2_12;
        try {
            class_ = this.forName("com.google.appengine.api.utils.SystemProperty");
        }
        catch (ClassNotFoundException classNotFoundException) {
            return false;
        }
        try {
            Field field = class_.getField("environment");
            Object object = field.get(null);
            Object object2 = field.getType().getMethod("value", new Class[0]).invoke(object, new Object[0]);
            boolean bl = false;
            if (object2 != null) {
                bl = true;
            }
            return bl;
        }
        catch (InvocationTargetException invocationTargetException) {
        }
        catch (NoSuchMethodException noSuchMethodException) {
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (IllegalArgumentException illegalArgumentException) {
        }
        catch (SecurityException securityException) {
        }
        catch (NoSuchFieldException noSuchFieldException) {
            // empty catch block
        }
        Object[] arrobject = new Object[]{var2_12.getMessage()};
        throw OAuth2Utils.exceptionWithCause(new RuntimeException(String.format((String)"Unexpcted error trying to determine if runnning on Google App Engine: %s", (Object[])arrobject)), (Throwable)var2_12);
    }

    boolean fileExists(File file) {
        return file.exists() && !file.isDirectory();
    }

    Class<?> forName(String string2) throws ClassNotFoundException {
        return Class.forName((String)string2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    final GoogleCredential getDefaultCredential(HttpTransport httpTransport, JsonFactory jsonFactory) throws IOException {
        DefaultCredentialProvider defaultCredentialProvider = this;
        synchronized (defaultCredentialProvider) {
            if (this.cachedCredential == null) {
                this.cachedCredential = this.getDefaultCredentialUnsynchronized(httpTransport, jsonFactory);
            }
            if (this.cachedCredential != null) {
                return this.cachedCredential;
            }
            throw new IOException(String.format((String)"The Application Default Credentials are not available. They are available if running on Google App Engine, Google Compute Engine, or Google Cloud Shell. Otherwise, the environment variable %s must be defined pointing to a file defining the credentials. See %s for more information.", (Object[])new Object[]{CREDENTIAL_ENV_VAR, HELP_PERMALINK}));
        }
    }

    String getProperty(String string2, String string3) {
        return System.getProperty((String)string2, (String)string3);
    }

    private static class ComputeGoogleCredential
    extends GoogleCredential {
        private static final String TOKEN_SERVER_ENCODED_URL;

        static {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(OAuth2Utils.getMetadataServerUrl());
            stringBuilder.append("/computeMetadata/v1/instance/service-accounts/default/token");
            TOKEN_SERVER_ENCODED_URL = stringBuilder.toString();
        }

        ComputeGoogleCredential(HttpTransport httpTransport, JsonFactory jsonFactory) {
            super((GoogleCredential.Builder)((GoogleCredential.Builder)((GoogleCredential.Builder)new GoogleCredential.Builder().setTransport(httpTransport)).setJsonFactory(jsonFactory)).setTokenServerEncodedUrl(TOKEN_SERVER_ENCODED_URL));
        }

        @Override
        protected TokenResponse executeRefreshToken() throws IOException {
            GenericUrl genericUrl = new GenericUrl(this.getTokenServerEncodedUrl());
            HttpRequest httpRequest = this.getTransport().createRequestFactory().buildGetRequest(genericUrl);
            JsonObjectParser jsonObjectParser = new JsonObjectParser(this.getJsonFactory());
            httpRequest.setParser(jsonObjectParser);
            httpRequest.getHeaders().set("Metadata-Flavor", "Google");
            httpRequest.setThrowExceptionOnExecuteError(false);
            HttpResponse httpResponse = httpRequest.execute();
            int n = httpResponse.getStatusCode();
            if (n == 200) {
                InputStream inputStream = httpResponse.getContent();
                if (inputStream != null) {
                    return jsonObjectParser.parseAndClose(inputStream, httpResponse.getContentCharset(), TokenResponse.class);
                }
                throw new IOException("Empty content from metadata token server request.");
            }
            if (n == 404) {
                Object[] arrobject = new Object[]{n};
                throw new IOException(String.format((String)"Error code %s trying to get security access token from Compute Engine metadata for the default service account. This may be because the virtual machine instance does not have permission scopes specified.", (Object[])arrobject));
            }
            Object[] arrobject = new Object[]{n, httpResponse.parseAsString()};
            throw new IOException(String.format((String)"Unexpected Error code %s trying to get security access token from Compute Engine metadata for the default service account: %s", (Object[])arrobject));
        }
    }

}

