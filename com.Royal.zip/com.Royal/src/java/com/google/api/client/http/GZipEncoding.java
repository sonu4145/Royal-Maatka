/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.util.zip.GZIPOutputStream
 */
package com.google.api.client.http;

import com.google.api.client.http.GZipEncoding;
import com.google.api.client.http.HttpEncoding;
import com.google.api.client.util.StreamingContent;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

public class GZipEncoding
implements HttpEncoding {
    @Override
    public void encode(StreamingContent streamingContent, OutputStream outputStream) throws IOException {
        GZIPOutputStream gZIPOutputStream = new GZIPOutputStream((OutputStream)new BufferedOutputStream(this, outputStream){
            final /* synthetic */ GZipEncoding this$0;
            {
                this.this$0 = gZipEncoding;
                super(outputStream);
            }

            public void close() throws IOException {
                try {
                    this.flush();
                }
                catch (IOException iOException) {}
            }
        });
        streamingContent.writeTo((OutputStream)gZIPOutputStream);
        gZIPOutputStream.close();
    }

    @Override
    public String getName() {
        return "gzip";
    }
}

