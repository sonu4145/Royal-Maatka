/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.util.Clock$1
 *  java.lang.Object
 */
package com.google.api.client.util;

import com.google.api.client.util.Clock;

public interface Clock {
    public static final Clock SYSTEM = new 1();

    public long currentTimeMillis();
}

