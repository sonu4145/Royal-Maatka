/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.logging.Logger
 */
package com.google.api.client.http;

import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.LowLevelHttpRequest;
import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Logger;

public abstract class HttpTransport {
    static final Logger LOGGER = Logger.getLogger((String)HttpTransport.class.getName());
    private static final String[] SUPPORTED_METHODS;

    static {
        Object[] arrobject = new String[]{"DELETE", "GET", "POST", "PUT"};
        SUPPORTED_METHODS = arrobject;
        Arrays.sort((Object[])arrobject);
    }

    HttpRequest buildRequest() {
        return new HttpRequest(this, null);
    }

    protected abstract LowLevelHttpRequest buildRequest(String var1, String var2) throws IOException;

    public final HttpRequestFactory createRequestFactory() {
        return this.createRequestFactory(null);
    }

    public final HttpRequestFactory createRequestFactory(HttpRequestInitializer httpRequestInitializer) {
        return new HttpRequestFactory(this, httpRequestInitializer);
    }

    public void shutdown() throws IOException {
    }

    public boolean supportsMethod(String string2) throws IOException {
        return Arrays.binarySearch((Object[])SUPPORTED_METHODS, (Object)string2) >= 0;
    }
}

