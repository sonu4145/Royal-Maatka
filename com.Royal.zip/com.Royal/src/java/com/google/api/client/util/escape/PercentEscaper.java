/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.google.api.client.util.escape;

import com.google.api.client.util.escape.UnicodeEscaper;

public class PercentEscaper
extends UnicodeEscaper {
    public static final String SAFECHARS_URLENCODER = "-_.*";
    public static final String SAFEPATHCHARS_URLENCODER = "-_.!~*'()@:$&,;=+";
    public static final String SAFEQUERYSTRINGCHARS_URLENCODER = "-_.!~*'()@:$,;/?:";
    public static final String SAFEUSERINFOCHARS_URLENCODER = "-_.!~*'():$&,;=";
    public static final String SAFE_PLUS_RESERVED_CHARS_URLENCODER = "-_.!~*'()@:$&,;=+/?";
    private static final char[] UPPER_HEX_DIGITS;
    private static final char[] URI_ESCAPED_SPACE;
    private final boolean plusForSpace;
    private final boolean[] safeOctets;

    static {
        URI_ESCAPED_SPACE = new char[]{'+'};
        UPPER_HEX_DIGITS = "0123456789ABCDEF".toCharArray();
    }

    public PercentEscaper(String string2) {
        this(string2, false);
    }

    @Deprecated
    public PercentEscaper(String string2, boolean bl) {
        if (!string2.matches(".*[0-9A-Za-z].*")) {
            if (bl && string2.contains((CharSequence)" ")) {
                throw new IllegalArgumentException("plusForSpace cannot be specified when space is a 'safe' character");
            }
            if (!string2.contains((CharSequence)"%")) {
                this.plusForSpace = bl;
                this.safeOctets = PercentEscaper.createSafeOctets(string2);
                return;
            }
            throw new IllegalArgumentException("The '%' character cannot be specified as 'safe'");
        }
        throw new IllegalArgumentException("Alphanumeric ASCII characters are always 'safe' and should not be escaped.");
    }

    private static boolean[] createSafeOctets(String string2) {
        char[] arrc = string2.toCharArray();
        int n = arrc.length;
        int n2 = 0;
        int n3 = 122;
        for (int i = 0; i < n; ++i) {
            n3 = Math.max((int)arrc[i], (int)n3);
        }
        boolean[] arrbl = new boolean[n3 + 1];
        for (int i = 48; i <= 57; ++i) {
            arrbl[i] = true;
        }
        for (int i = 65; i <= 90; ++i) {
            arrbl[i] = true;
        }
        for (int i = 97; i <= 122; ++i) {
            arrbl[i] = true;
        }
        int n4 = arrc.length;
        while (n2 < n4) {
            arrbl[arrc[n2]] = true;
            ++n2;
        }
        return arrbl;
    }

    @Override
    public String escape(String string2) {
        int n = string2.length();
        for (int i = 0; i < n; ++i) {
            boolean[] arrbl;
            char c = string2.charAt(i);
            if (c < (arrbl = this.safeOctets).length && arrbl[c]) {
                continue;
            }
            string2 = this.escapeSlow(string2, i);
            break;
        }
        return string2;
    }

    @Override
    protected char[] escape(int n) {
        boolean[] arrbl = this.safeOctets;
        if (n < arrbl.length && arrbl[n]) {
            return null;
        }
        if (n == 32 && this.plusForSpace) {
            return URI_ESCAPED_SPACE;
        }
        if (n <= 127) {
            char[] arrc = new char[3];
            arrc[0] = 37;
            char[] arrc2 = UPPER_HEX_DIGITS;
            arrc[2] = arrc2[n & 15];
            arrc[1] = arrc2[n >>> 4];
            return arrc;
        }
        if (n <= 2047) {
            char[] arrc = new char[6];
            arrc[0] = 37;
            arrc[3] = 37;
            char[] arrc3 = UPPER_HEX_DIGITS;
            arrc[5] = arrc3[n & 15];
            int n2 = n >>> 4;
            arrc[4] = arrc3[8 | n2 & 3];
            int n3 = n2 >>> 2;
            arrc[2] = arrc3[n3 & 15];
            arrc[1] = arrc3[12 | n3 >>> 4];
            return arrc;
        }
        if (n <= 65535) {
            char[] arrc = new char[9];
            arrc[0] = 37;
            arrc[1] = 69;
            arrc[3] = 37;
            arrc[6] = 37;
            char[] arrc4 = UPPER_HEX_DIGITS;
            arrc[8] = arrc4[n & 15];
            int n4 = n >>> 4;
            arrc[7] = arrc4[8 | n4 & 3];
            int n5 = n4 >>> 2;
            arrc[5] = arrc4[n5 & 15];
            int n6 = n5 >>> 4;
            arrc[4] = arrc4[8 | n6 & 3];
            arrc[2] = arrc4[n6 >>> 2];
            return arrc;
        }
        if (n <= 1114111) {
            char[] arrc = new char[12];
            arrc[0] = 37;
            arrc[1] = 70;
            arrc[3] = 37;
            arrc[6] = 37;
            arrc[9] = 37;
            char[] arrc5 = UPPER_HEX_DIGITS;
            arrc[11] = arrc5[n & 15];
            int n7 = n >>> 4;
            arrc[10] = arrc5[8 | n7 & 3];
            int n8 = n7 >>> 2;
            arrc[8] = arrc5[n8 & 15];
            int n9 = n8 >>> 4;
            arrc[7] = arrc5[8 | n9 & 3];
            int n10 = n9 >>> 2;
            arrc[5] = arrc5[n10 & 15];
            int n11 = n10 >>> 4;
            arrc[4] = arrc5[8 | n11 & 3];
            arrc[2] = arrc5[7 & n11 >>> 2];
            return arrc;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid unicode character value ");
        stringBuilder.append(n);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    @Override
    protected int nextEscapeIndex(CharSequence charSequence, int n, int n2) {
        boolean[] arrbl;
        char c;
        while (n < n2 && (c = charSequence.charAt(n)) < (arrbl = this.safeOctets).length) {
            if (!arrbl[c]) {
                return n;
            }
            ++n;
        }
        return n;
    }
}

