/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.InterruptedException
 *  java.lang.Object
 */
package com.google.api.client.util;

import com.google.api.client.util.BackOff;
import com.google.api.client.util.Sleeper;
import java.io.IOException;

public final class BackOffUtils {
    private BackOffUtils() {
    }

    public static boolean next(Sleeper sleeper, BackOff backOff) throws InterruptedException, IOException {
        long l = backOff.nextBackOffMillis();
        if (l == -1L) {
            return false;
        }
        sleeper.sleep(l);
        return true;
    }
}

