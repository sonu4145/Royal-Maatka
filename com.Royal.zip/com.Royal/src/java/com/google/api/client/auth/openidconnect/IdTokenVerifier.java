/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.auth.openidconnect.IdToken
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 */
package com.google.api.client.auth.openidconnect;

import com.google.api.client.auth.openidconnect.IdToken;
import com.google.api.client.util.Clock;
import com.google.api.client.util.Preconditions;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public class IdTokenVerifier {
    public static final long DEFAULT_TIME_SKEW_SECONDS = 300L;
    private final long acceptableTimeSkewSeconds;
    private final Collection<String> audience;
    private final Clock clock;
    private final Collection<String> issuers;

    public IdTokenVerifier() {
        this(new Builder());
    }

    protected IdTokenVerifier(Builder builder) {
        this.clock = builder.clock;
        this.acceptableTimeSkewSeconds = builder.acceptableTimeSkewSeconds;
        Collection collection = builder.issuers == null ? null : Collections.unmodifiableCollection(builder.issuers);
        this.issuers = collection;
        Collection collection2 = builder.audience == null ? null : Collections.unmodifiableCollection(builder.audience);
        this.audience = collection2;
    }

    public final long getAcceptableTimeSkewSeconds() {
        return this.acceptableTimeSkewSeconds;
    }

    public final Collection<String> getAudience() {
        return this.audience;
    }

    public final Clock getClock() {
        return this.clock;
    }

    public final String getIssuer() {
        Collection<String> collection = this.issuers;
        if (collection == null) {
            return null;
        }
        return (String)collection.iterator().next();
    }

    public final Collection<String> getIssuers() {
        return this.issuers;
    }

    public boolean verify(IdToken idToken) {
        Collection<String> collection;
        Collection<String> collection2 = this.issuers;
        return !(collection2 != null && !idToken.verifyIssuer(collection2) || (collection = this.audience) != null && !idToken.verifyAudience(collection) || !idToken.verifyTime(this.clock.currentTimeMillis(), this.acceptableTimeSkewSeconds));
    }

    public static class Builder {
        long acceptableTimeSkewSeconds = 300L;
        Collection<String> audience;
        Clock clock = Clock.SYSTEM;
        Collection<String> issuers;

        public IdTokenVerifier build() {
            return new IdTokenVerifier(this);
        }

        public final long getAcceptableTimeSkewSeconds() {
            return this.acceptableTimeSkewSeconds;
        }

        public final Collection<String> getAudience() {
            return this.audience;
        }

        public final Clock getClock() {
            return this.clock;
        }

        public final String getIssuer() {
            Collection<String> collection = this.issuers;
            if (collection == null) {
                return null;
            }
            return (String)collection.iterator().next();
        }

        public final Collection<String> getIssuers() {
            return this.issuers;
        }

        public Builder setAcceptableTimeSkewSeconds(long l) {
            boolean bl = l >= 0L;
            Preconditions.checkArgument(bl);
            this.acceptableTimeSkewSeconds = l;
            return this;
        }

        public Builder setAudience(Collection<String> collection) {
            this.audience = collection;
            return this;
        }

        public Builder setClock(Clock clock) {
            this.clock = Preconditions.checkNotNull(clock);
            return this;
        }

        public Builder setIssuer(String string2) {
            if (string2 == null) {
                return this.setIssuers(null);
            }
            return this.setIssuers((Collection<String>)Collections.singleton((Object)string2));
        }

        public Builder setIssuers(Collection<String> collection) {
            boolean bl = collection == null || !collection.isEmpty();
            Preconditions.checkArgument(bl, "Issuers must not be empty");
            this.issuers = collection;
            return this;
        }
    }

}

