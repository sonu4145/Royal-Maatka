/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.util.ArrayList
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 */
package com.google.api.client.testing.http.javanet;

import com.google.api.client.util.Preconditions;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MockHttpURLConnection
extends HttpURLConnection {
    @Deprecated
    public static final byte[] ERROR_BUF;
    @Deprecated
    public static final byte[] INPUT_BUF;
    private boolean doOutputCalled;
    private InputStream errorStream = null;
    private Map<String, List<String>> headers = new LinkedHashMap();
    private InputStream inputStream = null;
    private OutputStream outputStream = new ByteArrayOutputStream(0);

    static {
        INPUT_BUF = new byte[1];
        ERROR_BUF = new byte[5];
    }

    public MockHttpURLConnection(URL uRL) {
        super(uRL);
    }

    public MockHttpURLConnection addHeader(String string2, String string3) {
        Preconditions.checkNotNull(string2);
        Preconditions.checkNotNull(string3);
        if (this.headers.containsKey((Object)string2)) {
            ((List)this.headers.get((Object)string2)).add((Object)string3);
            return this;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)string3);
        this.headers.put((Object)string2, (Object)arrayList);
        return this;
    }

    public void connect() throws IOException {
    }

    public void disconnect() {
    }

    public final boolean doOutputCalled() {
        return this.doOutputCalled;
    }

    public int getChunkLength() {
        return this.chunkLength;
    }

    public InputStream getErrorStream() {
        return this.errorStream;
    }

    public String getHeaderField(String string2) {
        List list = (List)this.headers.get((Object)string2);
        if (list == null) {
            return null;
        }
        return (String)list.get(0);
    }

    public Map<String, List<String>> getHeaderFields() {
        return this.headers;
    }

    public InputStream getInputStream() throws IOException {
        if (this.responseCode < 400) {
            return this.inputStream;
        }
        throw new IOException();
    }

    public OutputStream getOutputStream() throws IOException {
        OutputStream outputStream = this.outputStream;
        if (outputStream != null) {
            return outputStream;
        }
        return super.getOutputStream();
    }

    public int getResponseCode() throws IOException {
        return this.responseCode;
    }

    public void setDoOutput(boolean bl) {
        this.doOutputCalled = true;
    }

    public MockHttpURLConnection setErrorStream(InputStream inputStream) {
        Preconditions.checkNotNull(inputStream);
        if (this.errorStream == null) {
            this.errorStream = inputStream;
        }
        return this;
    }

    public MockHttpURLConnection setInputStream(InputStream inputStream) {
        Preconditions.checkNotNull(inputStream);
        if (this.inputStream == null) {
            this.inputStream = inputStream;
        }
        return this;
    }

    public MockHttpURLConnection setOutputStream(OutputStream outputStream) {
        this.outputStream = outputStream;
        return this;
    }

    public MockHttpURLConnection setResponseCode(int n) {
        boolean bl = n >= -1;
        Preconditions.checkArgument(bl);
        this.responseCode = n;
        return this;
    }

    public boolean usingProxy() {
        return false;
    }
}

