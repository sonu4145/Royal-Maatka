/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package com.google.api.client.googleapis.media;

import com.google.api.client.googleapis.media.MediaHttpDownloader;
import java.io.IOException;

public interface MediaHttpDownloaderProgressListener {
    public void progressChanged(MediaHttpDownloader var1) throws IOException;
}

