/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.List
 *  java.util.concurrent.locks.Lock
 *  java.util.concurrent.locks.ReentrantLock
 *  java.util.logging.Level
 *  java.util.logging.Logger
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.google.api.client.auth.oauth2;

import com.google.api.client.auth.oauth2.BearerToken;
import com.google.api.client.auth.oauth2.CredentialRefreshListener;
import com.google.api.client.auth.oauth2.RefreshTokenRequest;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpExecuteInterceptor;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.HttpUnsuccessfulResponseHandler;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.util.Clock;
import com.google.api.client.util.Lists;
import com.google.api.client.util.Objects;
import com.google.api.client.util.Preconditions;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Credential
implements HttpExecuteInterceptor,
HttpRequestInitializer,
HttpUnsuccessfulResponseHandler {
    static final Logger LOGGER = Logger.getLogger((String)Credential.class.getName());
    private String accessToken;
    private final HttpExecuteInterceptor clientAuthentication;
    private final Clock clock;
    private Long expirationTimeMilliseconds;
    private final JsonFactory jsonFactory;
    private final Lock lock = new ReentrantLock();
    private final AccessMethod method;
    private final Collection<CredentialRefreshListener> refreshListeners;
    private String refreshToken;
    private final HttpRequestInitializer requestInitializer;
    private final String tokenServerEncodedUrl;
    private final HttpTransport transport;

    public Credential(AccessMethod accessMethod) {
        this(new Object(accessMethod){
            HttpExecuteInterceptor clientAuthentication;
            Clock clock = Clock.SYSTEM;
            JsonFactory jsonFactory;
            final AccessMethod method;
            Collection<CredentialRefreshListener> refreshListeners = Lists.newArrayList();
            HttpRequestInitializer requestInitializer;
            GenericUrl tokenServerUrl;
            HttpTransport transport;
            {
                this.method = Preconditions.checkNotNull(accessMethod);
            }

            public Builder addRefreshListener(CredentialRefreshListener credentialRefreshListener) {
                this.refreshListeners.add((Object)Preconditions.checkNotNull(credentialRefreshListener));
                return this;
            }

            public Credential build() {
                return new Credential(this);
            }

            public final HttpExecuteInterceptor getClientAuthentication() {
                return this.clientAuthentication;
            }

            public final Clock getClock() {
                return this.clock;
            }

            public final JsonFactory getJsonFactory() {
                return this.jsonFactory;
            }

            public final AccessMethod getMethod() {
                return this.method;
            }

            public final Collection<CredentialRefreshListener> getRefreshListeners() {
                return this.refreshListeners;
            }

            public final HttpRequestInitializer getRequestInitializer() {
                return this.requestInitializer;
            }

            public final GenericUrl getTokenServerUrl() {
                return this.tokenServerUrl;
            }

            public final HttpTransport getTransport() {
                return this.transport;
            }

            public Builder setClientAuthentication(HttpExecuteInterceptor httpExecuteInterceptor) {
                this.clientAuthentication = httpExecuteInterceptor;
                return this;
            }

            public Builder setClock(Clock clock) {
                this.clock = Preconditions.checkNotNull(clock);
                return this;
            }

            public Builder setJsonFactory(JsonFactory jsonFactory) {
                this.jsonFactory = jsonFactory;
                return this;
            }

            public Builder setRefreshListeners(Collection<CredentialRefreshListener> collection) {
                this.refreshListeners = Preconditions.checkNotNull(collection);
                return this;
            }

            public Builder setRequestInitializer(HttpRequestInitializer httpRequestInitializer) {
                this.requestInitializer = httpRequestInitializer;
                return this;
            }

            public Builder setTokenServerEncodedUrl(String string2) {
                GenericUrl genericUrl = string2 == null ? null : new GenericUrl(string2);
                this.tokenServerUrl = genericUrl;
                return this;
            }

            public Builder setTokenServerUrl(GenericUrl genericUrl) {
                this.tokenServerUrl = genericUrl;
                return this;
            }

            public Builder setTransport(HttpTransport httpTransport) {
                this.transport = httpTransport;
                return this;
            }
        });
    }

    protected Credential(Builder builder) {
        this.method = Preconditions.checkNotNull(builder.method);
        this.transport = builder.transport;
        this.jsonFactory = builder.jsonFactory;
        String string2 = builder.tokenServerUrl == null ? null : builder.tokenServerUrl.build();
        this.tokenServerEncodedUrl = string2;
        this.clientAuthentication = builder.clientAuthentication;
        this.requestInitializer = builder.requestInitializer;
        this.refreshListeners = Collections.unmodifiableCollection(builder.refreshListeners);
        this.clock = Preconditions.checkNotNull(builder.clock);
    }

    protected TokenResponse executeRefreshToken() throws IOException {
        if (this.refreshToken == null) {
            return null;
        }
        return new RefreshTokenRequest(this.transport, this.jsonFactory, new GenericUrl(this.tokenServerEncodedUrl), this.refreshToken).setClientAuthentication(this.clientAuthentication).setRequestInitializer(this.requestInitializer).execute();
    }

    public final String getAccessToken() {
        this.lock.lock();
        try {
            String string2 = this.accessToken;
            return string2;
        }
        finally {
            this.lock.unlock();
        }
    }

    public final HttpExecuteInterceptor getClientAuthentication() {
        return this.clientAuthentication;
    }

    public final Clock getClock() {
        return this.clock;
    }

    public final Long getExpirationTimeMilliseconds() {
        this.lock.lock();
        try {
            Long l = this.expirationTimeMilliseconds;
            return l;
        }
        finally {
            this.lock.unlock();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final Long getExpiresInSeconds() {
        this.lock.lock();
        try {
            Long l = this.expirationTimeMilliseconds;
            Long l2 = l != null ? Long.valueOf((long)((this.expirationTimeMilliseconds - this.clock.currentTimeMillis()) / 1000L)) : null;
            return l2;
        }
        finally {
            this.lock.unlock();
        }
    }

    public final JsonFactory getJsonFactory() {
        return this.jsonFactory;
    }

    public final AccessMethod getMethod() {
        return this.method;
    }

    public final Collection<CredentialRefreshListener> getRefreshListeners() {
        return this.refreshListeners;
    }

    public final String getRefreshToken() {
        this.lock.lock();
        try {
            String string2 = this.refreshToken;
            return string2;
        }
        finally {
            this.lock.unlock();
        }
    }

    public final HttpRequestInitializer getRequestInitializer() {
        return this.requestInitializer;
    }

    public final String getTokenServerEncodedUrl() {
        return this.tokenServerEncodedUrl;
    }

    public final HttpTransport getTransport() {
        return this.transport;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    @Override
    public boolean handleResponse(HttpRequest httpRequest, HttpResponse httpResponse, boolean bl) {
        boolean bl4;
        block9 : {
            boolean bl5;
            boolean bl2;
            boolean bl3;
            List<String> list = httpResponse.getHeaders().getAuthenticateAsList();
            bl4 = true;
            if (list != null) {
                for (String string2 : list) {
                    if (!string2.startsWith("Bearer ")) continue;
                    bl2 = BearerToken.INVALID_TOKEN_ERROR.matcher((CharSequence)string2).find();
                    bl3 = true;
                    break;
                }
            } else {
                bl2 = false;
                bl3 = false;
            }
            if (!bl3) {
                bl2 = httpResponse.getStatusCode() == 401;
            }
            if (!bl2) return false;
            this.lock.lock();
            if (!Objects.equal(this.accessToken, this.method.getAccessTokenFromRequest(httpRequest)) || (bl5 = this.refreshToken())) break block9;
            bl4 = false;
            {
                catch (Throwable throwable) {
                    this.lock.unlock();
                    throw throwable;
                }
            }
        }
        try {
            this.lock.unlock();
            return bl4;
        }
        catch (IOException iOException) {
            LOGGER.log(Level.SEVERE, "unable to refresh token", (Throwable)iOException);
        }
        return false;
    }

    @Override
    public void initialize(HttpRequest httpRequest) throws IOException {
        httpRequest.setInterceptor(this);
        httpRequest.setUnsuccessfulResponseHandler(this);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void intercept(HttpRequest httpRequest) throws IOException {
        block4 : {
            this.lock.lock();
            Long l = this.getExpiresInSeconds();
            if (this.accessToken != null && (l == null || l > 60L)) break block4;
            this.refreshToken();
            String string2 = this.accessToken;
            if (string2 != null) break block4;
            this.lock.unlock();
            return;
        }
        try {
            this.method.intercept(httpRequest, this.accessToken);
            return;
        }
        finally {
            this.lock.unlock();
        }
    }

    /*
     * Exception decompiling
     */
    public final boolean refreshToken() throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 8[SIMPLE_IF_TAKEN]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public Credential setAccessToken(String string2) {
        this.lock.lock();
        try {
            this.accessToken = string2;
            return this;
        }
        finally {
            this.lock.unlock();
        }
    }

    public Credential setExpirationTimeMilliseconds(Long l) {
        this.lock.lock();
        try {
            this.expirationTimeMilliseconds = l;
            return this;
        }
        finally {
            this.lock.unlock();
        }
    }

    public Credential setExpiresInSeconds(Long l) {
        Long l2 = l == null ? null : Long.valueOf((long)(this.clock.currentTimeMillis() + 1000L * l));
        return this.setExpirationTimeMilliseconds(l2);
    }

    public Credential setFromTokenResponse(TokenResponse tokenResponse) {
        this.setAccessToken(tokenResponse.getAccessToken());
        if (tokenResponse.getRefreshToken() != null) {
            this.setRefreshToken(tokenResponse.getRefreshToken());
        }
        this.setExpiresInSeconds(tokenResponse.getExpiresInSeconds());
        return this;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public Credential setRefreshToken(String var1_1) {
        this.lock.lock();
        if (var1_1 == null) ** GOTO lbl6
        try {
            var3_2 = this.jsonFactory != null && this.transport != null && this.clientAuthentication != null && this.tokenServerEncodedUrl != null;
            Preconditions.checkArgument(var3_2, "Please use the Builder and call setJsonFactory, setTransport, setClientAuthentication and setTokenServerUrl/setTokenServerEncodedUrl");
lbl6: // 2 sources:
            this.refreshToken = var1_1;
            return this;
        }
        finally {
            this.lock.unlock();
        }
    }

}

