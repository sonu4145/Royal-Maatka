/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package com.google.api.client.googleapis.json;

import com.google.api.client.googleapis.json.GoogleJsonError;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpMediaType;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpResponseException;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonParser;
import com.google.api.client.json.JsonToken;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.StringUtils;
import com.google.api.client.util.Strings;
import java.io.IOException;
import java.io.InputStream;

public class GoogleJsonResponseException
extends HttpResponseException {
    private static final long serialVersionUID = 409811126989994864L;
    private final transient GoogleJsonError details;

    public GoogleJsonResponseException(HttpResponseException.Builder builder, GoogleJsonError googleJsonError) {
        super(builder);
        this.details = googleJsonError;
    }

    public static HttpResponse execute(JsonFactory jsonFactory, HttpRequest httpRequest) throws GoogleJsonResponseException, IOException {
        Preconditions.checkNotNull(jsonFactory);
        boolean bl = httpRequest.getThrowExceptionOnExecuteError();
        if (bl) {
            httpRequest.setThrowExceptionOnExecuteError(false);
        }
        HttpResponse httpResponse = httpRequest.execute();
        httpRequest.setThrowExceptionOnExecuteError(bl);
        if (bl) {
            if (httpResponse.isSuccessStatusCode()) {
                return httpResponse;
            }
            throw GoogleJsonResponseException.from(jsonFactory, httpResponse);
        }
        return httpResponse;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static GoogleJsonResponseException from(JsonFactory var0, HttpResponse var1_1) {
        block26 : {
            block28 : {
                block29 : {
                    block23 : {
                        block27 : {
                            block25 : {
                                block24 : {
                                    var2_2 = new HttpResponseException.Builder(var1_1.getStatusCode(), var1_1.getStatusMessage(), var1_1.getHeaders());
                                    Preconditions.checkNotNull(var0);
                                    var4_3 = null;
                                    if (var1_1.isSuccessStatusCode() || !HttpMediaType.equalsIgnoreParameters("application/json; charset=UTF-8", var1_1.getContentType()) || (var12_4 = var1_1.getContent()) == null) break block23;
                                    var14_5 = var0.createJsonParser(var1_1.getContent());
                                    var17_6 = var14_5.getCurrentToken();
                                    if (var17_6 == null) {
                                        var17_6 = var14_5.nextToken();
                                    }
                                    if (var17_6 == null) break block24;
                                    var14_5.skipToKey("error");
                                    if (var14_5.getCurrentToken() == JsonToken.VALUE_STRING) {
                                        var6_7 = var14_5.getText();
                                        var4_3 = null;
                                        break block25;
                                    }
                                    if (var14_5.getCurrentToken() != JsonToken.START_OBJECT) break block24;
                                    var18_8 = var14_5.parseAndClose(GoogleJsonError.class);
                                    try {
                                        var6_7 = var21_9 = var18_8.toPrettyString();
                                        var4_3 = var18_8;
                                        break block25;
                                    }
                                    catch (Throwable var20_10) {
                                        var15_11 = var18_8;
                                        var16_12 = var20_10;
                                        break block26;
                                    }
                                    catch (IOException var19_16) {
                                        var15_11 = var18_8;
                                        var13_17 = var19_16;
                                        break block27;
                                    }
                                }
                                var6_7 = null;
                            }
                            if (var14_5 != null) ** GOTO lbl39
                            var1_1.ignore();
                            break block28;
lbl39: // 1 sources:
                            if (var4_3 == null) {
                                var14_5.close();
                            }
                            break block28;
                            catch (Throwable var16_13) {
                                var15_11 = null;
                                break block26;
                            }
                            catch (IOException var13_18) {
                                var15_11 = null;
                                break block27;
                            }
                            catch (Throwable var16_14) {
                                var15_11 = null;
                                var14_5 = null;
                                break block26;
                            }
                            catch (IOException var13_19) {
                                var14_5 = null;
                                var15_11 = null;
                            }
                        }
                        try {
                            var13_17.printStackTrace();
                            if (var14_5 != null) ** GOTO lbl63
                        }
                        catch (Throwable var16_15) {}
                        var1_1.ignore();
                        break block29;
lbl63: // 1 sources:
                        if (var15_11 != null) break block29;
                        var14_5.close();
                        break block29;
                    }
                    try {
                        var6_7 = var1_1.parseAsString();
                        var4_3 = null;
                    }
                    catch (IOException var5_20) {
                        block30 : {
                            var6_7 = null;
                            break block30;
                            catch (IOException var5_22) {
                                break block30;
                            }
                            catch (IOException var5_23) {
                                var4_3 = var15_11;
                                var6_7 = null;
                            }
                        }
                        var5_21.printStackTrace();
                    }
                    break block28;
                }
                var4_3 = var15_11;
                var6_7 = null;
            }
            var7_24 = HttpResponseException.computeMessageBuffer(var1_1);
            if (!Strings.isNullOrEmpty(var6_7)) {
                var7_24.append(StringUtils.LINE_SEPARATOR);
                var7_24.append(var6_7);
                var2_2.setContent(var6_7);
            }
            var2_2.setMessage(var7_24.toString());
            return new GoogleJsonResponseException(var2_2, var4_3);
        }
        if (var14_5 != null) {
            if (var15_11 != null) throw var16_12;
            var14_5.close();
            throw var16_12;
        }
        var1_1.ignore();
        throw var16_12;
    }

    public final GoogleJsonError getDetails() {
        return this.details;
    }
}

