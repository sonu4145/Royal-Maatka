/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Splitter
 *  com.google.common.collect.Lists
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.net.URLDecoder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Map
 */
package com.google.api.client.googleapis.testing;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public final class TestUtils {
    private static final String UTF_8 = "UTF-8";

    private TestUtils() {
    }

    public static Map<String, String> parseQuery(String string2) throws IOException {
        HashMap hashMap = new HashMap();
        for (String string3 : Splitter.on((char)'&').split((CharSequence)string2)) {
            ArrayList arrayList = Lists.newArrayList((Iterable)Splitter.on((char)'=').split((CharSequence)string3));
            if (arrayList.size() == 2) {
                hashMap.put((Object)URLDecoder.decode((String)((String)arrayList.get(0)), (String)UTF_8), (Object)URLDecoder.decode((String)((String)arrayList.get(1)), (String)UTF_8));
                continue;
            }
            throw new IOException("Invalid Query String");
        }
        return hashMap;
    }
}

