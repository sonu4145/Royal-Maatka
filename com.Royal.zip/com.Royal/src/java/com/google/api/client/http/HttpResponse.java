/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.http.HttpHeaders
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Type
 *  java.nio.charset.Charset
 *  java.util.logging.Level
 *  java.util.logging.Logger
 */
package com.google.api.client.http;

import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpMediaType;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpStatusCodes;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.LowLevelHttpResponse;
import com.google.api.client.util.Charsets;
import com.google.api.client.util.IOUtils;
import com.google.api.client.util.ObjectParser;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.StringUtils;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class HttpResponse {
    private static final String CONTENT_ENCODING_GZIP = "gzip";
    private static final String CONTENT_ENCODING_XGZIP = "x-gzip";
    private InputStream content;
    private final String contentEncoding;
    private int contentLoggingLimit;
    private boolean contentRead;
    private final String contentType;
    private boolean loggingEnabled;
    private final HttpMediaType mediaType;
    private final HttpRequest request;
    LowLevelHttpResponse response;
    private final boolean returnRawInputStream;
    private final int statusCode;
    private final String statusMessage;

    HttpResponse(HttpRequest httpRequest, LowLevelHttpResponse lowLevelHttpResponse) throws IOException {
        String string2;
        StringBuilder stringBuilder;
        this.request = httpRequest;
        this.returnRawInputStream = httpRequest.getResponseReturnRawInputStream();
        this.contentLoggingLimit = httpRequest.getContentLoggingLimit();
        this.loggingEnabled = httpRequest.isLoggingEnabled();
        this.response = lowLevelHttpResponse;
        this.contentEncoding = lowLevelHttpResponse.getContentEncoding();
        int n = lowLevelHttpResponse.getStatusCode();
        if (n < 0) {
            n = 0;
        }
        this.statusCode = n;
        this.statusMessage = string2 = lowLevelHttpResponse.getReasonPhrase();
        Logger logger = HttpTransport.LOGGER;
        boolean bl = this.loggingEnabled;
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = logger.isLoggable(Level.CONFIG);
            bl2 = false;
            if (bl3) {
                bl2 = true;
            }
        }
        if (bl2) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("-------------- RESPONSE --------------");
            stringBuilder.append(StringUtils.LINE_SEPARATOR);
            String string3 = lowLevelHttpResponse.getStatusLine();
            if (string3 != null) {
                stringBuilder.append(string3);
            } else {
                stringBuilder.append(this.statusCode);
                if (string2 != null) {
                    stringBuilder.append(' ');
                    stringBuilder.append(string2);
                }
            }
            stringBuilder.append(StringUtils.LINE_SEPARATOR);
        } else {
            stringBuilder = null;
        }
        HttpHeaders httpHeaders = httpRequest.getResponseHeaders();
        StringBuilder stringBuilder2 = null;
        if (bl2) {
            stringBuilder2 = stringBuilder;
        }
        httpHeaders.fromHttpResponse(lowLevelHttpResponse, stringBuilder2);
        String string4 = lowLevelHttpResponse.getContentType();
        if (string4 == null) {
            string4 = httpRequest.getResponseHeaders().getContentType();
        }
        this.contentType = string4;
        this.mediaType = HttpResponse.parseMediaType(string4);
        if (bl2) {
            logger.config(stringBuilder.toString());
        }
    }

    private boolean hasMessageBody() throws IOException {
        int n = this.getStatusCode();
        if (!this.getRequest().getRequestMethod().equals((Object)"HEAD") && n / 100 != 1 && n != 204 && n != 304) {
            return true;
        }
        this.ignore();
        return false;
    }

    private static HttpMediaType parseMediaType(String string2) {
        if (string2 == null) {
            return null;
        }
        try {
            HttpMediaType httpMediaType = new HttpMediaType(string2);
            return httpMediaType;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return null;
        }
    }

    public void disconnect() throws IOException {
        this.ignore();
        this.response.disconnect();
    }

    public void download(OutputStream outputStream) throws IOException {
        IOUtils.copy(this.getContent(), outputStream);
    }

    /*
     * Exception decompiling
     */
    public InputStream getContent() throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl67 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public Charset getContentCharset() {
        HttpMediaType httpMediaType = this.mediaType;
        if (httpMediaType != null && httpMediaType.getCharsetParameter() != null) {
            return this.mediaType.getCharsetParameter();
        }
        return Charsets.ISO_8859_1;
    }

    public String getContentEncoding() {
        return this.contentEncoding;
    }

    public int getContentLoggingLimit() {
        return this.contentLoggingLimit;
    }

    public String getContentType() {
        return this.contentType;
    }

    public HttpHeaders getHeaders() {
        return this.request.getResponseHeaders();
    }

    public HttpMediaType getMediaType() {
        return this.mediaType;
    }

    public HttpRequest getRequest() {
        return this.request;
    }

    public int getStatusCode() {
        return this.statusCode;
    }

    public String getStatusMessage() {
        return this.statusMessage;
    }

    public HttpTransport getTransport() {
        return this.request.getTransport();
    }

    public void ignore() throws IOException {
        InputStream inputStream = this.getContent();
        if (inputStream != null) {
            inputStream.close();
        }
    }

    public boolean isLoggingEnabled() {
        return this.loggingEnabled;
    }

    public boolean isSuccessStatusCode() {
        return HttpStatusCodes.isSuccess(this.statusCode);
    }

    public <T> T parseAs(Class<T> class_) throws IOException {
        if (!this.hasMessageBody()) {
            return null;
        }
        return this.request.getParser().parseAndClose(this.getContent(), this.getContentCharset(), class_);
    }

    public Object parseAs(Type type) throws IOException {
        if (!this.hasMessageBody()) {
            return null;
        }
        return this.request.getParser().parseAndClose(this.getContent(), this.getContentCharset(), type);
    }

    public String parseAsString() throws IOException {
        InputStream inputStream = this.getContent();
        if (inputStream == null) {
            return "";
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        IOUtils.copy(inputStream, (OutputStream)byteArrayOutputStream);
        return byteArrayOutputStream.toString(this.getContentCharset().name());
    }

    public HttpResponse setContentLoggingLimit(int n) {
        boolean bl = n >= 0;
        Preconditions.checkArgument(bl, "The content logging limit must be non-negative.");
        this.contentLoggingLimit = n;
        return this;
    }

    public HttpResponse setLoggingEnabled(boolean bl) {
        this.loggingEnabled = bl;
        return this;
    }
}

