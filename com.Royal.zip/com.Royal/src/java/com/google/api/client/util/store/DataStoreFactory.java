/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api.client.util.store;

import com.google.api.client.util.store.DataStore;
import java.io.IOException;
import java.io.Serializable;

public interface DataStoreFactory {
    public <V extends Serializable> DataStore<V> getDataStore(String var1) throws IOException;
}

