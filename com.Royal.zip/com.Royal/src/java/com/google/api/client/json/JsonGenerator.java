/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.Flushable
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Field
 *  java.math.BigDecimal
 *  java.math.BigInteger
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.google.api.client.json;

import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonString;
import com.google.api.client.util.ClassInfo;
import com.google.api.client.util.Data;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.FieldInfo;
import com.google.api.client.util.GenericData;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Types;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public abstract class JsonGenerator
implements Closeable,
Flushable {
    private void serialize(boolean bl, Object object) throws IOException {
        if (object == null) {
            return;
        }
        Class class_ = object.getClass();
        if (Data.isNull(object)) {
            this.writeNull();
            return;
        }
        if (object instanceof String) {
            this.writeString((String)object);
            return;
        }
        boolean bl2 = object instanceof Number;
        boolean bl3 = true;
        if (bl2) {
            if (bl) {
                this.writeString(object.toString());
                return;
            }
            if (object instanceof BigDecimal) {
                this.writeNumber((BigDecimal)object);
                return;
            }
            if (object instanceof BigInteger) {
                this.writeNumber((BigInteger)object);
                return;
            }
            if (object instanceof Long) {
                this.writeNumber((Long)object);
                return;
            }
            if (object instanceof Float) {
                float f = ((Number)object).floatValue();
                if (Float.isInfinite((float)f) || Float.isNaN((float)f)) {
                    bl3 = false;
                }
                Preconditions.checkArgument(bl3);
                this.writeNumber(f);
                return;
            }
            if (!(object instanceof Integer || object instanceof Short || object instanceof Byte)) {
                double d = ((Number)object).doubleValue();
                if (Double.isInfinite((double)d) || Double.isNaN((double)d)) {
                    bl3 = false;
                }
                Preconditions.checkArgument(bl3);
                this.writeNumber(d);
                return;
            }
            this.writeNumber(((Number)object).intValue());
            return;
        }
        if (object instanceof Boolean) {
            this.writeBoolean((Boolean)object);
            return;
        }
        if (object instanceof DateTime) {
            this.writeString(((DateTime)object).toStringRfc3339());
            return;
        }
        if ((object instanceof Iterable || class_.isArray()) && !(object instanceof Map) && !(object instanceof GenericData)) {
            this.writeStartArray();
            Iterator iterator = Types.iterableOf(object).iterator();
            while (iterator.hasNext()) {
                this.serialize(bl, iterator.next());
            }
            this.writeEndArray();
            return;
        }
        if (class_.isEnum()) {
            String string2 = FieldInfo.of((Enum)object).getName();
            if (string2 == null) {
                this.writeNull();
                return;
            }
            this.writeString(string2);
            return;
        }
        this.writeStartObject();
        boolean bl4 = object instanceof Map && !(object instanceof GenericData);
        ClassInfo classInfo = bl4 ? null : ClassInfo.of(class_);
        for (Map.Entry entry : Data.mapOf(object).entrySet()) {
            Field field;
            Object object2 = entry.getValue();
            if (object2 == null) continue;
            String string3 = (String)entry.getKey();
            boolean bl5 = bl4 ? bl : (field = classInfo.getField(string3)) != null && field.getAnnotation(JsonString.class) != null;
            this.writeFieldName(string3);
            this.serialize(bl5, object2);
        }
        this.writeEndObject();
    }

    public abstract void close() throws IOException;

    public void enablePrettyPrint() throws IOException {
    }

    public abstract void flush() throws IOException;

    public abstract JsonFactory getFactory();

    public final void serialize(Object object) throws IOException {
        this.serialize(false, object);
    }

    public abstract void writeBoolean(boolean var1) throws IOException;

    public abstract void writeEndArray() throws IOException;

    public abstract void writeEndObject() throws IOException;

    public abstract void writeFieldName(String var1) throws IOException;

    public abstract void writeNull() throws IOException;

    public abstract void writeNumber(double var1) throws IOException;

    public abstract void writeNumber(float var1) throws IOException;

    public abstract void writeNumber(int var1) throws IOException;

    public abstract void writeNumber(long var1) throws IOException;

    public abstract void writeNumber(String var1) throws IOException;

    public abstract void writeNumber(BigDecimal var1) throws IOException;

    public abstract void writeNumber(BigInteger var1) throws IOException;

    public abstract void writeStartArray() throws IOException;

    public abstract void writeStartObject() throws IOException;

    public abstract void writeString(String var1) throws IOException;
}

