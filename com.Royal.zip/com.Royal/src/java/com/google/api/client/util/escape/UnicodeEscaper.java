/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.IllegalArgumentException
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package com.google.api.client.util.escape;

import com.google.api.client.util.escape.Escaper;
import com.google.api.client.util.escape.Platform;

public abstract class UnicodeEscaper
extends Escaper {
    private static final int DEST_PAD = 32;

    protected static int codePointAt(CharSequence charSequence, int n, int n2) {
        if (n < n2) {
            int n3 = n + 1;
            char c = charSequence.charAt(n);
            if (c >= '\ud800') {
                if (c > '\udfff') {
                    return c;
                }
                if (c <= '\udbff') {
                    if (n3 == n2) {
                        return -c;
                    }
                    char c2 = charSequence.charAt(n3);
                    if (Character.isLowSurrogate((char)c2)) {
                        return Character.toCodePoint((char)c, (char)c2);
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected low surrogate but got char '");
                    stringBuilder.append(c2);
                    stringBuilder.append("' with value ");
                    stringBuilder.append((int)c2);
                    stringBuilder.append(" at index ");
                    stringBuilder.append(n3);
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unexpected low surrogate character '");
                stringBuilder.append(c);
                stringBuilder.append("' with value ");
                stringBuilder.append((int)c);
                stringBuilder.append(" at index ");
                stringBuilder.append(n3 - 1);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            return c;
        }
        throw new IndexOutOfBoundsException("Index exceeds specified range");
    }

    private static char[] growBuffer(char[] arrc, int n, int n2) {
        char[] arrc2 = new char[n2];
        if (n > 0) {
            System.arraycopy((Object)arrc, (int)0, (Object)arrc2, (int)0, (int)n);
        }
        return arrc2;
    }

    @Override
    public abstract String escape(String var1);

    protected abstract char[] escape(int var1);

    protected final String escapeSlow(String string2, int n) {
        int n2 = string2.length();
        char[] arrc = Platform.charBufferFromThreadLocal();
        int n3 = 0;
        int n4 = 0;
        while (n < n2) {
            int n5 = UnicodeEscaper.codePointAt(string2, n, n2);
            if (n5 >= 0) {
                char[] arrc2 = this.escape(n5);
                int n6 = Character.isSupplementaryCodePoint((int)n5) ? 2 : 1;
                int n7 = n6 + n;
                if (arrc2 != null) {
                    int n8 = n - n3;
                    int n9 = n4 + n8;
                    int n10 = n9 + arrc2.length;
                    if (arrc.length < n10) {
                        arrc = UnicodeEscaper.growBuffer(arrc, n4, 32 + (n10 + n2 - n));
                    }
                    if (n8 > 0) {
                        string2.getChars(n3, n, arrc, n4);
                        n4 = n9;
                    }
                    if (arrc2.length > 0) {
                        System.arraycopy((Object)arrc2, (int)0, (Object)arrc, (int)n4, (int)arrc2.length);
                        n4 += arrc2.length;
                    }
                    n3 = n7;
                }
                n = this.nextEscapeIndex(string2, n7, n2);
                continue;
            }
            throw new IllegalArgumentException("Trailing high surrogate at end of input");
        }
        int n11 = n2 - n3;
        if (n11 > 0) {
            int n12 = n11 + n4;
            if (arrc.length < n12) {
                arrc = UnicodeEscaper.growBuffer(arrc, n4, n12);
            }
            string2.getChars(n3, n2, arrc, n4);
            n4 = n12;
        }
        return new String(arrc, 0, n4);
    }

    protected abstract int nextEscapeIndex(CharSequence var1, int var2, int var3);
}

