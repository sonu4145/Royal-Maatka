/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Set
 */
package com.google.api.client.googleapis.services.json;

import com.google.api.client.googleapis.batch.BatchCallback;
import com.google.api.client.googleapis.batch.BatchRequest;
import com.google.api.client.googleapis.batch.json.JsonBatchCallback;
import com.google.api.client.googleapis.json.GoogleJsonErrorContainer;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.googleapis.services.AbstractGoogleClient;
import com.google.api.client.googleapis.services.AbstractGoogleClientRequest;
import com.google.api.client.googleapis.services.json.AbstractGoogleJsonClient;
import com.google.api.client.http.HttpContent;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.json.JsonHttpContent;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonObjectParser;
import com.google.api.client.util.GenericData;
import java.io.IOException;
import java.util.Set;

public abstract class AbstractGoogleJsonClientRequest<T>
extends AbstractGoogleClientRequest<T> {
    private final Object jsonContent;

    /*
     * Enabled aggressive block sorting
     */
    protected AbstractGoogleJsonClientRequest(AbstractGoogleJsonClient abstractGoogleJsonClient, String string2, String string3, Object object, Class<T> class_) {
        JsonHttpContent jsonHttpContent = null;
        if (object != null) {
            JsonHttpContent jsonHttpContent2 = new JsonHttpContent(abstractGoogleJsonClient.getJsonFactory(), object);
            String string4 = abstractGoogleJsonClient.getObjectParser().getWrapperKeys().isEmpty() ? null : "data";
            jsonHttpContent = jsonHttpContent2.setWrapperKey(string4);
        }
        JsonHttpContent jsonHttpContent3 = jsonHttpContent;
        super(abstractGoogleJsonClient, string2, string3, jsonHttpContent3, class_);
        this.jsonContent = object;
    }

    @Override
    public AbstractGoogleJsonClient getAbstractGoogleClient() {
        return (AbstractGoogleJsonClient)super.getAbstractGoogleClient();
    }

    public Object getJsonContent() {
        return this.jsonContent;
    }

    @Override
    protected GoogleJsonResponseException newExceptionOnError(HttpResponse httpResponse) {
        return GoogleJsonResponseException.from(((AbstractGoogleJsonClient)this.getAbstractGoogleClient()).getJsonFactory(), httpResponse);
    }

    public final void queue(BatchRequest batchRequest, JsonBatchCallback<T> jsonBatchCallback) throws IOException {
        super.queue(batchRequest, GoogleJsonErrorContainer.class, jsonBatchCallback);
    }

    @Override
    public AbstractGoogleJsonClientRequest<T> set(String string2, Object object) {
        return (AbstractGoogleJsonClientRequest)super.set(string2, object);
    }

    @Override
    public AbstractGoogleJsonClientRequest<T> setDisableGZipContent(boolean bl) {
        return (AbstractGoogleJsonClientRequest)super.setDisableGZipContent(bl);
    }

    @Override
    public AbstractGoogleJsonClientRequest<T> setRequestHeaders(HttpHeaders httpHeaders) {
        return (AbstractGoogleJsonClientRequest)super.setRequestHeaders(httpHeaders);
    }
}

