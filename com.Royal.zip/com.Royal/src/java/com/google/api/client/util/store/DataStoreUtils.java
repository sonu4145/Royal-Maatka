/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Iterator
 *  java.util.Set
 */
package com.google.api.client.util.store;

import com.google.api.client.util.store.DataStore;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

public final class DataStoreUtils {
    private DataStoreUtils() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String toString(DataStore<?> dataStore) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append('{');
            boolean bl = true;
            Iterator iterator = dataStore.keySet().iterator();
            do {
                if (!iterator.hasNext()) {
                    stringBuilder.append('}');
                    return stringBuilder.toString();
                }
                String string2 = (String)iterator.next();
                if (bl) {
                    bl = false;
                } else {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(string2);
                stringBuilder.append('=');
                stringBuilder.append(dataStore.get(string2));
            } while (true);
        }
        catch (IOException iOException) {
            RuntimeException runtimeException = new RuntimeException((Throwable)iOException);
            throw runtimeException;
        }
    }
}

