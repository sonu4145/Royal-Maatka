/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.CloneNotSupportedException
 *  java.lang.Cloneable
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api.client.json;

import com.google.api.client.json.JsonFactory;
import com.google.api.client.util.GenericData;
import com.google.api.client.util.Throwables;
import java.io.IOException;

public class GenericJson
extends GenericData
implements Cloneable {
    private JsonFactory jsonFactory;

    @Override
    public GenericJson clone() {
        return (GenericJson)super.clone();
    }

    public final JsonFactory getFactory() {
        return this.jsonFactory;
    }

    @Override
    public GenericJson set(String string2, Object object) {
        return (GenericJson)super.set(string2, object);
    }

    public final void setFactory(JsonFactory jsonFactory) {
        this.jsonFactory = jsonFactory;
    }

    public String toPrettyString() throws IOException {
        JsonFactory jsonFactory = this.jsonFactory;
        if (jsonFactory != null) {
            return jsonFactory.toPrettyString((Object)this);
        }
        return super.toString();
    }

    @Override
    public String toString() {
        JsonFactory jsonFactory = this.jsonFactory;
        if (jsonFactory != null) {
            try {
                String string2 = jsonFactory.toString((Object)this);
                return string2;
            }
            catch (IOException iOException) {
                throw Throwables.propagate(iOException);
            }
        }
        return super.toString();
    }
}

