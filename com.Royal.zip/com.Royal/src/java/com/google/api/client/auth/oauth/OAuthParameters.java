/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Multiset
 *  com.google.common.collect.TreeMultiset
 *  java.io.IOException
 *  java.lang.Comparable
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.security.GeneralSecurityException
 *  java.security.SecureRandom
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.NavigableSet
 *  java.util.Set
 */
package com.google.api.client.auth.oauth;

import com.google.api.client.auth.oauth.OAuthSigner;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpExecuteInterceptor;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.util.escape.PercentEscaper;
import com.google.common.collect.Multiset;
import com.google.common.collect.TreeMultiset;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.Set;

public final class OAuthParameters
implements HttpExecuteInterceptor,
HttpRequestInitializer {
    private static final PercentEscaper ESCAPER;
    private static final SecureRandom RANDOM;
    public String callback;
    public String consumerKey;
    public String nonce;
    public String realm;
    public String signature;
    public String signatureMethod;
    public OAuthSigner signer;
    public String timestamp;
    public String token;
    public String verifier;
    public String version;

    static {
        RANDOM = new SecureRandom();
        ESCAPER = new PercentEscaper("-_.~", false);
    }

    private void appendParameter(StringBuilder stringBuilder, String string2, String string3) {
        if (string3 != null) {
            stringBuilder.append(' ');
            stringBuilder.append(OAuthParameters.escape(string2));
            stringBuilder.append("=\"");
            stringBuilder.append(OAuthParameters.escape(string3));
            stringBuilder.append("\",");
        }
    }

    public static String escape(String string2) {
        return ESCAPER.escape(string2);
    }

    private void putParameter(Multiset<Parameter> multiset, String string2, Object object) {
        String string3 = OAuthParameters.escape(string2);
        String string4 = object == null ? null : OAuthParameters.escape(object.toString());
        multiset.add((Object)new Comparable<Parameter>(string3, string4){
            private final String key;
            private final String value;
            {
                this.key = string2;
                this.value = string3;
            }

            public int compareTo(Parameter parameter) {
                int n = this.key.compareTo(parameter.key);
                if (n == 0) {
                    n = this.value.compareTo(parameter.value);
                }
                return n;
            }

            public String getKey() {
                return this.key;
            }

            public String getValue() {
                return this.value;
            }
        });
    }

    private void putParameterIfValueNotNull(Multiset<Parameter> multiset, String string2, String string3) {
        if (string3 != null) {
            this.putParameter(multiset, string2, string3);
        }
    }

    public void computeNonce() {
        this.nonce = Long.toHexString((long)Math.abs((long)RANDOM.nextLong()));
    }

    public void computeSignature(String string2, GenericUrl genericUrl) throws GeneralSecurityException {
        String string3;
        OAuthSigner oAuthSigner = this.signer;
        this.signatureMethod = string3 = oAuthSigner.getSignatureMethod();
        TreeMultiset treeMultiset = TreeMultiset.create();
        this.putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_callback", this.callback);
        this.putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_consumer_key", this.consumerKey);
        this.putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_nonce", this.nonce);
        this.putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_signature_method", string3);
        this.putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_timestamp", this.timestamp);
        this.putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_token", this.token);
        this.putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_verifier", this.verifier);
        this.putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_version", this.version);
        for (Map.Entry entry : genericUrl.entrySet()) {
            Object object = entry.getValue();
            if (object == null) continue;
            String string4 = (String)entry.getKey();
            if (object instanceof Collection) {
                Iterator iterator = ((Collection)object).iterator();
                while (iterator.hasNext()) {
                    this.putParameter((Multiset<Parameter>)treeMultiset, string4, iterator.next());
                }
                continue;
            }
            this.putParameter((Multiset<Parameter>)treeMultiset, string4, object);
        }
        StringBuilder stringBuilder = new StringBuilder();
        boolean bl = true;
        for (Parameter parameter : treeMultiset.elementSet()) {
            if (bl) {
                bl = false;
            } else {
                stringBuilder.append('&');
            }
            stringBuilder.append(parameter.getKey());
            String string5 = parameter.getValue();
            if (string5 == null) continue;
            stringBuilder.append('=');
            stringBuilder.append(string5);
        }
        String string6 = stringBuilder.toString();
        GenericUrl genericUrl2 = new GenericUrl();
        String string7 = genericUrl.getScheme();
        genericUrl2.setScheme(string7);
        genericUrl2.setHost(genericUrl.getHost());
        genericUrl2.setPathParts(genericUrl.getPathParts());
        int n = genericUrl.getPort();
        if ("http".equals((Object)string7) && n == 80 || "https".equals((Object)string7) && n == 443) {
            n = -1;
        }
        genericUrl2.setPort(n);
        String string8 = genericUrl2.build();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(OAuthParameters.escape(string2));
        stringBuilder2.append('&');
        stringBuilder2.append(OAuthParameters.escape(string8));
        stringBuilder2.append('&');
        stringBuilder2.append(OAuthParameters.escape(string6));
        this.signature = oAuthSigner.computeSignature(stringBuilder2.toString());
    }

    public void computeTimestamp() {
        this.timestamp = Long.toString((long)(System.currentTimeMillis() / 1000L));
    }

    public String getAuthorizationHeader() {
        StringBuilder stringBuilder = new StringBuilder("OAuth");
        this.appendParameter(stringBuilder, "realm", this.realm);
        this.appendParameter(stringBuilder, "oauth_callback", this.callback);
        this.appendParameter(stringBuilder, "oauth_consumer_key", this.consumerKey);
        this.appendParameter(stringBuilder, "oauth_nonce", this.nonce);
        this.appendParameter(stringBuilder, "oauth_signature", this.signature);
        this.appendParameter(stringBuilder, "oauth_signature_method", this.signatureMethod);
        this.appendParameter(stringBuilder, "oauth_timestamp", this.timestamp);
        this.appendParameter(stringBuilder, "oauth_token", this.token);
        this.appendParameter(stringBuilder, "oauth_verifier", this.verifier);
        this.appendParameter(stringBuilder, "oauth_version", this.version);
        return stringBuilder.substring(0, -1 + stringBuilder.length());
    }

    @Override
    public void initialize(HttpRequest httpRequest) throws IOException {
        httpRequest.setInterceptor(this);
    }

    @Override
    public void intercept(HttpRequest httpRequest) throws IOException {
        this.computeNonce();
        this.computeTimestamp();
        try {
            this.computeSignature(httpRequest.getRequestMethod(), httpRequest.getUrl());
        }
        catch (GeneralSecurityException generalSecurityException) {
            IOException iOException = new IOException();
            iOException.initCause((Throwable)generalSecurityException);
            throw iOException;
        }
        httpRequest.getHeaders().setAuthorization(this.getAuthorizationHeader());
    }

}

