/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Object
 */
package com.google.api.client.util;

import java.io.IOException;
import java.io.OutputStream;

public interface StreamingContent {
    public void writeTo(OutputStream var1) throws IOException;
}

