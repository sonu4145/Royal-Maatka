/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.http.GenericUrl
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api.client.testing.http;

import com.google.api.client.http.GenericUrl;

public final class HttpTesting {
    public static final GenericUrl SIMPLE_GENERIC_URL = new GenericUrl("http://google.com/");
    public static final String SIMPLE_URL = "http://google.com/";

    private HttpTesting() {
    }
}

