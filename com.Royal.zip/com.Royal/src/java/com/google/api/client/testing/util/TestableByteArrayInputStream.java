/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayInputStream
 *  java.io.IOException
 */
package com.google.api.client.testing.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;

public class TestableByteArrayInputStream
extends ByteArrayInputStream {
    private boolean closed;

    public TestableByteArrayInputStream(byte[] arrby) {
        super(arrby);
    }

    public TestableByteArrayInputStream(byte[] arrby, int n, int n2) {
        super(arrby);
    }

    public void close() throws IOException {
        this.closed = true;
    }

    public final byte[] getBuffer() {
        return this.buf;
    }

    public final boolean isClosed() {
        return this.closed;
    }
}

