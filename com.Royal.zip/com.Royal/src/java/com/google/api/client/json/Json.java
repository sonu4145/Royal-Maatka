/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api.client.json;

public class Json {
    public static final String MEDIA_TYPE = "application/json; charset=UTF-8";
}

