/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.lang.reflect.Array
 *  java.lang.reflect.GenericArrayType
 *  java.lang.reflect.ParameterizedType
 *  java.lang.reflect.Type
 *  java.lang.reflect.TypeVariable
 *  java.lang.reflect.WildcardType
 *  java.math.BigDecimal
 *  java.math.BigInteger
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.TreeMap
 *  java.util.TreeSet
 *  java.util.concurrent.ConcurrentHashMap
 */
package com.google.api.client.util;

import com.google.api.client.util.ArrayMap;
import com.google.api.client.util.ClassInfo;
import com.google.api.client.util.DataMap;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.FieldInfo;
import com.google.api.client.util.GenericData;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Types;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

public class Data {
    public static final BigDecimal NULL_BIG_DECIMAL;
    public static final BigInteger NULL_BIG_INTEGER;
    public static final Boolean NULL_BOOLEAN;
    public static final Byte NULL_BYTE;
    private static final ConcurrentHashMap<Class<?>, Object> NULL_CACHE;
    public static final Character NULL_CHARACTER;
    public static final DateTime NULL_DATE_TIME;
    public static final Double NULL_DOUBLE;
    public static final Float NULL_FLOAT;
    public static final Integer NULL_INTEGER;
    public static final Long NULL_LONG;
    public static final Short NULL_SHORT;
    public static final String NULL_STRING;

    static {
        ConcurrentHashMap concurrentHashMap;
        NULL_BOOLEAN = new Boolean(true);
        NULL_STRING = new String();
        NULL_CHARACTER = new Character('\u0000');
        NULL_BYTE = new Byte(0);
        NULL_SHORT = new Short(0);
        NULL_INTEGER = new Integer(0);
        NULL_FLOAT = new Float(0.0f);
        NULL_LONG = new Long(0L);
        NULL_DOUBLE = new Double(0.0);
        NULL_BIG_INTEGER = new BigInteger("0");
        NULL_BIG_DECIMAL = new BigDecimal("0");
        NULL_DATE_TIME = new DateTime(0L);
        NULL_CACHE = concurrentHashMap = new ConcurrentHashMap();
        concurrentHashMap.put(Boolean.class, (Object)NULL_BOOLEAN);
        NULL_CACHE.put(String.class, (Object)NULL_STRING);
        NULL_CACHE.put(Character.class, (Object)NULL_CHARACTER);
        NULL_CACHE.put(Byte.class, (Object)NULL_BYTE);
        NULL_CACHE.put(Short.class, (Object)NULL_SHORT);
        NULL_CACHE.put(Integer.class, (Object)NULL_INTEGER);
        NULL_CACHE.put(Float.class, (Object)NULL_FLOAT);
        NULL_CACHE.put(Long.class, (Object)NULL_LONG);
        NULL_CACHE.put(Double.class, (Object)NULL_DOUBLE);
        NULL_CACHE.put(BigInteger.class, (Object)NULL_BIG_INTEGER);
        NULL_CACHE.put(BigDecimal.class, (Object)NULL_BIG_DECIMAL);
        NULL_CACHE.put(DateTime.class, (Object)NULL_DATE_TIME);
    }

    public static <T> T clone(T t) {
        if (t != null) {
            Object object;
            if (Data.isPrimitive((Type)t.getClass())) {
                return t;
            }
            if (t instanceof GenericData) {
                return (T)((Object)((GenericData)((Object)t)).clone());
            }
            Class class_ = t.getClass();
            if (class_.isArray()) {
                object = Array.newInstance((Class)class_.getComponentType(), (int)Array.getLength(t));
            } else if (t instanceof ArrayMap) {
                object = ((ArrayMap)((Object)t)).clone();
            } else {
                if ("java.util.Arrays$ArrayList".equals((Object)class_.getName())) {
                    Object[] arrobject = ((List)t).toArray();
                    Data.deepCopy(arrobject, arrobject);
                    return (T)Arrays.asList((Object[])arrobject);
                }
                object = Types.newInstance(class_);
            }
            Data.deepCopy(t, object);
            return (T)object;
        }
        return t;
    }

    private static Object createNullInstance(Class<?> class_) {
        boolean bl = class_.isArray();
        int n = 0;
        if (bl) {
            do {
                class_ = class_.getComponentType();
                ++n;
            } while (class_.isArray());
            return Array.newInstance((Class)class_, (int[])new int[n]);
        }
        if (class_.isEnum()) {
            FieldInfo fieldInfo = ClassInfo.of(class_).getFieldInfo(null);
            Preconditions.checkNotNull(fieldInfo, "enum missing constant with @NullValue annotation: %s", new Object[]{class_});
            return fieldInfo.enumValue();
        }
        return Types.newInstance(class_);
    }

    public static void deepCopy(Object object, Object object2) {
        int n;
        Class class_ = object.getClass();
        Class class_2 = object2.getClass();
        boolean bl = true;
        boolean bl2 = class_ == class_2;
        Preconditions.checkArgument(bl2);
        if (class_.isArray()) {
            if (Array.getLength((Object)object) != Array.getLength((Object)object2)) {
                bl = false;
            }
            Preconditions.checkArgument(bl);
            for (Object object3 : Types.iterableOf(object)) {
                int n2 = n + 1;
                Array.set((Object)object2, (int)n, (Object)Data.clone(object3));
                n = n2;
            }
        } else if (Collection.class.isAssignableFrom(class_)) {
            Collection collection = (Collection)object;
            if (ArrayList.class.isAssignableFrom(class_)) {
                ((ArrayList)object2).ensureCapacity(collection.size());
            }
            Collection collection2 = (Collection)object2;
            Iterator iterator = collection.iterator();
            while (iterator.hasNext()) {
                collection2.add(Data.clone(iterator.next()));
            }
        } else {
            boolean bl3 = GenericData.class.isAssignableFrom(class_);
            if (!bl3 && Map.class.isAssignableFrom(class_)) {
                if (ArrayMap.class.isAssignableFrom(class_)) {
                    ArrayMap arrayMap = (ArrayMap)((Object)object2);
                    ArrayMap arrayMap2 = (ArrayMap)((Object)object);
                    int n3 = arrayMap2.size();
                    for (n = 0; n < n3; ++n) {
                        arrayMap.set(n, Data.clone(arrayMap2.getValue(n)));
                    }
                } else {
                    Map map = (Map)object2;
                    for (Map.Entry entry : ((Map)object).entrySet()) {
                        map.put(entry.getKey(), Data.clone(entry.getValue()));
                    }
                }
            } else {
                ClassInfo classInfo = bl3 ? ((GenericData)object).classInfo : ClassInfo.of(class_);
                Iterator iterator = classInfo.names.iterator();
                while (iterator.hasNext()) {
                    Object object4;
                    FieldInfo fieldInfo = classInfo.getFieldInfo((String)iterator.next());
                    if (fieldInfo.isFinal() || bl3 && fieldInfo.isPrimitive() || (object4 = fieldInfo.getValue(object)) == null) continue;
                    fieldInfo.setValue(object2, Data.clone(object4));
                }
            }
        }
    }

    public static boolean isNull(Object object) {
        return object != null && object == NULL_CACHE.get((Object)object.getClass());
    }

    public static boolean isPrimitive(Type type) {
        boolean bl;
        block6 : {
            block5 : {
                if (type instanceof WildcardType) {
                    type = Types.getBound((WildcardType)type);
                }
                if (!(type instanceof Class)) {
                    return false;
                }
                Class class_ = (Class)type;
                if (class_.isPrimitive() || class_ == Character.class || class_ == String.class || class_ == Integer.class || class_ == Long.class || class_ == Short.class || class_ == Byte.class || class_ == Float.class || class_ == Double.class || class_ == BigInteger.class || class_ == BigDecimal.class || class_ == DateTime.class) break block5;
                bl = false;
                if (class_ != Boolean.class) break block6;
            }
            bl = true;
        }
        return bl;
    }

    public static boolean isValueOfPrimitiveType(Object object) {
        return object == null || Data.isPrimitive((Type)object.getClass());
        {
        }
    }

    public static Map<String, Object> mapOf(Object object) {
        if (object != null && !Data.isNull(object)) {
            if (object instanceof Map) {
                return (Map)object;
            }
            return new DataMap(object, false);
        }
        return Collections.emptyMap();
    }

    public static Collection<Object> newCollectionInstance(Type type) {
        if (type instanceof WildcardType) {
            type = Types.getBound((WildcardType)type);
        }
        if (type instanceof ParameterizedType) {
            type = ((ParameterizedType)type).getRawType();
        }
        Class class_ = type instanceof Class ? (Class)type : null;
        if (!(type == null || type instanceof GenericArrayType || class_ != null && (class_.isArray() || class_.isAssignableFrom(ArrayList.class)))) {
            if (class_ != null) {
                if (class_.isAssignableFrom(HashSet.class)) {
                    return new HashSet();
                }
                if (class_.isAssignableFrom(TreeSet.class)) {
                    return new TreeSet();
                }
                return (Collection)Types.newInstance(class_);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("unable to create new instance of type: ");
            stringBuilder.append((Object)type);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        return new ArrayList();
    }

    public static Map<String, Object> newMapInstance(Class<?> class_) {
        if (class_ != null && !class_.isAssignableFrom(ArrayMap.class)) {
            if (class_.isAssignableFrom(TreeMap.class)) {
                return new TreeMap();
            }
            return (Map)Types.newInstance(class_);
        }
        return ArrayMap.create();
    }

    public static <T> T nullOf(Class<T> class_) {
        Object object = NULL_CACHE.get(class_);
        if (object == null) {
            Object object2 = Data.createNullInstance(class_);
            Object object3 = NULL_CACHE.putIfAbsent(class_, object2);
            if (object3 == null) {
                return (T)object2;
            }
            object = object3;
        }
        return (T)object;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static Object parsePrimitiveValue(Type var0, String var1_1) {
        var2_2 = var0 instanceof Class != false ? (Class)var0 : null;
        if (var0 == null || var2_2 != null) {
            if (var2_2 == Void.class) {
                return null;
            }
            if (var1_1 == null) return var1_1;
            if (var2_2 == null) return var1_1;
            if (var2_2.isAssignableFrom(String.class)) {
                return var1_1;
            }
            if (var2_2 != Character.class && var2_2 != Character.TYPE) {
                if (var2_2 == Boolean.class) return Boolean.valueOf((String)var1_1);
                if (var2_2 == Boolean.TYPE) {
                    return Boolean.valueOf((String)var1_1);
                }
                if (var2_2 == Byte.class) return Byte.valueOf((String)var1_1);
                if (var2_2 == Byte.TYPE) {
                    return Byte.valueOf((String)var1_1);
                }
                if (var2_2 == Short.class) return Short.valueOf((String)var1_1);
                if (var2_2 == Short.TYPE) {
                    return Short.valueOf((String)var1_1);
                }
                if (var2_2 == Integer.class) return Integer.valueOf((String)var1_1);
                if (var2_2 == Integer.TYPE) {
                    return Integer.valueOf((String)var1_1);
                }
                if (var2_2 == Long.class) return Long.valueOf((String)var1_1);
                if (var2_2 == Long.TYPE) {
                    return Long.valueOf((String)var1_1);
                }
                if (var2_2 == Float.class) return Float.valueOf((String)var1_1);
                if (var2_2 == Float.TYPE) {
                    return Float.valueOf((String)var1_1);
                }
                if (var2_2 == Double.class) return Double.valueOf((String)var1_1);
                if (var2_2 == Double.TYPE) {
                    return Double.valueOf((String)var1_1);
                }
                if (var2_2 == DateTime.class) {
                    return DateTime.parseRfc3339(var1_1);
                }
                if (var2_2 == BigInteger.class) {
                    return new BigInteger(var1_1);
                }
                if (var2_2 == BigDecimal.class) {
                    return new BigDecimal(var1_1);
                }
                if (var2_2.isEnum()) {
                    if (!ClassInfo.of(var2_2).names.contains((Object)var1_1)) throw new IllegalArgumentException(String.format((String)"given enum name %s not part of enumeration", (Object[])new Object[]{var1_1}));
                    return ClassInfo.of(var2_2).getFieldInfo(var1_1).enumValue();
                } else {
                    ** GOTO lbl-1000
                }
            }
        } else lbl-1000: // 3 sources:
        {
            var6_3 = new StringBuilder();
            var6_3.append("expected primitive class, but got: ");
            var6_3.append((Object)var0);
            throw new IllegalArgumentException(var6_3.toString());
        }
        if (var1_1.length() == 1) {
            return Character.valueOf((char)var1_1.charAt(0));
        }
        var3_4 = new StringBuilder();
        var3_4.append("expected type Character/char but got ");
        var3_4.append((Object)var2_2);
        throw new IllegalArgumentException(var3_4.toString());
    }

    public static Type resolveWildcardTypeOrTypeVariable(List<Type> list, Type type) {
        if (type instanceof WildcardType) {
            type = Types.getBound((WildcardType)type);
        }
        while (type instanceof TypeVariable) {
            Type type2 = Types.resolveTypeVariable(list, (TypeVariable)type);
            if (type2 != null) {
                type = type2;
            }
            if (!(type instanceof TypeVariable)) continue;
            type = ((TypeVariable)type).getBounds()[0];
        }
        return type;
    }
}

