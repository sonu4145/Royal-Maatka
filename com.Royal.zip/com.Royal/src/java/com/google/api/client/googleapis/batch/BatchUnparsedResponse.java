/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.googleapis.batch.BatchUnparsedResponse$FakeResponseHttpTransport
 *  com.google.api.client.http.GenericUrl
 *  com.google.api.client.http.HttpContent
 *  com.google.api.client.http.HttpHeaders
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.FilterInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.List
 */
package com.google.api.client.googleapis.batch;

import com.google.api.client.googleapis.batch.BatchCallback;
import com.google.api.client.googleapis.batch.BatchRequest;
import com.google.api.client.googleapis.batch.BatchUnparsedResponse;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpContent;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpStatusCodes;
import com.google.api.client.http.HttpUnsuccessfulResponseHandler;
import com.google.api.client.util.ByteStreams;
import com.google.api.client.util.ObjectParser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/*
 * Exception performing whole class analysis.
 */
final class BatchUnparsedResponse {
    private final String boundary;
    private int contentId;
    boolean hasNext;
    private final InputStream inputStream;
    private final List<BatchRequest.RequestInfo<?, ?>> requestInfos;
    private final boolean retryAllowed;
    List<BatchRequest.RequestInfo<?, ?>> unsuccessfulRequestInfos;

    BatchUnparsedResponse(InputStream inputStream, String string2, List<BatchRequest.RequestInfo<?, ?>> list, boolean bl) throws IOException {
        this.hasNext = true;
        this.unsuccessfulRequestInfos = new ArrayList();
        this.contentId = 0;
        this.boundary = string2;
        this.requestInfos = list;
        this.retryAllowed = bl;
        this.inputStream = inputStream;
        this.checkForFinalBoundary(this.readLine());
    }

    private void checkForFinalBoundary(String string2) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.boundary);
        stringBuilder.append("--");
        if (string2.equals((Object)stringBuilder.toString())) {
            this.hasNext = false;
            this.inputStream.close();
        }
    }

    private HttpResponse getFakeResponse(int n, InputStream inputStream, List<String> list, List<String> list2) throws IOException {
        HttpRequest httpRequest = new /* Unavailable Anonymous Inner Class!! */.createRequestFactory().buildPostRequest(new GenericUrl("http://google.com/"), null);
        httpRequest.setLoggingEnabled(false);
        httpRequest.setThrowExceptionOnExecuteError(false);
        return httpRequest.execute();
    }

    private <A, T, E> A getParsedDataClass(Class<A> class_, HttpResponse httpResponse, BatchRequest.RequestInfo<T, E> requestInfo) throws IOException {
        if (class_ == Void.class) {
            return null;
        }
        return requestInfo.request.getParser().parseAndClose(httpResponse.getContent(), httpResponse.getContentCharset(), class_);
    }

    private <T, E> void parseAndCallback(BatchRequest.RequestInfo<T, E> requestInfo, int n, HttpResponse httpResponse) throws IOException {
        BatchCallback batchCallback = requestInfo.callback;
        HttpHeaders httpHeaders = httpResponse.getHeaders();
        HttpUnsuccessfulResponseHandler httpUnsuccessfulResponseHandler = requestInfo.request.getUnsuccessfulResponseHandler();
        if (HttpStatusCodes.isSuccess(n)) {
            if (batchCallback == null) {
                return;
            }
            batchCallback.onSuccess(this.getParsedDataClass(requestInfo.dataClass, httpResponse, requestInfo), httpHeaders);
            return;
        }
        HttpContent httpContent = requestInfo.request.getContent();
        boolean bl = this.retryAllowed;
        boolean bl2 = true;
        boolean bl3 = bl && (httpContent == null || httpContent.retrySupported());
        boolean bl4 = httpUnsuccessfulResponseHandler != null ? httpUnsuccessfulResponseHandler.handleResponse(requestInfo.request, httpResponse, bl3) : false;
        if (bl4 || !requestInfo.request.handleRedirect(httpResponse.getStatusCode(), httpResponse.getHeaders())) {
            bl2 = false;
        }
        if (bl3 && (bl4 || bl2)) {
            this.unsuccessfulRequestInfos.add(requestInfo);
            return;
        }
        if (batchCallback == null) {
            return;
        }
        batchCallback.onFailure(this.getParsedDataClass(requestInfo.errorClass, httpResponse, requestInfo), httpHeaders);
    }

    private String readLine() throws IOException {
        return BatchUnparsedResponse.trimCrlf(this.readRawLine());
    }

    private String readRawLine() throws IOException {
        int n = this.inputStream.read();
        if (n == -1) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        while (n != -1) {
            stringBuilder.append((char)n);
            if (n == 10) break;
            n = this.inputStream.read();
        }
        return stringBuilder.toString();
    }

    private static InputStream trimCrlf(byte[] arrby) {
        int n = arrby.length;
        if (n > 0 && arrby[n - 1] == 10) {
            --n;
        }
        if (n > 0 && arrby[n - 1] == 13) {
            --n;
        }
        return new ByteArrayInputStream(arrby, 0, n);
    }

    private static String trimCrlf(String string2) {
        if (string2.endsWith("\r\n")) {
            return string2.substring(0, -2 + string2.length());
        }
        if (string2.endsWith("\n")) {
            string2 = string2.substring(0, -1 + string2.length());
        }
        return string2;
    }

    void parseNextResponse() throws IOException {
        String string2;
        String string3;
        FilterInputStream filterInputStream;
        this.contentId = 1 + this.contentId;
        while ((string2 = this.readLine()) != null && !string2.equals((Object)"")) {
        }
        int n = Integer.parseInt((String)this.readLine().split(" ")[1]);
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        long l = -1L;
        while ((string3 = this.readLine()) != null && !string3.equals((Object)"")) {
            String[] arrstring = string3.split(": ", 2);
            String string4 = arrstring[0];
            String string5 = arrstring[1];
            arrayList.add((Object)string4);
            arrayList2.add((Object)string5);
            if (!"Content-Length".equalsIgnoreCase(string4.trim())) continue;
            l = Long.parseLong((String)string5);
        }
        if (l == -1L) {
            String string6;
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            while ((string6 = this.readRawLine()) != null && !string6.startsWith(this.boundary)) {
                byteArrayOutputStream.write(string6.getBytes("ISO-8859-1"));
            }
            filterInputStream = BatchUnparsedResponse.trimCrlf(byteArrayOutputStream.toByteArray());
            string3 = BatchUnparsedResponse.trimCrlf(string6);
        } else {
            filterInputStream = new FilterInputStream(ByteStreams.limit(this.inputStream, l)){

                public void close() {
                }
            };
        }
        HttpResponse httpResponse = this.getFakeResponse(n, (InputStream)filterInputStream, (List<String>)arrayList, (List<String>)arrayList2);
        this.parseAndCallback((BatchRequest.RequestInfo)this.requestInfos.get(this.contentId - 1), n, httpResponse);
        while (filterInputStream.skip(l) > 0L || filterInputStream.read() != -1) {
        }
        if (l != -1L) {
            string3 = this.readLine();
        }
        while (string3 != null && string3.length() == 0) {
            string3 = this.readLine();
        }
        this.checkForFinalBoundary(string3);
    }

}

