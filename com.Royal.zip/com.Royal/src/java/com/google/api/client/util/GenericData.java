/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.CloneNotSupportedException
 *  java.lang.Cloneable
 *  java.lang.Enum
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.AbstractMap
 *  java.util.AbstractSet
 *  java.util.EnumSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Objects
 *  java.util.Set
 */
package com.google.api.client.util;

import com.google.api.client.util.ArrayMap;
import com.google.api.client.util.ClassInfo;
import com.google.api.client.util.Data;
import com.google.api.client.util.DataMap;
import com.google.api.client.util.FieldInfo;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class GenericData
extends AbstractMap<String, Object>
implements Cloneable {
    final ClassInfo classInfo;
    Map<String, Object> unknownFields = ArrayMap.create();

    public GenericData() {
        this((EnumSet<Flags>)EnumSet.noneOf(Flags.class));
    }

    public GenericData(EnumSet<Flags> enumSet) {
        this.classInfo = ClassInfo.of(this.getClass(), enumSet.contains((Object)Flags.IGNORE_CASE));
    }

    public GenericData clone() {
        try {
            GenericData genericData = (GenericData)((Object)super.clone());
            Data.deepCopy((Object)this, (Object)genericData);
            genericData.unknownFields = Data.clone(this.unknownFields);
            return genericData;
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new IllegalStateException((Throwable)cloneNotSupportedException);
        }
    }

    public Set<Map.Entry<String, Object>> entrySet() {
        return new EntrySet();
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object != null) {
            if (!(object instanceof GenericData)) {
                return false;
            }
            GenericData genericData = (GenericData)((Object)object);
            return super.equals((Object)genericData) && Objects.equals((Object)this.classInfo, (Object)genericData.classInfo);
        }
        return false;
    }

    public final Object get(Object object) {
        if (!(object instanceof String)) {
            return null;
        }
        String string2 = (String)object;
        FieldInfo fieldInfo = this.classInfo.getFieldInfo(string2);
        if (fieldInfo != null) {
            return fieldInfo.getValue((Object)this);
        }
        if (this.classInfo.getIgnoreCase()) {
            string2 = string2.toLowerCase(Locale.US);
        }
        return this.unknownFields.get((Object)string2);
    }

    public final ClassInfo getClassInfo() {
        return this.classInfo;
    }

    public final Map<String, Object> getUnknownKeys() {
        return this.unknownFields;
    }

    public int hashCode() {
        Object[] arrobject = new Object[]{super.hashCode(), this.classInfo};
        return Objects.hash((Object[])arrobject);
    }

    public final Object put(String string2, Object object) {
        FieldInfo fieldInfo = this.classInfo.getFieldInfo(string2);
        if (fieldInfo != null) {
            Object object2 = fieldInfo.getValue((Object)this);
            fieldInfo.setValue((Object)this, object);
            return object2;
        }
        if (this.classInfo.getIgnoreCase()) {
            string2 = string2.toLowerCase(Locale.US);
        }
        return this.unknownFields.put((Object)string2, object);
    }

    public final void putAll(Map<? extends String, ?> map) {
        for (Map.Entry entry : map.entrySet()) {
            this.set((String)entry.getKey(), entry.getValue());
        }
    }

    public final Object remove(Object object) {
        if (!(object instanceof String)) {
            return null;
        }
        String string2 = (String)object;
        if (this.classInfo.getFieldInfo(string2) == null) {
            if (this.classInfo.getIgnoreCase()) {
                string2 = string2.toLowerCase(Locale.US);
            }
            return this.unknownFields.remove((Object)string2);
        }
        throw new UnsupportedOperationException();
    }

    public GenericData set(String string2, Object object) {
        FieldInfo fieldInfo = this.classInfo.getFieldInfo(string2);
        if (fieldInfo != null) {
            fieldInfo.setValue((Object)this, object);
            return this;
        }
        if (this.classInfo.getIgnoreCase()) {
            string2 = string2.toLowerCase(Locale.US);
        }
        this.unknownFields.put((Object)string2, object);
        return this;
    }

    public final void setUnknownKeys(Map<String, Object> map) {
        this.unknownFields = map;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("GenericData{classInfo=");
        stringBuilder.append(this.classInfo.names);
        stringBuilder.append(", ");
        stringBuilder.append(super.toString());
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    final class EntryIterator
    implements Iterator<Map.Entry<String, Object>> {
        private final Iterator<Map.Entry<String, Object>> fieldIterator;
        private boolean startedUnknown;
        private final Iterator<Map.Entry<String, Object>> unknownIterator;

        EntryIterator(DataMap.EntrySet entrySet) {
            this.fieldIterator = entrySet.iterator();
            this.unknownIterator = GenericData.this.unknownFields.entrySet().iterator();
        }

        public boolean hasNext() {
            return this.fieldIterator.hasNext() || this.unknownIterator.hasNext();
            {
            }
        }

        public Map.Entry<String, Object> next() {
            if (!this.startedUnknown) {
                if (this.fieldIterator.hasNext()) {
                    return (Map.Entry)this.fieldIterator.next();
                }
                this.startedUnknown = true;
            }
            return (Map.Entry)this.unknownIterator.next();
        }

        public void remove() {
            if (this.startedUnknown) {
                this.unknownIterator.remove();
            }
            this.fieldIterator.remove();
        }
    }

    final class EntrySet
    extends AbstractSet<Map.Entry<String, Object>> {
        private final DataMap.EntrySet dataEntrySet;

        EntrySet() {
            this.dataEntrySet = new DataMap((Object)GenericData.this, GenericData.this.classInfo.getIgnoreCase()).entrySet();
        }

        public void clear() {
            GenericData.this.unknownFields.clear();
            this.dataEntrySet.clear();
        }

        public Iterator<Map.Entry<String, Object>> iterator() {
            return new EntryIterator(this.dataEntrySet);
        }

        public int size() {
            return GenericData.this.unknownFields.size() + this.dataEntrySet.size();
        }
    }

    public static final class Flags
    extends Enum<Flags> {
        private static final /* synthetic */ Flags[] $VALUES;
        public static final /* enum */ Flags IGNORE_CASE;

        static {
            Flags flags;
            IGNORE_CASE = flags = new Flags();
            $VALUES = new Flags[]{flags};
        }

        public static Flags valueOf(String string2) {
            return (Flags)Enum.valueOf(Flags.class, (String)string2);
        }

        public static Flags[] values() {
            return (Flags[])$VALUES.clone();
        }
    }

}

