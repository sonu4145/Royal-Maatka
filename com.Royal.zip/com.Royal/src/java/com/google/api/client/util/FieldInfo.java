/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Ascii
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchFieldException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 *  java.lang.reflect.Type
 *  java.util.ArrayList
 *  java.util.Map
 *  java.util.WeakHashMap
 */
package com.google.api.client.util;

import com.google.api.client.util.ClassInfo;
import com.google.api.client.util.Data;
import com.google.api.client.util.Key;
import com.google.api.client.util.NullValue;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Value;
import com.google.common.base.Ascii;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;

public class FieldInfo {
    private static final Map<Field, FieldInfo> CACHE = new WeakHashMap();
    private final Field field;
    private final boolean isPrimitive;
    private final String name;
    private final Method[] setters;

    FieldInfo(Field field, String string2) {
        this.field = field;
        String string3 = string2 == null ? null : string2.intern();
        this.name = string3;
        this.isPrimitive = Data.isPrimitive(this.getType());
        this.setters = this.settersMethodForField(field);
    }

    public static Object getFieldValue(Field field, Object object) {
        try {
            Object object2 = field.get(object);
            return object2;
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new IllegalArgumentException((Throwable)illegalAccessException);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static FieldInfo of(Enum<?> enum_) {
        try {
            FieldInfo fieldInfo = FieldInfo.of(enum_.getClass().getField(enum_.name()));
            boolean bl = fieldInfo != null;
            Preconditions.checkArgument(bl, "enum constant missing @Value or @NullValue annotation: %s", enum_);
            return fieldInfo;
        }
        catch (NoSuchFieldException noSuchFieldException) {
            throw new RuntimeException((Throwable)noSuchFieldException);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static FieldInfo of(Field field) {
        Map<Field, FieldInfo> map;
        if (field == null) {
            return null;
        }
        Map<Field, FieldInfo> map2 = map = CACHE;
        synchronized (map2) {
            FieldInfo fieldInfo = (FieldInfo)CACHE.get((Object)field);
            boolean bl = field.isEnumConstant();
            if (fieldInfo == null && (bl || !Modifier.isStatic((int)field.getModifiers()))) {
                String string2;
                if (bl) {
                    Value value = (Value)field.getAnnotation(Value.class);
                    if (value != null) {
                        string2 = value.value();
                    } else {
                        if ((NullValue)field.getAnnotation(NullValue.class) == null) {
                            return null;
                        }
                        string2 = null;
                    }
                } else {
                    Key key = (Key)field.getAnnotation(Key.class);
                    if (key == null) {
                        return null;
                    }
                    string2 = key.value();
                    field.setAccessible(true);
                }
                if ("##default".equals((Object)string2)) {
                    string2 = field.getName();
                }
                fieldInfo = new FieldInfo(field, string2);
                CACHE.put((Object)field, (Object)fieldInfo);
            }
            return fieldInfo;
        }
    }

    public static void setFieldValue(Field field, Object object, Object object2) {
        if (Modifier.isFinal((int)field.getModifiers())) {
            Object object3 = FieldInfo.getFieldValue(field, object);
            if (object2 == null ? object3 == null : object2.equals(object3)) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("expected final value <");
            stringBuilder.append(object3);
            stringBuilder.append("> but was <");
            stringBuilder.append(object2);
            stringBuilder.append("> on ");
            stringBuilder.append(field.getName());
            stringBuilder.append(" field in ");
            stringBuilder.append(object.getClass().getName());
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        try {
            field.set(object, object2);
            return;
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new IllegalArgumentException((Throwable)illegalAccessException);
        }
        catch (SecurityException securityException) {
            throw new IllegalArgumentException((Throwable)securityException);
        }
    }

    private Method[] settersMethodForField(Field field) {
        ArrayList arrayList = new ArrayList();
        for (Method method : field.getDeclaringClass().getDeclaredMethods()) {
            String string2 = Ascii.toLowerCase((String)method.getName());
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("set");
            stringBuilder.append(Ascii.toLowerCase((String)field.getName()));
            if (!string2.equals((Object)stringBuilder.toString()) || method.getParameterTypes().length != 1) continue;
            arrayList.add((Object)method);
        }
        return (Method[])arrayList.toArray((Object[])new Method[0]);
    }

    public <T extends Enum<T>> T enumValue() {
        return (T)Enum.valueOf((Class)this.field.getDeclaringClass(), (String)this.field.getName());
    }

    public ClassInfo getClassInfo() {
        return ClassInfo.of(this.field.getDeclaringClass());
    }

    public Field getField() {
        return this.field;
    }

    public Type getGenericType() {
        return this.field.getGenericType();
    }

    public String getName() {
        return this.name;
    }

    public Class<?> getType() {
        return this.field.getType();
    }

    public Object getValue(Object object) {
        return FieldInfo.getFieldValue(this.field, object);
    }

    public boolean isFinal() {
        return Modifier.isFinal((int)this.field.getModifiers());
    }

    public boolean isPrimitive() {
        return this.isPrimitive;
    }

    /*
     * Exception decompiling
     */
    public void setValue(Object var1, Object var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl12 : ILOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }
}

