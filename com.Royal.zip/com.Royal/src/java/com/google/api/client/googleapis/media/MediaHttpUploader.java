/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.googleapis.MethodOverride
 *  com.google.api.client.googleapis.media.MediaUploadErrorHandler
 *  com.google.api.client.http.AbstractInputStreamContent
 *  com.google.api.client.http.ByteArrayContent
 *  com.google.api.client.http.EmptyContent
 *  com.google.api.client.http.GZipEncoding
 *  com.google.api.client.http.GenericUrl
 *  com.google.api.client.http.HttpContent
 *  com.google.api.client.http.HttpHeaders
 *  com.google.api.client.http.InputStreamContent
 *  com.google.api.client.http.MultipartContent
 *  java.io.BufferedInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Byte
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Map
 */
package com.google.api.client.googleapis.media;

import com.google.api.client.googleapis.MethodOverride;
import com.google.api.client.googleapis.media.MediaHttpUploaderProgressListener;
import com.google.api.client.googleapis.media.MediaUploadErrorHandler;
import com.google.api.client.http.AbstractInputStreamContent;
import com.google.api.client.http.ByteArrayContent;
import com.google.api.client.http.EmptyContent;
import com.google.api.client.http.GZipEncoding;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpContent;
import com.google.api.client.http.HttpEncoding;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.InputStreamContent;
import com.google.api.client.http.MultipartContent;
import com.google.api.client.util.ByteStreams;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Sleeper;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;

public final class MediaHttpUploader {
    public static final String CONTENT_LENGTH_HEADER = "X-Upload-Content-Length";
    public static final String CONTENT_TYPE_HEADER = "X-Upload-Content-Type";
    public static final int DEFAULT_CHUNK_SIZE = 10485760;
    private static final int KB = 1024;
    static final int MB = 1048576;
    public static final int MINIMUM_CHUNK_SIZE = 262144;
    private Byte cachedByte;
    private int chunkSize = 10485760;
    private InputStream contentInputStream;
    private int currentChunkLength;
    private HttpRequest currentRequest;
    private byte[] currentRequestContentBuffer;
    private boolean directUploadEnabled;
    private boolean disableGZipContent;
    private HttpHeaders initiationHeaders = new HttpHeaders();
    private String initiationRequestMethod = "POST";
    private boolean isMediaContentLengthCalculated;
    private final AbstractInputStreamContent mediaContent;
    private long mediaContentLength;
    String mediaContentLengthStr = "*";
    private HttpContent metadata;
    private MediaHttpUploaderProgressListener progressListener;
    private final HttpRequestFactory requestFactory;
    Sleeper sleeper = Sleeper.DEFAULT;
    private long totalBytesClientSent;
    private long totalBytesServerReceived;
    private final HttpTransport transport;
    private UploadState uploadState = UploadState.NOT_STARTED;

    public MediaHttpUploader(AbstractInputStreamContent abstractInputStreamContent, HttpTransport httpTransport, HttpRequestInitializer httpRequestInitializer) {
        this.mediaContent = Preconditions.checkNotNull(abstractInputStreamContent);
        this.transport = Preconditions.checkNotNull(httpTransport);
        HttpRequestFactory httpRequestFactory = httpRequestInitializer == null ? httpTransport.createRequestFactory() : httpTransport.createRequestFactory(httpRequestInitializer);
        this.requestFactory = httpRequestFactory;
    }

    private ContentChunk buildContentChunk() throws IOException {
        InputStreamContent inputStreamContent;
        String string2;
        int n = this.isMediaLengthKnown() ? (int)Math.min((long)this.chunkSize, (long)(this.getMediaContentLength() - this.totalBytesServerReceived)) : this.chunkSize;
        if (this.isMediaLengthKnown()) {
            this.contentInputStream.mark(n);
            InputStream inputStream = this.contentInputStream;
            long l = n;
            InputStream inputStream2 = ByteStreams.limit(inputStream, l);
            inputStreamContent = new InputStreamContent(this.mediaContent.getType(), inputStream2).setRetrySupported(true).setLength(l).setCloseInputStream(false);
            this.mediaContentLengthStr = String.valueOf((long)this.getMediaContentLength());
        } else {
            int n2;
            int n3;
            byte[] arrby = this.currentRequestContentBuffer;
            if (arrby == null) {
                n2 = this.cachedByte == null ? n + 1 : n;
                byte[] arrby2 = new byte[n + 1];
                this.currentRequestContentBuffer = arrby2;
                Byte by = this.cachedByte;
                if (by != null) {
                    arrby2[0] = by;
                }
                n3 = 0;
            } else {
                n3 = (int)(this.totalBytesClientSent - this.totalBytesServerReceived);
                System.arraycopy((Object)arrby, (int)(this.currentChunkLength - n3), (Object)arrby, (int)0, (int)n3);
                Byte by = this.cachedByte;
                if (by != null) {
                    this.currentRequestContentBuffer[n3] = by;
                }
                n2 = n - n3;
            }
            int n4 = ByteStreams.read(this.contentInputStream, this.currentRequestContentBuffer, n + 1 - n2, n2);
            if (n4 < n2) {
                int n5 = n3 + Math.max((int)0, (int)n4);
                if (this.cachedByte != null) {
                    ++n5;
                    this.cachedByte = null;
                }
                if (this.mediaContentLengthStr.equals((Object)"*")) {
                    this.mediaContentLengthStr = String.valueOf((long)(this.totalBytesServerReceived + (long)n5));
                }
                n = n5;
            } else {
                this.cachedByte = this.currentRequestContentBuffer[n];
            }
            inputStreamContent = new ByteArrayContent(this.mediaContent.getType(), this.currentRequestContentBuffer, 0, n);
            this.totalBytesClientSent = this.totalBytesServerReceived + (long)n;
        }
        this.currentChunkLength = n;
        if (n == 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("bytes */");
            stringBuilder.append(this.mediaContentLengthStr);
            string2 = stringBuilder.toString();
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("bytes ");
            stringBuilder.append(this.totalBytesServerReceived);
            stringBuilder.append("-");
            stringBuilder.append(this.totalBytesServerReceived + (long)n - 1L);
            stringBuilder.append("/");
            stringBuilder.append(this.mediaContentLengthStr);
            string2 = stringBuilder.toString();
        }
        return new ContentChunk((AbstractInputStreamContent)inputStreamContent, string2);
    }

    private HttpResponse directUpload(GenericUrl genericUrl) throws IOException {
        this.updateStateAndNotifyListener(UploadState.MEDIA_IN_PROGRESS);
        AbstractInputStreamContent abstractInputStreamContent = this.mediaContent;
        if (this.metadata != null) {
            MultipartContent multipartContent = new MultipartContent();
            Object[] arrobject = new HttpContent[]{this.metadata, this.mediaContent};
            abstractInputStreamContent = multipartContent.setContentParts((Collection)Arrays.asList((Object[])arrobject));
            genericUrl.put("uploadType", (Object)"multipart");
        } else {
            genericUrl.put("uploadType", (Object)"media");
        }
        HttpRequest httpRequest = this.requestFactory.buildRequest(this.initiationRequestMethod, genericUrl, (HttpContent)abstractInputStreamContent);
        httpRequest.getHeaders().putAll((Map)this.initiationHeaders);
        HttpResponse httpResponse = this.executeCurrentRequest(httpRequest);
        try {
            if (this.isMediaLengthKnown()) {
                this.totalBytesServerReceived = this.getMediaContentLength();
            }
            this.updateStateAndNotifyListener(UploadState.MEDIA_COMPLETE);
            return httpResponse;
        }
        catch (Throwable throwable) {
            httpResponse.disconnect();
            throw throwable;
        }
    }

    private HttpResponse executeCurrentRequest(HttpRequest httpRequest) throws IOException {
        if (!this.disableGZipContent && !(httpRequest.getContent() instanceof EmptyContent)) {
            httpRequest.setEncoding((HttpEncoding)new GZipEncoding());
        }
        return this.executeCurrentRequestWithoutGZip(httpRequest);
    }

    private HttpResponse executeCurrentRequestWithoutGZip(HttpRequest httpRequest) throws IOException {
        new MethodOverride().intercept(httpRequest);
        httpRequest.setThrowExceptionOnExecuteError(false);
        return httpRequest.execute();
    }

    private HttpResponse executeUploadInitiation(GenericUrl genericUrl) throws IOException {
        this.updateStateAndNotifyListener(UploadState.INITIATION_STARTED);
        genericUrl.put("uploadType", (Object)"resumable");
        HttpContent httpContent = this.metadata;
        if (httpContent == null) {
            httpContent = new EmptyContent();
        }
        HttpRequest httpRequest = this.requestFactory.buildRequest(this.initiationRequestMethod, genericUrl, httpContent);
        this.initiationHeaders.set(CONTENT_TYPE_HEADER, (Object)this.mediaContent.getType());
        if (this.isMediaLengthKnown()) {
            this.initiationHeaders.set(CONTENT_LENGTH_HEADER, (Object)this.getMediaContentLength());
        }
        httpRequest.getHeaders().putAll((Map)this.initiationHeaders);
        HttpResponse httpResponse = this.executeCurrentRequest(httpRequest);
        try {
            this.updateStateAndNotifyListener(UploadState.INITIATION_COMPLETE);
            return httpResponse;
        }
        catch (Throwable throwable) {
            httpResponse.disconnect();
            throw throwable;
        }
    }

    private long getMediaContentLength() throws IOException {
        if (!this.isMediaContentLengthCalculated) {
            this.mediaContentLength = this.mediaContent.getLength();
            this.isMediaContentLengthCalculated = true;
        }
        return this.mediaContentLength;
    }

    private long getNextByteIndex(String string2) {
        if (string2 == null) {
            return 0L;
        }
        return 1L + Long.parseLong((String)string2.substring(1 + string2.indexOf(45)));
    }

    private boolean isMediaLengthKnown() throws IOException {
        return this.getMediaContentLength() >= 0L;
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private HttpResponse resumableUpload(GenericUrl var1_1) throws IOException {
        block23 : {
            var2_2 = this.executeUploadInitiation(var1_1);
            if (!var2_2.isSuccessStatusCode()) {
                return var2_2;
            }
            try {
                var3_3 = new GenericUrl(var2_2.getHeaders().getLocation());
            }
            catch (Throwable var21_15) {
                var2_2.disconnect();
                throw var21_15;
            }
            var2_2.disconnect();
            this.contentInputStream = var4_4 = this.mediaContent.getInputStream();
            if (!var4_4.markSupported() && this.isMediaLengthKnown()) {
                this.contentInputStream = new BufferedInputStream(this.contentInputStream);
            }
            block12 : do {
                block20 : {
                    block19 : {
                        var5_5 = this.buildContentChunk();
                        this.currentRequest = var6_6 = this.requestFactory.buildPutRequest(var3_3, null);
                        var6_6.setContent((HttpContent)var5_5.getContent());
                        this.currentRequest.getHeaders().setContentRange(var5_5.getContentRange());
                        new MediaUploadErrorHandler(this, this.currentRequest);
                        var10_7 = this.isMediaLengthKnown() != false ? this.executeCurrentRequestWithoutGZip(this.currentRequest) : this.executeCurrentRequest(this.currentRequest);
                        if (!var10_7.isSuccessStatusCode()) break block19;
                        this.totalBytesServerReceived = this.getMediaContentLength();
                        if (this.mediaContent.getCloseInputStream()) {
                            this.contentInputStream.close();
                        }
                        this.updateStateAndNotifyListener(UploadState.MEDIA_COMPLETE);
                        return var10_7;
                    }
                    if (var10_7.getStatusCode() == 308) break block20;
                    if (!this.mediaContent.getCloseInputStream()) return var10_7;
                    this.contentInputStream.close();
                    return var10_7;
                }
                var12_8 = var10_7.getHeaders().getLocation();
                if (var12_8 == null) ** GOTO lbl36
                var3_3 = new GenericUrl(var12_8);
lbl36: // 2 sources:
                var13_9 = this.getNextByteIndex(var10_7.getHeaders().getRange());
                var15_10 = var13_9 - this.totalBytesServerReceived;
                var17_11 = true;
                if (var15_10 < 0L) break;
                if (var15_10 > (long)this.currentChunkLength) break;
                var18_12 = true;
lbl43: // 2 sources:
                do {
                    block22 : {
                        Preconditions.checkState(var18_12);
                        var19_13 = (long)this.currentChunkLength - var15_10;
                        if (!this.isMediaLengthKnown()) break block22;
                        ** if (var19_13 <= 0L) goto lbl55
lbl-1000: // 1 sources:
                        {
                            this.contentInputStream.reset();
                            if (var15_10 != this.contentInputStream.skip(var15_10)) break block23;
lbl52: // 2 sources:
                            do {
                                Preconditions.checkState(var17_11);
                                ** GOTO lbl60
                                break;
                            } while (true);
                        }
lbl55: // 1 sources:
                        ** GOTO lbl60
                    }
                    if (var19_13 != 0L) ** GOTO lbl60
                    try {
                        this.currentRequestContentBuffer = null;
lbl60: // 4 sources:
                        this.totalBytesServerReceived = var13_9;
                        this.updateStateAndNotifyListener(UploadState.MEDIA_IN_PROGRESS);
                        continue block12;
                    }
                    catch (Throwable var11_14) {
                        throw var11_14;
                    }
                    finally {
                        var10_7.disconnect();
                        continue block12;
                    }
                    break;
                } while (true);
                break;
            } while (true);
            var18_12 = false;
            ** while (true)
        }
        var17_11 = false;
        ** while (true)
    }

    private void updateStateAndNotifyListener(UploadState uploadState) throws IOException {
        this.uploadState = uploadState;
        MediaHttpUploaderProgressListener mediaHttpUploaderProgressListener = this.progressListener;
        if (mediaHttpUploaderProgressListener != null) {
            mediaHttpUploaderProgressListener.progressChanged(this);
        }
    }

    public int getChunkSize() {
        return this.chunkSize;
    }

    public boolean getDisableGZipContent() {
        return this.disableGZipContent;
    }

    public HttpHeaders getInitiationHeaders() {
        return this.initiationHeaders;
    }

    public String getInitiationRequestMethod() {
        return this.initiationRequestMethod;
    }

    public HttpContent getMediaContent() {
        return this.mediaContent;
    }

    public HttpContent getMetadata() {
        return this.metadata;
    }

    public long getNumBytesUploaded() {
        return this.totalBytesServerReceived;
    }

    public double getProgress() throws IOException {
        Preconditions.checkArgument(this.isMediaLengthKnown(), "Cannot call getProgress() if the specified AbstractInputStreamContent has no content length. Use  getNumBytesUploaded() to denote progress instead.");
        if (this.getMediaContentLength() == 0L) {
            return 0.0;
        }
        double d = this.totalBytesServerReceived;
        double d2 = this.getMediaContentLength();
        Double.isNaN((double)d);
        Double.isNaN((double)d2);
        return d / d2;
    }

    public MediaHttpUploaderProgressListener getProgressListener() {
        return this.progressListener;
    }

    public Sleeper getSleeper() {
        return this.sleeper;
    }

    public HttpTransport getTransport() {
        return this.transport;
    }

    public UploadState getUploadState() {
        return this.uploadState;
    }

    public boolean isDirectUploadEnabled() {
        return this.directUploadEnabled;
    }

    void serverErrorCallback() throws IOException {
        Preconditions.checkNotNull(this.currentRequest, "The current request should not be null");
        this.currentRequest.setContent((HttpContent)new EmptyContent());
        HttpHeaders httpHeaders = this.currentRequest.getHeaders();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("bytes */");
        stringBuilder.append(this.mediaContentLengthStr);
        httpHeaders.setContentRange(stringBuilder.toString());
    }

    public MediaHttpUploader setChunkSize(int n) {
        boolean bl = n > 0 && n % 262144 == 0;
        Preconditions.checkArgument(bl, "chunkSize must be a positive multiple of 262144.");
        this.chunkSize = n;
        return this;
    }

    public MediaHttpUploader setDirectUploadEnabled(boolean bl) {
        this.directUploadEnabled = bl;
        return this;
    }

    public MediaHttpUploader setDisableGZipContent(boolean bl) {
        this.disableGZipContent = bl;
        return this;
    }

    public MediaHttpUploader setInitiationHeaders(HttpHeaders httpHeaders) {
        this.initiationHeaders = httpHeaders;
        return this;
    }

    public MediaHttpUploader setInitiationRequestMethod(String string2) {
        boolean bl = string2.equals((Object)"POST") || string2.equals((Object)"PUT") || string2.equals((Object)"PATCH");
        Preconditions.checkArgument(bl);
        this.initiationRequestMethod = string2;
        return this;
    }

    public MediaHttpUploader setMetadata(HttpContent httpContent) {
        this.metadata = httpContent;
        return this;
    }

    public MediaHttpUploader setProgressListener(MediaHttpUploaderProgressListener mediaHttpUploaderProgressListener) {
        this.progressListener = mediaHttpUploaderProgressListener;
        return this;
    }

    public MediaHttpUploader setSleeper(Sleeper sleeper) {
        this.sleeper = sleeper;
        return this;
    }

    public HttpResponse upload(GenericUrl genericUrl) throws IOException {
        boolean bl = this.uploadState == UploadState.NOT_STARTED;
        Preconditions.checkArgument(bl);
        if (this.directUploadEnabled) {
            return this.directUpload(genericUrl);
        }
        return this.resumableUpload(genericUrl);
    }

    private static class ContentChunk {
        private final AbstractInputStreamContent content;
        private final String contentRange;

        ContentChunk(AbstractInputStreamContent abstractInputStreamContent, String string2) {
            this.content = abstractInputStreamContent;
            this.contentRange = string2;
        }

        AbstractInputStreamContent getContent() {
            return this.content;
        }

        String getContentRange() {
            return this.contentRange;
        }
    }

    public static final class UploadState
    extends Enum<UploadState> {
        private static final /* synthetic */ UploadState[] $VALUES;
        public static final /* enum */ UploadState INITIATION_COMPLETE;
        public static final /* enum */ UploadState INITIATION_STARTED;
        public static final /* enum */ UploadState MEDIA_COMPLETE;
        public static final /* enum */ UploadState MEDIA_IN_PROGRESS;
        public static final /* enum */ UploadState NOT_STARTED;

        static {
            UploadState uploadState;
            NOT_STARTED = new UploadState();
            INITIATION_STARTED = new UploadState();
            INITIATION_COMPLETE = new UploadState();
            MEDIA_IN_PROGRESS = new UploadState();
            MEDIA_COMPLETE = uploadState = new UploadState();
            UploadState[] arruploadState = new UploadState[]{NOT_STARTED, INITIATION_STARTED, INITIATION_COMPLETE, MEDIA_IN_PROGRESS, uploadState};
            $VALUES = arruploadState;
        }

        public static UploadState valueOf(String string2) {
            return (UploadState)Enum.valueOf(UploadState.class, (String)string2);
        }

        public static UploadState[] values() {
            return (UploadState[])$VALUES.clone();
        }
    }

}

