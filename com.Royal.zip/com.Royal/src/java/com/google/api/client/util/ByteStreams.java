/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.FilterInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api.client.util;

import com.google.api.client.util.Preconditions;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public final class ByteStreams {
    private static final int BUF_SIZE = 4096;

    private ByteStreams() {
    }

    public static long copy(InputStream inputStream, OutputStream outputStream) throws IOException {
        Preconditions.checkNotNull(inputStream);
        Preconditions.checkNotNull(outputStream);
        byte[] arrby = new byte[4096];
        long l = 0L;
        int n;
        while ((n = inputStream.read(arrby)) != -1) {
            outputStream.write(arrby, 0, n);
            l += (long)n;
        }
        return l;
    }

    public static InputStream limit(InputStream inputStream, long l) {
        return new LimitedInputStream(inputStream, l);
    }

    public static int read(InputStream inputStream, byte[] arrby, int n, int n2) throws IOException {
        IndexOutOfBoundsException indexOutOfBoundsException;
        Preconditions.checkNotNull(inputStream);
        Preconditions.checkNotNull(arrby);
        if (n2 >= 0) {
            int n3;
            int n4;
            for (n3 = 0; n3 < n2; n3 += n4) {
                n4 = inputStream.read(arrby, n + n3, n2 - n3);
                if (n4 != -1) continue;
                return n3;
            }
            return n3;
        }
        indexOutOfBoundsException = new IndexOutOfBoundsException("len is negative");
        throw indexOutOfBoundsException;
    }

    private static final class LimitedInputStream
    extends FilterInputStream {
        private long left;
        private long mark = -1L;

        LimitedInputStream(InputStream inputStream, long l) {
            super(inputStream);
            Preconditions.checkNotNull(inputStream);
            boolean bl = l >= 0L;
            Preconditions.checkArgument(bl, "limit must be non-negative");
            this.left = l;
        }

        public int available() throws IOException {
            return (int)Math.min((long)this.in.available(), (long)this.left);
        }

        public void mark(int n) {
            LimitedInputStream limitedInputStream = this;
            synchronized (limitedInputStream) {
                this.in.mark(n);
                this.mark = this.left;
                return;
            }
        }

        public int read() throws IOException {
            if (this.left == 0L) {
                return -1;
            }
            int n = this.in.read();
            if (n != -1) {
                --this.left;
            }
            return n;
        }

        public int read(byte[] arrby, int n, int n2) throws IOException {
            long l = this.left;
            if (l == 0L) {
                return -1;
            }
            int n3 = (int)Math.min((long)n2, (long)l);
            int n4 = this.in.read(arrby, n, n3);
            if (n4 != -1) {
                this.left -= (long)n4;
            }
            return n4;
        }

        public void reset() throws IOException {
            LimitedInputStream limitedInputStream = this;
            synchronized (limitedInputStream) {
                if (this.in.markSupported()) {
                    if (this.mark != -1L) {
                        this.in.reset();
                        this.left = this.mark;
                        return;
                    }
                    throw new IOException("Mark not set");
                }
                throw new IOException("Mark not supported");
            }
        }

        public long skip(long l) throws IOException {
            long l2 = Math.min((long)l, (long)this.left);
            long l3 = this.in.skip(l2);
            this.left -= l3;
            return l3;
        }
    }

}

