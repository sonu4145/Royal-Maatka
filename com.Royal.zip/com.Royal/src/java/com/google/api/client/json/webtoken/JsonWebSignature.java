/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.CloneNotSupportedException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.GeneralSecurityException
 *  java.security.PrivateKey
 *  java.security.PublicKey
 *  java.security.cert.X509Certificate
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.List
 *  javax.net.ssl.X509TrustManager
 */
package com.google.api.client.json.webtoken;

import com.google.api.client.json.GenericJson;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.webtoken.JsonWebToken;
import com.google.api.client.util.Base64;
import com.google.api.client.util.GenericData;
import com.google.api.client.util.Key;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.SecurityUtils;
import com.google.api.client.util.StringUtils;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.net.ssl.X509TrustManager;

public class JsonWebSignature
extends JsonWebToken {
    private final byte[] signatureBytes;
    private final byte[] signedContentBytes;

    public JsonWebSignature(Header header, JsonWebToken.Payload payload, byte[] arrby, byte[] arrby2) {
        super(header, payload);
        this.signatureBytes = Preconditions.checkNotNull(arrby);
        this.signedContentBytes = Preconditions.checkNotNull(arrby2);
    }

    /*
     * Exception decompiling
     */
    private static X509TrustManager getDefaultX509TrustManager() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl33.1 : ACONST_NULL : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static JsonWebSignature parse(JsonFactory jsonFactory, String string2) throws IOException {
        return JsonWebSignature.parser(jsonFactory).parse(string2);
    }

    public static Parser parser(JsonFactory jsonFactory) {
        return new Object(jsonFactory){
            private Class<? extends Header> headerClass = Header.class;
            private final JsonFactory jsonFactory;
            private Class<? extends JsonWebToken.Payload> payloadClass = JsonWebToken.Payload.class;
            {
                this.jsonFactory = Preconditions.checkNotNull(jsonFactory);
            }

            public Class<? extends Header> getHeaderClass() {
                return this.headerClass;
            }

            public JsonFactory getJsonFactory() {
                return this.jsonFactory;
            }

            public Class<? extends JsonWebToken.Payload> getPayloadClass() {
                return this.payloadClass;
            }

            public JsonWebSignature parse(String string2) throws IOException {
                int n = string2.indexOf(46);
                boolean bl = true;
                boolean bl2 = n != -1;
                Preconditions.checkArgument(bl2);
                byte[] arrby = Base64.decodeBase64(string2.substring(0, n));
                int n2 = n + bl;
                int n3 = string2.indexOf(46, n2);
                boolean bl3 = n3 != -1;
                Preconditions.checkArgument(bl3);
                int n4 = n3 + 1;
                boolean bl4 = string2.indexOf(46, n4) == -1;
                Preconditions.checkArgument(bl4);
                byte[] arrby2 = Base64.decodeBase64(string2.substring(n2, n3));
                byte[] arrby3 = Base64.decodeBase64(string2.substring(n4));
                byte[] arrby4 = StringUtils.getBytesUtf8(string2.substring(0, n3));
                Header header = this.jsonFactory.fromInputStream((InputStream)new ByteArrayInputStream(arrby), this.headerClass);
                if (header.getAlgorithm() == null) {
                    bl = false;
                }
                Preconditions.checkArgument(bl);
                return new JsonWebSignature(header, this.jsonFactory.fromInputStream((InputStream)new ByteArrayInputStream(arrby2), this.payloadClass), arrby3, arrby4);
            }

            public Parser setHeaderClass(Class<? extends Header> class_) {
                this.headerClass = class_;
                return this;
            }

            public Parser setPayloadClass(Class<? extends JsonWebToken.Payload> class_) {
                this.payloadClass = class_;
                return this;
            }
        };
    }

    public static String signUsingRsaSha256(PrivateKey privateKey, JsonFactory jsonFactory, Header header, JsonWebToken.Payload payload) throws GeneralSecurityException, IOException {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(Base64.encodeBase64URLSafeString(jsonFactory.toByteArray((Object)header)));
        stringBuilder.append(".");
        stringBuilder.append(Base64.encodeBase64URLSafeString(jsonFactory.toByteArray((Object)payload)));
        String string2 = stringBuilder.toString();
        byte[] arrby = StringUtils.getBytesUtf8(string2);
        byte[] arrby2 = SecurityUtils.sign(SecurityUtils.getSha256WithRsaSignatureAlgorithm(), privateKey, arrby);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(string2);
        stringBuilder2.append(".");
        stringBuilder2.append(Base64.encodeBase64URLSafeString(arrby2));
        return stringBuilder2.toString();
    }

    @Override
    public Header getHeader() {
        return (Header)super.getHeader();
    }

    public final byte[] getSignatureBytes() {
        byte[] arrby = this.signatureBytes;
        return Arrays.copyOf((byte[])arrby, (int)arrby.length);
    }

    public final byte[] getSignedContentBytes() {
        byte[] arrby = this.signedContentBytes;
        return Arrays.copyOf((byte[])arrby, (int)arrby.length);
    }

    public final X509Certificate verifySignature() throws GeneralSecurityException {
        X509TrustManager x509TrustManager = JsonWebSignature.getDefaultX509TrustManager();
        if (x509TrustManager == null) {
            return null;
        }
        return this.verifySignature(x509TrustManager);
    }

    public final X509Certificate verifySignature(X509TrustManager x509TrustManager) throws GeneralSecurityException {
        List<String> list = this.getHeader().getX509Certificates();
        if (list != null) {
            if (list.isEmpty()) {
                return null;
            }
            if ("RS256".equals((Object)this.getHeader().getAlgorithm())) {
                return SecurityUtils.verify(SecurityUtils.getSha256WithRsaSignatureAlgorithm(), x509TrustManager, list, this.signatureBytes, this.signedContentBytes);
            }
        }
        return null;
    }

    public final boolean verifySignature(PublicKey publicKey) throws GeneralSecurityException {
        if ("RS256".equals((Object)this.getHeader().getAlgorithm())) {
            return SecurityUtils.verify(SecurityUtils.getSha256WithRsaSignatureAlgorithm(), publicKey, this.signatureBytes, this.signedContentBytes);
        }
        return false;
    }

    public static class Header
    extends JsonWebToken.Header {
        @Key(value="alg")
        private String algorithm;
        @Key(value="crit")
        private List<String> critical;
        @Key(value="jwk")
        private String jwk;
        @Key(value="jku")
        private String jwkUrl;
        @Key(value="kid")
        private String keyId;
        @Key(value="x5c")
        private ArrayList<String> x509Certificates;
        @Key(value="x5t")
        private String x509Thumbprint;
        @Key(value="x5u")
        private String x509Url;

        @Override
        public Header clone() {
            return (Header)super.clone();
        }

        public final String getAlgorithm() {
            return this.algorithm;
        }

        public final List<String> getCritical() {
            List<String> list = this.critical;
            if (list != null && !list.isEmpty()) {
                return new ArrayList(this.critical);
            }
            return null;
        }

        public final String getJwk() {
            return this.jwk;
        }

        public final String getJwkUrl() {
            return this.jwkUrl;
        }

        public final String getKeyId() {
            return this.keyId;
        }

        public final List<String> getX509Certificates() {
            return new ArrayList(this.x509Certificates);
        }

        public final String getX509Thumbprint() {
            return this.x509Thumbprint;
        }

        public final String getX509Url() {
            return this.x509Url;
        }

        @Override
        public Header set(String string2, Object object) {
            return (Header)super.set(string2, object);
        }

        public Header setAlgorithm(String string2) {
            this.algorithm = string2;
            return this;
        }

        public Header setCritical(List<String> list) {
            this.critical = new ArrayList(list);
            return this;
        }

        public Header setJwk(String string2) {
            this.jwk = string2;
            return this;
        }

        public Header setJwkUrl(String string2) {
            this.jwkUrl = string2;
            return this;
        }

        public Header setKeyId(String string2) {
            this.keyId = string2;
            return this;
        }

        @Override
        public Header setType(String string2) {
            super.setType(string2);
            return this;
        }

        public Header setX509Certificates(List<String> list) {
            this.x509Certificates = new ArrayList(list);
            return this;
        }

        public Header setX509Thumbprint(String string2) {
            this.x509Thumbprint = string2;
            return this;
        }

        public Header setX509Url(String string2) {
            this.x509Url = string2;
            return this;
        }
    }

}

