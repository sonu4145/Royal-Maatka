/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.atomic.AtomicLong
 */
package com.google.api.client.testing.http;

import com.google.api.client.util.Clock;
import java.util.concurrent.atomic.AtomicLong;

public class FixedClock
implements Clock {
    private AtomicLong currentTime;

    public FixedClock() {
        this(0L);
    }

    public FixedClock(long l) {
        this.currentTime = new AtomicLong(l);
    }

    @Override
    public long currentTimeMillis() {
        return this.currentTime.get();
    }

    public FixedClock setTime(long l) {
        this.currentTime.set(l);
        return this;
    }
}

