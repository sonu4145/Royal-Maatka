/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.OutputStream
 */
package com.google.api.client.util;

import java.io.IOException;
import java.io.OutputStream;

final class ByteCountingOutputStream
extends OutputStream {
    long count;

    ByteCountingOutputStream() {
    }

    public void write(int n) throws IOException {
        this.count = 1L + this.count;
    }

    public void write(byte[] arrby, int n, int n2) throws IOException {
        this.count += (long)n2;
    }
}

