/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.security.GeneralSecurityException
 *  java.security.Key
 *  javax.crypto.Mac
 *  javax.crypto.spec.SecretKeySpec
 */
package com.google.api.client.auth.oauth;

import com.google.api.client.auth.oauth.OAuthParameters;
import com.google.api.client.auth.oauth.OAuthSigner;
import com.google.api.client.util.Base64;
import com.google.api.client.util.StringUtils;
import java.security.GeneralSecurityException;
import java.security.Key;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class OAuthHmacSigner
implements OAuthSigner {
    public String clientSharedSecret;
    public String tokenSharedSecret;

    @Override
    public String computeSignature(String string2) throws GeneralSecurityException {
        StringBuilder stringBuilder = new StringBuilder();
        String string3 = this.clientSharedSecret;
        if (string3 != null) {
            stringBuilder.append(OAuthParameters.escape(string3));
        }
        stringBuilder.append('&');
        String string4 = this.tokenSharedSecret;
        if (string4 != null) {
            stringBuilder.append(OAuthParameters.escape(string4));
        }
        SecretKeySpec secretKeySpec = new SecretKeySpec(StringUtils.getBytesUtf8(stringBuilder.toString()), "HmacSHA1");
        Mac mac = Mac.getInstance((String)"HmacSHA1");
        mac.init((Key)secretKeySpec);
        return Base64.encodeBase64String(mac.doFinal(StringUtils.getBytesUtf8(string2)));
    }

    @Override
    public String getSignatureMethod() {
        return "HMAC-SHA1";
    }
}

