/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 */
package com.google.api.client.auth.oauth2;

import com.google.api.client.http.HttpExecuteInterceptor;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.UrlEncodedContent;
import com.google.api.client.util.Data;
import com.google.api.client.util.Preconditions;
import java.io.IOException;
import java.util.Map;

public class ClientParametersAuthentication
implements HttpRequestInitializer,
HttpExecuteInterceptor {
    private final String clientId;
    private final String clientSecret;

    public ClientParametersAuthentication(String string2, String string3) {
        this.clientId = Preconditions.checkNotNull(string2);
        this.clientSecret = string3;
    }

    public final String getClientId() {
        return this.clientId;
    }

    public final String getClientSecret() {
        return this.clientSecret;
    }

    @Override
    public void initialize(HttpRequest httpRequest) throws IOException {
        httpRequest.setInterceptor(this);
    }

    @Override
    public void intercept(HttpRequest httpRequest) throws IOException {
        Map<String, Object> map = Data.mapOf(UrlEncodedContent.getContent(httpRequest).getData());
        map.put((Object)"client_id", (Object)this.clientId);
        String string2 = this.clientSecret;
        if (string2 != null) {
            map.put((Object)"client_secret", (Object)string2);
        }
    }
}

