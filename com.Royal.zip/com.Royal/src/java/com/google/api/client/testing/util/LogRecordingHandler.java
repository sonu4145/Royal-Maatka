/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.logging.Handler
 *  java.util.logging.LogRecord
 */
package com.google.api.client.testing.util;

import com.google.api.client.util.Lists;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

public class LogRecordingHandler
extends Handler {
    private final List<LogRecord> records = Lists.newArrayList();

    public void close() throws SecurityException {
    }

    public void flush() {
    }

    public List<String> messages() {
        ArrayList arrayList = Lists.newArrayList();
        Iterator iterator = this.records.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((LogRecord)iterator.next()).getMessage());
        }
        return arrayList;
    }

    public void publish(LogRecord logRecord) {
        this.records.add((Object)logRecord);
    }
}

