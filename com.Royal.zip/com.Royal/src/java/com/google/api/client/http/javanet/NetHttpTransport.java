/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.net.HttpURLConnection
 *  java.net.InetSocketAddress
 *  java.net.Proxy
 *  java.net.Proxy$Type
 *  java.net.SocketAddress
 *  java.net.URL
 *  java.security.GeneralSecurityException
 *  java.security.KeyStore
 *  java.util.Arrays
 *  javax.net.ssl.HostnameVerifier
 *  javax.net.ssl.HttpsURLConnection
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLSocketFactory
 */
package com.google.api.client.http.javanet;

import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.LowLevelHttpRequest;
import com.google.api.client.http.javanet.ConnectionFactory;
import com.google.api.client.http.javanet.DefaultConnectionFactory;
import com.google.api.client.http.javanet.NetHttpRequest;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.SecurityUtils;
import com.google.api.client.util.SslUtils;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.Arrays;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;

public final class NetHttpTransport
extends HttpTransport {
    private static final String SHOULD_USE_PROXY_FLAG = "com.google.api.client.should_use_proxy";
    private static final String[] SUPPORTED_METHODS;
    private final ConnectionFactory connectionFactory;
    private final HostnameVerifier hostnameVerifier;
    private final SSLSocketFactory sslSocketFactory;

    static {
        Object[] arrobject = new String[]{"DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT", "TRACE"};
        SUPPORTED_METHODS = arrobject;
        Arrays.sort((Object[])arrobject);
    }

    public NetHttpTransport() {
        this((ConnectionFactory)null, null, null);
    }

    NetHttpTransport(ConnectionFactory connectionFactory, SSLSocketFactory sSLSocketFactory, HostnameVerifier hostnameVerifier) {
        this.connectionFactory = this.getConnectionFactory(connectionFactory);
        this.sslSocketFactory = sSLSocketFactory;
        this.hostnameVerifier = hostnameVerifier;
    }

    NetHttpTransport(Proxy proxy, SSLSocketFactory sSLSocketFactory, HostnameVerifier hostnameVerifier) {
        this(new DefaultConnectionFactory(proxy), sSLSocketFactory, hostnameVerifier);
    }

    private static Proxy defaultProxy() {
        return new Proxy(Proxy.Type.HTTP, (SocketAddress)new InetSocketAddress(System.getProperty((String)"https.proxyHost"), Integer.parseInt((String)System.getProperty((String)"https.proxyPort"))));
    }

    private ConnectionFactory getConnectionFactory(ConnectionFactory connectionFactory) {
        if (connectionFactory == null) {
            if (System.getProperty((String)SHOULD_USE_PROXY_FLAG) != null) {
                return new DefaultConnectionFactory(NetHttpTransport.defaultProxy());
            }
            connectionFactory = new DefaultConnectionFactory();
        }
        return connectionFactory;
    }

    @Override
    protected NetHttpRequest buildRequest(String string2, String string3) throws IOException {
        Preconditions.checkArgument(this.supportsMethod(string2), "HTTP method %s not supported", string2);
        URL uRL = new URL(string3);
        HttpURLConnection httpURLConnection = this.connectionFactory.openConnection(uRL);
        httpURLConnection.setRequestMethod(string2);
        if (httpURLConnection instanceof HttpsURLConnection) {
            SSLSocketFactory sSLSocketFactory;
            HttpsURLConnection httpsURLConnection = (HttpsURLConnection)httpURLConnection;
            HostnameVerifier hostnameVerifier = this.hostnameVerifier;
            if (hostnameVerifier != null) {
                httpsURLConnection.setHostnameVerifier(hostnameVerifier);
            }
            if ((sSLSocketFactory = this.sslSocketFactory) != null) {
                httpsURLConnection.setSSLSocketFactory(sSLSocketFactory);
            }
        }
        return new NetHttpRequest(httpURLConnection);
    }

    @Override
    public boolean supportsMethod(String string2) {
        return Arrays.binarySearch((Object[])SUPPORTED_METHODS, (Object)string2) >= 0;
    }

}

