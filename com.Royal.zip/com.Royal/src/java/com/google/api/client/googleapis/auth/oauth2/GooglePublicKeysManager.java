/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.http.GenericUrl
 *  com.google.api.client.http.HttpHeaders
 *  java.io.ByteArrayInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.security.GeneralSecurityException
 *  java.security.PublicKey
 *  java.security.cert.Certificate
 *  java.security.cert.CertificateFactory
 *  java.security.cert.X509Certificate
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 *  java.util.concurrent.locks.Lock
 *  java.util.concurrent.locks.ReentrantLock
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.google.api.client.googleapis.auth.oauth2;

import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonParser;
import com.google.api.client.json.JsonToken;
import com.google.api.client.util.Clock;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.SecurityUtils;
import com.google.api.client.util.StringUtils;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GooglePublicKeysManager {
    private static final Pattern MAX_AGE_PATTERN = Pattern.compile((String)"\\s*max-age\\s*=\\s*(\\d+)\\s*");
    private static final long REFRESH_SKEW_MILLIS = 300000L;
    private final Clock clock;
    private long expirationTimeMilliseconds;
    private final JsonFactory jsonFactory;
    private final Lock lock = new ReentrantLock();
    private final String publicCertsEncodedUrl;
    private List<PublicKey> publicKeys;
    private final HttpTransport transport;

    protected GooglePublicKeysManager(Builder builder) {
        this.transport = builder.transport;
        this.jsonFactory = builder.jsonFactory;
        this.clock = builder.clock;
        this.publicCertsEncodedUrl = builder.publicCertsEncodedUrl;
    }

    public GooglePublicKeysManager(HttpTransport httpTransport, JsonFactory jsonFactory) {
        this(new Builder(httpTransport, jsonFactory));
    }

    long getCacheTimeInSec(HttpHeaders httpHeaders) {
        long l;
        if (httpHeaders.getCacheControl() != null) {
            for (String string2 : httpHeaders.getCacheControl().split(",")) {
                Matcher matcher = MAX_AGE_PATTERN.matcher((CharSequence)string2);
                if (!matcher.matches()) continue;
                l = Long.parseLong((String)matcher.group(1));
                break;
            }
        } else {
            l = 0L;
        }
        if (httpHeaders.getAge() != null) {
            l -= httpHeaders.getAge().longValue();
        }
        return Math.max((long)0L, (long)l);
    }

    public final Clock getClock() {
        return this.clock;
    }

    public final long getExpirationTimeMilliseconds() {
        return this.expirationTimeMilliseconds;
    }

    public final JsonFactory getJsonFactory() {
        return this.jsonFactory;
    }

    public final String getPublicCertsEncodedUrl() {
        return this.publicCertsEncodedUrl;
    }

    public final List<PublicKey> getPublicKeys() throws GeneralSecurityException, IOException {
        this.lock.lock();
        try {
            if (this.publicKeys == null || 300000L + this.clock.currentTimeMillis() > this.expirationTimeMilliseconds) {
                this.refresh();
            }
            List<PublicKey> list = this.publicKeys;
            return list;
        }
        finally {
            this.lock.unlock();
        }
    }

    public final HttpTransport getTransport() {
        return this.transport;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public GooglePublicKeysManager refresh() throws GeneralSecurityException, IOException {
        this.lock.lock();
        this.publicKeys = new ArrayList();
        CertificateFactory certificateFactory = SecurityUtils.getX509CertificateFactory();
        HttpResponse httpResponse = this.transport.createRequestFactory().buildGetRequest(new GenericUrl(this.publicCertsEncodedUrl)).execute();
        this.expirationTimeMilliseconds = this.clock.currentTimeMillis() + 1000L * this.getCacheTimeInSec(httpResponse.getHeaders());
        JsonParser jsonParser = this.jsonFactory.createJsonParser(httpResponse.getContent());
        JsonToken jsonToken = jsonParser.getCurrentToken();
        if (jsonToken == null) {
            jsonToken = jsonParser.nextToken();
        }
        boolean bl = jsonToken == JsonToken.START_OBJECT;
        Preconditions.checkArgument(bl);
        try {
            while (jsonParser.nextToken() != JsonToken.END_OBJECT) {
                jsonParser.nextToken();
                X509Certificate x509Certificate = (X509Certificate)certificateFactory.generateCertificate((InputStream)new ByteArrayInputStream(StringUtils.getBytesUtf8(jsonParser.getText())));
                this.publicKeys.add((Object)x509Certificate.getPublicKey());
            }
            this.publicKeys = Collections.unmodifiableList(this.publicKeys);
        }
        catch (Throwable throwable) {
            jsonParser.close();
            throw throwable;
        }
        try {
            jsonParser.close();
            return this;
        }
        finally {
            this.lock.unlock();
        }
    }

    public static class Builder {
        Clock clock = Clock.SYSTEM;
        final JsonFactory jsonFactory;
        String publicCertsEncodedUrl = "https://www.googleapis.com/oauth2/v1/certs";
        final HttpTransport transport;

        public Builder(HttpTransport httpTransport, JsonFactory jsonFactory) {
            this.transport = Preconditions.checkNotNull(httpTransport);
            this.jsonFactory = Preconditions.checkNotNull(jsonFactory);
        }

        public GooglePublicKeysManager build() {
            return new GooglePublicKeysManager(this);
        }

        public final Clock getClock() {
            return this.clock;
        }

        public final JsonFactory getJsonFactory() {
            return this.jsonFactory;
        }

        public final String getPublicCertsEncodedUrl() {
            return this.publicCertsEncodedUrl;
        }

        public final HttpTransport getTransport() {
            return this.transport;
        }

        public Builder setClock(Clock clock) {
            this.clock = Preconditions.checkNotNull(clock);
            return this;
        }

        public Builder setPublicCertsEncodedUrl(String string2) {
            this.publicCertsEncodedUrl = Preconditions.checkNotNull(string2);
            return this;
        }
    }

}

