/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.util.Collection
 */
package com.google.api.client.json;

import java.lang.reflect.Field;
import java.util.Collection;

public class CustomizeJsonParser {
    public void handleUnrecognizedKey(Object object, String string2) {
    }

    public Collection<Object> newInstanceForArray(Object object, Field field) {
        return null;
    }

    public Object newInstanceForObject(Object object, Class<?> class_) {
        return null;
    }

    public boolean stopAt(Object object, String string2) {
        return false;
    }
}

