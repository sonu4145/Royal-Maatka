/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.base.StandardSystemProperty
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableSet
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.file.FileSystem
 *  java.nio.file.Files
 *  java.nio.file.LinkOption
 *  java.nio.file.Path
 *  java.nio.file.Paths
 *  java.nio.file.attribute.AclEntry
 *  java.nio.file.attribute.AclEntry$Builder
 *  java.nio.file.attribute.AclEntryPermission
 *  java.nio.file.attribute.AclEntryType
 *  java.nio.file.attribute.AclFileAttributeView
 *  java.nio.file.attribute.UserPrincipal
 *  java.nio.file.attribute.UserPrincipalLookupService
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Set
 *  java.util.logging.Logger
 */
package com.google.api.client.util.store;

import com.google.api.client.util.IOUtils;
import com.google.api.client.util.Maps;
import com.google.api.client.util.store.AbstractDataStoreFactory;
import com.google.api.client.util.store.AbstractMemoryDataStore;
import com.google.api.client.util.store.DataStore;
import com.google.api.client.util.store.DataStoreFactory;
import com.google.common.base.StandardSystemProperty;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.AclEntry;
import java.nio.file.attribute.AclEntryPermission;
import java.nio.file.attribute.AclEntryType;
import java.nio.file.attribute.AclFileAttributeView;
import java.nio.file.attribute.UserPrincipal;
import java.nio.file.attribute.UserPrincipalLookupService;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

public class FileDataStoreFactory
extends AbstractDataStoreFactory {
    private static final boolean IS_WINDOWS;
    private static final Logger LOGGER;
    private final File dataDirectory;

    static {
        LOGGER = Logger.getLogger((String)FileDataStoreFactory.class.getName());
        IS_WINDOWS = StandardSystemProperty.OS_NAME.value().startsWith("WINDOWS");
    }

    public FileDataStoreFactory(File file) throws IOException {
        File file2;
        this.dataDirectory = file2 = file.getCanonicalFile();
        if (!IOUtils.isSymbolicLink(file2)) {
            if (!file2.exists() && !file2.mkdirs()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("unable to create directory: ");
                stringBuilder.append((Object)file2);
                throw new IOException(stringBuilder.toString());
            }
            if (IS_WINDOWS) {
                FileDataStoreFactory.setPermissionsToOwnerOnlyWindows(file2);
                return;
            }
            FileDataStoreFactory.setPermissionsToOwnerOnly(file2);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("unable to use a symbolic link: ");
        stringBuilder.append((Object)file2);
        throw new IOException(stringBuilder.toString());
    }

    /*
     * Exception decompiling
     */
    static void setPermissionsToOwnerOnly(File var0) throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl50 : RETURN : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    static void setPermissionsToOwnerOnlyWindows(File file) throws IOException {
        Path path = Paths.get((String)file.getAbsolutePath(), (String[])new String[0]);
        UserPrincipal userPrincipal = path.getFileSystem().getUserPrincipalLookupService().lookupPrincipalByName("OWNER@");
        AclFileAttributeView aclFileAttributeView = (AclFileAttributeView)Files.getFileAttributeView((Path)path, AclFileAttributeView.class, (LinkOption[])new LinkOption[0]);
        AclEntryPermission aclEntryPermission = AclEntryPermission.APPEND_DATA;
        AclEntryPermission aclEntryPermission2 = AclEntryPermission.DELETE;
        AclEntryPermission aclEntryPermission3 = AclEntryPermission.DELETE_CHILD;
        AclEntryPermission aclEntryPermission4 = AclEntryPermission.READ_ACL;
        AclEntryPermission aclEntryPermission5 = AclEntryPermission.READ_ATTRIBUTES;
        AclEntryPermission aclEntryPermission6 = AclEntryPermission.READ_DATA;
        Object[] arrobject = new AclEntryPermission[]{AclEntryPermission.READ_NAMED_ATTRS, AclEntryPermission.SYNCHRONIZE, AclEntryPermission.WRITE_ACL, AclEntryPermission.WRITE_ATTRIBUTES, AclEntryPermission.WRITE_DATA, AclEntryPermission.WRITE_NAMED_ATTRS, AclEntryPermission.WRITE_OWNER};
        ImmutableSet immutableSet = ImmutableSet.of((Object)aclEntryPermission, (Object)aclEntryPermission2, (Object)aclEntryPermission3, (Object)aclEntryPermission4, (Object)aclEntryPermission5, (Object)aclEntryPermission6, (Object[])arrobject);
        aclFileAttributeView.setAcl((List)ImmutableList.of((Object)AclEntry.newBuilder().setType(AclEntryType.ALLOW).setPrincipal(userPrincipal).setPermissions((Set)immutableSet).build()));
    }

    @Override
    protected <V extends Serializable> DataStore<V> createDataStore(String string2) throws IOException {
        return new FileDataStore(this, this.dataDirectory, string2);
    }

    public final File getDataDirectory() {
        return this.dataDirectory;
    }

    static class FileDataStore<V extends Serializable>
    extends AbstractMemoryDataStore<V> {
        private final File dataFile;

        FileDataStore(FileDataStoreFactory fileDataStoreFactory, File file, String string2) throws IOException {
            File file2;
            super(fileDataStoreFactory, string2);
            this.dataFile = file2 = new File(file, string2);
            if (!IOUtils.isSymbolicLink(file2)) {
                if (this.dataFile.createNewFile()) {
                    this.keyValueMap = Maps.newHashMap();
                    this.save();
                    return;
                }
                this.keyValueMap = (HashMap)IOUtils.deserialize((InputStream)new FileInputStream(this.dataFile));
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("unable to use a symbolic link: ");
            stringBuilder.append((Object)this.dataFile);
            throw new IOException(stringBuilder.toString());
        }

        @Override
        public FileDataStoreFactory getDataStoreFactory() {
            return (FileDataStoreFactory)super.getDataStoreFactory();
        }

        @Override
        public void save() throws IOException {
            IOUtils.serialize((Object)this.keyValueMap, (OutputStream)new FileOutputStream(this.dataFile));
        }
    }

}

