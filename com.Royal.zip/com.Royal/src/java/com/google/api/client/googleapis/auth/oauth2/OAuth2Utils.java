/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.http.GenericUrl
 *  com.google.api.client.http.HttpHeaders
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.SocketTimeoutException
 *  java.nio.charset.Charset
 *  java.util.Collection
 *  java.util.logging.Level
 *  java.util.logging.Logger
 */
package com.google.api.client.googleapis.auth.oauth2;

import com.google.api.client.googleapis.auth.oauth2.SystemEnvironmentProvider;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;

public class OAuth2Utils {
    private static final int COMPUTE_PING_CONNECTION_TIMEOUT_MS = 500;
    private static final String DEFAULT_METADATA_SERVER_URL = "http://169.254.169.254";
    private static final Logger LOGGER;
    private static final int MAX_COMPUTE_PING_TRIES = 3;
    static final Charset UTF_8;

    static {
        UTF_8 = Charset.forName((String)"UTF-8");
        LOGGER = Logger.getLogger((String)OAuth2Utils.class.getName());
    }

    static <T extends Throwable> T exceptionWithCause(T t, Throwable throwable) {
        t.initCause(throwable);
        return t;
    }

    public static String getMetadataServerUrl() {
        return OAuth2Utils.getMetadataServerUrl(SystemEnvironmentProvider.INSTANCE);
    }

    static String getMetadataServerUrl(SystemEnvironmentProvider systemEnvironmentProvider) {
        String string2 = systemEnvironmentProvider.getEnv("GCE_METADATA_HOST");
        if (string2 != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("http://");
            stringBuilder.append(string2);
            return stringBuilder.toString();
        }
        return DEFAULT_METADATA_SERVER_URL;
    }

    static boolean headersContainValue(HttpHeaders httpHeaders, String string2, String string3) {
        Object object = httpHeaders.get((Object)string2);
        if (object instanceof Collection) {
            for (Object object2 : (Collection)object) {
                if (!(object2 instanceof String) || !((String)object2).equals((Object)string3)) continue;
                return true;
            }
        }
        return false;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    static boolean runningOnComputeEngine(HttpTransport httpTransport, SystemEnvironmentProvider systemEnvironmentProvider) {
        if (Boolean.parseBoolean((String)systemEnvironmentProvider.getEnv("NO_GCE_CHECK"))) {
            return false;
        }
        GenericUrl genericUrl = new GenericUrl(OAuth2Utils.getMetadataServerUrl(systemEnvironmentProvider));
        int i = 1;
        while (i <= 3) {
            HttpRequest httpRequest = httpTransport.createRequestFactory().buildGetRequest(genericUrl);
            httpRequest.setConnectTimeout(500);
            httpRequest.getHeaders().set("Metadata-Flavor", (Object)"Google");
            HttpResponse httpResponse = httpRequest.execute();
            boolean bl = OAuth2Utils.headersContainValue(httpResponse.getHeaders(), "Metadata-Flavor", "Google");
            {
                catch (Throwable throwable) {
                    httpResponse.disconnect();
                    throw throwable;
                }
            }
            try {
                httpResponse.disconnect();
                return bl;
            }
            catch (IOException iOException) {
                LOGGER.log(Level.WARNING, "Failed to detect whether we are running on Google Compute Engine.", (Throwable)iOException);
            }
            catch (SocketTimeoutException socketTimeoutException) {}
            ++i;
        }
        return false;
    }
}

