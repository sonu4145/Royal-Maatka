/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.auth.oauth2.BearerToken$AuthorizationHeaderAccessMethod
 *  com.google.api.client.auth.oauth2.BearerToken$FormEncodedBodyAccessMethod
 *  com.google.api.client.auth.oauth2.BearerToken$QueryParameterAccessMethod
 *  com.google.api.client.auth.oauth2.Credential
 *  java.lang.Object
 *  java.lang.String
 *  java.util.regex.Pattern
 */
package com.google.api.client.auth.oauth2;

import com.google.api.client.auth.oauth2.BearerToken;
import com.google.api.client.auth.oauth2.Credential;
import java.util.regex.Pattern;

/*
 * Exception performing whole class analysis.
 */
public class BearerToken {
    static final Pattern INVALID_TOKEN_ERROR;
    static final String PARAM_NAME = "access_token";

    static {
        INVALID_TOKEN_ERROR = Pattern.compile((String)"\\s*error\\s*=\\s*\"?invalid_token\"?");
    }

    public static Credential.AccessMethod authorizationHeaderAccessMethod() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public static Credential.AccessMethod formEncodedBodyAccessMethod() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public static Credential.AccessMethod queryParameterAccessMethod() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }
}

