/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api.client.http;

import com.google.api.client.http.HttpContent;
import java.io.IOException;
import java.io.OutputStream;

public class EmptyContent
implements HttpContent {
    @Override
    public long getLength() throws IOException {
        return 0L;
    }

    @Override
    public String getType() {
        return null;
    }

    @Override
    public boolean retrySupported() {
        return true;
    }

    @Override
    public void writeTo(OutputStream outputStream) throws IOException {
        outputStream.flush();
    }
}

