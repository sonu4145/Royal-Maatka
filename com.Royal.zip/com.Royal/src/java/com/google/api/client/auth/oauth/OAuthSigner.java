/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.security.GeneralSecurityException
 */
package com.google.api.client.auth.oauth;

import java.security.GeneralSecurityException;

public interface OAuthSigner {
    public String computeSignature(String var1) throws GeneralSecurityException;

    public String getSignatureMethod();
}

