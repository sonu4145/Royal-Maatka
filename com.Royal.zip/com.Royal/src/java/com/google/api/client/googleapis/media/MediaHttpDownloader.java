/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.http.GenericUrl
 *  com.google.api.client.http.HttpHeaders
 *  com.google.common.base.MoreObjects
 *  com.google.common.io.ByteStreams
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Map
 */
package com.google.api.client.googleapis.media;

import com.google.api.client.googleapis.media.MediaHttpDownloaderProgressListener;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.util.Preconditions;
import com.google.common.base.MoreObjects;
import com.google.common.io.ByteStreams;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

public final class MediaHttpDownloader {
    public static final int MAXIMUM_CHUNK_SIZE = 33554432;
    private long bytesDownloaded;
    private int chunkSize = 33554432;
    private boolean directDownloadEnabled = false;
    private DownloadState downloadState = DownloadState.NOT_STARTED;
    private long lastBytePos = -1L;
    private long mediaContentLength;
    private MediaHttpDownloaderProgressListener progressListener;
    private final HttpRequestFactory requestFactory;
    private final HttpTransport transport;

    public MediaHttpDownloader(HttpTransport httpTransport, HttpRequestInitializer httpRequestInitializer) {
        this.transport = Preconditions.checkNotNull(httpTransport);
        HttpRequestFactory httpRequestFactory = httpRequestInitializer == null ? httpTransport.createRequestFactory() : httpTransport.createRequestFactory(httpRequestInitializer);
        this.requestFactory = httpRequestFactory;
    }

    private HttpResponse executeCurrentRequest(long l, GenericUrl genericUrl, HttpHeaders httpHeaders, OutputStream outputStream) throws IOException {
        HttpRequest httpRequest = this.requestFactory.buildGetRequest(genericUrl);
        if (httpHeaders != null) {
            httpRequest.getHeaders().putAll((Map)httpHeaders);
        }
        if (this.bytesDownloaded != 0L || l != -1L) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("bytes=");
            stringBuilder.append(this.bytesDownloaded);
            stringBuilder.append("-");
            if (l != -1L) {
                stringBuilder.append(l);
            }
            httpRequest.getHeaders().setRange(stringBuilder.toString());
        }
        HttpResponse httpResponse = httpRequest.execute();
        try {
            ByteStreams.copy((InputStream)httpResponse.getContent(), (OutputStream)outputStream);
            return httpResponse;
        }
        finally {
            httpResponse.disconnect();
        }
    }

    private long getNextByteIndex(String string2) {
        if (string2 == null) {
            return 0L;
        }
        return 1L + Long.parseLong((String)string2.substring(1 + string2.indexOf(45), string2.indexOf(47)));
    }

    private void setMediaContentLength(String string2) {
        if (string2 == null) {
            return;
        }
        if (this.mediaContentLength == 0L) {
            this.mediaContentLength = Long.parseLong((String)string2.substring(1 + string2.indexOf(47)));
        }
    }

    private void updateStateAndNotifyListener(DownloadState downloadState) throws IOException {
        this.downloadState = downloadState;
        MediaHttpDownloaderProgressListener mediaHttpDownloaderProgressListener = this.progressListener;
        if (mediaHttpDownloaderProgressListener != null) {
            mediaHttpDownloaderProgressListener.progressChanged(this);
        }
    }

    public void download(GenericUrl genericUrl, HttpHeaders httpHeaders, OutputStream outputStream) throws IOException {
        boolean bl = this.downloadState == DownloadState.NOT_STARTED;
        Preconditions.checkArgument(bl);
        genericUrl.put("alt", (Object)"media");
        if (this.directDownloadEnabled) {
            long l;
            this.updateStateAndNotifyListener(DownloadState.MEDIA_IN_PROGRESS);
            this.mediaContentLength = l = ((Long)MoreObjects.firstNonNull((Object)this.executeCurrentRequest(this.lastBytePos, genericUrl, httpHeaders, outputStream).getHeaders().getContentLength(), (Object)this.mediaContentLength)).longValue();
            this.bytesDownloaded = l;
            this.updateStateAndNotifyListener(DownloadState.MEDIA_COMPLETE);
            return;
        }
        do {
            long l = this.bytesDownloaded + (long)this.chunkSize - 1L;
            long l2 = this.lastBytePos;
            if (l2 != -1L) {
                l = Math.min((long)l2, (long)l);
            }
            String string2 = this.executeCurrentRequest(l, genericUrl, httpHeaders, outputStream).getHeaders().getContentRange();
            long l3 = this.getNextByteIndex(string2);
            this.setMediaContentLength(string2);
            long l4 = this.lastBytePos;
            if (l4 != -1L && l4 <= l3) {
                this.bytesDownloaded = l4;
                this.updateStateAndNotifyListener(DownloadState.MEDIA_COMPLETE);
                return;
            }
            long l5 = this.mediaContentLength;
            if (l5 <= l3) {
                this.bytesDownloaded = l5;
                this.updateStateAndNotifyListener(DownloadState.MEDIA_COMPLETE);
                return;
            }
            this.bytesDownloaded = l3;
            this.updateStateAndNotifyListener(DownloadState.MEDIA_IN_PROGRESS);
        } while (true);
    }

    public void download(GenericUrl genericUrl, OutputStream outputStream) throws IOException {
        this.download(genericUrl, null, outputStream);
    }

    public int getChunkSize() {
        return this.chunkSize;
    }

    public DownloadState getDownloadState() {
        return this.downloadState;
    }

    public long getLastBytePosition() {
        return this.lastBytePos;
    }

    public long getNumBytesDownloaded() {
        return this.bytesDownloaded;
    }

    public double getProgress() {
        long l = this.mediaContentLength;
        if (l == 0L) {
            return 0.0;
        }
        double d = this.bytesDownloaded;
        double d2 = l;
        Double.isNaN((double)d);
        Double.isNaN((double)d2);
        return d / d2;
    }

    public MediaHttpDownloaderProgressListener getProgressListener() {
        return this.progressListener;
    }

    public HttpTransport getTransport() {
        return this.transport;
    }

    public boolean isDirectDownloadEnabled() {
        return this.directDownloadEnabled;
    }

    public MediaHttpDownloader setBytesDownloaded(long l) {
        boolean bl = l >= 0L;
        Preconditions.checkArgument(bl);
        this.bytesDownloaded = l;
        return this;
    }

    public MediaHttpDownloader setChunkSize(int n) {
        boolean bl = n > 0 && n <= 33554432;
        Preconditions.checkArgument(bl);
        this.chunkSize = n;
        return this;
    }

    @Deprecated
    public MediaHttpDownloader setContentRange(long l, int n) {
        return this.setContentRange(l, (long)n);
    }

    public MediaHttpDownloader setContentRange(long l, long l2) {
        boolean bl = l2 >= l;
        Preconditions.checkArgument(bl);
        this.setBytesDownloaded(l);
        this.lastBytePos = l2;
        return this;
    }

    public MediaHttpDownloader setDirectDownloadEnabled(boolean bl) {
        this.directDownloadEnabled = bl;
        return this;
    }

    public MediaHttpDownloader setProgressListener(MediaHttpDownloaderProgressListener mediaHttpDownloaderProgressListener) {
        this.progressListener = mediaHttpDownloaderProgressListener;
        return this;
    }

    public static final class DownloadState
    extends Enum<DownloadState> {
        private static final /* synthetic */ DownloadState[] $VALUES;
        public static final /* enum */ DownloadState MEDIA_COMPLETE;
        public static final /* enum */ DownloadState MEDIA_IN_PROGRESS;
        public static final /* enum */ DownloadState NOT_STARTED;

        static {
            DownloadState downloadState;
            NOT_STARTED = new DownloadState();
            MEDIA_IN_PROGRESS = new DownloadState();
            MEDIA_COMPLETE = downloadState = new DownloadState();
            DownloadState[] arrdownloadState = new DownloadState[]{NOT_STARTED, MEDIA_IN_PROGRESS, downloadState};
            $VALUES = arrdownloadState;
        }

        public static DownloadState valueOf(String string2) {
            return (DownloadState)Enum.valueOf(DownloadState.class, (String)string2);
        }

        public static DownloadState[] values() {
            return (DownloadState[])$VALUES.clone();
        }
    }

}

