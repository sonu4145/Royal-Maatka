/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.googleapis.json.GoogleJsonResponseException
 *  com.google.api.client.http.GenericUrl
 *  com.google.api.client.testing.http.MockHttpTransport
 *  com.google.api.client.testing.http.MockLowLevelHttpResponse
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.google.api.client.googleapis.testing.json;

import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.testing.http.HttpTesting;
import com.google.api.client.testing.http.MockHttpTransport;
import com.google.api.client.testing.http.MockLowLevelHttpResponse;
import java.io.IOException;

public final class GoogleJsonResponseExceptionFactoryTesting {
    public static GoogleJsonResponseException newMock(JsonFactory jsonFactory, int n, String string2) throws IOException {
        MockLowLevelHttpResponse mockLowLevelHttpResponse = new MockLowLevelHttpResponse().setStatusCode(n).setReasonPhrase(string2).setContentType("application/json; charset=UTF-8");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("{ \"error\": { \"errors\": [ { \"reason\": \"");
        stringBuilder.append(string2);
        stringBuilder.append("\" } ], \"code\": ");
        stringBuilder.append(n);
        stringBuilder.append(" } }");
        MockLowLevelHttpResponse mockLowLevelHttpResponse2 = mockLowLevelHttpResponse.setContent(stringBuilder.toString());
        HttpRequest httpRequest = new MockHttpTransport.Builder().setLowLevelHttpResponse(mockLowLevelHttpResponse2).build().createRequestFactory().buildGetRequest(HttpTesting.SIMPLE_GENERIC_URL);
        httpRequest.setThrowExceptionOnExecuteError(false);
        return GoogleJsonResponseException.from((JsonFactory)jsonFactory, (HttpResponse)httpRequest.execute());
    }
}

