/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.googleapis.services.AbstractGoogleClientRequest
 *  java.io.IOException
 *  java.lang.Object
 */
package com.google.api.client.googleapis.services;

import com.google.api.client.googleapis.services.AbstractGoogleClientRequest;
import java.io.IOException;

public interface GoogleClientRequestInitializer {
    public void initialize(AbstractGoogleClientRequest<?> var1) throws IOException;
}

