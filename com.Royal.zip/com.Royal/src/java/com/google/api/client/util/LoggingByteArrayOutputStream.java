/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.NumberFormat
 *  java.util.logging.Level
 *  java.util.logging.Logger
 */
package com.google.api.client.util;

import com.google.api.client.util.Preconditions;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggingByteArrayOutputStream
extends ByteArrayOutputStream {
    private int bytesWritten;
    private boolean closed;
    private final Logger logger;
    private final Level loggingLevel;
    private final int maximumBytesToLog;

    public LoggingByteArrayOutputStream(Logger logger, Level level, int n) {
        this.logger = Preconditions.checkNotNull(logger);
        this.loggingLevel = Preconditions.checkNotNull(level);
        boolean bl = n >= 0;
        Preconditions.checkArgument(bl);
        this.maximumBytesToLog = n;
    }

    private static void appendBytes(StringBuilder stringBuilder, int n) {
        if (n == 1) {
            stringBuilder.append("1 byte");
            return;
        }
        stringBuilder.append(NumberFormat.getInstance().format((long)n));
        stringBuilder.append(" bytes");
    }

    public void close() throws IOException {
        LoggingByteArrayOutputStream loggingByteArrayOutputStream = this;
        synchronized (loggingByteArrayOutputStream) {
            if (!this.closed) {
                if (this.bytesWritten != 0) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Total: ");
                    LoggingByteArrayOutputStream.appendBytes(stringBuilder, this.bytesWritten);
                    if (this.count != 0 && this.count < this.bytesWritten) {
                        stringBuilder.append(" (logging first ");
                        LoggingByteArrayOutputStream.appendBytes(stringBuilder, this.count);
                        stringBuilder.append(")");
                    }
                    this.logger.config(stringBuilder.toString());
                    if (this.count != 0) {
                        this.logger.log(this.loggingLevel, this.toString("UTF-8").replaceAll("[\\x00-\\x09\\x0B\\x0C\\x0E-\\x1F\\x7F]", " "));
                    }
                }
                this.closed = true;
            }
            return;
        }
    }

    public final int getBytesWritten() {
        LoggingByteArrayOutputStream loggingByteArrayOutputStream = this;
        synchronized (loggingByteArrayOutputStream) {
            int n = this.bytesWritten;
            return n;
        }
    }

    public final int getMaximumBytesToLog() {
        return this.maximumBytesToLog;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void write(int n) {
        LoggingByteArrayOutputStream loggingByteArrayOutputStream = this;
        synchronized (loggingByteArrayOutputStream) {
            boolean bl = !this.closed;
            Preconditions.checkArgument(bl);
            this.bytesWritten = 1 + this.bytesWritten;
            if (this.count < this.maximumBytesToLog) {
                super.write(n);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void write(byte[] arrby, int n, int n2) {
        LoggingByteArrayOutputStream loggingByteArrayOutputStream = this;
        synchronized (loggingByteArrayOutputStream) {
            boolean bl = !this.closed;
            Preconditions.checkArgument(bl);
            this.bytesWritten = n2 + this.bytesWritten;
            if (this.count < this.maximumBytesToLog) {
                int n3 = n2 + this.count;
                if (n3 > this.maximumBytesToLog) {
                    n2 += this.maximumBytesToLog - n3;
                }
                super.write(arrby, n, n2);
            }
            return;
        }
    }
}

