/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.google.api.client.googleapis.auth.oauth2;

class SystemEnvironmentProvider {
    static final SystemEnvironmentProvider INSTANCE = new SystemEnvironmentProvider();

    SystemEnvironmentProvider() {
    }

    String getEnv(String string2) {
        return System.getenv((String)string2);
    }

    boolean getEnvEquals(String string2, String string3) {
        return System.getenv().containsKey((Object)string2) && System.getenv((String)string2).equals((Object)string3);
    }
}

