/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Preconditions
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api.client.util;

public final class Preconditions {
    private Preconditions() {
    }

    public static void checkArgument(boolean bl) {
        com.google.common.base.Preconditions.checkArgument((boolean)bl);
    }

    public static void checkArgument(boolean bl, Object object) {
        com.google.common.base.Preconditions.checkArgument((boolean)bl, (Object)object);
    }

    public static /* varargs */ void checkArgument(boolean bl, String string2, Object ... arrobject) {
        com.google.common.base.Preconditions.checkArgument((boolean)bl, (String)string2, (Object[])arrobject);
    }

    public static <T> T checkNotNull(T t) {
        return (T)com.google.common.base.Preconditions.checkNotNull(t);
    }

    public static <T> T checkNotNull(T t, Object object) {
        return (T)com.google.common.base.Preconditions.checkNotNull(t, (Object)object);
    }

    public static /* varargs */ <T> T checkNotNull(T t, String string2, Object ... arrobject) {
        return (T)com.google.common.base.Preconditions.checkNotNull(t, (String)string2, (Object[])arrobject);
    }

    public static void checkState(boolean bl) {
        com.google.common.base.Preconditions.checkState((boolean)bl);
    }

    public static void checkState(boolean bl, Object object) {
        com.google.common.base.Preconditions.checkState((boolean)bl, (Object)object);
    }

    public static /* varargs */ void checkState(boolean bl, String string2, Object ... arrobject) {
        com.google.common.base.Preconditions.checkState((boolean)bl, (String)string2, (Object[])arrobject);
    }
}

