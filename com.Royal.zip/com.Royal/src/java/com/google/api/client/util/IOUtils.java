/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.OutputStream
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 */
package com.google.api.client.util;

import com.google.api.client.util.ByteCountingOutputStream;
import com.google.api.client.util.ByteStreams;
import com.google.api.client.util.StreamingContent;
import com.google.api.client.util.Throwables;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class IOUtils {
    public static long computeLength(StreamingContent streamingContent) throws IOException {
        ByteCountingOutputStream byteCountingOutputStream = new ByteCountingOutputStream();
        try {
            streamingContent.writeTo(byteCountingOutputStream);
            return byteCountingOutputStream.count;
        }
        finally {
            byteCountingOutputStream.close();
        }
    }

    public static void copy(InputStream inputStream, OutputStream outputStream) throws IOException {
        IOUtils.copy(inputStream, outputStream, true);
    }

    public static void copy(InputStream inputStream, OutputStream outputStream, boolean bl) throws IOException {
        try {
            ByteStreams.copy(inputStream, outputStream);
            return;
        }
        finally {
            if (bl) {
                inputStream.close();
            }
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static <S extends Serializable> S deserialize(InputStream inputStream) throws IOException {
        Throwable throwable2222;
        Serializable serializable = (Serializable)new ObjectInputStream(inputStream).readObject();
        inputStream.close();
        return (S)serializable;
        {
            catch (Throwable throwable2222) {
            }
            catch (ClassNotFoundException classNotFoundException) {}
            {
                IOException iOException = new IOException("Failed to deserialize object");
                iOException.initCause((Throwable)classNotFoundException);
                throw iOException;
            }
        }
        inputStream.close();
        throw throwable2222;
    }

    public static <S extends Serializable> S deserialize(byte[] arrby) throws IOException {
        if (arrby == null) {
            return null;
        }
        return IOUtils.deserialize((InputStream)new ByteArrayInputStream(arrby));
    }

    public static boolean isSymbolicLink(File file) throws IOException {
        try {
            Class class_ = Class.forName((String)"java.nio.file.Files");
            Class class_2 = Class.forName((String)"java.nio.file.Path");
            Object object = File.class.getMethod("toPath", new Class[0]).invoke((Object)file, new Object[0]);
            boolean bl = (Boolean)class_.getMethod("isSymbolicLink", new Class[]{class_2}).invoke(null, new Object[]{object});
            return bl;
        }
        catch (ClassNotFoundException | IllegalAccessException | IllegalArgumentException | NoSuchMethodException | SecurityException throwable) {
            if (File.separatorChar == '\\') {
                return false;
            }
            if (file.getParent() != null) {
                file = new File(file.getParentFile().getCanonicalFile(), file.getName());
            }
            return true ^ file.getCanonicalFile().equals((Object)file.getAbsoluteFile());
        }
        catch (InvocationTargetException invocationTargetException) {
            Throwable throwable = invocationTargetException.getCause();
            Throwables.propagateIfPossible(throwable, IOException.class);
            throw new RuntimeException(throwable);
        }
    }

    public static void serialize(Object object, OutputStream outputStream) throws IOException {
        try {
            new ObjectOutputStream(outputStream).writeObject(object);
            return;
        }
        finally {
            outputStream.close();
        }
    }

    public static byte[] serialize(Object object) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        IOUtils.serialize(object, (OutputStream)byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
}

