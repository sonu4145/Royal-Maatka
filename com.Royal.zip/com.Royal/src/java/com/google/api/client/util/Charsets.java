/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 */
package com.google.api.client.util;

import java.nio.charset.Charset;

public final class Charsets {
    public static final Charset ISO_8859_1;
    public static final Charset UTF_8;

    static {
        UTF_8 = Charset.forName((String)"UTF-8");
        ISO_8859_1 = Charset.forName((String)"ISO-8859-1");
    }

    private Charsets() {
    }
}

