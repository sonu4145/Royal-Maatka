/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.net.HttpURLConnection
 *  java.net.Proxy
 *  java.net.URL
 *  java.net.URLConnection
 */
package com.google.api.client.http.javanet;

import com.google.api.client.http.javanet.ConnectionFactory;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;

public class DefaultConnectionFactory
implements ConnectionFactory {
    private final Proxy proxy;

    public DefaultConnectionFactory() {
        this(null);
    }

    public DefaultConnectionFactory(Proxy proxy) {
        this.proxy = proxy;
    }

    @Override
    public HttpURLConnection openConnection(URL uRL) throws IOException {
        Proxy proxy = this.proxy;
        URLConnection uRLConnection = proxy == null ? uRL.openConnection() : uRL.openConnection(proxy);
        return (HttpURLConnection)uRLConnection;
    }
}

