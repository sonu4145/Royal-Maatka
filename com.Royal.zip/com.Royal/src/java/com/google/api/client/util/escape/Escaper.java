/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api.client.util.escape;

public abstract class Escaper {
    public abstract String escape(String var1);
}

