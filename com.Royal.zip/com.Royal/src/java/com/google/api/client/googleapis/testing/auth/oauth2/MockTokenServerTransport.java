/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.logging.Logger
 */
package com.google.api.client.googleapis.testing.auth.oauth2;

import com.google.api.client.googleapis.testing.TestUtils;
import com.google.api.client.http.LowLevelHttpRequest;
import com.google.api.client.http.LowLevelHttpResponse;
import com.google.api.client.json.GenericJson;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.json.webtoken.JsonWebSignature;
import com.google.api.client.json.webtoken.JsonWebToken;
import com.google.api.client.testing.http.MockHttpTransport;
import com.google.api.client.testing.http.MockLowLevelHttpRequest;
import com.google.api.client.testing.http.MockLowLevelHttpResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class MockTokenServerTransport
extends MockHttpTransport {
    static final String EXPECTED_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:jwt-bearer";
    static final JsonFactory JSON_FACTORY;
    private static final String LEGACY_TOKEN_SERVER_URL = "https://accounts.google.com/o/oauth2/token";
    private static final Logger LOGGER;
    Map<String, String> clients = new HashMap();
    Map<String, String> refreshTokens = new HashMap();
    Map<String, String> serviceAccounts = new HashMap();
    final String tokenServerUrl;

    static {
        LOGGER = Logger.getLogger((String)MockTokenServerTransport.class.getName());
        JSON_FACTORY = new JacksonFactory();
    }

    public MockTokenServerTransport() {
        this("https://oauth2.googleapis.com/token");
    }

    public MockTokenServerTransport(String string2) {
        this.tokenServerUrl = string2;
    }

    private MockLowLevelHttpRequest buildTokenRequest(String string2) {
        return new MockLowLevelHttpRequest(string2){

            @Override
            public LowLevelHttpResponse execute() throws IOException {
                block7 : {
                    block8 : {
                        block9 : {
                            block10 : {
                                String string2;
                                block6 : {
                                    Map<String, String> map;
                                    block2 : {
                                        block3 : {
                                            block4 : {
                                                block5 : {
                                                    map = TestUtils.parseQuery(this.getContentAsString());
                                                    String string3 = (String)map.get((Object)"client_id");
                                                    if (string3 == null) break block2;
                                                    if (!MockTokenServerTransport.this.clients.containsKey((Object)string3)) break block3;
                                                    String string4 = (String)map.get((Object)"client_secret");
                                                    String string5 = (String)MockTokenServerTransport.this.clients.get((Object)string3);
                                                    if (string4 == null || !string4.equals((Object)string5)) break block4;
                                                    String string6 = (String)map.get((Object)"refresh_token");
                                                    if (!MockTokenServerTransport.this.refreshTokens.containsKey((Object)string6)) break block5;
                                                    string2 = (String)MockTokenServerTransport.this.refreshTokens.get((Object)string6);
                                                    break block6;
                                                }
                                                throw new IOException("Refresh Token not found.");
                                            }
                                            throw new IOException("Client secret not found.");
                                        }
                                        throw new IOException("Client ID not found.");
                                    }
                                    if (!map.containsKey((Object)"grant_type")) break block7;
                                    if (!MockTokenServerTransport.EXPECTED_GRANT_TYPE.equals((Object)((String)map.get((Object)"grant_type")))) break block8;
                                    String string7 = (String)map.get((Object)"assertion");
                                    JsonWebSignature jsonWebSignature = JsonWebSignature.parse(MockTokenServerTransport.JSON_FACTORY, string7);
                                    String string8 = jsonWebSignature.getPayload().getIssuer();
                                    if (!MockTokenServerTransport.this.serviceAccounts.containsKey((Object)string8)) break block9;
                                    String string9 = (String)MockTokenServerTransport.this.serviceAccounts.get((Object)string8);
                                    String string10 = (String)jsonWebSignature.getPayload().get("scope");
                                    if (string10 == null || string10.length() == 0) break block10;
                                    string2 = string9;
                                }
                                GenericJson genericJson = new GenericJson();
                                genericJson.setFactory(MockTokenServerTransport.JSON_FACTORY);
                                genericJson.put("access_token", (Object)string2);
                                genericJson.put("expires_in", (Object)3600);
                                genericJson.put("token_type", (Object)"Bearer");
                                String string11 = genericJson.toPrettyString();
                                return new MockLowLevelHttpResponse().setContentType("application/json; charset=UTF-8").setContent(string11);
                            }
                            throw new IOException("Scopes not found.");
                        }
                        throw new IOException("Service Account Email not found as issuer.");
                    }
                    throw new IOException("Unexpected Grant Type.");
                }
                throw new IOException("Unknown token type.");
            }
        };
    }

    public void addClient(String string2, String string3) {
        this.clients.put((Object)string2, (Object)string3);
    }

    public void addRefreshToken(String string2, String string3) {
        this.refreshTokens.put((Object)string2, (Object)string3);
    }

    public void addServiceAccount(String string2, String string3) {
        this.serviceAccounts.put((Object)string2, (Object)string3);
    }

    @Override
    public LowLevelHttpRequest buildRequest(String string2, String string3) throws IOException {
        if (string3.equals((Object)this.tokenServerUrl)) {
            return this.buildTokenRequest(string3);
        }
        if (string3.equals((Object)LEGACY_TOKEN_SERVER_URL)) {
            LOGGER.warning("Your configured token_uri is using a legacy endpoint. You may want to redownload your credentials.");
            return this.buildTokenRequest(string3);
        }
        return super.buildRequest(string2, string3);
    }

}

