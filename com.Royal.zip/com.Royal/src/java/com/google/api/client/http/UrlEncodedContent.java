/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedWriter
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Writer
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.google.api.client.http;

import com.google.api.client.http.AbstractHttpContent;
import com.google.api.client.http.HttpContent;
import com.google.api.client.http.HttpMediaType;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.UrlEncodedParser;
import com.google.api.client.util.Data;
import com.google.api.client.util.FieldInfo;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Types;
import com.google.api.client.util.escape.CharEscapers;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class UrlEncodedContent
extends AbstractHttpContent {
    private Object data;

    public UrlEncodedContent(Object object) {
        super(UrlEncodedParser.MEDIA_TYPE);
        this.setData(object);
    }

    private static boolean appendParam(boolean bl, Writer writer, String string2, Object object) throws IOException {
        if (object != null) {
            if (Data.isNull(object)) {
                return bl;
            }
            if (bl) {
                bl = false;
            } else {
                writer.write("&");
            }
            writer.write(string2);
            String string3 = object instanceof Enum ? FieldInfo.of((Enum)object).getName() : object.toString();
            String string4 = CharEscapers.escapeUri(string3);
            if (string4.length() != 0) {
                writer.write("=");
                writer.write(string4);
            }
        }
        return bl;
    }

    public static UrlEncodedContent getContent(HttpRequest httpRequest) {
        HttpContent httpContent = httpRequest.getContent();
        if (httpContent != null) {
            return (UrlEncodedContent)httpContent;
        }
        UrlEncodedContent urlEncodedContent = new UrlEncodedContent((Object)new HashMap());
        httpRequest.setContent(urlEncodedContent);
        return urlEncodedContent;
    }

    public final Object getData() {
        return this.data;
    }

    public UrlEncodedContent setData(Object object) {
        this.data = Preconditions.checkNotNull(object);
        return this;
    }

    @Override
    public UrlEncodedContent setMediaType(HttpMediaType httpMediaType) {
        super.setMediaType(httpMediaType);
        return this;
    }

    @Override
    public void writeTo(OutputStream outputStream) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter((Writer)new OutputStreamWriter(outputStream, this.getCharset()));
        Iterator iterator = Data.mapOf(this.data).entrySet().iterator();
        boolean bl = true;
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            Object object = entry.getValue();
            if (object == null) continue;
            String string2 = CharEscapers.escapeUri((String)entry.getKey());
            Class class_ = object.getClass();
            if (!(object instanceof Iterable) && !class_.isArray()) {
                bl = UrlEncodedContent.appendParam(bl, (Writer)bufferedWriter, string2, object);
                continue;
            }
            Iterator iterator2 = Types.iterableOf(object).iterator();
            while (iterator2.hasNext()) {
                bl = UrlEncodedContent.appendParam(bl, (Writer)bufferedWriter, string2, iterator2.next());
            }
        }
        bufferedWriter.flush();
    }
}

