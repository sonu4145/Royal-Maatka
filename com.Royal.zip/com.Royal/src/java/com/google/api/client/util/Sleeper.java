/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.util.Sleeper$1
 *  java.lang.InterruptedException
 *  java.lang.Object
 */
package com.google.api.client.util;

import com.google.api.client.util.Sleeper;

public interface Sleeper {
    public static final Sleeper DEFAULT = new 1();

    public void sleep(long var1) throws InterruptedException;
}

