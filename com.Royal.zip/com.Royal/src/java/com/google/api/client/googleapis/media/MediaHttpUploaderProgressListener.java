/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package com.google.api.client.googleapis.media;

import com.google.api.client.googleapis.media.MediaHttpUploader;
import java.io.IOException;

public interface MediaHttpUploaderProgressListener {
    public void progressChanged(MediaHttpUploader var1) throws IOException;
}

