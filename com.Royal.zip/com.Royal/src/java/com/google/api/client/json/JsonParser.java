/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.json.GenericJson
 *  java.io.Closeable
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Field
 *  java.lang.reflect.Type
 *  java.math.BigDecimal
 *  java.math.BigInteger
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Set
 *  java.util.WeakHashMap
 *  java.util.concurrent.locks.Lock
 *  java.util.concurrent.locks.ReentrantLock
 */
package com.google.api.client.json;

import com.google.api.client.json.CustomizeJsonParser;
import com.google.api.client.json.GenericJson;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonPolymorphicTypeMap;
import com.google.api.client.json.JsonToken;
import com.google.api.client.util.ClassInfo;
import com.google.api.client.util.Data;
import com.google.api.client.util.FieldInfo;
import com.google.api.client.util.GenericData;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Sets;
import com.google.api.client.util.Types;
import java.io.Closeable;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public abstract class JsonParser
implements Closeable {
    private static WeakHashMap<Class<?>, Field> cachedTypemapFields = new WeakHashMap();
    private static final Lock lock = new ReentrantLock();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Field getCachedTypemapFieldFor(Class<?> var0) {
        block8 : {
            var1_1 = null;
            if (var0 == null) {
                return null;
            }
            JsonParser.lock.lock();
            if (!JsonParser.cachedTypemapFields.containsKey(var0)) break block8;
            var18_2 = (Field)JsonParser.cachedTypemapFields.get(var0);
            JsonParser.lock.unlock();
            return var18_2;
        }
        var3_3 = ClassInfo.of(var0).getFieldInfos().iterator();
lbl13: // 2 sources:
        do {
            if (!var3_3.hasNext()) ** break block9
            var5_4 = ((FieldInfo)var3_3.next()).getField();
            var6_5 = (JsonPolymorphicTypeMap)var5_4.getAnnotation(JsonPolymorphicTypeMap.class);
            if (var6_5 == null) continue;
            var7_6 = var1_1 == null;
            Preconditions.checkArgument(var7_6, "Class contains more than one field with @JsonPolymorphicTypeMap annotation: %s", new Object[]{var0});
            var8_7 = Data.isPrimitive((Type)var5_4.getType());
            var9_8 = new Object[]{var0, var5_4.getType()};
            Preconditions.checkArgument(var8_7, "Field which has the @JsonPolymorphicTypeMap, %s, is not a supported type: %s", var9_8);
            var10_9 = var6_5.typeDefinitions();
            var11_10 = Sets.newHashSet();
            var12_11 = var10_9.length > 0;
            Preconditions.checkArgument(var12_11, "@JsonPolymorphicTypeMap must have at least one @TypeDef");
            var13_12 = var10_9.length;
            break;
        } while (true);
        {
            
            JsonParser.cachedTypemapFields.put(var0, var1_1);
            return var1_1;
        }
        finally {
            JsonParser.lock.unlock();
        }
        for (var14_13 = 0; var14_13 < var13_12; ++var14_13) {
            var15_14 = var10_9[var14_13];
            var16_15 = var11_10.add((Object)var15_14.key());
            var17_16 = new Object[]{var15_14.key()};
            Preconditions.checkArgument(var16_15, "Class contains two @TypeDef annotations with identical key: %s", var17_16);
        }
        var1_1 = var5_4;
        ** while (true)
    }

    private void parse(ArrayList<Type> arrayList, Object object, CustomizeJsonParser customizeJsonParser) throws IOException {
        if (object instanceof GenericJson) {
            ((GenericJson)object).setFactory(this.getFactory());
        }
        JsonToken jsonToken = this.startParsingObjectOrArray();
        Class class_ = object.getClass();
        ClassInfo classInfo = ClassInfo.of(class_);
        boolean bl = GenericData.class.isAssignableFrom(class_);
        if (!bl && Map.class.isAssignableFrom(class_)) {
            this.parseMap(null, (Map<String, Object>)((Map)object), Types.getMapValueParameter((Type)class_), arrayList, customizeJsonParser);
            return;
        }
        while (jsonToken == JsonToken.FIELD_NAME) {
            String string2 = this.getText();
            this.nextToken();
            if (customizeJsonParser != null && customizeJsonParser.stopAt(object, string2)) {
                return;
            }
            FieldInfo fieldInfo = classInfo.getFieldInfo(string2);
            if (fieldInfo != null) {
                if (fieldInfo.isFinal() && !fieldInfo.isPrimitive()) {
                    throw new IllegalArgumentException("final array/object fields are not supported");
                }
                Field field = fieldInfo.getField();
                int n = arrayList.size();
                arrayList.add((Object)field.getGenericType());
                Object object2 = this.parseValue(field, fieldInfo.getGenericType(), arrayList, object, customizeJsonParser, true);
                arrayList.remove(n);
                fieldInfo.setValue(object, object2);
            } else if (bl) {
                ((GenericData)((Object)object)).set(string2, this.parseValue(null, null, arrayList, object, customizeJsonParser, true));
            } else {
                if (customizeJsonParser != null) {
                    customizeJsonParser.handleUnrecognizedKey(object, string2);
                }
                this.skipChildren();
            }
            jsonToken = this.nextToken();
        }
    }

    private <T> void parseArray(Field field, Collection<T> collection, Type type, ArrayList<Type> arrayList, CustomizeJsonParser customizeJsonParser) throws IOException {
        JsonToken jsonToken = this.startParsingObjectOrArray();
        while (jsonToken != JsonToken.END_ARRAY) {
            collection.add(this.parseValue(field, type, arrayList, collection, customizeJsonParser, true));
            jsonToken = this.nextToken();
        }
    }

    private void parseMap(Field field, Map<String, Object> map, Type type, ArrayList<Type> arrayList, CustomizeJsonParser customizeJsonParser) throws IOException {
        JsonToken jsonToken = this.startParsingObjectOrArray();
        while (jsonToken == JsonToken.FIELD_NAME) {
            String string2 = this.getText();
            this.nextToken();
            if (customizeJsonParser != null && customizeJsonParser.stopAt(map, string2)) {
                return;
            }
            map.put((Object)string2, this.parseValue(field, type, arrayList, map, customizeJsonParser, true));
            jsonToken = this.nextToken();
        }
    }

    /*
     * Exception decompiling
     */
    private final Object parseValue(Field var1_1, Type var2_2, ArrayList<Type> var3_3, Object var4_4, CustomizeJsonParser var5_5, boolean var6_6) throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [13[CASE]], but top level block is 2[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    private JsonToken startParsing() throws IOException {
        JsonToken jsonToken = this.getCurrentToken();
        if (jsonToken == null) {
            jsonToken = this.nextToken();
        }
        boolean bl = jsonToken != null;
        Preconditions.checkArgument(bl, "no JSON input found");
        return jsonToken;
    }

    private JsonToken startParsingObjectOrArray() throws IOException {
        boolean bl;
        JsonToken jsonToken = this.startParsing();
        boolean bl2 = 1.$SwitchMap$com$google$api$client$json$JsonToken[jsonToken.ordinal()];
        if (bl2 != (bl = true)) {
            if (!bl2) {
                return jsonToken;
            }
            return this.nextToken();
        }
        JsonToken jsonToken2 = this.nextToken();
        if (jsonToken2 != JsonToken.FIELD_NAME && jsonToken2 != JsonToken.END_OBJECT) {
            bl = false;
        }
        Preconditions.checkArgument(bl, (Object)jsonToken2);
        return jsonToken2;
    }

    public abstract void close() throws IOException;

    public abstract BigInteger getBigIntegerValue() throws IOException;

    public abstract byte getByteValue() throws IOException;

    public abstract String getCurrentName() throws IOException;

    public abstract JsonToken getCurrentToken();

    public abstract BigDecimal getDecimalValue() throws IOException;

    public abstract double getDoubleValue() throws IOException;

    public abstract JsonFactory getFactory();

    public abstract float getFloatValue() throws IOException;

    public abstract int getIntValue() throws IOException;

    public abstract long getLongValue() throws IOException;

    public abstract short getShortValue() throws IOException;

    public abstract String getText() throws IOException;

    public abstract JsonToken nextToken() throws IOException;

    public final <T> T parse(Class<T> class_) throws IOException {
        return this.parse(class_, null);
    }

    public final <T> T parse(Class<T> class_, CustomizeJsonParser customizeJsonParser) throws IOException {
        return (T)this.parse((Type)class_, false, customizeJsonParser);
    }

    public Object parse(Type type, boolean bl) throws IOException {
        return this.parse(type, bl, null);
    }

    public Object parse(Type type, boolean bl, CustomizeJsonParser customizeJsonParser) throws IOException {
        try {
            if (!Void.class.equals((Object)type)) {
                this.startParsing();
            }
            Object object = this.parseValue(null, type, (ArrayList<Type>)new ArrayList(), null, customizeJsonParser, true);
            return object;
        }
        finally {
            if (bl) {
                this.close();
            }
        }
    }

    public final void parse(Object object) throws IOException {
        this.parse(object, null);
    }

    public final void parse(Object object, CustomizeJsonParser customizeJsonParser) throws IOException {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)object.getClass());
        this.parse((ArrayList<Type>)arrayList, object, customizeJsonParser);
    }

    public final <T> T parseAndClose(Class<T> class_) throws IOException {
        return this.parseAndClose(class_, null);
    }

    public final <T> T parseAndClose(Class<T> class_, CustomizeJsonParser customizeJsonParser) throws IOException {
        try {
            T t = this.parse(class_, customizeJsonParser);
            return t;
        }
        finally {
            this.close();
        }
    }

    public final void parseAndClose(Object object) throws IOException {
        this.parseAndClose(object, null);
    }

    public final void parseAndClose(Object object, CustomizeJsonParser customizeJsonParser) throws IOException {
        try {
            this.parse(object, customizeJsonParser);
            return;
        }
        finally {
            this.close();
        }
    }

    public final <T> Collection<T> parseArray(Class<?> class_, Class<T> class_2) throws IOException {
        return this.parseArray(class_, class_2, null);
    }

    public final <T> Collection<T> parseArray(Class<?> class_, Class<T> class_2, CustomizeJsonParser customizeJsonParser) throws IOException {
        Collection<Object> collection = Data.newCollectionInstance(class_);
        this.parseArray(collection, class_2, customizeJsonParser);
        return collection;
    }

    public final <T> void parseArray(Collection<? super T> collection, Class<T> class_) throws IOException {
        this.parseArray(collection, class_, null);
    }

    public final <T> void parseArray(Collection<? super T> collection, Class<T> class_, CustomizeJsonParser customizeJsonParser) throws IOException {
        this.parseArray(null, (Collection<T>)collection, (Type)class_, (ArrayList<Type>)new ArrayList(), customizeJsonParser);
    }

    public final <T> Collection<T> parseArrayAndClose(Class<?> class_, Class<T> class_2) throws IOException {
        return this.parseArrayAndClose(class_, class_2, null);
    }

    public final <T> Collection<T> parseArrayAndClose(Class<?> class_, Class<T> class_2, CustomizeJsonParser customizeJsonParser) throws IOException {
        try {
            Collection<T> collection = this.parseArray(class_, class_2, customizeJsonParser);
            return collection;
        }
        finally {
            this.close();
        }
    }

    public final <T> void parseArrayAndClose(Collection<? super T> collection, Class<T> class_) throws IOException {
        this.parseArrayAndClose(collection, class_, null);
    }

    public final <T> void parseArrayAndClose(Collection<? super T> collection, Class<T> class_, CustomizeJsonParser customizeJsonParser) throws IOException {
        try {
            this.parseArray(collection, class_, customizeJsonParser);
            return;
        }
        finally {
            this.close();
        }
    }

    public abstract JsonParser skipChildren() throws IOException;

    public final String skipToKey(Set<String> set) throws IOException {
        JsonToken jsonToken = this.startParsingObjectOrArray();
        while (jsonToken == JsonToken.FIELD_NAME) {
            String string2 = this.getText();
            this.nextToken();
            if (set.contains((Object)string2)) {
                return string2;
            }
            this.skipChildren();
            jsonToken = this.nextToken();
        }
        return null;
    }

    public final void skipToKey(String string2) throws IOException {
        this.skipToKey((Set<String>)Collections.singleton((Object)string2));
    }

}

