/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.util.BackOff$1
 *  com.google.api.client.util.BackOff$2
 *  java.io.IOException
 *  java.lang.Object
 */
package com.google.api.client.util;

import com.google.api.client.util.BackOff;
import java.io.IOException;

public interface BackOff {
    public static final long STOP = -1L;
    public static final BackOff STOP_BACKOFF;
    public static final BackOff ZERO_BACKOFF;

    static {
        ZERO_BACKOFF = new 1();
        STOP_BACKOFF = new 2();
    }

    public long nextBackOffMillis() throws IOException;

    public void reset() throws IOException;
}

