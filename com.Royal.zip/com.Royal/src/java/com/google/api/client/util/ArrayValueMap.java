/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.util.ArrayList
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.google.api.client.util;

import com.google.api.client.util.ArrayMap;
import com.google.api.client.util.FieldInfo;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Types;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

public final class ArrayValueMap {
    private final Object destination;
    private final Map<Field, ArrayValue> fieldMap = ArrayMap.create();
    private final Map<String, ArrayValue> keyMap = ArrayMap.create();

    public ArrayValueMap(Object object) {
        this.destination = object;
    }

    public void put(String string2, Class<?> class_, Object object) {
        ArrayValue arrayValue = (ArrayValue)this.keyMap.get((Object)string2);
        if (arrayValue == null) {
            arrayValue = new ArrayValue(class_);
            this.keyMap.put((Object)string2, (Object)arrayValue);
        }
        arrayValue.addValue(class_, object);
    }

    public void put(Field field, Class<?> class_, Object object) {
        ArrayValue arrayValue = (ArrayValue)this.fieldMap.get((Object)field);
        if (arrayValue == null) {
            arrayValue = new ArrayValue(class_);
            this.fieldMap.put((Object)field, (Object)arrayValue);
        }
        arrayValue.addValue(class_, object);
    }

    public void setValues() {
        for (Map.Entry entry : this.keyMap.entrySet()) {
            ((Map)this.destination).put(entry.getKey(), ((ArrayValue)entry.getValue()).toArray());
        }
        for (Map.Entry entry : this.fieldMap.entrySet()) {
            FieldInfo.setFieldValue((Field)entry.getKey(), this.destination, ((ArrayValue)entry.getValue()).toArray());
        }
    }

    static class ArrayValue {
        final Class<?> componentType;
        final ArrayList<Object> values = new ArrayList();

        ArrayValue(Class<?> class_) {
            this.componentType = class_;
        }

        void addValue(Class<?> class_, Object object) {
            boolean bl = class_ == this.componentType;
            Preconditions.checkArgument(bl);
            this.values.add(object);
        }

        Object toArray() {
            return Types.toArray(this.values, this.componentType);
        }
    }

}

