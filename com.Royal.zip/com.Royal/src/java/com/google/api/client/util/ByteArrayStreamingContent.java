/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Object
 */
package com.google.api.client.util;

import com.google.api.client.util.Preconditions;
import com.google.api.client.util.StreamingContent;
import java.io.IOException;
import java.io.OutputStream;

public class ByteArrayStreamingContent
implements StreamingContent {
    private final byte[] byteArray;
    private final int length;
    private final int offset;

    public ByteArrayStreamingContent(byte[] arrby) {
        this(arrby, 0, arrby.length);
    }

    public ByteArrayStreamingContent(byte[] arrby, int n, int n2) {
        this.byteArray = Preconditions.checkNotNull(arrby);
        boolean bl = n >= 0 && n2 >= 0 && n + n2 <= arrby.length;
        Preconditions.checkArgument(bl);
        this.offset = n;
        this.length = n2;
    }

    @Override
    public void writeTo(OutputStream outputStream) throws IOException {
        outputStream.write(this.byteArray, this.offset, this.length);
        outputStream.flush();
    }
}

