/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.AbstractMap
 *  java.util.AbstractSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.NoSuchElementException
 *  java.util.Set
 */
package com.google.api.client.util;

import com.google.api.client.util.ClassInfo;
import com.google.api.client.util.FieldInfo;
import com.google.api.client.util.Preconditions;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

final class DataMap
extends AbstractMap<String, Object> {
    final ClassInfo classInfo;
    final Object object;

    DataMap(Object object, boolean bl) {
        this.object = object;
        this.classInfo = ClassInfo.of(object.getClass(), bl);
    }

    public boolean containsKey(Object object) {
        return this.get(object) != null;
    }

    public EntrySet entrySet() {
        return new EntrySet();
    }

    public Object get(Object object) {
        if (!(object instanceof String)) {
            return null;
        }
        FieldInfo fieldInfo = this.classInfo.getFieldInfo((String)object);
        if (fieldInfo == null) {
            return null;
        }
        return fieldInfo.getValue(this.object);
    }

    public Object put(String string2, Object object) {
        FieldInfo fieldInfo = this.classInfo.getFieldInfo(string2);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no field of key ");
        stringBuilder.append(string2);
        Preconditions.checkNotNull(fieldInfo, stringBuilder.toString());
        Object object2 = fieldInfo.getValue(this.object);
        fieldInfo.setValue(this.object, Preconditions.checkNotNull(object));
        return object2;
    }

    final class Entry
    implements Map.Entry<String, Object> {
        private final FieldInfo fieldInfo;
        private Object fieldValue;

        Entry(FieldInfo fieldInfo, Object object) {
            this.fieldInfo = fieldInfo;
            this.fieldValue = Preconditions.checkNotNull(object);
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (!(object instanceof Map.Entry)) {
                return false;
            }
            Map.Entry entry = (Map.Entry)object;
            return this.getKey().equals(entry.getKey()) && this.getValue().equals(entry.getValue());
        }

        public String getKey() {
            String string2 = this.fieldInfo.getName();
            if (DataMap.this.classInfo.getIgnoreCase()) {
                string2 = string2.toLowerCase(Locale.US);
            }
            return string2;
        }

        public Object getValue() {
            return this.fieldValue;
        }

        public int hashCode() {
            return this.getKey().hashCode() ^ this.getValue().hashCode();
        }

        public Object setValue(Object object) {
            Object object2 = this.fieldValue;
            this.fieldValue = Preconditions.checkNotNull(object);
            this.fieldInfo.setValue(DataMap.this.object, object);
            return object2;
        }
    }

    final class EntryIterator
    implements Iterator<Map.Entry<String, Object>> {
        private FieldInfo currentFieldInfo;
        private boolean isComputed;
        private boolean isRemoved;
        private FieldInfo nextFieldInfo;
        private Object nextFieldValue;
        private int nextKeyIndex = -1;

        EntryIterator() {
        }

        public boolean hasNext() {
            if (!this.isComputed) {
                this.isComputed = true;
                this.nextFieldValue = null;
                while (this.nextFieldValue == null) {
                    FieldInfo fieldInfo;
                    int n;
                    this.nextKeyIndex = n = 1 + this.nextKeyIndex;
                    if (n >= DataMap.this.classInfo.names.size()) break;
                    this.nextFieldInfo = fieldInfo = DataMap.this.classInfo.getFieldInfo((String)DataMap.this.classInfo.names.get(this.nextKeyIndex));
                    this.nextFieldValue = fieldInfo.getValue(DataMap.this.object);
                }
            }
            return this.nextFieldValue != null;
        }

        public Map.Entry<String, Object> next() {
            if (this.hasNext()) {
                FieldInfo fieldInfo;
                this.currentFieldInfo = fieldInfo = this.nextFieldInfo;
                Object object = this.nextFieldValue;
                this.isComputed = false;
                this.isRemoved = false;
                this.nextFieldInfo = null;
                this.nextFieldValue = null;
                return new Entry(fieldInfo, object);
            }
            throw new NoSuchElementException();
        }

        public void remove() {
            boolean bl = this.currentFieldInfo != null && !this.isRemoved;
            Preconditions.checkState(bl);
            this.isRemoved = true;
            this.currentFieldInfo.setValue(DataMap.this.object, null);
        }
    }

    final class EntrySet
    extends AbstractSet<Map.Entry<String, Object>> {
        EntrySet() {
        }

        public void clear() {
            for (String string2 : DataMap.this.classInfo.names) {
                DataMap.this.classInfo.getFieldInfo(string2).setValue(DataMap.this.object, null);
            }
        }

        public boolean isEmpty() {
            for (String string2 : DataMap.this.classInfo.names) {
                if (DataMap.this.classInfo.getFieldInfo(string2).getValue(DataMap.this.object) == null) continue;
                return false;
            }
            return true;
        }

        public EntryIterator iterator() {
            return new EntryIterator();
        }

        public int size() {
            Iterator iterator = DataMap.this.classInfo.names.iterator();
            int n = 0;
            while (iterator.hasNext()) {
                String string2 = (String)iterator.next();
                if (DataMap.this.classInfo.getFieldInfo(string2).getValue(DataMap.this.object) == null) continue;
                ++n;
            }
            return n;
        }
    }

}

