/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedReader
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.io.StringReader
 *  java.io.StringWriter
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.lang.reflect.Type
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.List
 *  java.util.Map
 */
package com.google.api.client.http;

import com.google.api.client.http.HttpMediaType;
import com.google.api.client.util.ArrayValueMap;
import com.google.api.client.util.Charsets;
import com.google.api.client.util.ClassInfo;
import com.google.api.client.util.Data;
import com.google.api.client.util.FieldInfo;
import com.google.api.client.util.GenericData;
import com.google.api.client.util.ObjectParser;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Throwables;
import com.google.api.client.util.Types;
import com.google.api.client.util.escape.CharEscapers;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class UrlEncodedParser
implements ObjectParser {
    public static final String CONTENT_TYPE = "application/x-www-form-urlencoded";
    public static final String MEDIA_TYPE = new HttpMediaType("application/x-www-form-urlencoded").setCharsetParameter(Charsets.UTF_8).build();

    public static void parse(Reader reader, Object object) throws IOException {
        UrlEncodedParser.parse(reader, object, true);
    }

    public static void parse(Reader reader, Object object, boolean bl) throws IOException {
        int n;
        Class class_ = object.getClass();
        ClassInfo classInfo = ClassInfo.of(class_);
        List list = Arrays.asList((Object[])new Type[]{class_});
        GenericData genericData = GenericData.class.isAssignableFrom(class_) ? (GenericData)((Object)object) : null;
        Map map = Map.class.isAssignableFrom(class_) ? (Map)object : null;
        ArrayValueMap arrayValueMap = new ArrayValueMap(object);
        StringWriter stringWriter = new StringWriter();
        StringWriter stringWriter2 = new StringWriter();
        do {
            boolean bl2 = true;
            while ((n = reader.read()) != -1 && n != 38) {
                if (n != 61) {
                    if (bl2) {
                        stringWriter.write(n);
                        continue;
                    }
                    stringWriter2.write(n);
                    continue;
                }
                if (bl2) {
                    bl2 = false;
                    continue;
                }
                stringWriter2.write(n);
            }
            String string2 = stringWriter.toString();
            if (bl) {
                string2 = CharEscapers.decodeUri(string2);
            }
            if (string2.length() != 0) {
                FieldInfo fieldInfo;
                String string3 = stringWriter2.toString();
                if (bl) {
                    string3 = CharEscapers.decodeUri(string3);
                }
                if ((fieldInfo = classInfo.getFieldInfo(string2)) != null) {
                    Type type = Data.resolveWildcardTypeOrTypeVariable((List<Type>)list, fieldInfo.getGenericType());
                    if (Types.isArray(type)) {
                        Class<?> class_2 = Types.getRawArrayComponentType((List<Type>)list, Types.getArrayComponentType(type));
                        arrayValueMap.put(fieldInfo.getField(), class_2, UrlEncodedParser.parseValue(class_2, (List<Type>)list, string3));
                    } else if (Types.isAssignableToOrFrom(Types.getRawArrayComponentType((List<Type>)list, type), Iterable.class)) {
                        Collection<Object> collection = (Collection<Object>)fieldInfo.getValue(object);
                        if (collection == null) {
                            collection = Data.newCollectionInstance(type);
                            fieldInfo.setValue(object, collection);
                        }
                        Type type2 = type == Object.class ? null : Types.getIterableParameter(type);
                        collection.add(UrlEncodedParser.parseValue(type2, (List<Type>)list, string3));
                    } else {
                        fieldInfo.setValue(object, UrlEncodedParser.parseValue(type, (List<Type>)list, string3));
                    }
                } else if (map != null) {
                    ArrayList arrayList = (ArrayList)map.get((Object)string2);
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                        if (genericData != null) {
                            genericData.set(string2, (Object)arrayList);
                        } else {
                            map.put((Object)string2, (Object)arrayList);
                        }
                    }
                    arrayList.add((Object)string3);
                }
            }
            stringWriter = new StringWriter();
            stringWriter2 = new StringWriter();
        } while (n != -1);
        arrayValueMap.setValues();
    }

    public static void parse(String string2, Object object) {
        UrlEncodedParser.parse(string2, object, true);
    }

    public static void parse(String string2, Object object, boolean bl) {
        if (string2 == null) {
            return;
        }
        try {
            UrlEncodedParser.parse((Reader)new StringReader(string2), object, bl);
            return;
        }
        catch (IOException iOException) {
            throw Throwables.propagate(iOException);
        }
    }

    private static Object parseValue(Type type, List<Type> list, String string2) {
        return Data.parsePrimitiveValue(Data.resolveWildcardTypeOrTypeVariable(list, type), string2);
    }

    @Override
    public <T> T parseAndClose(InputStream inputStream, Charset charset, Class<T> class_) throws IOException {
        return this.parseAndClose((Reader)new InputStreamReader(inputStream, charset), class_);
    }

    @Override
    public Object parseAndClose(InputStream inputStream, Charset charset, Type type) throws IOException {
        return this.parseAndClose((Reader)new InputStreamReader(inputStream, charset), type);
    }

    @Override
    public <T> T parseAndClose(Reader reader, Class<T> class_) throws IOException {
        return (T)this.parseAndClose(reader, (Type)class_);
    }

    @Override
    public Object parseAndClose(Reader reader, Type type) throws IOException {
        Preconditions.checkArgument(type instanceof Class, "dataType has to be of type Class<?>");
        Object t = Types.newInstance((Class)type);
        UrlEncodedParser.parse((Reader)new BufferedReader(reader), t);
        return t;
    }
}

