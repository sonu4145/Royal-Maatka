/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 */
package com.google.api.client.googleapis.services.json;

import com.google.api.client.googleapis.services.AbstractGoogleClient;
import com.google.api.client.googleapis.services.GoogleClientRequestInitializer;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonObjectParser;
import com.google.api.client.util.ObjectParser;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public abstract class AbstractGoogleJsonClient
extends AbstractGoogleClient {
    protected AbstractGoogleJsonClient(Builder builder) {
        super(builder);
    }

    public final JsonFactory getJsonFactory() {
        return this.getObjectParser().getJsonFactory();
    }

    @Override
    public JsonObjectParser getObjectParser() {
        return (JsonObjectParser)super.getObjectParser();
    }

    public static abstract class Builder
    extends AbstractGoogleClient.Builder {
        protected Builder(HttpTransport httpTransport, JsonFactory jsonFactory, String string2, String string3, HttpRequestInitializer httpRequestInitializer, boolean bl) {
            Object object = new Object(jsonFactory){
                final JsonFactory jsonFactory;
                Collection<String> wrapperKeys;
                {
                    this.wrapperKeys = com.google.api.client.util.Sets.newHashSet();
                    this.jsonFactory = com.google.api.client.util.Preconditions.checkNotNull(jsonFactory);
                }

                public JsonObjectParser build() {
                    return new JsonObjectParser(this);
                }

                public final JsonFactory getJsonFactory() {
                    return this.jsonFactory;
                }

                public final Collection<String> getWrapperKeys() {
                    return this.wrapperKeys;
                }

                public JsonObjectParser.Builder setWrapperKeys(Collection<String> collection) {
                    this.wrapperKeys = collection;
                    return this;
                }
            };
            Object object2 = bl ? Arrays.asList((Object[])new String[]{"data", "error"}) : Collections.emptySet();
            super(httpTransport, string2, string3, object.setWrapperKeys((Collection<String>)object2).build(), httpRequestInitializer);
        }

        @Override
        public abstract AbstractGoogleJsonClient build();

        public final JsonFactory getJsonFactory() {
            return this.getObjectParser().getJsonFactory();
        }

        @Override
        public final JsonObjectParser getObjectParser() {
            return (JsonObjectParser)super.getObjectParser();
        }

        @Override
        public Builder setApplicationName(String string2) {
            return (Builder)super.setApplicationName(string2);
        }

        @Override
        public Builder setGoogleClientRequestInitializer(GoogleClientRequestInitializer googleClientRequestInitializer) {
            return (Builder)super.setGoogleClientRequestInitializer(googleClientRequestInitializer);
        }

        @Override
        public Builder setHttpRequestInitializer(HttpRequestInitializer httpRequestInitializer) {
            return (Builder)super.setHttpRequestInitializer(httpRequestInitializer);
        }

        @Override
        public Builder setRootUrl(String string2) {
            return (Builder)super.setRootUrl(string2);
        }

        @Override
        public Builder setServicePath(String string2) {
            return (Builder)super.setServicePath(string2);
        }

        @Override
        public Builder setSuppressAllChecks(boolean bl) {
            return (Builder)super.setSuppressAllChecks(bl);
        }

        @Override
        public Builder setSuppressPatternChecks(boolean bl) {
            return (Builder)super.setSuppressPatternChecks(bl);
        }

        @Override
        public Builder setSuppressRequiredParameterChecks(boolean bl) {
            return (Builder)super.setSuppressRequiredParameterChecks(bl);
        }
    }

}

