/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.Reader
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.reflect.Type
 *  java.nio.charset.Charset
 */
package com.google.api.client.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.Charset;

public interface ObjectParser {
    public <T> T parseAndClose(InputStream var1, Charset var2, Class<T> var3) throws IOException;

    public Object parseAndClose(InputStream var1, Charset var2, Type var3) throws IOException;

    public <T> T parseAndClose(Reader var1, Class<T> var2) throws IOException;

    public Object parseAndClose(Reader var1, Type var2) throws IOException;
}

