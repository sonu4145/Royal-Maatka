/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CloneNotSupportedException
 *  java.lang.Cloneable
 *  java.lang.IllegalArgumentException
 *  java.lang.IndexOutOfBoundsException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.AbstractMap
 *  java.util.AbstractSet
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.NoSuchElementException
 *  java.util.Set
 */
package com.google.api.client.util;

import com.google.api.client.util.Objects;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

public class ArrayMap<K, V>
extends AbstractMap<K, V>
implements Cloneable {
    private Object[] data;
    int size;

    public static <K, V> ArrayMap<K, V> create() {
        return new ArrayMap<K, V>();
    }

    public static <K, V> ArrayMap<K, V> create(int n) {
        ArrayMap<K, V> arrayMap = ArrayMap.create();
        arrayMap.ensureCapacity(n);
        return arrayMap;
    }

    private int getDataIndexOfKey(Object object) {
        int n = this.size << 1;
        Object[] arrobject = this.data;
        for (int i = 0; i < n; i += 2) {
            Object object2 = arrobject[i];
            if (!(object == null ? object2 == null : object.equals(object2))) continue;
            return i;
        }
        return -2;
    }

    public static /* varargs */ <K, V> ArrayMap<K, V> of(Object ... arrobject) {
        ArrayMap<K, V> arrayMap = ArrayMap.create(1);
        int n = arrobject.length;
        if (1 != n % 2) {
            arrayMap.size = arrobject.length / 2;
            Object[] arrobject2 = new Object[n];
            arrayMap.data = arrobject2;
            System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)n);
            return arrayMap;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("missing value for last key: ");
        stringBuilder.append(arrobject[n - 1]);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    private V removeFromDataIndexOfKey(int n) {
        int n2 = this.size << 1;
        if (n >= 0) {
            if (n >= n2) {
                return null;
            }
            V v = this.valueAtDataIndex(n + 1);
            Object[] arrobject = this.data;
            int n3 = -2 + (n2 - n);
            if (n3 != 0) {
                System.arraycopy((Object)arrobject, (int)(n + 2), (Object)arrobject, (int)n, (int)n3);
            }
            this.size = -1 + this.size;
            this.setData(n2 - 2, null, null);
            return v;
        }
        return null;
    }

    private void setData(int n, K k, V v) {
        Object[] arrobject = this.data;
        arrobject[n] = k;
        arrobject[n + 1] = v;
    }

    private void setDataCapacity(int n) {
        if (n == 0) {
            this.data = null;
            return;
        }
        int n2 = this.size;
        Object[] arrobject = this.data;
        if (n2 == 0 || n != arrobject.length) {
            Object[] arrobject2 = new Object[n];
            this.data = arrobject2;
            if (n2 != 0) {
                System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)(n2 << 1));
            }
        }
    }

    private V valueAtDataIndex(int n) {
        if (n < 0) {
            return null;
        }
        return (V)this.data[n];
    }

    public final void add(K k, V v) {
        this.set(this.size, k, v);
    }

    public void clear() {
        this.size = 0;
        this.data = null;
    }

    public ArrayMap<K, V> clone() {
        ArrayMap arrayMap;
        block3 : {
            Object[] arrobject;
            try {
                arrayMap = (ArrayMap)((Object)super.clone());
                arrobject = this.data;
                if (arrobject == null) break block3;
            }
            catch (CloneNotSupportedException cloneNotSupportedException) {
                return null;
            }
            int n = arrobject.length;
            Object[] arrobject2 = new Object[n];
            arrayMap.data = arrobject2;
            System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)n);
        }
        return arrayMap;
    }

    public final boolean containsKey(Object object) {
        return -2 != this.getDataIndexOfKey(object);
    }

    public final boolean containsValue(Object object) {
        int n = this.size << 1;
        Object[] arrobject = this.data;
        for (int i = 1; i < n; i += 2) {
            Object object2 = arrobject[i];
            if (!(object == null ? object2 == null : object.equals(object2))) continue;
            return true;
        }
        return false;
    }

    public final void ensureCapacity(int n) {
        if (n >= 0) {
            int n2 = n << 1;
            Object[] arrobject = this.data;
            int n3 = arrobject == null ? 0 : arrobject.length;
            if (n2 > n3) {
                int n4 = 1 + 3 * (n3 / 2);
                if (n4 % 2 != 0) {
                    ++n4;
                }
                if (n4 >= n2) {
                    n2 = n4;
                }
                this.setDataCapacity(n2);
            }
            return;
        }
        throw new IndexOutOfBoundsException();
    }

    public final Set<Map.Entry<K, V>> entrySet() {
        return new EntrySet();
    }

    public final V get(Object object) {
        return this.valueAtDataIndex(1 + this.getDataIndexOfKey(object));
    }

    public final int getIndexOfKey(K k) {
        return this.getDataIndexOfKey(k) >> 1;
    }

    public final K getKey(int n) {
        if (n >= 0 && n < this.size) {
            return (K)this.data[n << 1];
        }
        return null;
    }

    public final V getValue(int n) {
        if (n >= 0 && n < this.size) {
            return this.valueAtDataIndex(1 + (n << 1));
        }
        return null;
    }

    public final V put(K k, V v) {
        int n = this.getIndexOfKey(k);
        if (n == -1) {
            n = this.size;
        }
        return this.set(n, k, v);
    }

    public final V remove(int n) {
        return this.removeFromDataIndexOfKey(n << 1);
    }

    public final V remove(Object object) {
        return this.removeFromDataIndexOfKey(this.getDataIndexOfKey(object));
    }

    public final V set(int n, V v) {
        int n2 = this.size;
        if (n >= 0 && n < n2) {
            int n3 = 1 + (n << 1);
            V v2 = this.valueAtDataIndex(n3);
            this.data[n3] = v;
            return v2;
        }
        throw new IndexOutOfBoundsException();
    }

    public final V set(int n, K k, V v) {
        if (n >= 0) {
            int n2 = n + 1;
            this.ensureCapacity(n2);
            int n3 = n << 1;
            V v2 = this.valueAtDataIndex(n3 + 1);
            this.setData(n3, k, v);
            if (n2 > this.size) {
                this.size = n2;
            }
            return v2;
        }
        throw new IndexOutOfBoundsException();
    }

    public final int size() {
        return this.size;
    }

    public final void trim() {
        this.setDataCapacity(this.size << 1);
    }

    final class Entry
    implements Map.Entry<K, V> {
        private int index;

        Entry(int n) {
            this.index = n;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (!(object instanceof Map.Entry)) {
                return false;
            }
            Map.Entry entry = (Map.Entry)object;
            return Objects.equal(this.getKey(), entry.getKey()) && Objects.equal(this.getValue(), entry.getValue());
        }

        public K getKey() {
            return ArrayMap.this.getKey(this.index);
        }

        public V getValue() {
            return ArrayMap.this.getValue(this.index);
        }

        public int hashCode() {
            K k = this.getKey();
            V v = this.getValue();
            int n = k != null ? k.hashCode() : 0;
            int n2 = 0;
            if (v != null) {
                n2 = v.hashCode();
            }
            return n ^ n2;
        }

        public V setValue(V v) {
            return ArrayMap.this.set(this.index, v);
        }
    }

    final class EntryIterator
    implements Iterator<Map.Entry<K, V>> {
        private int nextIndex;
        private boolean removed;

        EntryIterator() {
        }

        public boolean hasNext() {
            return this.nextIndex < ArrayMap.this.size;
        }

        public Map.Entry<K, V> next() {
            int n = this.nextIndex;
            if (n != ArrayMap.this.size) {
                this.nextIndex = 1 + this.nextIndex;
                this.removed = false;
                return new Entry(n);
            }
            throw new NoSuchElementException();
        }

        public void remove() {
            int n = this.nextIndex - 1;
            if (!this.removed && n >= 0) {
                ArrayMap.this.remove(n);
                --this.nextIndex;
                this.removed = true;
                return;
            }
            throw new IllegalArgumentException();
        }
    }

    final class EntrySet
    extends AbstractSet<Map.Entry<K, V>> {
        EntrySet() {
        }

        public Iterator<Map.Entry<K, V>> iterator() {
            return new EntryIterator();
        }

        public int size() {
            return ArrayMap.this.size;
        }
    }

}

