/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.charset.Charset
 *  java.util.Collections
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.SortedMap
 *  java.util.TreeMap
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.google.api.client.http;

import com.google.api.client.util.Preconditions;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class HttpMediaType {
    private static final Pattern FULL_MEDIA_TYPE_REGEX;
    private static final Pattern PARAMETER_REGEX;
    private static final Pattern TOKEN_REGEX;
    private static final Pattern TYPE_REGEX;
    private String cachedBuildResult;
    private final SortedMap<String, String> parameters = new TreeMap();
    private String subType = "octet-stream";
    private String type = "application";

    static {
        TYPE_REGEX = Pattern.compile((String)"[\\w!#$&.+\\-\\^_]+|[*]");
        TOKEN_REGEX = Pattern.compile((String)"[\\p{ASCII}&&[^\\p{Cntrl} ;/=\\[\\]\\(\\)\\<\\>\\@\\,\\:\\\"\\?\\=]]+");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\\s*(");
        stringBuilder.append("[^\\s/=;\"]+");
        stringBuilder.append(")/(");
        stringBuilder.append("[^\\s/=;\"]+");
        stringBuilder.append(")\\s*(");
        stringBuilder.append(";.*");
        stringBuilder.append(")?");
        FULL_MEDIA_TYPE_REGEX = Pattern.compile((String)stringBuilder.toString(), (int)32);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("\\s*;\\s*(");
        stringBuilder2.append("[^\\s/=;\"]+");
        stringBuilder2.append(")=(");
        stringBuilder2.append("\"([^\"]*)\"|[^\\s;\"]*");
        stringBuilder2.append(")");
        PARAMETER_REGEX = Pattern.compile((String)stringBuilder2.toString());
    }

    public HttpMediaType(String string2) {
        this.fromString(string2);
    }

    public HttpMediaType(String string2, String string3) {
        this.setType(string2);
        this.setSubType(string3);
    }

    public static boolean equalsIgnoreParameters(String string2, String string3) {
        return string2 == null && string3 == null || string2 != null && string3 != null && new HttpMediaType(string2).equalsIgnoreParameters(new HttpMediaType(string3));
    }

    private HttpMediaType fromString(String string2) {
        Matcher matcher = FULL_MEDIA_TYPE_REGEX.matcher((CharSequence)string2);
        Preconditions.checkArgument(matcher.matches(), "Type must be in the 'maintype/subtype; parameter=value' format");
        this.setType(matcher.group(1));
        this.setSubType(matcher.group(2));
        String string3 = matcher.group(3);
        if (string3 != null) {
            Matcher matcher2 = PARAMETER_REGEX.matcher((CharSequence)string3);
            while (matcher2.find()) {
                String string4 = matcher2.group(1);
                String string5 = matcher2.group(3);
                if (string5 == null) {
                    string5 = matcher2.group(2);
                }
                this.setParameter(string4, string5);
            }
        }
        return this;
    }

    static boolean matchesToken(String string2) {
        return TOKEN_REGEX.matcher((CharSequence)string2).matches();
    }

    private static String quoteString(String string2) {
        String string3 = string2.replace((CharSequence)"\\", (CharSequence)"\\\\").replace((CharSequence)"\"", (CharSequence)"\\\"");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\"");
        stringBuilder.append(string3);
        stringBuilder.append("\"");
        return stringBuilder.toString();
    }

    public String build() {
        String string2;
        String string3 = this.cachedBuildResult;
        if (string3 != null) {
            return string3;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.type);
        stringBuilder.append('/');
        stringBuilder.append(this.subType);
        SortedMap<String, String> sortedMap = this.parameters;
        if (sortedMap != null) {
            for (Map.Entry entry : sortedMap.entrySet()) {
                String string4 = (String)entry.getValue();
                stringBuilder.append("; ");
                stringBuilder.append((String)entry.getKey());
                stringBuilder.append("=");
                if (!HttpMediaType.matchesToken(string4)) {
                    string4 = HttpMediaType.quoteString(string4);
                }
                stringBuilder.append(string4);
            }
        }
        this.cachedBuildResult = string2 = stringBuilder.toString();
        return string2;
    }

    public void clearParameters() {
        this.cachedBuildResult = null;
        this.parameters.clear();
    }

    public boolean equals(Object object) {
        if (!(object instanceof HttpMediaType)) {
            return false;
        }
        HttpMediaType httpMediaType = (HttpMediaType)object;
        boolean bl = this.equalsIgnoreParameters(httpMediaType);
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = this.parameters.equals(httpMediaType.parameters);
            bl2 = false;
            if (bl3) {
                bl2 = true;
            }
        }
        return bl2;
    }

    public boolean equalsIgnoreParameters(HttpMediaType httpMediaType) {
        return httpMediaType != null && this.getType().equalsIgnoreCase(httpMediaType.getType()) && this.getSubType().equalsIgnoreCase(httpMediaType.getSubType());
    }

    public Charset getCharsetParameter() {
        String string2 = this.getParameter("charset");
        if (string2 == null) {
            return null;
        }
        return Charset.forName((String)string2);
    }

    public String getParameter(String string2) {
        return (String)this.parameters.get((Object)string2.toLowerCase(Locale.US));
    }

    public Map<String, String> getParameters() {
        return Collections.unmodifiableMap(this.parameters);
    }

    public String getSubType() {
        return this.subType;
    }

    public String getType() {
        return this.type;
    }

    public int hashCode() {
        return this.build().hashCode();
    }

    public HttpMediaType removeParameter(String string2) {
        this.cachedBuildResult = null;
        this.parameters.remove((Object)string2.toLowerCase(Locale.US));
        return this;
    }

    public HttpMediaType setCharsetParameter(Charset charset) {
        String string2 = charset == null ? null : charset.name();
        this.setParameter("charset", string2);
        return this;
    }

    public HttpMediaType setParameter(String string2, String string3) {
        if (string3 == null) {
            this.removeParameter(string2);
            return this;
        }
        Preconditions.checkArgument(TOKEN_REGEX.matcher((CharSequence)string2).matches(), "Name contains reserved characters");
        this.cachedBuildResult = null;
        this.parameters.put((Object)string2.toLowerCase(Locale.US), (Object)string3);
        return this;
    }

    public HttpMediaType setSubType(String string2) {
        Preconditions.checkArgument(TYPE_REGEX.matcher((CharSequence)string2).matches(), "Subtype contains reserved characters");
        this.subType = string2;
        this.cachedBuildResult = null;
        return this;
    }

    public HttpMediaType setType(String string2) {
        Preconditions.checkArgument(TYPE_REGEX.matcher((CharSequence)string2).matches(), "Type contains reserved characters");
        this.type = string2;
        this.cachedBuildResult = null;
        return this;
    }

    public String toString() {
        return this.build();
    }
}

