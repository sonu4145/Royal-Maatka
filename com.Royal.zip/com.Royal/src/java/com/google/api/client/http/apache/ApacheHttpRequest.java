/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  org.apache.http.HttpEntity
 *  org.apache.http.HttpEntityEnclosingRequest
 *  org.apache.http.HttpResponse
 *  org.apache.http.RequestLine
 *  org.apache.http.client.HttpClient
 *  org.apache.http.client.methods.HttpRequestBase
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.conn.params.ConnManagerParams
 *  org.apache.http.params.HttpConnectionParams
 *  org.apache.http.params.HttpParams
 */
package com.google.api.client.http.apache;

import com.google.api.client.http.LowLevelHttpRequest;
import com.google.api.client.http.LowLevelHttpResponse;
import com.google.api.client.http.apache.ApacheHttpResponse;
import com.google.api.client.http.apache.ContentEntity;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.StreamingContent;
import java.io.IOException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpResponse;
import org.apache.http.RequestLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

final class ApacheHttpRequest
extends LowLevelHttpRequest {
    private final HttpClient httpClient;
    private final HttpRequestBase request;

    ApacheHttpRequest(HttpClient httpClient, HttpRequestBase httpRequestBase) {
        this.httpClient = httpClient;
        this.request = httpRequestBase;
    }

    @Override
    public void addHeader(String string2, String string3) {
        this.request.addHeader(string2, string3);
    }

    @Override
    public LowLevelHttpResponse execute() throws IOException {
        if (this.getStreamingContent() != null) {
            HttpRequestBase httpRequestBase = this.request;
            boolean bl = httpRequestBase instanceof HttpEntityEnclosingRequest;
            Object[] arrobject = new Object[]{httpRequestBase.getRequestLine().getMethod()};
            Preconditions.checkState(bl, "Apache HTTP client does not support %s requests with content.", arrobject);
            ContentEntity contentEntity = new ContentEntity(this.getContentLength(), this.getStreamingContent());
            contentEntity.setContentEncoding(this.getContentEncoding());
            contentEntity.setContentType(this.getContentType());
            if (this.getContentLength() == -1L) {
                contentEntity.setChunked(true);
            }
            ((HttpEntityEnclosingRequest)this.request).setEntity((HttpEntity)contentEntity);
        }
        HttpRequestBase httpRequestBase = this.request;
        return new ApacheHttpResponse(httpRequestBase, this.httpClient.execute((HttpUriRequest)httpRequestBase));
    }

    @Override
    public void setTimeout(int n, int n2) throws IOException {
        HttpParams httpParams = this.request.getParams();
        ConnManagerParams.setTimeout((HttpParams)httpParams, (long)n);
        HttpConnectionParams.setConnectionTimeout((HttpParams)httpParams, (int)n);
        HttpConnectionParams.setSoTimeout((HttpParams)httpParams, (int)n2);
    }
}

