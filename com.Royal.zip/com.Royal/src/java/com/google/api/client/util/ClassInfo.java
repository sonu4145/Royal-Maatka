/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Field
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Comparator
 *  java.util.IdentityHashMap
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.TreeSet
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.ConcurrentMap
 */
package com.google.api.client.util;

import com.google.api.client.util.FieldInfo;
import com.google.api.client.util.Objects;
import com.google.api.client.util.Preconditions;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public final class ClassInfo {
    private static final ConcurrentMap<Class<?>, ClassInfo> CACHE = new ConcurrentHashMap();
    private static final ConcurrentMap<Class<?>, ClassInfo> CACHE_IGNORE_CASE = new ConcurrentHashMap();
    private final Class<?> clazz;
    private final boolean ignoreCase;
    private final IdentityHashMap<String, FieldInfo> nameToFieldInfoMap = new IdentityHashMap();
    final List<String> names;

    private ClassInfo(Class<?> class_, boolean bl) {
        this.clazz = class_;
        this.ignoreCase = bl;
        boolean bl2 = !bl || !class_.isEnum();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("cannot ignore case on an enum: ");
        stringBuilder.append(class_);
        Preconditions.checkArgument(bl2, stringBuilder.toString());
        TreeSet treeSet = new TreeSet((Comparator)new Comparator<String>(){

            public int compare(String string2, String string3) {
                if (Objects.equal(string2, string3)) {
                    return 0;
                }
                if (string2 == null) {
                    return -1;
                }
                if (string3 == null) {
                    return 1;
                }
                return string2.compareTo(string3);
            }
        });
        for (Field field : class_.getDeclaredFields()) {
            FieldInfo fieldInfo;
            FieldInfo fieldInfo2 = FieldInfo.of(field);
            if (fieldInfo2 == null) continue;
            String string2 = fieldInfo2.getName();
            if (bl) {
                string2 = string2.toLowerCase(Locale.US).intern();
            }
            boolean bl3 = (fieldInfo = (FieldInfo)this.nameToFieldInfoMap.get((Object)string2)) == null;
            Object[] arrobject = new Object[4];
            String string3 = bl ? "case-insensitive " : "";
            arrobject[0] = string3;
            arrobject[1] = string2;
            arrobject[2] = field;
            Field field2 = fieldInfo == null ? null : fieldInfo.getField();
            arrobject[3] = field2;
            Preconditions.checkArgument(bl3, "two fields have the same %sname <%s>: %s and %s", arrobject);
            this.nameToFieldInfoMap.put((Object)string2, (Object)fieldInfo2);
            treeSet.add((Object)string2);
        }
        Class class_2 = class_.getSuperclass();
        if (class_2 != null) {
            ClassInfo classInfo = ClassInfo.of(class_2, bl);
            treeSet.addAll(classInfo.names);
            for (Map.Entry entry : classInfo.nameToFieldInfoMap.entrySet()) {
                String string4 = (String)entry.getKey();
                if (this.nameToFieldInfoMap.containsKey((Object)string4)) continue;
                this.nameToFieldInfoMap.put((Object)string4, entry.getValue());
            }
        }
        List list = treeSet.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList((List)new ArrayList((Collection)treeSet));
        this.names = list;
    }

    public static ClassInfo of(Class<?> class_) {
        return ClassInfo.of(class_, false);
    }

    public static ClassInfo of(Class<?> class_, boolean bl) {
        if (class_ == null) {
            return null;
        }
        ConcurrentMap<Class<?>, ClassInfo> concurrentMap = bl ? CACHE_IGNORE_CASE : CACHE;
        ClassInfo classInfo = (ClassInfo)concurrentMap.get(class_);
        if (classInfo == null) {
            ClassInfo classInfo2 = new ClassInfo(class_, bl);
            ClassInfo classInfo3 = (ClassInfo)concurrentMap.putIfAbsent(class_, (Object)classInfo2);
            if (classInfo3 == null) {
                return classInfo2;
            }
            classInfo = classInfo3;
        }
        return classInfo;
    }

    public Field getField(String string2) {
        FieldInfo fieldInfo = this.getFieldInfo(string2);
        if (fieldInfo == null) {
            return null;
        }
        return fieldInfo.getField();
    }

    public FieldInfo getFieldInfo(String string2) {
        if (string2 != null) {
            if (this.ignoreCase) {
                string2 = string2.toLowerCase(Locale.US);
            }
            string2 = string2.intern();
        }
        return (FieldInfo)this.nameToFieldInfoMap.get((Object)string2);
    }

    public Collection<FieldInfo> getFieldInfos() {
        return Collections.unmodifiableCollection((Collection)this.nameToFieldInfoMap.values());
    }

    public final boolean getIgnoreCase() {
        return this.ignoreCase;
    }

    public Collection<String> getNames() {
        return this.names;
    }

    public Class<?> getUnderlyingClass() {
        return this.clazz;
    }

    public boolean isEnum() {
        return this.clazz.isEnum();
    }

}

