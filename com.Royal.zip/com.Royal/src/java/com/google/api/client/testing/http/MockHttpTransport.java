/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.Set
 */
package com.google.api.client.testing.http;

import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.LowLevelHttpRequest;
import com.google.api.client.testing.http.MockLowLevelHttpRequest;
import com.google.api.client.testing.http.MockLowLevelHttpResponse;
import com.google.api.client.util.Preconditions;
import java.io.IOException;
import java.util.Collections;
import java.util.Set;

public class MockHttpTransport
extends HttpTransport {
    private MockLowLevelHttpRequest lowLevelHttpRequest;
    private MockLowLevelHttpResponse lowLevelHttpResponse;
    private Set<String> supportedMethods;

    public MockHttpTransport() {
    }

    protected MockHttpTransport(Builder builder) {
        this.supportedMethods = builder.supportedMethods;
        this.lowLevelHttpRequest = builder.lowLevelHttpRequest;
        this.lowLevelHttpResponse = builder.lowLevelHttpResponse;
    }

    @Override
    public LowLevelHttpRequest buildRequest(String string2, String string3) throws IOException {
        MockLowLevelHttpRequest mockLowLevelHttpRequest;
        Preconditions.checkArgument(this.supportsMethod(string2), "HTTP method %s not supported", string2);
        MockLowLevelHttpRequest mockLowLevelHttpRequest2 = this.lowLevelHttpRequest;
        if (mockLowLevelHttpRequest2 != null) {
            return mockLowLevelHttpRequest2;
        }
        this.lowLevelHttpRequest = mockLowLevelHttpRequest = new MockLowLevelHttpRequest(string3);
        MockLowLevelHttpResponse mockLowLevelHttpResponse = this.lowLevelHttpResponse;
        if (mockLowLevelHttpResponse != null) {
            mockLowLevelHttpRequest.setResponse(mockLowLevelHttpResponse);
        }
        return this.lowLevelHttpRequest;
    }

    public final MockLowLevelHttpRequest getLowLevelHttpRequest() {
        return this.lowLevelHttpRequest;
    }

    public final Set<String> getSupportedMethods() {
        Set<String> set = this.supportedMethods;
        if (set == null) {
            return null;
        }
        return Collections.unmodifiableSet(set);
    }

    @Override
    public boolean supportsMethod(String string2) throws IOException {
        Set<String> set = this.supportedMethods;
        return set == null || set.contains((Object)string2);
        {
        }
    }

}

