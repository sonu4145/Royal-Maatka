/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.io.BaseEncoding
 *  com.google.common.io.BaseEncoding$DecodingException
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.google.api.client.util;

import com.google.api.client.util.StringUtils;
import com.google.common.io.BaseEncoding;

public class Base64 {
    private Base64() {
    }

    public static byte[] decodeBase64(String string2) {
        if (string2 == null) {
            return null;
        }
        try {
            byte[] arrby = BaseEncoding.base64().decode((CharSequence)string2);
            return arrby;
        }
        catch (IllegalArgumentException illegalArgumentException) {
            if (illegalArgumentException.getCause() instanceof BaseEncoding.DecodingException) {
                return BaseEncoding.base64Url().decode((CharSequence)string2.trim());
            }
            throw illegalArgumentException;
        }
    }

    public static byte[] decodeBase64(byte[] arrby) {
        return Base64.decodeBase64(StringUtils.newStringUtf8(arrby));
    }

    public static byte[] encodeBase64(byte[] arrby) {
        return StringUtils.getBytesUtf8(Base64.encodeBase64String(arrby));
    }

    public static String encodeBase64String(byte[] arrby) {
        if (arrby == null) {
            return null;
        }
        return BaseEncoding.base64().encode(arrby);
    }

    public static byte[] encodeBase64URLSafe(byte[] arrby) {
        return StringUtils.getBytesUtf8(Base64.encodeBase64URLSafeString(arrby));
    }

    public static String encodeBase64URLSafeString(byte[] arrby) {
        if (arrby == null) {
            return null;
        }
        return BaseEncoding.base64Url().omitPadding().encode(arrby);
    }
}

