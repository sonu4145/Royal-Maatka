/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.Date
 *  java.util.GregorianCalendar
 *  java.util.Objects
 *  java.util.TimeZone
 *  java.util.concurrent.TimeUnit
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.google.api.client.util;

import com.google.common.base.Strings;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Objects;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DateTime
implements Serializable {
    private static final TimeZone GMT = TimeZone.getTimeZone((String)"GMT");
    private static final Pattern RFC3339_PATTERN = Pattern.compile((String)"(\\d{4})-(\\d{2})-(\\d{2})([Tt](\\d{2}):(\\d{2}):(\\d{2})(\\.\\d{1,9})?)?([Zz]|([+-])(\\d{2}):(\\d{2}))?");
    private static final String RFC3339_REGEX = "(\\d{4})-(\\d{2})-(\\d{2})([Tt](\\d{2}):(\\d{2}):(\\d{2})(\\.\\d{1,9})?)?([Zz]|([+-])(\\d{2}):(\\d{2}))?";
    private static final long serialVersionUID = 1L;
    private final boolean dateOnly;
    private final int tzShift;
    private final long value;

    public DateTime(long l) {
        this(false, l, null);
    }

    public DateTime(long l, int n) {
        this(false, l, n);
    }

    public DateTime(String string2) {
        DateTime dateTime = DateTime.parseRfc3339(string2);
        this.dateOnly = dateTime.dateOnly;
        this.value = dateTime.value;
        this.tzShift = dateTime.tzShift;
    }

    public DateTime(Date date) {
        this(date.getTime());
    }

    public DateTime(Date date, TimeZone timeZone) {
        long l = date.getTime();
        Integer n = timeZone == null ? null : Integer.valueOf((int)(timeZone.getOffset(date.getTime()) / 60000));
        this(false, l, n);
    }

    public DateTime(boolean bl, long l, Integer n) {
        this.dateOnly = bl;
        this.value = l;
        int n2 = bl ? 0 : (n == null ? TimeZone.getDefault().getOffset(l) / 60000 : n);
        this.tzShift = n2;
    }

    private static void appendInt(StringBuilder stringBuilder, int n, int n2) {
        if (n < 0) {
            stringBuilder.append('-');
            n = -n;
        }
        int n3 = n;
        while (n3 > 0) {
            n3 /= 10;
            --n2;
        }
        for (int i = 0; i < n2; ++i) {
            stringBuilder.append('0');
        }
        if (n != 0) {
            stringBuilder.append(n);
        }
    }

    public static DateTime parseRfc3339(String string2) {
        return DateTime.parseRfc3339WithNanoSeconds(string2).toDateTime();
    }

    public static SecondsAndNanos parseRfc3339ToSecondsAndNanos(String string2) {
        return DateTime.parseRfc3339WithNanoSeconds(string2).toSecondsAndNanos();
    }

    private static Rfc3339ParseResult parseRfc3339WithNanoSeconds(String string2) throws NumberFormatException {
        Matcher matcher = RFC3339_PATTERN.matcher((CharSequence)string2);
        if (matcher.matches()) {
            int n;
            int n2;
            int n3;
            int n4;
            Integer n5;
            int n6 = Integer.parseInt((String)matcher.group(1));
            int n7 = -1 + Integer.parseInt((String)matcher.group(2));
            int n8 = Integer.parseInt((String)matcher.group(3));
            boolean bl = matcher.group(4) != null;
            String string3 = matcher.group(9);
            boolean bl2 = string3 != null;
            if (bl2 && !bl) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Invalid date/time format, cannot specify time zone shift without specifying time: ");
                stringBuilder.append(string2);
                throw new NumberFormatException(stringBuilder.toString());
            }
            if (bl) {
                int n9 = Integer.parseInt((String)matcher.group(5));
                int n10 = Integer.parseInt((String)matcher.group(6));
                int n11 = Integer.parseInt((String)matcher.group(7));
                if (matcher.group(8) != null) {
                    n3 = Integer.parseInt((String)Strings.padEnd((String)matcher.group(8).substring(1), (int)9, (char)'0'));
                    n = n10;
                    n4 = n11;
                } else {
                    n = n10;
                    n4 = n11;
                    n3 = 0;
                }
                n2 = n9;
            } else {
                n2 = 0;
                n = 0;
                n4 = 0;
                n3 = 0;
            }
            GregorianCalendar gregorianCalendar = new GregorianCalendar(GMT);
            gregorianCalendar.clear();
            gregorianCalendar.set(n6, n7, n8, n2, n, n4);
            long l = gregorianCalendar.getTimeInMillis();
            if (bl && bl2) {
                Integer n12;
                if (Character.toUpperCase((char)string3.charAt(0)) != 'Z') {
                    int n13 = 60 * Integer.parseInt((String)matcher.group(11)) + Integer.parseInt((String)matcher.group(12));
                    if (matcher.group(10).charAt(0) == '-') {
                        n13 = -n13;
                    }
                    l -= 60000L * (long)n13;
                    n12 = n13;
                } else {
                    n12 = 0;
                }
                n5 = n12;
            } else {
                n5 = null;
            }
            long l2 = l / 1000L;
            Rfc3339ParseResult rfc3339ParseResult = new Rfc3339ParseResult(l2, n3, bl, n5);
            return rfc3339ParseResult;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid date/time format: ");
        stringBuilder.append(string2);
        throw new NumberFormatException(stringBuilder.toString());
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof DateTime)) {
            return false;
        }
        DateTime dateTime = (DateTime)object;
        return this.dateOnly == dateTime.dateOnly && this.value == dateTime.value && this.tzShift == dateTime.tzShift;
    }

    public int getTimeZoneShift() {
        return this.tzShift;
    }

    public long getValue() {
        return this.value;
    }

    public int hashCode() {
        long[] arrl = new long[3];
        arrl[0] = this.value;
        long l = this.dateOnly ? 1L : 0L;
        arrl[1] = l;
        arrl[2] = this.tzShift;
        return Arrays.hashCode((long[])arrl);
    }

    public boolean isDateOnly() {
        return this.dateOnly;
    }

    public String toString() {
        return this.toStringRfc3339();
    }

    public String toStringRfc3339() {
        StringBuilder stringBuilder = new StringBuilder();
        GregorianCalendar gregorianCalendar = new GregorianCalendar(GMT);
        gregorianCalendar.setTimeInMillis(this.value + 60000L * (long)this.tzShift);
        DateTime.appendInt(stringBuilder, gregorianCalendar.get(1), 4);
        stringBuilder.append('-');
        DateTime.appendInt(stringBuilder, 1 + gregorianCalendar.get(2), 2);
        stringBuilder.append('-');
        DateTime.appendInt(stringBuilder, gregorianCalendar.get(5), 2);
        if (!this.dateOnly) {
            int n;
            stringBuilder.append('T');
            DateTime.appendInt(stringBuilder, gregorianCalendar.get(11), 2);
            stringBuilder.append(':');
            DateTime.appendInt(stringBuilder, gregorianCalendar.get(12), 2);
            stringBuilder.append(':');
            DateTime.appendInt(stringBuilder, gregorianCalendar.get(13), 2);
            if (gregorianCalendar.isSet(14)) {
                stringBuilder.append('.');
                DateTime.appendInt(stringBuilder, gregorianCalendar.get(14), 3);
            }
            if ((n = this.tzShift) == 0) {
                stringBuilder.append('Z');
            } else {
                if (n > 0) {
                    stringBuilder.append('+');
                } else {
                    stringBuilder.append('-');
                    n = -n;
                }
                int n2 = n / 60;
                int n3 = n % 60;
                DateTime.appendInt(stringBuilder, n2, 2);
                stringBuilder.append(':');
                DateTime.appendInt(stringBuilder, n3, 2);
            }
        }
        return stringBuilder.toString();
    }

    private static class Rfc3339ParseResult
    implements Serializable {
        private final int nanos;
        private final long seconds;
        private final boolean timeGiven;
        private final Integer tzShift;

        private Rfc3339ParseResult(long l, int n, boolean bl, Integer n2) {
            this.seconds = l;
            this.nanos = n;
            this.timeGiven = bl;
            this.tzShift = n2;
        }

        private DateTime toDateTime() {
            long l = TimeUnit.SECONDS.toMillis(this.seconds);
            long l2 = TimeUnit.NANOSECONDS.toMillis((long)this.nanos);
            return new DateTime(true ^ this.timeGiven, l + l2, this.tzShift);
        }

        private SecondsAndNanos toSecondsAndNanos() {
            return new SecondsAndNanos(this.seconds, this.nanos);
        }
    }

    public static final class SecondsAndNanos
    implements Serializable {
        private final int nanos;
        private final long seconds;

        private SecondsAndNanos(long l, int n) {
            this.seconds = l;
            this.nanos = n;
        }

        public static SecondsAndNanos ofSecondsAndNanos(long l, int n) {
            return new SecondsAndNanos(l, n);
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (object != null) {
                if (this.getClass() != object.getClass()) {
                    return false;
                }
                SecondsAndNanos secondsAndNanos = (SecondsAndNanos)object;
                return this.seconds == secondsAndNanos.seconds && this.nanos == secondsAndNanos.nanos;
            }
            return false;
        }

        public int getNanos() {
            return this.nanos;
        }

        public long getSeconds() {
            return this.seconds;
        }

        public int hashCode() {
            Object[] arrobject = new Object[]{this.seconds, this.nanos};
            return Objects.hash((Object[])arrobject);
        }

        public String toString() {
            Object[] arrobject = new Object[]{this.seconds, this.nanos};
            return String.format((String)"Seconds: %d, Nanos: %d", (Object[])arrobject);
        }
    }

}

