/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.ClassCastException
 *  java.lang.Object
 *  java.net.HttpURLConnection
 *  java.net.URL
 */
package com.google.api.client.http.javanet;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public interface ConnectionFactory {
    public HttpURLConnection openConnection(URL var1) throws IOException, ClassCastException;
}

