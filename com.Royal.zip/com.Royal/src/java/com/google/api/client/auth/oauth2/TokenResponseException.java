/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.charset.Charset
 */
package com.google.api.client.auth.oauth2;

import com.google.api.client.auth.oauth2.TokenErrorResponse;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpMediaType;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpResponseException;
import com.google.api.client.json.GenericJson;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonObjectParser;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.StringUtils;
import com.google.api.client.util.Strings;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

public class TokenResponseException
extends HttpResponseException {
    private static final long serialVersionUID = 4020689092957439244L;
    private final transient TokenErrorResponse details;

    TokenResponseException(HttpResponseException.Builder builder, TokenErrorResponse tokenErrorResponse) {
        super(builder);
        this.details = tokenErrorResponse;
    }

    public static TokenResponseException from(JsonFactory jsonFactory, HttpResponse httpResponse) {
        Object object;
        HttpResponseException.Builder builder;
        Object object2;
        block10 : {
            void var6_10;
            block9 : {
                String string2;
                block8 : {
                    block7 : {
                        builder = new HttpResponseException.Builder(httpResponse.getStatusCode(), httpResponse.getStatusMessage(), httpResponse.getHeaders());
                        Preconditions.checkNotNull(jsonFactory);
                        String string3 = httpResponse.getContentType();
                        object2 = null;
                        if (httpResponse.isSuccessStatusCode() || string3 == null) break block7;
                        if (httpResponse.getContent() == null || !HttpMediaType.equalsIgnoreParameters("application/json; charset=UTF-8", string3)) break block7;
                        object = new JsonObjectParser(jsonFactory).parseAndClose(httpResponse.getContent(), httpResponse.getContentCharset(), TokenErrorResponse.class);
                        try {
                            String string4 = ((GenericJson)((Object)object)).toPrettyString();
                            object2 = object;
                            string2 = string4;
                            break block8;
                        }
                        catch (IOException iOException) {
                            break block9;
                        }
                    }
                    try {
                        string2 = httpResponse.parseAsString();
                    }
                    catch (IOException iOException) {
                        object = null;
                    }
                }
                String string5 = object2;
                object2 = string2;
                object = string5;
                break block10;
            }
            var6_10.printStackTrace();
        }
        StringBuilder stringBuilder = HttpResponseException.computeMessageBuffer(httpResponse);
        if (!Strings.isNullOrEmpty((String)object2)) {
            stringBuilder.append(StringUtils.LINE_SEPARATOR);
            stringBuilder.append((String)object2);
            builder.setContent((String)object2);
        }
        builder.setMessage(stringBuilder.toString());
        return new TokenResponseException(builder, (TokenErrorResponse)((Object)object));
    }

    public final TokenErrorResponse getDetails() {
        return this.details;
    }
}

