/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Strings
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.api.client.util;

public final class Strings {
    private Strings() {
    }

    public static boolean isNullOrEmpty(String string2) {
        return com.google.common.base.Strings.isNullOrEmpty((String)string2);
    }
}

