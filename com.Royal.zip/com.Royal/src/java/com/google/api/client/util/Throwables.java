/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Throwables
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.Throwable
 */
package com.google.api.client.util;

public final class Throwables {
    private Throwables() {
    }

    public static RuntimeException propagate(Throwable throwable) {
        return com.google.common.base.Throwables.propagate((Throwable)throwable);
    }

    public static void propagateIfPossible(Throwable throwable) {
        if (throwable != null) {
            com.google.common.base.Throwables.throwIfUnchecked((Throwable)throwable);
        }
    }

    public static <X extends Throwable> void propagateIfPossible(Throwable throwable, Class<X> class_) throws Throwable {
        com.google.common.base.Throwables.propagateIfPossible((Throwable)throwable, class_);
    }
}

