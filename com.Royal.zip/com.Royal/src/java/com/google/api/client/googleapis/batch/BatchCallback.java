/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.http.HttpHeaders
 *  java.io.IOException
 *  java.lang.Object
 */
package com.google.api.client.googleapis.batch;

import com.google.api.client.http.HttpHeaders;
import java.io.IOException;

public interface BatchCallback<T, E> {
    public void onFailure(E var1, HttpHeaders var2) throws IOException;

    public void onSuccess(T var1, HttpHeaders var2) throws IOException;
}

