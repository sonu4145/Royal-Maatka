/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileReader
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.Reader
 *  java.io.StringReader
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.security.GeneralSecurityException
 *  java.security.NoSuchAlgorithmException
 *  java.security.PrivateKey
 *  java.security.spec.InvalidKeySpecException
 *  java.security.spec.KeySpec
 *  java.security.spec.PKCS8EncodedKeySpec
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.List
 */
package com.google.api.client.googleapis.auth.oauth2;

import com.google.api.client.auth.oauth2.BearerToken;
import com.google.api.client.auth.oauth2.ClientParametersAuthentication;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.CredentialRefreshListener;
import com.google.api.client.auth.oauth2.TokenRequest;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.DefaultCredentialProvider;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.OAuth2Utils;
import com.google.api.client.googleapis.util.Utils;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpExecuteInterceptor;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.GenericJson;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonObjectParser;
import com.google.api.client.json.webtoken.JsonWebSignature;
import com.google.api.client.json.webtoken.JsonWebToken;
import com.google.api.client.util.Clock;
import com.google.api.client.util.Joiner;
import com.google.api.client.util.PemReader;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.SecurityUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Deprecated
public class GoogleCredential
extends Credential {
    static final String SERVICE_ACCOUNT_FILE_TYPE = "service_account";
    static final String USER_FILE_TYPE = "authorized_user";
    private static DefaultCredentialProvider defaultCredentialProvider = new DefaultCredentialProvider();
    private String serviceAccountId;
    private PrivateKey serviceAccountPrivateKey;
    private String serviceAccountPrivateKeyId;
    private String serviceAccountProjectId;
    private Collection<String> serviceAccountScopes;
    private String serviceAccountUser;

    public GoogleCredential() {
        this(new Builder());
    }

    protected GoogleCredential(Builder builder) {
        super(builder);
        if (builder.serviceAccountPrivateKey == null) {
            boolean bl = builder.serviceAccountId == null && builder.serviceAccountScopes == null && builder.serviceAccountUser == null;
            Preconditions.checkArgument(bl);
            return;
        }
        this.serviceAccountId = Preconditions.checkNotNull(builder.serviceAccountId);
        this.serviceAccountProjectId = builder.serviceAccountProjectId;
        Object object = builder.serviceAccountScopes == null ? Collections.emptyList() : Collections.unmodifiableCollection(builder.serviceAccountScopes);
        this.serviceAccountScopes = object;
        this.serviceAccountPrivateKey = builder.serviceAccountPrivateKey;
        this.serviceAccountPrivateKeyId = builder.serviceAccountPrivateKeyId;
        this.serviceAccountUser = builder.serviceAccountUser;
    }

    public static GoogleCredential fromStream(InputStream inputStream) throws IOException {
        return GoogleCredential.fromStream(inputStream, Utils.getDefaultTransport(), Utils.getDefaultJsonFactory());
    }

    public static GoogleCredential fromStream(InputStream inputStream, HttpTransport httpTransport, JsonFactory jsonFactory) throws IOException {
        Preconditions.checkNotNull(inputStream);
        Preconditions.checkNotNull(httpTransport);
        Preconditions.checkNotNull(jsonFactory);
        GenericJson genericJson = new JsonObjectParser(jsonFactory).parseAndClose(inputStream, OAuth2Utils.UTF_8, GenericJson.class);
        String string2 = (String)genericJson.get("type");
        if (string2 != null) {
            if (USER_FILE_TYPE.equals((Object)string2)) {
                return GoogleCredential.fromStreamUser(genericJson, httpTransport, jsonFactory);
            }
            if (SERVICE_ACCOUNT_FILE_TYPE.equals((Object)string2)) {
                return GoogleCredential.fromStreamServiceAccount(genericJson, httpTransport, jsonFactory);
            }
            throw new IOException(String.format((String)"Error reading credentials from stream, 'type' value '%s' not recognized. Expecting '%s' or '%s'.", (Object[])new Object[]{string2, USER_FILE_TYPE, SERVICE_ACCOUNT_FILE_TYPE}));
        }
        throw new IOException("Error reading credentials from stream, 'type' field not specified.");
    }

    private static GoogleCredential fromStreamServiceAccount(GenericJson genericJson, HttpTransport httpTransport, JsonFactory jsonFactory) throws IOException {
        String string2 = (String)genericJson.get("client_id");
        String string3 = (String)genericJson.get("client_email");
        String string4 = (String)genericJson.get("private_key");
        String string5 = (String)genericJson.get("private_key_id");
        if (string2 != null && string3 != null && string4 != null && string5 != null) {
            String string6;
            PrivateKey privateKey = GoogleCredential.privateKeyFromPkcs8(string4);
            List list = Collections.emptyList();
            Builder builder = ((Builder)((Builder)new Builder().setTransport(httpTransport)).setJsonFactory(jsonFactory)).setServiceAccountId(string3).setServiceAccountScopes((Collection<String>)list).setServiceAccountPrivateKey(privateKey).setServiceAccountPrivateKeyId(string5);
            String string7 = (String)genericJson.get("token_uri");
            if (string7 != null) {
                builder.setTokenServerEncodedUrl(string7);
            }
            if ((string6 = (String)genericJson.get("project_id")) != null) {
                builder.setServiceAccountProjectId(string6);
            }
            return builder.build();
        }
        throw new IOException("Error reading service account credential from stream, expecting  'client_id', 'client_email', 'private_key' and 'private_key_id'.");
    }

    private static GoogleCredential fromStreamUser(GenericJson genericJson, HttpTransport httpTransport, JsonFactory jsonFactory) throws IOException {
        String string2 = (String)genericJson.get("client_id");
        String string3 = (String)genericJson.get("client_secret");
        String string4 = (String)genericJson.get("refresh_token");
        if (string2 != null && string3 != null && string4 != null) {
            Credential credential = ((Builder)((Builder)new Builder().setClientSecrets(string2, string3).setTransport(httpTransport)).setJsonFactory(jsonFactory)).build();
            ((GoogleCredential)credential).setRefreshToken(string4);
            credential.refreshToken();
            return credential;
        }
        throw new IOException("Error reading user credential from stream,  expecting 'client_id', 'client_secret' and 'refresh_token'.");
    }

    public static GoogleCredential getApplicationDefault() throws IOException {
        return GoogleCredential.getApplicationDefault(Utils.getDefaultTransport(), Utils.getDefaultJsonFactory());
    }

    public static GoogleCredential getApplicationDefault(HttpTransport httpTransport, JsonFactory jsonFactory) throws IOException {
        Preconditions.checkNotNull(httpTransport);
        Preconditions.checkNotNull(jsonFactory);
        return defaultCredentialProvider.getDefaultCredential(httpTransport, jsonFactory);
    }

    private static PrivateKey privateKeyFromPkcs8(String string2) throws IOException {
        PemReader.Section section = PemReader.readFirstSectionAndClose((Reader)new StringReader(string2), "PRIVATE KEY");
        if (section != null) {
            void var3_6;
            PKCS8EncodedKeySpec pKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(section.getBase64DecodedBytes());
            try {
                PrivateKey privateKey = SecurityUtils.getRsaKeyFactory().generatePrivate((KeySpec)pKCS8EncodedKeySpec);
                return privateKey;
            }
            catch (InvalidKeySpecException invalidKeySpecException) {
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                // empty catch block
            }
            throw OAuth2Utils.exceptionWithCause(new IOException("Unexpected exception reading PKCS data"), (Throwable)var3_6);
        }
        throw new IOException("Invalid PKCS8 data.");
    }

    public GoogleCredential createDelegated(String string2) {
        if (this.serviceAccountPrivateKey == null) {
            return this;
        }
        return this.toBuilder().setServiceAccountUser(string2).build();
    }

    public GoogleCredential createScoped(Collection<String> collection) {
        if (this.serviceAccountPrivateKey == null) {
            return this;
        }
        return this.toBuilder().setServiceAccountScopes(collection).build();
    }

    public boolean createScopedRequired() {
        boolean bl;
        block5 : {
            block4 : {
                if (this.serviceAccountPrivateKey == null) {
                    return false;
                }
                Collection<String> collection = this.serviceAccountScopes;
                if (collection == null) break block4;
                boolean bl2 = collection.isEmpty();
                bl = false;
                if (!bl2) break block5;
            }
            bl = true;
        }
        return bl;
    }

    @Override
    protected TokenResponse executeRefreshToken() throws IOException {
        if (this.serviceAccountPrivateKey == null) {
            return super.executeRefreshToken();
        }
        JsonWebSignature.Header header = new JsonWebSignature.Header();
        header.setAlgorithm("RS256");
        header.setType("JWT");
        header.setKeyId(this.serviceAccountPrivateKeyId);
        GenericJson genericJson = new GenericJson(){
            @com.google.api.client.util.Key(value="aud")
            private Object audience;
            @com.google.api.client.util.Key(value="exp")
            private Long expirationTimeSeconds;
            @com.google.api.client.util.Key(value="iat")
            private Long issuedAtTimeSeconds;
            @com.google.api.client.util.Key(value="iss")
            private String issuer;
            @com.google.api.client.util.Key(value="jti")
            private String jwtId;
            @com.google.api.client.util.Key(value="nbf")
            private Long notBeforeTimeSeconds;
            @com.google.api.client.util.Key(value="sub")
            private String subject;
            @com.google.api.client.util.Key(value="typ")
            private String type;

            public JsonWebToken.Payload clone() {
                return super.clone();
            }

            public final Object getAudience() {
                return this.audience;
            }

            public final List<String> getAudienceAsList() {
                Object object = this.audience;
                if (object == null) {
                    return Collections.emptyList();
                }
                if (object instanceof String) {
                    return Collections.singletonList((Object)((String)object));
                }
                return (List)object;
            }

            public final Long getExpirationTimeSeconds() {
                return this.expirationTimeSeconds;
            }

            public final Long getIssuedAtTimeSeconds() {
                return this.issuedAtTimeSeconds;
            }

            public final String getIssuer() {
                return this.issuer;
            }

            public final String getJwtId() {
                return this.jwtId;
            }

            public final Long getNotBeforeTimeSeconds() {
                return this.notBeforeTimeSeconds;
            }

            public final String getSubject() {
                return this.subject;
            }

            public final String getType() {
                return this.type;
            }

            public JsonWebToken.Payload set(String string2, Object object) {
                return super.set(string2, object);
            }

            public JsonWebToken.Payload setAudience(Object object) {
                this.audience = object;
                return this;
            }

            public JsonWebToken.Payload setExpirationTimeSeconds(Long l) {
                this.expirationTimeSeconds = l;
                return this;
            }

            public JsonWebToken.Payload setIssuedAtTimeSeconds(Long l) {
                this.issuedAtTimeSeconds = l;
                return this;
            }

            public JsonWebToken.Payload setIssuer(String string2) {
                this.issuer = string2;
                return this;
            }

            public JsonWebToken.Payload setJwtId(String string2) {
                this.jwtId = string2;
                return this;
            }

            public JsonWebToken.Payload setNotBeforeTimeSeconds(Long l) {
                this.notBeforeTimeSeconds = l;
                return this;
            }

            public JsonWebToken.Payload setSubject(String string2) {
                this.subject = string2;
                return this;
            }

            public JsonWebToken.Payload setType(String string2) {
                this.type = string2;
                return this;
            }
        };
        long l = this.getClock().currentTimeMillis();
        genericJson.setIssuer(this.serviceAccountId);
        genericJson.setAudience(this.getTokenServerEncodedUrl());
        long l2 = l / 1000L;
        genericJson.setIssuedAtTimeSeconds(l2);
        genericJson.setExpirationTimeSeconds(l2 + 3600L);
        genericJson.setSubject(this.serviceAccountUser);
        genericJson.put("scope", (Object)Joiner.on(' ').join((Iterable<?>)this.serviceAccountScopes));
        try {
            String string2 = JsonWebSignature.signUsingRsaSha256(this.serviceAccountPrivateKey, this.getJsonFactory(), header, genericJson);
            TokenRequest tokenRequest = new TokenRequest(this.getTransport(), this.getJsonFactory(), new GenericUrl(this.getTokenServerEncodedUrl()), "urn:ietf:params:oauth:grant-type:jwt-bearer");
            tokenRequest.put("assertion", (Object)string2);
            TokenResponse tokenResponse = tokenRequest.execute();
            return tokenResponse;
        }
        catch (GeneralSecurityException generalSecurityException) {
            IOException iOException = new IOException();
            iOException.initCause((Throwable)generalSecurityException);
            throw iOException;
        }
    }

    public final String getServiceAccountId() {
        return this.serviceAccountId;
    }

    public final PrivateKey getServiceAccountPrivateKey() {
        return this.serviceAccountPrivateKey;
    }

    public final String getServiceAccountPrivateKeyId() {
        return this.serviceAccountPrivateKeyId;
    }

    public final String getServiceAccountProjectId() {
        return this.serviceAccountProjectId;
    }

    public final Collection<String> getServiceAccountScopes() {
        return this.serviceAccountScopes;
    }

    public final String getServiceAccountScopesAsString() {
        if (this.serviceAccountScopes == null) {
            return null;
        }
        return Joiner.on(' ').join((Iterable<?>)this.serviceAccountScopes);
    }

    public final String getServiceAccountUser() {
        return this.serviceAccountUser;
    }

    @Override
    public GoogleCredential setAccessToken(String string2) {
        return (GoogleCredential)super.setAccessToken(string2);
    }

    @Override
    public GoogleCredential setExpirationTimeMilliseconds(Long l) {
        return (GoogleCredential)super.setExpirationTimeMilliseconds(l);
    }

    @Override
    public GoogleCredential setExpiresInSeconds(Long l) {
        return (GoogleCredential)super.setExpiresInSeconds(l);
    }

    @Override
    public GoogleCredential setFromTokenResponse(TokenResponse tokenResponse) {
        return (GoogleCredential)super.setFromTokenResponse(tokenResponse);
    }

    @Override
    public GoogleCredential setRefreshToken(String string2) {
        if (string2 != null) {
            boolean bl = this.getJsonFactory() != null && this.getTransport() != null && this.getClientAuthentication() != null;
            Preconditions.checkArgument(bl, "Please use the Builder and call setJsonFactory, setTransport and setClientSecrets");
        }
        return (GoogleCredential)super.setRefreshToken(string2);
    }

    public Builder toBuilder() {
        Credential.Builder builder = ((Builder)((Builder)((Builder)new Builder().setServiceAccountPrivateKey(this.serviceAccountPrivateKey).setServiceAccountPrivateKeyId(this.serviceAccountPrivateKeyId).setServiceAccountId(this.serviceAccountId).setServiceAccountProjectId(this.serviceAccountProjectId).setServiceAccountUser(this.serviceAccountUser).setServiceAccountScopes(this.serviceAccountScopes).setTokenServerEncodedUrl(this.getTokenServerEncodedUrl())).setTransport(this.getTransport())).setJsonFactory(this.getJsonFactory())).setClock(this.getClock());
        ((Builder)builder).setClientAuthentication(this.getClientAuthentication());
        return builder;
    }

    public static class Builder
    extends Credential.Builder {
        String serviceAccountId;
        PrivateKey serviceAccountPrivateKey;
        String serviceAccountPrivateKeyId;
        String serviceAccountProjectId;
        Collection<String> serviceAccountScopes;
        String serviceAccountUser;

        public Builder() {
            super(BearerToken.authorizationHeaderAccessMethod());
            this.setTokenServerEncodedUrl("https://oauth2.googleapis.com/token");
        }

        @Override
        public Builder addRefreshListener(CredentialRefreshListener credentialRefreshListener) {
            return (Builder)super.addRefreshListener(credentialRefreshListener);
        }

        @Override
        public GoogleCredential build() {
            return new GoogleCredential(this);
        }

        public final String getServiceAccountId() {
            return this.serviceAccountId;
        }

        public final PrivateKey getServiceAccountPrivateKey() {
            return this.serviceAccountPrivateKey;
        }

        public final String getServiceAccountPrivateKeyId() {
            return this.serviceAccountPrivateKeyId;
        }

        public final String getServiceAccountProjectId() {
            return this.serviceAccountProjectId;
        }

        public final Collection<String> getServiceAccountScopes() {
            return this.serviceAccountScopes;
        }

        public final String getServiceAccountUser() {
            return this.serviceAccountUser;
        }

        @Override
        public Builder setClientAuthentication(HttpExecuteInterceptor httpExecuteInterceptor) {
            return (Builder)super.setClientAuthentication(httpExecuteInterceptor);
        }

        public Builder setClientSecrets(GoogleClientSecrets googleClientSecrets) {
            GoogleClientSecrets.Details details = googleClientSecrets.getDetails();
            this.setClientAuthentication(new ClientParametersAuthentication(details.getClientId(), details.getClientSecret()));
            return this;
        }

        public Builder setClientSecrets(String string2, String string3) {
            this.setClientAuthentication(new ClientParametersAuthentication(string2, string3));
            return this;
        }

        @Override
        public Builder setClock(Clock clock) {
            return (Builder)super.setClock(clock);
        }

        @Override
        public Builder setJsonFactory(JsonFactory jsonFactory) {
            return (Builder)super.setJsonFactory(jsonFactory);
        }

        @Override
        public Builder setRefreshListeners(Collection<CredentialRefreshListener> collection) {
            return (Builder)super.setRefreshListeners(collection);
        }

        @Override
        public Builder setRequestInitializer(HttpRequestInitializer httpRequestInitializer) {
            return (Builder)super.setRequestInitializer(httpRequestInitializer);
        }

        public Builder setServiceAccountId(String string2) {
            this.serviceAccountId = string2;
            return this;
        }

        public Builder setServiceAccountPrivateKey(PrivateKey privateKey) {
            this.serviceAccountPrivateKey = privateKey;
            return this;
        }

        public Builder setServiceAccountPrivateKeyFromP12File(File file) throws GeneralSecurityException, IOException {
            this.setServiceAccountPrivateKeyFromP12File((InputStream)new FileInputStream(file));
            return this;
        }

        public Builder setServiceAccountPrivateKeyFromP12File(InputStream inputStream) throws GeneralSecurityException, IOException {
            this.serviceAccountPrivateKey = SecurityUtils.loadPrivateKeyFromKeyStore(SecurityUtils.getPkcs12KeyStore(), inputStream, "notasecret", "privatekey", "notasecret");
            return this;
        }

        public Builder setServiceAccountPrivateKeyFromPemFile(File file) throws GeneralSecurityException, IOException {
            byte[] arrby = PemReader.readFirstSectionAndClose((Reader)new FileReader(file), "PRIVATE KEY").getBase64DecodedBytes();
            this.serviceAccountPrivateKey = SecurityUtils.getRsaKeyFactory().generatePrivate((KeySpec)new PKCS8EncodedKeySpec(arrby));
            return this;
        }

        public Builder setServiceAccountPrivateKeyId(String string2) {
            this.serviceAccountPrivateKeyId = string2;
            return this;
        }

        public Builder setServiceAccountProjectId(String string2) {
            this.serviceAccountProjectId = string2;
            return this;
        }

        public Builder setServiceAccountScopes(Collection<String> collection) {
            this.serviceAccountScopes = collection;
            return this;
        }

        public Builder setServiceAccountUser(String string2) {
            this.serviceAccountUser = string2;
            return this;
        }

        @Override
        public Builder setTokenServerEncodedUrl(String string2) {
            return (Builder)super.setTokenServerEncodedUrl(string2);
        }

        @Override
        public Builder setTokenServerUrl(GenericUrl genericUrl) {
            return (Builder)super.setTokenServerUrl(genericUrl);
        }

        @Override
        public Builder setTransport(HttpTransport httpTransport) {
            return (Builder)super.setTransport(httpTransport);
        }
    }

}

