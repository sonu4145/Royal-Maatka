/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.base.StandardSystemProperty
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.Map
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.google.api.client.googleapis.services;

import com.google.api.client.googleapis.GoogleUtils;
import com.google.api.client.googleapis.MethodOverride;
import com.google.api.client.googleapis.batch.BatchCallback;
import com.google.api.client.googleapis.batch.BatchRequest;
import com.google.api.client.googleapis.media.MediaHttpDownloader;
import com.google.api.client.googleapis.media.MediaHttpUploader;
import com.google.api.client.googleapis.services.AbstractGoogleClient;
import com.google.api.client.http.AbstractInputStreamContent;
import com.google.api.client.http.EmptyContent;
import com.google.api.client.http.GZipEncoding;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpContent;
import com.google.api.client.http.HttpEncoding;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.HttpResponseException;
import com.google.api.client.http.HttpResponseInterceptor;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.UriTemplate;
import com.google.api.client.util.GenericData;
import com.google.api.client.util.ObjectParser;
import com.google.api.client.util.Preconditions;
import com.google.common.base.StandardSystemProperty;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class AbstractGoogleClientRequest<T>
extends GenericData {
    private static final String API_VERSION_HEADER = "X-Goog-Api-Client";
    public static final String USER_AGENT_SUFFIX = "Google-API-Java-Client";
    private final AbstractGoogleClient abstractGoogleClient;
    private boolean disableGZipContent;
    private MediaHttpDownloader downloader;
    private final HttpContent httpContent;
    private HttpHeaders lastResponseHeaders;
    private int lastStatusCode = -1;
    private String lastStatusMessage;
    private HttpHeaders requestHeaders = new HttpHeaders();
    private final String requestMethod;
    private Class<T> responseClass;
    private boolean returnRawInputStream;
    private MediaHttpUploader uploader;
    private final String uriTemplate;

    protected AbstractGoogleClientRequest(AbstractGoogleClient abstractGoogleClient, String string2, String string3, HttpContent httpContent, Class<T> class_) {
        this.responseClass = Preconditions.checkNotNull(class_);
        this.abstractGoogleClient = Preconditions.checkNotNull(abstractGoogleClient);
        this.requestMethod = Preconditions.checkNotNull(string2);
        this.uriTemplate = Preconditions.checkNotNull(string3);
        this.httpContent = httpContent;
        String string4 = abstractGoogleClient.getApplicationName();
        if (string4 != null) {
            HttpHeaders httpHeaders = this.requestHeaders;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string4);
            stringBuilder.append(" ");
            stringBuilder.append(USER_AGENT_SUFFIX);
            stringBuilder.append("/");
            stringBuilder.append(GoogleUtils.VERSION);
            httpHeaders.setUserAgent(stringBuilder.toString());
        } else {
            HttpHeaders httpHeaders = this.requestHeaders;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Google-API-Java-Client/");
            stringBuilder.append(GoogleUtils.VERSION);
            httpHeaders.setUserAgent(stringBuilder.toString());
        }
        this.requestHeaders.set(API_VERSION_HEADER, ApiClientVersion.DEFAULT_VERSION);
    }

    private HttpRequest buildHttpRequest(boolean bl) throws IOException {
        MediaHttpUploader mediaHttpUploader = this.uploader;
        boolean bl2 = true;
        boolean bl3 = mediaHttpUploader == null;
        Preconditions.checkArgument(bl3);
        if (bl && !this.requestMethod.equals((Object)"GET")) {
            bl2 = false;
        }
        Preconditions.checkArgument(bl2);
        String string2 = bl ? "HEAD" : this.requestMethod;
        HttpRequest httpRequest = this.getAbstractGoogleClient().getRequestFactory().buildRequest(string2, this.buildHttpRequestUrl(), this.httpContent);
        new MethodOverride().intercept(httpRequest);
        httpRequest.setParser(this.getAbstractGoogleClient().getObjectParser());
        if (this.httpContent == null && (this.requestMethod.equals((Object)"POST") || this.requestMethod.equals((Object)"PUT") || this.requestMethod.equals((Object)"PATCH"))) {
            httpRequest.setContent(new EmptyContent());
        }
        httpRequest.getHeaders().putAll((Map<? extends String, ?>)this.requestHeaders);
        if (!this.disableGZipContent) {
            httpRequest.setEncoding(new GZipEncoding());
        }
        httpRequest.setResponseReturnRawInputStream(this.returnRawInputStream);
        httpRequest.setResponseInterceptor(new HttpResponseInterceptor(httpRequest.getResponseInterceptor(), httpRequest){
            final /* synthetic */ HttpRequest val$httpRequest;
            final /* synthetic */ HttpResponseInterceptor val$responseInterceptor;
            {
                this.val$responseInterceptor = httpResponseInterceptor;
                this.val$httpRequest = httpRequest;
            }

            @Override
            public void interceptResponse(HttpResponse httpResponse) throws IOException {
                HttpResponseInterceptor httpResponseInterceptor = this.val$responseInterceptor;
                if (httpResponseInterceptor != null) {
                    httpResponseInterceptor.interceptResponse(httpResponse);
                }
                if (!httpResponse.isSuccessStatusCode()) {
                    if (!this.val$httpRequest.getThrowExceptionOnExecuteError()) {
                        return;
                    }
                    throw AbstractGoogleClientRequest.this.newExceptionOnError(httpResponse);
                }
            }
        });
        return httpRequest;
    }

    private HttpResponse executeUnparsed(boolean bl) throws IOException {
        HttpResponse httpResponse;
        if (this.uploader == null) {
            httpResponse = this.buildHttpRequest(bl).execute();
        } else {
            GenericUrl genericUrl = this.buildHttpRequestUrl();
            boolean bl2 = this.getAbstractGoogleClient().getRequestFactory().buildRequest(this.requestMethod, genericUrl, this.httpContent).getThrowExceptionOnExecuteError();
            httpResponse = this.uploader.setInitiationHeaders(this.requestHeaders).setDisableGZipContent(this.disableGZipContent).upload(genericUrl);
            httpResponse.getRequest().setParser(this.getAbstractGoogleClient().getObjectParser());
            if (bl2 && !httpResponse.isSuccessStatusCode()) {
                throw this.newExceptionOnError(httpResponse);
            }
        }
        this.lastResponseHeaders = httpResponse.getHeaders();
        this.lastStatusCode = httpResponse.getStatusCode();
        this.lastStatusMessage = httpResponse.getStatusMessage();
        return httpResponse;
    }

    public HttpRequest buildHttpRequest() throws IOException {
        return this.buildHttpRequest(false);
    }

    public GenericUrl buildHttpRequestUrl() {
        return new GenericUrl(UriTemplate.expand(this.abstractGoogleClient.getBaseUrl(), this.uriTemplate, (Object)this, true));
    }

    protected HttpRequest buildHttpRequestUsingHead() throws IOException {
        return this.buildHttpRequest(true);
    }

    protected final void checkRequiredParameter(Object object, String string2) {
        boolean bl = this.abstractGoogleClient.getSuppressRequiredParameterChecks() || object != null;
        Preconditions.checkArgument(bl, "Required parameter %s must be specified", string2);
    }

    public T execute() throws IOException {
        return this.executeUnparsed().parseAs(this.responseClass);
    }

    public void executeAndDownloadTo(OutputStream outputStream) throws IOException {
        this.executeUnparsed().download(outputStream);
    }

    public InputStream executeAsInputStream() throws IOException {
        return this.executeUnparsed().getContent();
    }

    protected HttpResponse executeMedia() throws IOException {
        this.set("alt", "media");
        return this.executeUnparsed();
    }

    protected void executeMediaAndDownloadTo(OutputStream outputStream) throws IOException {
        MediaHttpDownloader mediaHttpDownloader = this.downloader;
        if (mediaHttpDownloader == null) {
            this.executeMedia().download(outputStream);
            return;
        }
        mediaHttpDownloader.download(this.buildHttpRequestUrl(), this.requestHeaders, outputStream);
    }

    protected InputStream executeMediaAsInputStream() throws IOException {
        return this.executeMedia().getContent();
    }

    public HttpResponse executeUnparsed() throws IOException {
        return this.executeUnparsed(false);
    }

    protected HttpResponse executeUsingHead() throws IOException {
        boolean bl = this.uploader == null;
        Preconditions.checkArgument(bl);
        HttpResponse httpResponse = this.executeUnparsed(true);
        httpResponse.ignore();
        return httpResponse;
    }

    public AbstractGoogleClient getAbstractGoogleClient() {
        return this.abstractGoogleClient;
    }

    public final boolean getDisableGZipContent() {
        return this.disableGZipContent;
    }

    public final HttpContent getHttpContent() {
        return this.httpContent;
    }

    public final HttpHeaders getLastResponseHeaders() {
        return this.lastResponseHeaders;
    }

    public final int getLastStatusCode() {
        return this.lastStatusCode;
    }

    public final String getLastStatusMessage() {
        return this.lastStatusMessage;
    }

    public final MediaHttpDownloader getMediaHttpDownloader() {
        return this.downloader;
    }

    public final MediaHttpUploader getMediaHttpUploader() {
        return this.uploader;
    }

    public final HttpHeaders getRequestHeaders() {
        return this.requestHeaders;
    }

    public final String getRequestMethod() {
        return this.requestMethod;
    }

    public final Class<T> getResponseClass() {
        return this.responseClass;
    }

    public final boolean getReturnRawInputSteam() {
        return this.returnRawInputStream;
    }

    public final String getUriTemplate() {
        return this.uriTemplate;
    }

    protected final void initializeMediaDownload() {
        HttpRequestFactory httpRequestFactory = this.abstractGoogleClient.getRequestFactory();
        this.downloader = new MediaHttpDownloader(httpRequestFactory.getTransport(), httpRequestFactory.getInitializer());
    }

    protected final void initializeMediaUpload(AbstractInputStreamContent abstractInputStreamContent) {
        MediaHttpUploader mediaHttpUploader;
        HttpRequestFactory httpRequestFactory = this.abstractGoogleClient.getRequestFactory();
        this.uploader = mediaHttpUploader = new MediaHttpUploader(abstractInputStreamContent, httpRequestFactory.getTransport(), httpRequestFactory.getInitializer());
        mediaHttpUploader.setInitiationRequestMethod(this.requestMethod);
        HttpContent httpContent = this.httpContent;
        if (httpContent != null) {
            this.uploader.setMetadata(httpContent);
        }
    }

    protected IOException newExceptionOnError(HttpResponse httpResponse) {
        return new HttpResponseException(httpResponse);
    }

    public final <E> void queue(BatchRequest batchRequest, Class<E> class_, BatchCallback<T, E> batchCallback) throws IOException {
        boolean bl = this.uploader == null;
        Preconditions.checkArgument(bl, "Batching media requests is not supported");
        batchRequest.queue(this.buildHttpRequest(), this.getResponseClass(), class_, batchCallback);
    }

    @Override
    public AbstractGoogleClientRequest<T> set(String string2, Object object) {
        return (AbstractGoogleClientRequest)super.set(string2, object);
    }

    public AbstractGoogleClientRequest<T> setDisableGZipContent(boolean bl) {
        this.disableGZipContent = bl;
        return this;
    }

    public AbstractGoogleClientRequest<T> setRequestHeaders(HttpHeaders httpHeaders) {
        this.requestHeaders = httpHeaders;
        return this;
    }

    public AbstractGoogleClientRequest<T> setReturnRawInputStream(boolean bl) {
        this.returnRawInputStream = bl;
        return this;
    }

}

