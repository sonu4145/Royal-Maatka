/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.security.GeneralSecurityException
 *  java.security.PrivateKey
 *  java.security.Signature
 */
package com.google.api.client.auth.oauth;

import com.google.api.client.auth.oauth.OAuthSigner;
import com.google.api.client.util.Base64;
import com.google.api.client.util.SecurityUtils;
import com.google.api.client.util.StringUtils;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.Signature;

public final class OAuthRsaSigner
implements OAuthSigner {
    public PrivateKey privateKey;

    @Override
    public String computeSignature(String string2) throws GeneralSecurityException {
        Signature signature = SecurityUtils.getSha1WithRsaSignatureAlgorithm();
        byte[] arrby = StringUtils.getBytesUtf8(string2);
        return Base64.encodeBase64String(SecurityUtils.sign(signature, this.privateKey, arrby));
    }

    @Override
    public String getSignatureMethod() {
        return "RSA-SHA1";
    }
}

