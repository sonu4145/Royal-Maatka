/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.api.client.http.GenericUrl
 *  com.google.common.base.Splitter
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.ListIterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.google.api.client.http;

import com.google.api.client.http.GenericUrl;
import com.google.api.client.util.Data;
import com.google.api.client.util.FieldInfo;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Types;
import com.google.api.client.util.escape.CharEscapers;
import com.google.common.base.Splitter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

public class UriTemplate {
    private static final String COMPOSITE_NON_EXPLODE_JOINER = ",";
    private static final Map<Character, CompositeOutput> COMPOSITE_PREFIXES = new HashMap();

    static {
        CompositeOutput.values();
    }

    public static String expand(String string2, Object object, boolean bl) {
        Map<String, Object> map = UriTemplate.getMap(object);
        StringBuilder stringBuilder = new StringBuilder();
        int n = string2.length();
        int n2 = 0;
        while (n2 < n) {
            int n3 = string2.indexOf(123, n2);
            if (n3 == -1) {
                if (n2 == 0 && !bl) {
                    return string2;
                }
                stringBuilder.append(string2.substring(n2));
                break;
            }
            stringBuilder.append(string2.substring(n2, n3));
            int n4 = string2.indexOf(125, n3 + 2);
            int n5 = n4 + 1;
            String string3 = string2.substring(n3 + 1, n4);
            CompositeOutput compositeOutput = UriTemplate.getCompositeOutput(string3);
            ListIterator listIterator = Splitter.on((char)',').splitToList((CharSequence)string3).listIterator();
            boolean bl2 = true;
            while (listIterator.hasNext()) {
                String string4;
                String string5;
                Object object2;
                String string6 = (String)listIterator.next();
                boolean bl3 = string6.endsWith("*");
                int n6 = listIterator.nextIndex() == 1 ? compositeOutput.getVarNameStartIndex() : 0;
                int n7 = string6.length();
                if (bl3) {
                    --n7;
                }
                if ((object2 = map.remove((Object)(string5 = string6.substring(n6, n7)))) == null) continue;
                if (!bl2) {
                    stringBuilder.append(compositeOutput.getExplodeJoiner());
                } else {
                    stringBuilder.append(compositeOutput.getOutputPrefix());
                    bl2 = false;
                }
                if (object2 instanceof Iterator) {
                    string4 = UriTemplate.getListPropertyValue(string5, (Iterator)object2, bl3, compositeOutput);
                } else if (!(object2 instanceof Iterable) && !object2.getClass().isArray()) {
                    if (object2.getClass().isEnum()) {
                        String string7 = FieldInfo.of((Enum)object2).getName();
                        if (string7 == null) {
                            string7 = object2.toString();
                        }
                        string4 = UriTemplate.getSimpleValue(string5, string7, compositeOutput);
                    } else {
                        string4 = !Data.isValueOfPrimitiveType(object2) ? UriTemplate.getMapPropertyValue(string5, UriTemplate.getMap(object2), bl3, compositeOutput) : UriTemplate.getSimpleValue(string5, object2.toString(), compositeOutput);
                    }
                } else {
                    string4 = UriTemplate.getListPropertyValue(string5, Types.iterableOf(object2).iterator(), bl3, compositeOutput);
                }
                stringBuilder.append((Object)string4);
            }
            n2 = n5;
        }
        if (bl) {
            GenericUrl.addQueryParams((Set)map.entrySet(), (StringBuilder)stringBuilder, (boolean)false);
        }
        return stringBuilder.toString();
    }

    public static String expand(String string2, String string3, Object object, boolean bl) {
        if (string3.startsWith("/")) {
            GenericUrl genericUrl = new GenericUrl(string2);
            genericUrl.setRawPath(null);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(genericUrl.build());
            stringBuilder.append(string3);
            string3 = stringBuilder.toString();
        } else if (!string3.startsWith("http://") && !string3.startsWith("https://")) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(string3);
            string3 = stringBuilder.toString();
        }
        return UriTemplate.expand(string3, object, bl);
    }

    static CompositeOutput getCompositeOutput(String string2) {
        CompositeOutput compositeOutput = (CompositeOutput)((Object)COMPOSITE_PREFIXES.get((Object)Character.valueOf((char)string2.charAt(0))));
        if (compositeOutput == null) {
            compositeOutput = CompositeOutput.SIMPLE;
        }
        return compositeOutput;
    }

    private static String getListPropertyValue(String string2, Iterator<?> iterator, boolean bl, CompositeOutput compositeOutput) {
        String string3;
        if (!iterator.hasNext()) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (bl) {
            string3 = compositeOutput.getExplodeJoiner();
        } else {
            if (compositeOutput.requiresVarAssignment()) {
                stringBuilder.append(CharEscapers.escapeUriPath(string2));
                stringBuilder.append("=");
            }
            string3 = COMPOSITE_NON_EXPLODE_JOINER;
        }
        while (iterator.hasNext()) {
            if (bl && compositeOutput.requiresVarAssignment()) {
                stringBuilder.append(CharEscapers.escapeUriPath(string2));
                stringBuilder.append("=");
            }
            stringBuilder.append(compositeOutput.getEncodedValue(iterator.next().toString()));
            if (!iterator.hasNext()) continue;
            stringBuilder.append(string3);
        }
        return stringBuilder.toString();
    }

    private static Map<String, Object> getMap(Object object) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (Map.Entry entry : Data.mapOf(object).entrySet()) {
            Object object2 = entry.getValue();
            if (object2 == null || Data.isNull(object2)) continue;
            linkedHashMap.put(entry.getKey(), object2);
        }
        return linkedHashMap;
    }

    private static String getMapPropertyValue(String string2, Map<String, Object> map, boolean bl, CompositeOutput compositeOutput) {
        if (map.isEmpty()) {
            return "";
        }
        StringBuilder stringBuilder = new StringBuilder();
        String string3 = "=";
        String string4 = COMPOSITE_NON_EXPLODE_JOINER;
        if (bl) {
            string4 = compositeOutput.getExplodeJoiner();
        } else {
            if (compositeOutput.requiresVarAssignment()) {
                stringBuilder.append(CharEscapers.escapeUriPath(string2));
                stringBuilder.append(string3);
            }
            string3 = string4;
        }
        Iterator iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            String string5 = compositeOutput.getEncodedValue((String)entry.getKey());
            String string6 = compositeOutput.getEncodedValue(entry.getValue().toString());
            stringBuilder.append(string5);
            stringBuilder.append(string3);
            stringBuilder.append(string6);
            if (!iterator.hasNext()) continue;
            stringBuilder.append(string4);
        }
        return stringBuilder.toString();
    }

    private static String getSimpleValue(String string2, String string3, CompositeOutput compositeOutput) {
        if (compositeOutput.requiresVarAssignment()) {
            Object[] arrobject = new Object[]{string2, compositeOutput.getEncodedValue(string3)};
            return String.format((String)"%s=%s", (Object[])arrobject);
        }
        return compositeOutput.getEncodedValue(string3);
    }

    private static final class CompositeOutput
    extends Enum<CompositeOutput> {
        private static final /* synthetic */ CompositeOutput[] $VALUES;
        public static final /* enum */ CompositeOutput AMP;
        public static final /* enum */ CompositeOutput DOT;
        public static final /* enum */ CompositeOutput FORWARD_SLASH;
        public static final /* enum */ CompositeOutput HASH;
        public static final /* enum */ CompositeOutput PLUS;
        public static final /* enum */ CompositeOutput QUERY;
        public static final /* enum */ CompositeOutput SEMI_COLON;
        public static final /* enum */ CompositeOutput SIMPLE;
        private final String explodeJoiner;
        private final String outputPrefix;
        private final Character propertyPrefix;
        private final boolean requiresVarAssignment;
        private final boolean reservedExpansion;

        static {
            CompositeOutput compositeOutput;
            CompositeOutput compositeOutput2;
            CompositeOutput compositeOutput3;
            CompositeOutput compositeOutput4;
            CompositeOutput compositeOutput5;
            CompositeOutput compositeOutput6;
            CompositeOutput compositeOutput7;
            CompositeOutput compositeOutput8;
            PLUS = compositeOutput3 = new CompositeOutput(Character.valueOf((char)'+'), "", UriTemplate.COMPOSITE_NON_EXPLODE_JOINER, false, true);
            HASH = compositeOutput5 = new CompositeOutput(Character.valueOf((char)'#'), "#", UriTemplate.COMPOSITE_NON_EXPLODE_JOINER, false, true);
            DOT = compositeOutput8 = new CompositeOutput(Character.valueOf((char)'.'), ".", ".", false, false);
            FORWARD_SLASH = compositeOutput2 = new CompositeOutput(Character.valueOf((char)'/'), "/", "/", false, false);
            SEMI_COLON = compositeOutput4 = new CompositeOutput(Character.valueOf((char)';'), ";", ";", true, false);
            QUERY = compositeOutput6 = new CompositeOutput(Character.valueOf((char)'?'), "?", "&", true, false);
            AMP = compositeOutput = new CompositeOutput(Character.valueOf((char)'&'), "&", "&", true, false);
            SIMPLE = compositeOutput7 = new CompositeOutput(null, "", UriTemplate.COMPOSITE_NON_EXPLODE_JOINER, false, false);
            CompositeOutput[] arrcompositeOutput = new CompositeOutput[]{PLUS, HASH, DOT, FORWARD_SLASH, SEMI_COLON, QUERY, AMP, compositeOutput7};
            $VALUES = arrcompositeOutput;
        }

        private CompositeOutput(Character c, String string3, String string4, boolean bl, boolean bl2) {
            this.propertyPrefix = c;
            this.outputPrefix = Preconditions.checkNotNull(string3);
            this.explodeJoiner = Preconditions.checkNotNull(string4);
            this.requiresVarAssignment = bl;
            this.reservedExpansion = bl2;
            if (c != null) {
                COMPOSITE_PREFIXES.put((Object)c, (Object)this);
            }
        }

        private String getEncodedValue(String string2) {
            if (this.reservedExpansion) {
                return CharEscapers.escapeUriPathWithoutReserved(string2);
            }
            return CharEscapers.escapeUriConformant(string2);
        }

        public static CompositeOutput valueOf(String string2) {
            return (CompositeOutput)Enum.valueOf(CompositeOutput.class, (String)string2);
        }

        public static CompositeOutput[] values() {
            return (CompositeOutput[])$VALUES.clone();
        }

        String getExplodeJoiner() {
            return this.explodeJoiner;
        }

        String getOutputPrefix() {
            return this.outputPrefix;
        }

        int getVarNameStartIndex() {
            return this.propertyPrefix != null;
        }

        boolean requiresVarAssignment() {
            return this.requiresVarAssignment;
        }
    }

}

