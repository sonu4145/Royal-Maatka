/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.Reader
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Type
 *  java.nio.charset.Charset
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Set
 */
package com.google.api.client.json;

import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.JsonParser;
import com.google.api.client.json.JsonToken;
import com.google.api.client.util.ObjectParser;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.Sets;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class JsonObjectParser
implements ObjectParser {
    private final JsonFactory jsonFactory;
    private final Set<String> wrapperKeys;

    public JsonObjectParser(JsonFactory jsonFactory) {
        this(new Object(jsonFactory){
            final JsonFactory jsonFactory;
            Collection<String> wrapperKeys = Sets.newHashSet();
            {
                this.jsonFactory = Preconditions.checkNotNull(jsonFactory);
            }

            public JsonObjectParser build() {
                return new JsonObjectParser(this);
            }

            public final JsonFactory getJsonFactory() {
                return this.jsonFactory;
            }

            public final Collection<String> getWrapperKeys() {
                return this.wrapperKeys;
            }

            public Builder setWrapperKeys(Collection<String> collection) {
                this.wrapperKeys = collection;
                return this;
            }
        });
    }

    protected JsonObjectParser(Builder builder) {
        this.jsonFactory = builder.jsonFactory;
        this.wrapperKeys = new HashSet(builder.wrapperKeys);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void initializeParser(JsonParser jsonParser) throws IOException {
        boolean bl;
        if (this.wrapperKeys.isEmpty()) {
            return;
        }
        try {
            bl = jsonParser.skipToKey(this.wrapperKeys) != null && jsonParser.getCurrentToken() != JsonToken.END_OBJECT;
        }
        catch (Throwable throwable) {
            jsonParser.close();
            throw throwable;
        }
        Object[] arrobject = new Object[]{this.wrapperKeys};
        Preconditions.checkArgument(bl, "wrapper key(s) not found: %s", arrobject);
    }

    public final JsonFactory getJsonFactory() {
        return this.jsonFactory;
    }

    public Set<String> getWrapperKeys() {
        return Collections.unmodifiableSet(this.wrapperKeys);
    }

    @Override
    public <T> T parseAndClose(InputStream inputStream, Charset charset, Class<T> class_) throws IOException {
        return (T)this.parseAndClose(inputStream, charset, (Type)class_);
    }

    @Override
    public Object parseAndClose(InputStream inputStream, Charset charset, Type type) throws IOException {
        JsonParser jsonParser = this.jsonFactory.createJsonParser(inputStream, charset);
        this.initializeParser(jsonParser);
        return jsonParser.parse(type, true);
    }

    @Override
    public <T> T parseAndClose(Reader reader, Class<T> class_) throws IOException {
        return (T)this.parseAndClose(reader, (Type)class_);
    }

    @Override
    public Object parseAndClose(Reader reader, Type type) throws IOException {
        JsonParser jsonParser = this.jsonFactory.createJsonParser(reader);
        this.initializeParser(jsonParser);
        return jsonParser.parse(type, true);
    }

}

