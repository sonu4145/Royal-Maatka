/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.InstantiationException
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.UnsupportedOperationException
 *  java.lang.reflect.Array
 *  java.lang.reflect.GenericArrayType
 *  java.lang.reflect.GenericDeclaration
 *  java.lang.reflect.ParameterizedType
 *  java.lang.reflect.Type
 *  java.lang.reflect.TypeVariable
 *  java.lang.reflect.WildcardType
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.NoSuchElementException
 */
package com.google.api.client.util;

import com.google.api.client.util.Preconditions;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

public class Types {
    private Types() {
    }

    private static Type getActualParameterAtPosition(Type type, Class<?> class_, int n) {
        ParameterizedType parameterizedType = Types.getSuperParameterizedType(type, class_);
        if (parameterizedType == null) {
            return null;
        }
        Type type2 = parameterizedType.getActualTypeArguments()[n];
        if (type2 instanceof TypeVariable) {
            Type type3 = Types.resolveTypeVariable((List<Type>)Arrays.asList((Object[])new Type[]{type}), (TypeVariable)type2);
            if (type3 != null) {
                return type3;
            }
        }
        return type2;
    }

    public static Type getArrayComponentType(Type type) {
        if (type instanceof GenericArrayType) {
            return ((GenericArrayType)type).getGenericComponentType();
        }
        return ((Class)type).getComponentType();
    }

    public static Type getBound(WildcardType wildcardType) {
        Type[] arrtype = wildcardType.getLowerBounds();
        if (arrtype.length != 0) {
            return arrtype[0];
        }
        return wildcardType.getUpperBounds()[0];
    }

    public static Type getIterableParameter(Type type) {
        return Types.getActualParameterAtPosition(type, Iterable.class, 0);
    }

    public static Type getMapValueParameter(Type type) {
        return Types.getActualParameterAtPosition(type, Map.class, 1);
    }

    public static Class<?> getRawArrayComponentType(List<Type> list, Type type) {
        if (type instanceof TypeVariable) {
            type = Types.resolveTypeVariable(list, (TypeVariable)type);
        }
        if (type instanceof GenericArrayType) {
            return Array.newInstance(Types.getRawArrayComponentType(list, Types.getArrayComponentType(type)), (int)0).getClass();
        }
        if (type instanceof Class) {
            return (Class)type;
        }
        if (type instanceof ParameterizedType) {
            return Types.getRawClass((ParameterizedType)type);
        }
        boolean bl = type == null;
        Preconditions.checkArgument(bl, "wildcard type is not supported: %s", new Object[]{type});
        return Object.class;
    }

    public static Class<?> getRawClass(ParameterizedType parameterizedType) {
        return (Class)parameterizedType.getRawType();
    }

    public static ParameterizedType getSuperParameterizedType(Type type, Class<?> class_) {
        if (type instanceof Class || type instanceof ParameterizedType) {
            block0 : while (type != null && type != Object.class) {
                Class<?> class_2;
                if (type instanceof Class) {
                    class_2 = (Class<?>)type;
                } else {
                    ParameterizedType parameterizedType = (ParameterizedType)type;
                    Class<?> class_3 = Types.getRawClass(parameterizedType);
                    if (class_3 == class_) {
                        return parameterizedType;
                    }
                    if (class_.isInterface()) {
                        for (Type type2 : class_3.getGenericInterfaces()) {
                            Class<?> class_4 = type2 instanceof Class ? (Class<?>)type2 : Types.getRawClass((ParameterizedType)type2);
                            if (!class_.isAssignableFrom(class_4)) continue;
                            type = type2;
                            continue block0;
                        }
                    }
                    class_2 = class_3;
                }
                type = class_2.getGenericSuperclass();
            }
        }
        return null;
    }

    /*
     * Exception decompiling
     */
    private static IllegalArgumentException handleExceptionForNewInstance(Exception var0, Class<?> var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl90 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static boolean isArray(Type type) {
        return type instanceof GenericArrayType || type instanceof Class && ((Class)type).isArray();
        {
        }
    }

    public static boolean isAssignableToOrFrom(Class<?> class_, Class<?> class_2) {
        return class_.isAssignableFrom(class_2) || class_2.isAssignableFrom(class_);
        {
        }
    }

    public static <T> Iterable<T> iterableOf(final Object object) {
        if (object instanceof Iterable) {
            return (Iterable)object;
        }
        Class class_ = object.getClass();
        Preconditions.checkArgument(class_.isArray(), "not an array or Iterable: %s", new Object[]{class_});
        if (!class_.getComponentType().isPrimitive()) {
            return Arrays.asList((Object[])((Object[])object));
        }
        return new Iterable<T>(){

            public Iterator<T> iterator() {
                return new Iterator<T>(){
                    int index;
                    final int length;
                    {
                        this.length = Array.getLength((Object)object);
                        this.index = 0;
                    }

                    public boolean hasNext() {
                        return this.index < this.length;
                    }

                    public T next() {
                        if (this.hasNext()) {
                            Object object = object;
                            int n = this.index;
                            this.index = n + 1;
                            return (T)Array.get((Object)object, (int)n);
                        }
                        throw new NoSuchElementException();
                    }

                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }

        };
    }

    public static <T> T newInstance(Class<T> class_) {
        Object object;
        try {
            object = class_.newInstance();
        }
        catch (InstantiationException instantiationException) {
            throw Types.handleExceptionForNewInstance((Exception)((Object)instantiationException), class_);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw Types.handleExceptionForNewInstance((Exception)((Object)illegalAccessException), class_);
        }
        return (T)object;
    }

    public static Type resolveTypeVariable(List<Type> list, TypeVariable<?> typeVariable) {
        GenericDeclaration genericDeclaration = typeVariable.getGenericDeclaration();
        if (genericDeclaration instanceof Class) {
            Class class_ = (Class)genericDeclaration;
            int n = list.size();
            ParameterizedType parameterizedType = null;
            while (parameterizedType == null && --n >= 0) {
                parameterizedType = Types.getSuperParameterizedType((Type)list.get(n), class_);
            }
            if (parameterizedType != null) {
                Type type;
                int n2;
                TypeVariable[] arrtypeVariable = genericDeclaration.getTypeParameters();
                for (n2 = 0; n2 < arrtypeVariable.length && !arrtypeVariable[n2].equals(typeVariable); ++n2) {
                }
                Type type2 = parameterizedType.getActualTypeArguments()[n2];
                if (type2 instanceof TypeVariable && (type = Types.resolveTypeVariable(list, (TypeVariable)type2)) != null) {
                    return type;
                }
                return type2;
            }
        }
        return null;
    }

    public static Object toArray(Collection<?> collection, Class<?> class_) {
        if (class_.isPrimitive()) {
            Object object = Array.newInstance(class_, (int)collection.size());
            int n = 0;
            for (Object object2 : collection) {
                int n2 = n + 1;
                Array.set((Object)object, (int)n, (Object)object2);
                n = n2;
            }
            return object;
        }
        return collection.toArray((Object[])Array.newInstance(class_, (int)collection.size()));
    }

}

