/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Writer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.UUID
 */
package com.google.api.client.http;

import com.google.api.client.http.AbstractHttpContent;
import com.google.api.client.http.HttpContent;
import com.google.api.client.http.HttpEncoding;
import com.google.api.client.http.HttpEncodingStreamingContent;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpMediaType;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.StreamingContent;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.UUID;

public class MultipartContent
extends AbstractHttpContent {
    static final String NEWLINE = "\r\n";
    private static final String TWO_DASHES = "--";
    private ArrayList<Part> parts;

    public MultipartContent() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("__END_OF_PART__");
        stringBuilder.append(UUID.randomUUID().toString());
        stringBuilder.append("__");
        this(stringBuilder.toString());
    }

    public MultipartContent(String string2) {
        super(new HttpMediaType("multipart/related").setParameter("boundary", string2));
        this.parts = new ArrayList();
    }

    public MultipartContent addPart(Part part) {
        this.parts.add((Object)Preconditions.checkNotNull(part));
        return this;
    }

    public final String getBoundary() {
        return this.getMediaType().getParameter("boundary");
    }

    public final Collection<Part> getParts() {
        return Collections.unmodifiableCollection(this.parts);
    }

    @Override
    public boolean retrySupported() {
        Iterator iterator = this.parts.iterator();
        while (iterator.hasNext()) {
            if ((iterator.next()).content.retrySupported()) continue;
            return false;
        }
        return true;
    }

    public MultipartContent setBoundary(String string2) {
        this.getMediaType().setParameter("boundary", Preconditions.checkNotNull(string2));
        return this;
    }

    public MultipartContent setContentParts(Collection<? extends HttpContent> collection) {
        this.parts = new ArrayList(collection.size());
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            this.addPart(new Object((HttpContent)iterator.next()){
                HttpContent content;
                HttpEncoding encoding;
                HttpHeaders headers;
                {
                    this(null);
                }
                {
                    this(null, httpContent);
                }
                {
                    this.setHeaders(httpHeaders);
                    this.setContent(httpContent);
                }

                public HttpContent getContent() {
                    return this.content;
                }

                public HttpEncoding getEncoding() {
                    return this.encoding;
                }

                public HttpHeaders getHeaders() {
                    return this.headers;
                }

                public Part setContent(HttpContent httpContent) {
                    this.content = httpContent;
                    return this;
                }

                public Part setEncoding(HttpEncoding httpEncoding) {
                    this.encoding = httpEncoding;
                    return this;
                }

                public Part setHeaders(HttpHeaders httpHeaders) {
                    this.headers = httpHeaders;
                    return this;
                }
            });
        }
        return this;
    }

    @Override
    public MultipartContent setMediaType(HttpMediaType httpMediaType) {
        super.setMediaType(httpMediaType);
        return this;
    }

    public MultipartContent setParts(Collection<Part> collection) {
        this.parts = new ArrayList(collection);
        return this;
    }

    @Override
    public void writeTo(OutputStream outputStream) throws IOException {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, this.getCharset());
        String string2 = this.getBoundary();
        for (Part part : this.parts) {
            HttpHeaders httpHeaders = new HttpHeaders().setAcceptEncoding(null);
            if (part.headers != null) {
                httpHeaders.fromHttpHeaders(part.headers);
            }
            httpHeaders.setContentEncoding(null).setUserAgent(null).setContentType(null).setContentLength(null).set("Content-Transfer-Encoding", null);
            StreamingContent streamingContent = part.content;
            if (streamingContent != null) {
                long l;
                httpHeaders.set("Content-Transfer-Encoding", (Object)Arrays.asList((Object[])new String[]{"binary"}));
                httpHeaders.setContentType(streamingContent.getType());
                HttpEncoding httpEncoding = part.encoding;
                if (httpEncoding == null) {
                    l = streamingContent.getLength();
                } else {
                    httpHeaders.setContentEncoding(httpEncoding.getName());
                    HttpEncodingStreamingContent httpEncodingStreamingContent = new HttpEncodingStreamingContent(streamingContent, httpEncoding);
                    long l2 = AbstractHttpContent.computeLength(streamingContent);
                    streamingContent = httpEncodingStreamingContent;
                    l = l2;
                }
                if (l != -1L) {
                    httpHeaders.setContentLength(l);
                }
            } else {
                streamingContent = null;
            }
            outputStreamWriter.write(TWO_DASHES);
            outputStreamWriter.write(string2);
            outputStreamWriter.write(NEWLINE);
            HttpHeaders.serializeHeadersForMultipartRequests(httpHeaders, null, null, (Writer)outputStreamWriter);
            if (streamingContent != null) {
                outputStreamWriter.write(NEWLINE);
                outputStreamWriter.flush();
                streamingContent.writeTo(outputStream);
            }
            outputStreamWriter.write(NEWLINE);
        }
        outputStreamWriter.write(TWO_DASHES);
        outputStreamWriter.write(string2);
        outputStreamWriter.write(TWO_DASHES);
        outputStreamWriter.write(NEWLINE);
        outputStreamWriter.flush();
    }

}

