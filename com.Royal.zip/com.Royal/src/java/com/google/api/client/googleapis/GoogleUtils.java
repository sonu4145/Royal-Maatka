/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.security.GeneralSecurityException
 *  java.security.KeyStore
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.google.api.client.googleapis;

import com.google.api.client.util.SecurityUtils;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class GoogleUtils {
    public static final Integer BUGFIX_VERSION;
    public static final Integer MAJOR_VERSION;
    public static final Integer MINOR_VERSION;
    public static final String VERSION;
    static final Pattern VERSION_PATTERN;
    static KeyStore certTrustStore;

    static {
        Pattern pattern;
        VERSION = GoogleUtils.getVersion();
        VERSION_PATTERN = pattern = Pattern.compile((String)"(\\d+)\\.(\\d+)\\.(\\d+)(-SNAPSHOT)?");
        Matcher matcher = pattern.matcher((CharSequence)VERSION);
        matcher.find();
        MAJOR_VERSION = Integer.parseInt((String)matcher.group(1));
        MINOR_VERSION = Integer.parseInt((String)matcher.group(2));
        BUGFIX_VERSION = Integer.parseInt((String)matcher.group(3));
    }

    private GoogleUtils() {
    }

    public static KeyStore getCertificateTrustStore() throws IOException, GeneralSecurityException {
        Class<GoogleUtils> class_ = GoogleUtils.class;
        synchronized (GoogleUtils.class) {
            if (certTrustStore == null) {
                certTrustStore = SecurityUtils.getJavaKeyStore();
                InputStream inputStream = GoogleUtils.class.getResourceAsStream("google.jks");
                SecurityUtils.loadKeyStore(certTrustStore, inputStream, "notasecret");
            }
            KeyStore keyStore = certTrustStore;
            // ** MonitorExit[var3] (shouldn't be in output)
            return keyStore;
        }
    }

    /*
     * Exception decompiling
     */
    private static String getVersion() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl43.1 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }
}

