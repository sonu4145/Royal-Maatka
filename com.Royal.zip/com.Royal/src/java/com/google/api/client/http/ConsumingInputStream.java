/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.common.io.ByteStreams
 *  java.io.FilterInputStream
 *  java.io.IOException
 *  java.io.InputStream
 */
package com.google.api.client.http;

import com.google.common.io.ByteStreams;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

final class ConsumingInputStream
extends FilterInputStream {
    private boolean closed = false;

    ConsumingInputStream(InputStream inputStream) {
        super(inputStream);
    }

    public void close() throws IOException {
        if (!this.closed && this.in != null) {
            try {
                ByteStreams.exhaust((InputStream)this);
                this.in.close();
                return;
            }
            finally {
                this.closed = true;
            }
        }
    }
}

