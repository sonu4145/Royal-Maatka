/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  java.util.concurrent.locks.Lock
 *  java.util.concurrent.locks.ReentrantLock
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.google.api.client.util.store;

import com.google.api.client.util.Maps;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.store.DataStore;
import com.google.api.client.util.store.DataStoreFactory;
import java.io.IOException;
import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class AbstractDataStoreFactory
implements DataStoreFactory {
    private static final Pattern ID_PATTERN = Pattern.compile((String)"\\w{1,30}");
    private final Map<String, DataStore<? extends Serializable>> dataStoreMap = Maps.newHashMap();
    private final Lock lock = new ReentrantLock();

    protected abstract <V extends Serializable> DataStore<V> createDataStore(String var1) throws IOException;

    @Override
    public final <V extends Serializable> DataStore<V> getDataStore(String string2) throws IOException {
        DataStore<V> dataStore;
        block4 : {
            boolean bl = ID_PATTERN.matcher((CharSequence)string2).matches();
            Object[] arrobject = new Object[]{string2, ID_PATTERN};
            Preconditions.checkArgument(bl, "%s does not match pattern %s", arrobject);
            this.lock.lock();
            dataStore = (DataStore<V>)this.dataStoreMap.get((Object)string2);
            if (dataStore != null) break block4;
            dataStore = this.createDataStore(string2);
            this.dataStoreMap.put((Object)string2, dataStore);
        }
        return dataStore;
        finally {
            this.lock.unlock();
        }
    }
}

