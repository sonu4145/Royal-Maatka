/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.FilterInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.util.logging.Level
 *  java.util.logging.Logger
 */
package com.google.api.client.util;

import com.google.api.client.util.LoggingByteArrayOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggingInputStream
extends FilterInputStream {
    private final LoggingByteArrayOutputStream logStream;

    public LoggingInputStream(InputStream inputStream, Logger logger, Level level, int n) {
        super(inputStream);
        this.logStream = new LoggingByteArrayOutputStream(logger, level, n);
    }

    public void close() throws IOException {
        this.logStream.close();
        super.close();
    }

    public final LoggingByteArrayOutputStream getLogStream() {
        return this.logStream;
    }

    public int read() throws IOException {
        int n = super.read();
        this.logStream.write(n);
        return n;
    }

    public int read(byte[] arrby, int n, int n2) throws IOException {
        int n3 = super.read(arrby, n, n2);
        if (n3 > 0) {
            this.logStream.write(arrby, n, n3);
        }
        return n3;
    }
}

