/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$FontMetrics
 *  android.graphics.Path
 *  android.graphics.Path$FillType
 *  android.graphics.Point
 *  android.graphics.Typeface
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.Layout
 *  android.text.Layout$Alignment
 *  android.text.StaticLayout
 *  android.text.TextPaint
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.LayoutInflater
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.animation.Interpolator
 *  android.view.animation.LinearInterpolator
 *  android.widget.Adapter
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemSelectedListener
 *  android.widget.BaseAdapter
 *  android.widget.Spinner
 *  android.widget.SpinnerAdapter
 *  android.widget.TextView
 *  com.nineoldandroids.animation.ObjectAnimator
 *  com.nineoldandroids.animation.ValueAnimator
 *  com.nineoldandroids.animation.ValueAnimator$AnimatorUpdateListener
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package fr.ganfra.materialspinner;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Typeface;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.animation.ValueAnimator;
import fr.ganfra.materialspinner.MaterialSpinner;
import fr.ganfra.materialspinner.R;

public class MaterialSpinner
extends Spinner
implements ValueAnimator.AnimatorUpdateListener {
    public static final int DEFAULT_ARROW_WIDTH_DP = 12;
    private static final String TAG = MaterialSpinner.class.getSimpleName();
    private boolean alignLabels;
    private int arrowColor;
    private float arrowSize;
    private int baseAlpha;
    private int baseColor;
    private float currentNbErrorLines;
    private int disabledColor;
    private boolean enableErrorLabel;
    private boolean enableFloatingLabel;
    private CharSequence error;
    private int errorColor;
    private ObjectAnimator errorLabelAnimator;
    private int errorLabelPosX;
    private int errorLabelSpacing;
    private int extraPaddingBottom;
    private int extraPaddingTop;
    private ObjectAnimator floatingLabelAnimator;
    private int floatingLabelBottomSpacing;
    private int floatingLabelColor;
    private int floatingLabelInsideSpacing;
    private float floatingLabelPercent;
    private CharSequence floatingLabelText;
    private int floatingLabelTopSpacing;
    private boolean floatingLabelVisible;
    private int highlightColor;
    private CharSequence hint;
    private int hintColor;
    private int innerPaddingBottom;
    private int innerPaddingLeft;
    private int innerPaddingRight;
    private int innerPaddingTop;
    private boolean isSelected;
    private int lastPosition;
    private int minContentHeight;
    private int minNbErrorLines;
    private boolean multiline;
    private Paint paint;
    private int rightLeftSpinnerPadding;
    private Path selectorPath;
    private Point[] selectorPoints;
    private StaticLayout staticLayout;
    private TextPaint textPaint;
    private float thickness;
    private float thicknessError;
    private Typeface typeface;
    private int underlineBottomSpacing;
    private int underlineTopSpacing;

    public MaterialSpinner(Context context) {
        super(context);
        this.init(context, null);
    }

    public MaterialSpinner(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(context, attributeSet);
    }

    public MaterialSpinner(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(context, attributeSet);
    }

    static /* synthetic */ void access$001(MaterialSpinner materialSpinner, int n) {
        super.setSelection(n);
    }

    static /* synthetic */ CharSequence access$200(MaterialSpinner materialSpinner) {
        return materialSpinner.floatingLabelText;
    }

    static /* synthetic */ boolean access$300(MaterialSpinner materialSpinner) {
        return materialSpinner.floatingLabelVisible;
    }

    static /* synthetic */ void access$400(MaterialSpinner materialSpinner) {
        materialSpinner.showFloatingLabel();
    }

    static /* synthetic */ void access$500(MaterialSpinner materialSpinner) {
        materialSpinner.hideFloatingLabel();
    }

    static /* synthetic */ int access$600(MaterialSpinner materialSpinner) {
        return materialSpinner.lastPosition;
    }

    static /* synthetic */ int access$602(MaterialSpinner materialSpinner, int n) {
        materialSpinner.lastPosition = n;
        return n;
    }

    static /* synthetic */ CharSequence access$700(MaterialSpinner materialSpinner) {
        return materialSpinner.error;
    }

    private int dpToPx(float f) {
        return Math.round((float)TypedValue.applyDimension((int)1, (float)f, (DisplayMetrics)this.getContext().getResources().getDisplayMetrics()));
    }

    private void drawSelector(Canvas canvas, int n, int n2) {
        if (!this.isSelected && !this.hasFocus()) {
            Paint paint = this.paint;
            int n3 = this.isEnabled() ? this.arrowColor : this.disabledColor;
            paint.setColor(n3);
        } else {
            this.paint.setColor(this.highlightColor);
        }
        Point[] arrpoint = this.selectorPoints;
        Point point = arrpoint[0];
        Point point2 = arrpoint[1];
        Point point3 = arrpoint[2];
        point.set(n, n2);
        float f = n;
        point2.set((int)(f - this.arrowSize), n2);
        float f2 = this.arrowSize;
        point3.set((int)(f - f2 / 2.0f), (int)((float)n2 + f2 / 2.0f));
        this.selectorPath.reset();
        this.selectorPath.moveTo((float)point.x, (float)point.y);
        this.selectorPath.lineTo((float)point2.x, (float)point2.y);
        this.selectorPath.lineTo((float)point3.x, (float)point3.y);
        this.selectorPath.close();
        canvas.drawPath(this.selectorPath, this.paint);
    }

    private float getCurrentNbErrorLines() {
        return this.currentNbErrorLines;
    }

    private int getErrorLabelPosX() {
        return this.errorLabelPosX;
    }

    private float getFloatingLabelPercent() {
        return this.floatingLabelPercent;
    }

    private void hideFloatingLabel() {
        ObjectAnimator objectAnimator = this.floatingLabelAnimator;
        if (objectAnimator != null) {
            this.floatingLabelVisible = false;
            objectAnimator.reverse();
        }
    }

    private void init(Context context, AttributeSet attributeSet) {
        this.initAttributes(context, attributeSet);
        this.initPaintObjects();
        this.initDimensions();
        this.initPadding();
        this.initFloatingLabelAnimator();
        this.initOnItemSelectedListener();
        this.setMinimumHeight(this.getPaddingTop() + this.getPaddingBottom() + this.minContentHeight);
        this.setBackgroundResource(R.drawable.my_background);
    }

    private void initAttributes(Context context, AttributeSet attributeSet) {
        int[] arrn = new int[]{R.attr.colorControlNormal, R.attr.colorAccent};
        TypedArray typedArray = context.obtainStyledAttributes(arrn);
        int n = typedArray.getColor(0, 0);
        int n2 = typedArray.getColor(1, 0);
        int n3 = context.getResources().getColor(R.color.error_color);
        typedArray.recycle();
        TypedArray typedArray2 = context.obtainStyledAttributes(attributeSet, R.styleable.MaterialSpinner);
        this.baseColor = typedArray2.getColor(R.styleable.MaterialSpinner_ms_baseColor, n);
        this.highlightColor = typedArray2.getColor(R.styleable.MaterialSpinner_ms_highlightColor, n2);
        this.errorColor = typedArray2.getColor(R.styleable.MaterialSpinner_ms_errorColor, n3);
        this.disabledColor = context.getResources().getColor(R.color.disabled_color);
        this.error = typedArray2.getString(R.styleable.MaterialSpinner_ms_error);
        this.hint = typedArray2.getString(R.styleable.MaterialSpinner_ms_hint);
        this.hintColor = typedArray2.getColor(R.styleable.MaterialSpinner_ms_hintColor, this.baseColor);
        this.floatingLabelText = typedArray2.getString(R.styleable.MaterialSpinner_ms_floatingLabelText);
        this.floatingLabelColor = typedArray2.getColor(R.styleable.MaterialSpinner_ms_floatingLabelColor, this.baseColor);
        this.multiline = typedArray2.getBoolean(R.styleable.MaterialSpinner_ms_multiline, true);
        this.minNbErrorLines = typedArray2.getInt(R.styleable.MaterialSpinner_ms_nbErrorLines, 1);
        this.alignLabels = typedArray2.getBoolean(R.styleable.MaterialSpinner_ms_alignLabels, true);
        this.thickness = typedArray2.getDimension(R.styleable.MaterialSpinner_ms_thickness, 1.0f);
        this.thicknessError = typedArray2.getDimension(R.styleable.MaterialSpinner_ms_thickness_error, 2.0f);
        this.arrowColor = typedArray2.getColor(R.styleable.MaterialSpinner_ms_arrowColor, this.baseColor);
        this.arrowSize = typedArray2.getDimension(R.styleable.MaterialSpinner_ms_arrowSize, (float)this.dpToPx(12.0f));
        this.enableErrorLabel = typedArray2.getBoolean(R.styleable.MaterialSpinner_ms_enableErrorLabel, true);
        this.enableFloatingLabel = typedArray2.getBoolean(R.styleable.MaterialSpinner_ms_enableFloatingLabel, true);
        String string = typedArray2.getString(R.styleable.MaterialSpinner_ms_typeface);
        if (string != null) {
            this.typeface = Typeface.createFromAsset((AssetManager)this.getContext().getAssets(), (String)string);
        }
        typedArray2.recycle();
        this.floatingLabelPercent = 0.0f;
        this.errorLabelPosX = 0;
        this.isSelected = false;
        this.floatingLabelVisible = false;
        this.lastPosition = -1;
        this.currentNbErrorLines = this.minNbErrorLines;
    }

    private void initDimensions() {
        this.underlineTopSpacing = this.getResources().getDimensionPixelSize(R.dimen.underline_top_spacing);
        this.underlineBottomSpacing = this.getResources().getDimensionPixelSize(R.dimen.underline_bottom_spacing);
        this.floatingLabelTopSpacing = this.getResources().getDimensionPixelSize(R.dimen.floating_label_top_spacing);
        this.floatingLabelBottomSpacing = this.getResources().getDimensionPixelSize(R.dimen.floating_label_bottom_spacing);
        int n = this.alignLabels ? this.getResources().getDimensionPixelSize(R.dimen.right_left_spinner_padding) : 0;
        this.rightLeftSpinnerPadding = n;
        this.floatingLabelInsideSpacing = this.getResources().getDimensionPixelSize(R.dimen.floating_label_inside_spacing);
        this.errorLabelSpacing = (int)this.getResources().getDimension(R.dimen.error_label_spacing);
        this.minContentHeight = (int)this.getResources().getDimension(R.dimen.min_content_height);
    }

    private void initFloatingLabelAnimator() {
        if (this.floatingLabelAnimator == null) {
            ObjectAnimator objectAnimator;
            this.floatingLabelAnimator = objectAnimator = ObjectAnimator.ofFloat((Object)((Object)this), (String)"floatingLabelPercent", (float[])new float[]{0.0f, 1.0f});
            objectAnimator.addUpdateListener((ValueAnimator.AnimatorUpdateListener)this);
        }
    }

    private void initOnItemSelectedListener() {
        this.setOnItemSelectedListener(null);
    }

    private void initPadding() {
        this.innerPaddingTop = this.getPaddingTop();
        this.innerPaddingLeft = this.getPaddingLeft();
        this.innerPaddingRight = this.getPaddingRight();
        this.innerPaddingBottom = this.getPaddingBottom();
        int n = this.enableFloatingLabel ? this.floatingLabelTopSpacing + this.floatingLabelInsideSpacing + this.floatingLabelBottomSpacing : this.floatingLabelBottomSpacing;
        this.extraPaddingTop = n;
        this.updateBottomPadding();
    }

    private void initPaintObjects() {
        TextPaint textPaint;
        Path path;
        int n = this.getResources().getDimensionPixelSize(R.dimen.label_text_size);
        this.paint = new Paint(1);
        this.textPaint = textPaint = new TextPaint(1);
        textPaint.setTextSize((float)n);
        Typeface typeface = this.typeface;
        if (typeface != null) {
            this.textPaint.setTypeface(typeface);
        }
        this.textPaint.setColor(this.baseColor);
        this.baseAlpha = this.textPaint.getAlpha();
        this.selectorPath = path = new Path();
        path.setFillType(Path.FillType.EVEN_ODD);
        this.selectorPoints = new Point[3];
        for (int i = 0; i < 3; ++i) {
            this.selectorPoints[i] = new Point();
        }
    }

    private boolean isSpinnerEmpty() {
        int n = this.getAdapter().getCount();
        int n2 = 1;
        if (n != 0 || this.hint != null) {
            if (this.getAdapter().getCount() == n2 && this.hint != null) {
                return n2;
            }
            n2 = 0;
        }
        return n2;
    }

    private boolean needScrollingAnimation() {
        CharSequence charSequence = this.error;
        boolean bl = false;
        if (charSequence != null) {
            float f = this.getWidth() - this.rightLeftSpinnerPadding;
            float f2 = this.textPaint.measureText(this.error.toString(), 0, this.error.length()) FCMPL f;
            bl = false;
            if (f2 > 0) {
                bl = true;
            }
        }
        return bl;
    }

    private int prepareBottomPadding() {
        int n = this.minNbErrorLines;
        if (this.error != null) {
            StaticLayout staticLayout;
            this.staticLayout = staticLayout = new StaticLayout(this.error, this.textPaint, this.getWidth() - this.getPaddingRight() - this.getPaddingLeft(), Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            int n2 = staticLayout.getLineCount();
            n = Math.max((int)this.minNbErrorLines, (int)n2);
        }
        return n;
    }

    private float pxToDp(float f) {
        return f * this.getContext().getResources().getDisplayMetrics().density;
    }

    private void setCurrentNbErrorLines(float f) {
        this.currentNbErrorLines = f;
        this.updateBottomPadding();
    }

    private void setErrorLabelPosX(int n) {
        this.errorLabelPosX = n;
    }

    private void setFloatingLabelPercent(float f) {
        this.floatingLabelPercent = f;
    }

    private void showFloatingLabel() {
        ObjectAnimator objectAnimator = this.floatingLabelAnimator;
        if (objectAnimator != null) {
            this.floatingLabelVisible = true;
            if (objectAnimator.isRunning()) {
                this.floatingLabelAnimator.reverse();
                return;
            }
            this.floatingLabelAnimator.start();
        }
    }

    private void startErrorMultilineAnimator(float f) {
        ObjectAnimator objectAnimator = this.errorLabelAnimator;
        if (objectAnimator == null) {
            this.errorLabelAnimator = ObjectAnimator.ofFloat((Object)((Object)this), (String)"currentNbErrorLines", (float[])new float[]{f});
        } else {
            objectAnimator.setFloatValues(new float[]{f});
        }
        this.errorLabelAnimator.start();
    }

    private void startErrorScrollingAnimator() {
        int n = Math.round((float)this.textPaint.measureText(this.error.toString()));
        ObjectAnimator objectAnimator = this.errorLabelAnimator;
        if (objectAnimator == null) {
            ObjectAnimator objectAnimator2;
            int[] arrn = new int[]{0, n + this.getWidth() / 2};
            this.errorLabelAnimator = objectAnimator2 = ObjectAnimator.ofInt((Object)((Object)this), (String)"errorLabelPosX", (int[])arrn);
            objectAnimator2.setStartDelay(1000L);
            this.errorLabelAnimator.setInterpolator((Interpolator)new LinearInterpolator());
            this.errorLabelAnimator.setDuration((long)(150 * this.error.length()));
            this.errorLabelAnimator.addUpdateListener((ValueAnimator.AnimatorUpdateListener)this);
            this.errorLabelAnimator.setRepeatCount(-1);
        } else {
            int[] arrn = new int[]{0, n + this.getWidth() / 2};
            objectAnimator.setIntValues(arrn);
        }
        this.errorLabelAnimator.start();
    }

    private void updateBottomPadding() {
        int n;
        Paint.FontMetrics fontMetrics = this.textPaint.getFontMetrics();
        this.extraPaddingBottom = n = this.underlineTopSpacing + this.underlineBottomSpacing;
        if (this.enableErrorLabel) {
            this.extraPaddingBottom = n + (int)((fontMetrics.descent - fontMetrics.ascent) * this.currentNbErrorLines);
        }
        this.updatePadding();
    }

    private void updatePadding() {
        int n = this.innerPaddingLeft;
        int n2 = this.innerPaddingTop + this.extraPaddingTop;
        int n3 = this.innerPaddingRight;
        int n4 = this.innerPaddingBottom + this.extraPaddingBottom;
        super.setPadding(n, n2, n3, n4);
        this.setMinimumHeight(n2 + n4 + this.minContentHeight);
    }

    public int getBaseColor() {
        return this.baseColor;
    }

    public CharSequence getError() {
        return this.error;
    }

    public int getErrorColor() {
        return this.errorColor;
    }

    public CharSequence getFloatingLabelText() {
        return this.floatingLabelText;
    }

    public int getHighlightColor() {
        return this.highlightColor;
    }

    public CharSequence getHint() {
        return this.hint;
    }

    public int getHintColor() {
        return this.hintColor;
    }

    public Object getItemAtPosition(int n) {
        SpinnerAdapter spinnerAdapter = this.getAdapter();
        if (this.hint != null) {
            ++n;
        }
        if (spinnerAdapter != null && n >= 0) {
            return spinnerAdapter.getItem(n);
        }
        return null;
    }

    public long getItemIdAtPosition(int n) {
        SpinnerAdapter spinnerAdapter = this.getAdapter();
        if (this.hint != null) {
            ++n;
        }
        if (spinnerAdapter != null && n >= 0) {
            return spinnerAdapter.getItemId(n);
        }
        return Long.MIN_VALUE;
    }

    public int getSelectedItemPosition() {
        return super.getSelectedItemPosition();
    }

    public void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.invalidate();
    }

    protected void onDraw(Canvas canvas) {
        int n;
        super.onDraw(canvas);
        int n2 = this.getWidth();
        int n3 = this.getHeight() - this.getPaddingBottom() + this.underlineTopSpacing;
        int n4 = (int)((float)this.getPaddingTop() - this.floatingLabelPercent * (float)this.floatingLabelBottomSpacing);
        if (this.error != null && this.enableErrorLabel) {
            n = this.dpToPx(this.thicknessError);
            int n5 = n + (n3 + this.errorLabelSpacing);
            this.paint.setColor(this.errorColor);
            this.textPaint.setColor(this.errorColor);
            if (this.multiline) {
                canvas.save();
                canvas.translate((float)(0 + this.rightLeftSpinnerPadding), (float)(n5 - this.errorLabelSpacing));
                this.staticLayout.draw(canvas);
                canvas.restore();
            } else {
                String string = this.error.toString();
                float f = 0 + this.rightLeftSpinnerPadding - this.errorLabelPosX;
                float f2 = n5;
                canvas.drawText(string, f, f2, (Paint)this.textPaint);
                if (this.errorLabelPosX > 0) {
                    canvas.save();
                    canvas.translate(this.textPaint.measureText(this.error.toString()) + (float)(this.getWidth() / 2), 0.0f);
                    canvas.drawText(this.error.toString(), (float)(0 + this.rightLeftSpinnerPadding - this.errorLabelPosX), f2, (Paint)this.textPaint);
                    canvas.restore();
                }
            }
        } else {
            n = this.dpToPx(this.thickness);
            if (!this.isSelected && !this.hasFocus()) {
                Paint paint = this.paint;
                int n6 = this.isEnabled() ? this.baseColor : this.disabledColor;
                paint.setColor(n6);
            } else {
                this.paint.setColor(this.highlightColor);
            }
        }
        canvas.drawRect((float)false, (float)n3, (float)n2, (float)(n3 + n), this.paint);
        if ((this.hint != null || this.floatingLabelText != null) && this.enableFloatingLabel) {
            CharSequence charSequence;
            if (!this.isSelected && !this.hasFocus()) {
                TextPaint textPaint = this.textPaint;
                int n7 = this.isEnabled() ? this.floatingLabelColor : this.disabledColor;
                textPaint.setColor(n7);
            } else {
                this.textPaint.setColor(this.highlightColor);
            }
            if (this.floatingLabelAnimator.isRunning() || !this.floatingLabelVisible) {
                TextPaint textPaint = this.textPaint;
                float f = this.floatingLabelPercent;
                double d = f;
                Double.isNaN((double)d);
                double d2 = 0.2 + d * 0.8;
                double d3 = this.baseAlpha;
                Double.isNaN((double)d3);
                double d4 = d2 * d3;
                double d5 = f;
                Double.isNaN((double)d5);
                textPaint.setAlpha((int)(d4 * d5));
            }
            if ((charSequence = this.floatingLabelText) == null) {
                charSequence = this.hint;
            }
            canvas.drawText(charSequence.toString(), (float)(0 + this.rightLeftSpinnerPadding), (float)n4, (Paint)this.textPaint);
        }
        this.drawSelector(canvas, this.getWidth() - this.rightLeftSpinnerPadding, this.getPaddingTop() + this.dpToPx(8.0f));
    }

    protected void onMeasure(int n, int n2) {
        super.onMeasure(n, n2);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.isEnabled()) {
            int n = motionEvent.getAction();
            if (n != 0) {
                if (n == 1 || n == 3) {
                    this.isSelected = false;
                }
            } else {
                this.isSelected = true;
            }
            this.invalidate();
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        super.setAdapter((SpinnerAdapter)new BaseAdapter(spinnerAdapter, this.getContext()){
            private static final int HINT_TYPE = -1;
            private Context mContext;
            private SpinnerAdapter mSpinnerAdapter;
            {
                this.mSpinnerAdapter = spinnerAdapter;
                this.mContext = context;
            }

            private View buildView(int n, View view, ViewGroup viewGroup, boolean bl) {
                if (this.getItemViewType(n) == -1) {
                    return this.getHintView(view, viewGroup, bl);
                }
                if (!(view == null || view.getTag() != null && view.getTag() instanceof Integer && (Integer)view.getTag() != -1)) {
                    view = null;
                }
                if (MaterialSpinner.this.hint != null) {
                    --n;
                }
                if (bl) {
                    return this.mSpinnerAdapter.getDropDownView(n, view, viewGroup);
                }
                return this.mSpinnerAdapter.getView(n, view, viewGroup);
            }

            private View getHintView(View view, ViewGroup viewGroup, boolean bl) {
                LayoutInflater layoutInflater = LayoutInflater.from((Context)this.mContext);
                int n = bl ? 17367049 : 17367048;
                TextView textView = (TextView)layoutInflater.inflate(n, viewGroup, false);
                textView.setText(MaterialSpinner.this.hint);
                int n2 = MaterialSpinner.this.isEnabled() ? MaterialSpinner.this.hintColor : MaterialSpinner.this.disabledColor;
                textView.setTextColor(n2);
                textView.setTag((Object)-1);
                return textView;
            }

            public int getCount() {
                int n = this.mSpinnerAdapter.getCount();
                if (MaterialSpinner.this.hint != null) {
                    ++n;
                }
                return n;
            }

            public View getDropDownView(int n, View view, ViewGroup viewGroup) {
                return this.buildView(n, view, viewGroup, true);
            }

            public Object getItem(int n) {
                if (MaterialSpinner.this.hint != null) {
                    --n;
                }
                if (n == -1) {
                    return MaterialSpinner.this.hint;
                }
                return this.mSpinnerAdapter.getItem(n);
            }

            public long getItemId(int n) {
                if (MaterialSpinner.this.hint != null) {
                    --n;
                }
                if (n == -1) {
                    return 0L;
                }
                return this.mSpinnerAdapter.getItemId(n);
            }

            public int getItemViewType(int n) {
                if (MaterialSpinner.this.hint != null) {
                    --n;
                }
                if (n == -1) {
                    return -1;
                }
                return this.mSpinnerAdapter.getItemViewType(n);
            }

            public View getView(int n, View view, ViewGroup viewGroup) {
                return this.buildView(n, view, viewGroup, false);
            }

            public int getViewTypeCount() {
                if (Build.VERSION.SDK_INT >= 21) {
                    return 1;
                }
                return this.mSpinnerAdapter.getViewTypeCount();
            }
        });
    }

    public void setBaseColor(int n) {
        this.baseColor = n;
        this.textPaint.setColor(n);
        this.baseAlpha = this.textPaint.getAlpha();
        this.invalidate();
    }

    public void setEnabled(boolean bl) {
        if (!bl) {
            this.isSelected = false;
            this.invalidate();
        }
        super.setEnabled(bl);
    }

    public void setError(int n) {
        this.setError(this.getResources().getString(n));
    }

    public void setError(CharSequence charSequence) {
        this.error = charSequence;
        ObjectAnimator objectAnimator = this.errorLabelAnimator;
        if (objectAnimator != null) {
            objectAnimator.end();
        }
        if (this.multiline) {
            this.startErrorMultilineAnimator(this.prepareBottomPadding());
        } else if (this.needScrollingAnimation()) {
            this.startErrorScrollingAnimator();
        }
        this.requestLayout();
    }

    public void setErrorColor(int n) {
        this.errorColor = n;
        this.invalidate();
    }

    public void setFloatingLabelText(int n) {
        this.setFloatingLabelText(this.getResources().getString(n));
    }

    public void setFloatingLabelText(CharSequence charSequence) {
        this.floatingLabelText = charSequence;
        this.invalidate();
    }

    public void setHighlightColor(int n) {
        this.highlightColor = n;
        this.invalidate();
    }

    public void setHint(int n) {
        this.setHint(this.getResources().getString(n));
    }

    public void setHint(CharSequence charSequence) {
        this.hint = charSequence;
        this.invalidate();
    }

    public void setHintColor(int n) {
        this.hintColor = n;
        this.invalidate();
    }

    public void setOnItemSelectedListener(AdapterView.OnItemSelectedListener onItemSelectedListener) {
        super.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(this, onItemSelectedListener){
            final /* synthetic */ MaterialSpinner this$0;
            final /* synthetic */ AdapterView.OnItemSelectedListener val$listener;
            {
                this.this$0 = materialSpinner;
                this.val$listener = onItemSelectedListener;
            }

            public void onItemSelected(AdapterView<?> adapterView, View view, int n, long l) {
                if (MaterialSpinner.access$100(this.this$0) != null || MaterialSpinner.access$200(this.this$0) != null) {
                    if (!MaterialSpinner.access$300(this.this$0) && n != 0) {
                        MaterialSpinner.access$400(this.this$0);
                    } else if (MaterialSpinner.access$300(this.this$0) && n == 0) {
                        MaterialSpinner.access$500(this.this$0);
                    }
                }
                if (n != MaterialSpinner.access$600(this.this$0) && MaterialSpinner.access$700(this.this$0) != null) {
                    this.this$0.setError(null);
                }
                MaterialSpinner.access$602(this.this$0, n);
                if (this.val$listener != null) {
                    if (MaterialSpinner.access$100(this.this$0) != null) {
                        --n;
                    }
                    int n2 = n;
                    this.val$listener.onItemSelected(adapterView, view, n2, l);
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
                AdapterView.OnItemSelectedListener onItemSelectedListener = this.val$listener;
                if (onItemSelectedListener != null) {
                    onItemSelectedListener.onNothingSelected(adapterView);
                }
            }
        });
    }

    @Deprecated
    public void setPadding(int n, int n2, int n3, int n4) {
        super.setPadding(n, n2, n3, n4);
    }

    public void setPaddingSafe(int n, int n2, int n3, int n4) {
        this.innerPaddingRight = n3;
        this.innerPaddingLeft = n;
        this.innerPaddingTop = n2;
        this.innerPaddingBottom = n4;
        this.updatePadding();
    }

    public void setSelection(int n) {
        this.post(new Runnable(this, n){
            final /* synthetic */ MaterialSpinner this$0;
            final /* synthetic */ int val$position;
            {
                this.this$0 = materialSpinner;
                this.val$position = n;
            }

            public void run() {
                MaterialSpinner.access$001(this.this$0, this.val$position);
            }
        });
    }

}

